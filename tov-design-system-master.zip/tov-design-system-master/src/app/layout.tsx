import type { Metadata } from "next";
import { Montserrat, Geist_Mono } from "next/font/google";
import localFont from "next/font/local";
import { AppFrame } from "@/components/docs/AppFrame";
import "./globals.css";

const montserrat = Montserrat({
  variable: "--font-montserrat",
  subsets: ["latin"],
});

// The real "GT Ultra Fine Trial" headline face — pulled directly from
// tovfurniture.com's own CDN (it's already public: anyone visiting the
// live site downloads this exact file to render the page), not a
// placeholder. Regular weight only; that's what's actually served live and
// matches the Typography Export Sheet's "GT Ultra Fine Trial Regular".
const gtUltraFine = localFont({
  src: "../../public/fonts/GT-Ultra-Fine-Regular.woff2",
  variable: "--font-display",
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "TOV Design System",
  description: "TOV Furniture's component and imagery source of truth.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${montserrat.variable} ${gtUltraFine.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full bg-white text-ink">
        <AppFrame>{children}</AppFrame>
      </body>
    </html>
  );
}
