import { DocPage, DocSection } from "@/components/docs/DocPage";
import { PropsTable } from "@/components/docs/Preview";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { Badge } from "@/components/ui/Badge";
import { Input, SearchField, Select, Textarea } from "@/components/ui/FormFields";

const Updated = <Badge variant="new">Updated</Badge>;

type StateKey = "default" | "focus" | "filled" | "error" | "disabled";

const STATES: { key: StateKey; label: string; note: string }[] = [
  { key: "default", label: "Default", note: "Placeholder in #BBBBBB" },
  { key: "focus", label: "Focus", note: "Border turns Bold lip #713A40" },
  { key: "filled", label: "Filled", note: "Entered text in #3F3D3E" },
  { key: "error", label: "Error", note: "Sale-color border and message" },
  { key: "disabled", label: "Disabled", note: "50% opacity" },
];

const ALL: StateKey[] = ["default", "focus", "filled", "error", "disabled"];

/** Focus is forced here so the state can be seen without clicking into the field. */
const FOCUS = "!border-bold-lip";

const HELPER = "Use the date on your delivery receipt.";
const DETAILS_HELPER = "Include the part name or number if a part is missing.";
const SELECT_HELPER = "Where the item was delivered.";

function SelectOptions() {
  return (
    <>
      <option value="" disabled>
        Choose a country
      </option>
      <option>United States</option>
      <option>Canada</option>
    </>
  );
}

interface FieldDef {
  name: string;
  /** Height of the control at every viewport, for the caption under the name. */
  size: string;
  states: StateKey[];
  render: (state: StateKey) => React.ReactNode;
}

const FIELDS: FieldDef[] = [
  {
    name: "Input",
    size: "54px tall",
    states: ALL,
    render: (s) =>
      s === "default" ? (
        <Input label="Delivery Date" required placeholder="MM/DD/YYYY" helper={HELPER} />
      ) : s === "focus" ? (
        <Input label="Delivery Date" required placeholder="MM/DD/YYYY" helper={HELPER} className={FOCUS} />
      ) : s === "filled" ? (
        <Input label="Delivery Date" required defaultValue="10/21/2026" helper={HELPER} />
      ) : s === "error" ? (
        <Input label="Delivery Date" required defaultValue="10/21" error="Enter the full date, for example 10/21/2026" />
      ) : (
        <Input label="Delivery Date" required placeholder="MM/DD/YYYY" helper={HELPER} disabled />
      ),
  },
  {
    name: "Select",
    size: "54px tall",
    states: ALL,
    render: (s) =>
      s === "default" ? (
        <Select label="Ships to" required defaultValue="" helper={SELECT_HELPER}>
          <SelectOptions />
        </Select>
      ) : s === "focus" ? (
        <Select label="Ships to" required defaultValue="" helper={SELECT_HELPER} className={FOCUS}>
          <SelectOptions />
        </Select>
      ) : s === "filled" ? (
        <Select label="Ships to" required defaultValue="United States" helper={SELECT_HELPER}>
          <SelectOptions />
        </Select>
      ) : s === "error" ? (
        <Select label="Ships to" required defaultValue="" error="Choose where the item was delivered">
          <SelectOptions />
        </Select>
      ) : (
        <Select label="Ships to" required defaultValue="" helper={SELECT_HELPER} disabled>
          <SelectOptions />
        </Select>
      ),
  },
  {
    name: "Textarea",
    size: "118px minimum height",
    states: ALL,
    render: (s) =>
      s === "default" ? (
        <Textarea label="Additional details" placeholder="Enter your message here..." helper={DETAILS_HELPER} />
      ) : s === "focus" ? (
        <Textarea label="Additional details" placeholder="Enter your message here..." helper={DETAILS_HELPER} className={FOCUS} />
      ) : s === "filled" ? (
        <Textarea label="Additional details" defaultValue="The left leg arrived cracked." helper={DETAILS_HELPER} />
      ) : s === "error" ? (
        <Textarea label="Additional details" error="Tell us what happened so we can help" />
      ) : (
        <Textarea label="Additional details" placeholder="Enter your message here..." helper={DETAILS_HELPER} disabled />
      ),
  },
  {
    name: "Search field",
    size: "36px tall pill, no label",
    states: ["default", "filled"],
    render: (s) => (s === "default" ? <SearchField placeholder="Search SKU" /> : <SearchField defaultValue="TOV-L68923" />),
  },
];

function Spec({ rows }: { rows: string[][] }) {
  return (
    <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
      <table className="w-full text-sm">
        <tbody>
          {rows.map((r, i) => (
            <tr key={r[0]} className={`align-top ${i > 0 ? "border-t border-neutral-200" : ""}`}>
              {r.map((c, j) => (
                <td key={j} className={`px-4 py-2.5 ${j === 0 ? "whitespace-nowrap font-semibold text-ink" : "text-ink-muted"}`}>
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Every state of one field side by side at the real pixel width; the row scrolls sideways when it is wider than the page. */
function FieldStates({ field, width }: { field: FieldDef; width: number }) {
  return (
    <div className="mt-6">
      <p className="mb-2 text-sm font-semibold text-ink">
        {field.name} <span className="font-normal text-ink-muted">· {width}px wide · {field.size}</span>
      </p>
      <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-cream-100">
        <div className="flex w-max gap-6 p-6">
          {STATES.filter((s) => field.states.includes(s.key)).map((s) => (
            <div key={s.key} style={{ width }}>
              <p className="font-sans text-xs font-semibold text-ink">{s.label}</p>
              <p className="mb-3 font-sans text-[11px] leading-[14px] text-ink-muted">{s.note}</p>
              {field.render(s.key)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Note({ children }: { children: React.ReactNode }) {
  return <p className="mb-3 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

export default function FormFieldsPage() {
  return (
    <DocPage
      title="Input & Select"
      description="The entry fields used in forms such as the claims flow. The specs come first, then every field with all of its states, once for Desktop and once for Mobile."
    >
      <DocSection title={<>Specs {Updated}</>}>
        <Note>
          A label, a soft-filled rounded field and a line of helper or error text. Height, shape and type are the same at
          both viewports; only the field width changes, because the card around it does.
        </Note>
        <Spec
          rows={[
            ["Label", "16/19 Regular, #3F3D3E, 10px above the field. A required field ends its label with *"],
            ["Field", "16px radius, #F6F6F6 fill, 1px #E8E8E8 border, 10px padding on the left"],
            ["Entered text", "14/16 Regular, #3F3D3E"],
            ["Placeholder", "14/16 Regular, #BBBBBB. An example of the format, never the label itself"],
            ["Helper text", "10/12 Regular, #BBBBBB, 10px under the field. An error message replaces it"],
            ["Error message", "12/14 Regular in the sale color, 10px under the field"],
            ["Input and Select", "54px tall. With a label and helper line the Input is 105px tall in total (19 + 10 + 54 + 10 + 12)"],
            ["Textarea", "118px minimum height, 18px top and bottom padding, resizes vertically"],
            ["Search field", "36px tall pill, 18px icon in a 36px square, 12/14 text"],
          ]}
        />
        <p className="mb-2 mt-6 text-sm font-semibold text-ink">Width by viewport</p>
        <Spec
          rows={[
            ["Desktop · 1440px page", "460px field, inside a 500px card"],
            ["Mobile · 375px page", "295px field, inside a 335px card"],
          ]}
        />
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Figma has no Tablet form frame, so there is no Tablet section. Each field fills its container. The rows below are
          drawn at real size and scroll sideways when they are wider than the page.
        </p>
      </DocSection>

      <DocSection title={<>Desktop · 460px fields {Updated}</>}>
        <Note>The form on a 1440px page. Input, Select and Textarea each show all five states. Figma has no Desktop search field.</Note>
        {FIELDS.filter((f) => f.name !== "Search field").map((f) => (
          <FieldStates key={f.name} field={f} width={460} />
        ))}
      </DocSection>

      <DocSection title={<>Mobile · 295px fields {Updated}</>}>
        <Note>The form on a 375px page. Search is Mobile only and has a Default and a Filled state.</Note>
        {FIELDS.map((f) => (
          <FieldStates key={f.name} field={f} width={295} />
        ))}
      </DocSection>

      <DocSection title="Code">
        <pre className="overflow-x-auto rounded-app-lg bg-ink px-4 py-3 font-mono text-xs leading-5 text-white">{`<Input label="Delivery Date" required placeholder="MM/DD/YYYY" helper="Use the date on your delivery receipt." />
<Input label="Delivery Date" required error="Enter the full date, for example 10/21/2026" />
<Select label="Ships to" required defaultValue="">
  <option value="" disabled>Choose a country</option>
  <option>United States</option>
</Select>
<Textarea label="Additional details" placeholder="Enter your message here..." helper="Include the part name or number if a part is missing." />
<SearchField placeholder="Search SKU" />`}</pre>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "label", type: "string", description: "Field label above the control (Input, Textarea, Select)" },
            { name: "required", type: "boolean", default: "false", description: "Adds * to the label and the native required attribute" },
            { name: "helper", type: "string", description: "Guidance under the field. Replaced by the error message when there is one" },
            { name: "error", type: "string", description: "Error message; also switches the border to the sale color" },
            { name: "...rest", type: "native input / select / textarea props", description: "Any native prop is passed to the control" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="form-fields" />
    </DocPage>
  );
}
