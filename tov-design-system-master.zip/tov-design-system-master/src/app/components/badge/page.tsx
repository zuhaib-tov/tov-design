import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { BADGE_SIZES, BADGE_TYPES, badgeCss, type BadgeSizeSpec } from "@/lib/badgeSpec";

const Updated = <Badge variant="new">Updated</Badge>;

function Note({ children }: { children: React.ReactNode }) {
  return <p className="mb-4 max-w-2xl text-sm text-ink-muted">{children}</p>;
}

const px = (n: number) => `${n}px`;

/**
 * A badge drawn at actual size, one CSS pixel per pixel, so a Medium badge on
 * this page is 27px tall, exactly as it is on the site. The height sits on the
 * right and the side padding below; top and bottom padding are in the line under.
 */
function Anatomy({ size }: { size: BadgeSizeSpec }) {
  const guide = "font-mono text-[11px] leading-none text-primary-dark";
  return (
    <div className="flex flex-col items-start gap-2">
      <div className="flex items-center gap-3">
        <Badge variant="best-seller" size={size.key}>
          Best Seller
        </Badge>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 border-y border-r border-primary-dark" style={{ height: size.height }} />
          <span className={guide}>{size.height}</span>
        </div>
      </div>
      <div className="flex items-start" style={{ width: size.padX }}>
        <div className="flex w-full flex-col items-center gap-1">
          <div className="h-1.5 w-full border-x border-b border-primary-dark" />
          <span className={guide}>{size.padX}</span>
        </div>
      </div>
      <p className="font-mono text-xs text-ink-muted">
        {`${size.name} · ${size.height}px tall · ${size.padY}px top and bottom, ${size.padX}px left and right · label ${size.font}/${size.line} · actual size`}
      </p>
    </div>
  );
}

const SHARED: [string, string][] = [
  ["Typeface", "Montserrat Bold"],
  ["Case", "All caps. Write the label in sentence case; the component sets uppercase"],
  ["Letter-spacing", "+4.5%, the system rule for all-caps text. Figma sets 2%"],
  ["Shape", "Fully rounded pill, 999px radius, no border"],
  ["Width", "Set by the label. A badge hugs its text"],
  ["Text color", "#3F3D3E on the pink and gold badges, white on the others"],
];

export default function BadgePage() {
  return (
    <DocPage
      title="Badge"
      description="Product tags in 9 types and 2 sizes: Medium on Desktop and Small on Mobile. All measurements are written the way they are coded, in pixels."
    >
      <DocSection title={<>Anatomy and padding {Updated}</>}>
        <Note>
          A badge is a label with padding around it. Height is the top padding, the line height and the bottom padding added
          together, so each size has one fixed height. The label is Montserrat Bold, uppercase, with +4.5% letter-spacing, and
          the radius is 999px.
        </Note>
        <div className="mb-4 flex flex-col gap-8 overflow-x-auto rounded-app-lg border border-neutral-200 bg-cream-100 p-6">
          <p className="max-w-2xl text-xs text-ink-muted">
            Drawn at actual size. The number on the right is the height, and the bracket under each badge is the left and
            right padding on one side.
          </p>
          {BADGE_SIZES.map((s) => (
            <Anatomy key={s.key} size={s} />
          ))}
        </div>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Size</th>
                <th className="px-4 py-2 font-semibold">Screen</th>
                <th className="px-4 py-2 font-semibold">Height</th>
                <th className="px-4 py-2 font-semibold">Padding top / bottom</th>
                <th className="px-4 py-2 font-semibold">Padding left / right</th>
                <th className="px-4 py-2 font-semibold">Font / line</th>
                <th className="px-4 py-2 font-semibold">Flame / gap</th>
              </tr>
            </thead>
            <tbody>
              {BADGE_SIZES.map((s) => (
                <tr key={s.key} className="border-t border-neutral-200 align-top">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">
                    {s.name} <span className="font-mono text-xs font-normal text-ink-muted">size=&quot;{s.key}&quot;</span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-ink-muted">{s.screen}</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{px(s.height)}</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{px(s.padY)}</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{px(s.padX)}</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">
                    {s.font} / {s.line}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">
                    {s.flame} / {s.flameGap}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Height check: Medium 6 + 15 + 6 = 27, Small 4 + 11 + 4 = 19. The flame belongs to Hot List only; the gap is the
          space between the flame and the label. The live site draws badges about 23 to 28px tall on Desktop and 17px on
          Mobile, which is these two sizes. The 45px Large badge in Figma is archived below. Figma draws Limited Edition Small at 7px; the code uses 10px and 8px for every type.
        </p>
      </DocSection>

      <DocSection title={<>Sizes {Updated}</>}>
        <Preview
          code={`<Badge variant="best-seller" size="md">Best Seller</Badge>
<Badge variant="best-seller" size="sm">Best Seller</Badge>`}
        >
          <Badge variant="best-seller" size="md">Best Seller</Badge>
          <Badge variant="best-seller" size="sm">Best Seller</Badge>
        </Preview>
      </DocSection>

      <DocSection title={<>By screen {Updated}</>}>
        <Note>
          Desktop uses Medium and Mobile uses Small. Each size keeps the same padding and type on every badge type.
        </Note>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {(["Desktop", "Mobile"] as const).map((screen) => (
            <div key={screen} className="rounded-app-lg border border-neutral-200 bg-white p-4 shadow-sm">
              <p className="text-sm font-semibold text-ink">{screen}</p>
              <div className="mt-3 flex flex-col gap-3">
                {BADGE_SIZES.filter((s) => s.screen === screen).map((s) => (
                  <div key={s.key} className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="font-display text-2xl text-primary-dark">{s.name}</p>
                      <p className="font-mono text-xs text-ink-muted">
                        {px(s.height)} tall · {s.padY} / {s.padX} padding · {s.font}px
                      </p>
                    </div>
                    <Badge variant="best-seller" size={s.key}>
                      Best Seller
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title={<>Badge types {Updated}</>}>
        <Note>Nine types. Every type is available in every size; only the colors change.</Note>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Type</th>
                <th className="px-4 py-2 font-semibold">Medium</th>
                <th className="px-4 py-2 font-semibold">Small</th>
                <th className="px-4 py-2 font-semibold">Fill</th>
                <th className="px-4 py-2 font-semibold">Text</th>
              </tr>
            </thead>
            <tbody>
              {BADGE_TYPES.map((t) => (
                <tr key={t.variant} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-3 align-middle font-semibold text-ink">
                    {t.name}
                    <div className="font-mono text-[11px] font-normal text-ink-muted">variant=&quot;{t.variant}&quot;</div>
                  </td>
                  {BADGE_SIZES.map((s) => (
                    <td key={s.key} className="px-4 py-3 align-middle">
                      <Badge variant={t.variant} size={s.key}>
                        {t.label}
                      </Badge>
                    </td>
                  ))}
                  <td className="whitespace-nowrap px-4 py-3 align-middle font-mono text-xs text-ink-muted">{t.fill}</td>
                  <td className="whitespace-nowrap px-4 py-3 align-middle font-mono text-xs text-ink-muted">{t.text}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          The two Sale badges are named the same in Figma, so the code tells them apart by color: mauve and lagoon green.
        </p>
      </DocSection>

      <DocSection title={<>Shared by every badge</>}>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {SHARED.map(([k, v], i) => (
                <tr key={k} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-2.5 align-top font-semibold text-ink">{k}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title="Archived: Large (45px)">
        <p className="mb-3 max-w-2xl text-sm text-ink-muted">
          Figma also draws a Large badge, used as the Desktop gallery tag in the PDP file. It looks like a reference design:
          the live site never shows a badge that tall, so it is not in the system and the component has no Large size. The
          measurements are kept here in case it comes back.
        </p>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {[
                ["Height", "45px (10 + 25 + 10)"],
                ["Font / line", "17px Bold / 25px (18px on Hot List and Limited Edition)"],
                ["Padding", "10px top and bottom, 16.67px left and right"],
                ["Flame (Hot List)", "20px, 4px gap"],
                ["Figma source", "Buttons, Badges page, Tags frame, size Large (OG file); PDP file Desktop Gallery"],
              ].map(([k, v], i) => (
                <tr key={k} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-2.5 align-top font-semibold text-ink">{k}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title="App-chrome indicators (not a real product badge)">
        <Preview
          code={`<Badge variant="sale">Sale</Badge>
<Badge variant="new">New</Badge>
<Badge variant="success">In stock</Badge>
<Badge variant="neutral">Backordered</Badge>`}
        >
          <Badge variant="sale">Sale</Badge>
          <Badge variant="new">New</Badge>
          <Badge variant="success">In stock</Badge>
          <Badge variant="neutral">Backordered</Badge>
        </Preview>
        <p className="mt-3 text-xs text-ink-muted">
          These 4 power this docs site&apos;s own UI, such as the &ldquo;Updated&rdquo; indicator, and are not TOV product badges.
        </p>
      </DocSection>

      <DocSection title={<>CSS reference {Updated}</>}>
        <Note>Each size written as plain CSS, for use outside the component library. Colors come from the table above.</Note>
        <pre className="overflow-x-auto rounded-app-lg bg-ink px-4 py-3 font-mono text-xs leading-5 text-white">
          {BADGE_SIZES.map((s) => badgeCss(s)).join("\n\n")}
        </pre>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            {
              name: "variant",
              type: '"new-arrival" | "new-arrival-sale" | "best-seller" | "best-seller-sale" | "final-sale" | "sale-mauve" | "sale-lagoon" | "hot-list" | "limited-edition" | "new" | "sale" | "success" | "neutral"',
              default: '"neutral"',
              description: "Color treatment. The first 9 are TOV product badges, the last 4 are app-chrome only",
            },
            { name: "size", type: '"sm" | "md"', default: '"md"', description: "Small 19px (Mobile), Medium 27px (Desktop) tall" },
            { name: "icon", type: "ReactNode", description: "Optional leading icon. Hot List adds its flame automatically" },
            { name: "children", type: "ReactNode", description: "Label text" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="badge" />
    </DocPage>
  );
}
