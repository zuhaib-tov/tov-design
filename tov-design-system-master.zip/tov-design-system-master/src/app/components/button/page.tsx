import Link from "next/link";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { Button, buttonClasses } from "@/components/ui/Button";
import { TextLink, textLinkClasses } from "@/components/ui/TextLink";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import {
  BUTTON_BORDER,
  BUTTON_SCREENS,
  BUTTON_SIZES,
  BUTTON_USE_CASES,
  BUTTON_VARIANTS,
  DISABLED_OPACITY,
  TEXT_LINK_SIZES,
  type ButtonSize,
} from "@/lib/buttonSpec";

const Updated = <Badge variant="new">Updated</Badge>;
const New = <Badge variant="new">New</Badge>;

function Note({ children }: { children: React.ReactNode }) {
  return <p className="mb-4 max-w-2xl text-sm text-ink-muted">{children}</p>;
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded-app-sm bg-cream-100 px-1 py-0.5 font-mono text-xs text-primary-dark">{children}</code>;
}

/**
 * A button drawn at actual size, one CSS pixel per pixel, so a Large button on
 * this page is 54px tall, exactly as it is on the site. The measurements sit
 * outside the button: the height on the right, and the side padding below.
 */
function Anatomy({ size }: { size: ButtonSize }) {
  const guide = "font-mono text-[11px] leading-none text-primary-dark";
  return (
    <div className="flex flex-col items-start gap-2">
      <div className="flex items-center gap-3">
        <div
          className="relative inline-flex items-center justify-center bg-white text-charcoal"
          style={{
            borderRadius: 999,
            border: `${BUTTON_BORDER}px solid #3F3D3E`,
            height: size.height,
            padding: `0 ${size.padX}px`,
          }}
        >
          <span
            className="whitespace-nowrap font-bold uppercase"
            style={{ fontSize: size.font, lineHeight: `${size.line}px`, letterSpacing: "0.045em" }}
          >
            Add to cart
          </span>
        </div>
        {/* height bracket */}
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 border-y border-r border-primary-dark" style={{ height: size.height }} />
          <span className={guide}>{size.height}</span>
        </div>
      </div>
      {/* side padding bracket: one tick under each side of the label */}
      <div className="flex items-start" style={{ width: size.padX, marginLeft: BUTTON_BORDER }}>
        <div className="flex w-full flex-col items-center gap-1">
          <div className="h-1.5 w-full border-x border-b border-primary-dark" />
          <span className={guide}>{size.padX}</span>
        </div>
      </div>
      <p className="font-mono text-xs text-ink-muted">
        {`${size.name} · ${size.height}px tall · ${size.padX}px minimum side padding, each side · label ${size.font}/${size.line} · actual size`}
      </p>
    </div>
  );
}

function Swatch({ color }: { color: string }) {
  return (
    <span
      className="mr-2 inline-block h-3.5 w-3.5 rounded-[3px] border border-neutral-300 align-[-2px]"
      style={{ background: color === "transparent" ? "repeating-conic-gradient(#e8e8e8 0% 25%, #fff 0% 50%) 0 0 / 6px 6px" : color }}
    />
  );
}

const STATE_COLUMNS = [
  { key: "default", label: "Default" },
  { key: "hover", label: "Hover" },
  { key: "pressed", label: "Pressed" },
  { key: "focus", label: "Focus" },
  { key: "disabled", label: "Disabled" },
] as const;

const STATE_SELECTORS: Record<(typeof STATE_COLUMNS)[number]["key"], string> = {
  default: "no selector",
  hover: ":hover",
  pressed: ":active",
  focus: ":focus-visible",
  disabled: '[aria-disabled="true"]',
};

const TEXT_LINK_ROWS = [
  { name: "Call to action · Large", form: "cta", size: "lg", inverse: false },
  { name: "Call to action · Medium", form: "cta", size: "md", inverse: false },
  { name: "Call to action · Small", form: "cta", size: "sm", inverse: false },
  { name: "Inline · Large", form: "inline", size: "lg", inverse: false },
  { name: "Inline · Medium", form: "inline", size: "md", inverse: false },
  { name: "Inline · Small", form: "inline", size: "sm", inverse: false },
  { name: "Call to action inverse · Large", form: "cta", size: "lg", inverse: true },
  { name: "Call to action inverse · Medium", form: "cta", size: "md", inverse: true },
  { name: "Call to action inverse · Small", form: "cta", size: "sm", inverse: true },
  { name: "Inline inverse · Large", form: "inline", size: "lg", inverse: true },
  { name: "Inline inverse · Medium", form: "inline", size: "md", inverse: true },
  { name: "Inline inverse · Small", form: "inline", size: "sm", inverse: true },
] as const;

const BUTTON_CLASSES: { cls: string; adds: string }[] = [
  { cls: "tov-btn", adds: "On every button. Pill shape, Bold uppercase label with +4.5% letter-spacing, 1px border, 150ms color change." },
  { cls: "tov-btn--primary", adds: "Style: charcoal fill, white label." },
  { cls: "tov-btn--secondary", adds: "Style: pink fill, charcoal label." },
  { cls: "tov-btn--tertiary", adds: "Style: cream fill, charcoal outline and label." },
  { cls: "tov-btn--inverse", adds: "Style: white outline and label, for dark backgrounds and photography." },
  { cls: "tov-btn--lg", adds: "Size: 54px tall, 24px minimum side padding, 14/16 label. Default on Desktop and Tablet." },
  { cls: "tov-btn--md", adds: "Size: 42px tall, 24px minimum side padding, 14/16 label. Default on Mobile." },
  { cls: "tov-btn--sm", adds: "Size: 33px tall, 16px minimum side padding, 12/14 label. For cards and list rows." },
];

const TEXT_LINK_CLASSES: { cls: string; adds: string }[] = [
  { cls: "tov-link", adds: "On every text link. Underline, 1px thick and 3px below the baseline, no button shape, 150ms color change." },
  { cls: "tov-link--cta", adds: "Call to action form: bold, uppercase, +4.5% letter-spacing. Medium 14/16 unless a size class is added." },
  { cls: "tov-link--inline", adds: "Inline form: regular, sentence case, no letter-spacing. Medium 14/16 unless a size class is added." },
  { cls: "tov-link--sm", adds: "Small size: 12/14. Add to either form." },
  { cls: "tov-link--lg", adds: "Large size: 16/18. Add to either form. Medium (14/16) is the default and has no size class." },
  { cls: "tov-link--inverse", adds: "Cream text for dark backgrounds and photography. Add to either form." },
];

const CTA_FORMS: { form: string; looks: string; use: string; code: string }[] = [
  { form: "Button", looks: "Pill, filled or outlined, uppercase label", use: "The action that moves the customer forward: add, buy, submit, continue.", code: "<Button />" },
  { form: "Text link, call to action", looks: "Bold, uppercase, underlined", use: "A lighter call to action under a tile or banner: Shop now, All new arrivals.", code: '<TextLink form="cta" />' },
  { form: "Inline link", looks: "Regular, sentence case, underlined", use: "A link inside a sentence or a footer line: Learn more, See examples, Contact our team.", code: '<TextLink form="inline" />' },
  { form: "Icon button", looks: "Circle or square with a single icon", use: "Wishlist heart, carousel arrows, close. See PDP, Carousel and Navigation.", code: "see component page" },
];

const RULES: { rule: string; detail: string }[] = [
  { rule: "One primary per view", detail: "A screen area has one Primary button. Everything else is Secondary, Tertiary or a text link." },
  { rule: "Write labels in sentence case", detail: "Type Add to cart. The component sets uppercase and letter-spacing, so never type the label in capitals or add spacing by hand." },
  { rule: "Verb first, two or three words", detail: "Add to cart, Shop now, View details. Avoid Click here and Submit." },
  { rule: "Width follows the layout", detail: "A button hugs its label by default. Set a width only when the layout needs it: fill a card or the Mobile screen, or match a column. The extra width goes into the side padding." },
  { rule: "Pick a size, not a height", detail: "Height comes from the size and is the same for every button of that size. Never set it by hand or change vertical padding to make a button taller." },
  { rule: "Icon and label", detail: "An icon sits before or after the label with the size's gap (Large 10, Medium 8, Small 6) and is 16px square." },
];

export default function ButtonPage() {
  return (
    <DocPage
      title="Button"
      description="Every call to action on the site: three button sizes, four button styles, and the text links. All measurements are written the way they are coded, in pixels. Each size has one fixed height, and only the side padding changes with width."
    >
      <DocSection title={<>Anatomy and padding {Updated}</>}>
        <Note>
          Every size has a fixed height, and the label is centered in it, so the space above and below the label is the
          same on every button of that size. The only padding that changes is horizontal: the space either side of the
          label has a minimum, and grows when a button is wider than its label. The label is Montserrat Bold, uppercase,
          with +4.5% letter-spacing, and the radius is 999px on every button.
        </Note>
        <div className="mb-4 flex flex-col gap-8 overflow-x-auto rounded-app-lg border border-neutral-200 bg-cream-100 p-6">
          <p className="max-w-2xl text-xs text-ink-muted">
            Drawn at actual size. The label is at its real width, the number on the right is the height, and the bracket
            under each button is the side padding on one side.
          </p>
          {BUTTON_SIZES.map((s) => (
            <Anatomy key={s.key} size={s} />
          ))}
        </div>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Size</th>
                <th className="px-4 py-2 font-semibold">Height</th>
                <th className="px-4 py-2 font-semibold">Min. side padding</th>
                <th className="px-4 py-2 font-semibold">Font / line</th>
                <th className="px-4 py-2 font-semibold">Icon gap</th>
                <th className="px-4 py-2 font-semibold">Use for</th>
              </tr>
            </thead>
            <tbody>
              {BUTTON_SIZES.map((s) => (
                <tr key={s.key} className="border-t border-neutral-200 align-top">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">
                    {s.name} <span className="font-mono text-xs font-normal text-ink-muted">size=&quot;{s.key}&quot;</span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{s.height}px</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{s.padX}px</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">
                    {s.font} / {s.line}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{s.gap}px</td>
                  <td className="min-w-[240px] px-4 py-3 text-ink-muted">{s.use}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Height includes the {BUTTON_BORDER}px border, which is on every style and transparent on Secondary, so all
          styles of a size are the same height. In CSS, set <Code>height</Code> and <Code>padding: 0 24px</Code>, and
          center the label with flex.
        </p>
      </DocSection>

      <DocSection title={<>Sizes {Updated}</>}>
        <Preview
          code={`<Button size="lg">Add to cart</Button>
<Button size="md">View details</Button>
<Button size="sm">Quick add</Button>`}
        >
          <Button size="lg">Add to cart</Button>
          <Button size="md">View details</Button>
          <Button size="sm">Quick add</Button>
        </Preview>
      </DocSection>

      <DocSection title={<>By screen {New}</>}>
        <Note>
          Each screen has one default size for a Primary button. The three sizes keep the same height, side padding
          and type on every screen. What changes from Desktop to Mobile is the default size and the width a button
          takes.
        </Note>
        <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
          {BUTTON_SCREENS.map((sc) => {
            const size = BUTTON_SIZES.find((z) => z.key === sc.primary)!;
            return (
              <div key={sc.key} className="rounded-app-lg border border-neutral-200 bg-white p-4 shadow-sm">
                <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                  <span className="text-sm font-semibold text-ink">{sc.label}</span>
                  <span className="text-[11px] text-ink-muted">{sc.from}</span>
                </div>
                <div className="mt-3 text-xs font-bold uppercase tracking-wide-ui text-ink-muted">Primary size</div>
                <div className="font-display text-3xl text-primary-dark">{size.name}</div>
                <div className="font-mono text-xs text-ink-muted">
                  {size.height}px tall · {size.padX}px side padding
                </div>
                <p className="mt-3 text-[13px] leading-[1.5] text-ink-muted">{sc.primaryNote}</p>
              </div>
            );
          })}
        </div>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Screen</th>
                <th className="px-4 py-2 font-semibold">Page margin</th>
                <th className="min-w-[200px] px-4 py-2 font-semibold">Large</th>
                <th className="min-w-[200px] px-4 py-2 font-semibold">Medium</th>
                <th className="min-w-[160px] px-4 py-2 font-semibold">Small</th>
              </tr>
            </thead>
            <tbody>
              {BUTTON_SCREENS.map((sc) => (
                <tr key={sc.key} className="border-t border-neutral-200 align-top">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">
                    {sc.label}
                    <div className="text-[11px] font-normal text-ink-muted">{sc.from}</div>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs">{sc.margin}px</td>
                  {(["lg", "md", "sm"] as const).map((k) => (
                    <td key={k} className={`px-4 py-3 text-ink-muted ${sc.primary === k ? "bg-pink-50" : ""}`}>
                      {sc.primary === k && (
                        <div className="mb-1 text-[10px] font-bold uppercase tracking-wide-ui text-primary-dark">
                          Primary size
                        </div>
                      )}
                      {k === "lg" ? sc.large : k === "md" ? sc.medium : sc.small}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Form step actions, Desktop and Mobile</h3>
        <Preview
          align="start"
          code={`// Desktop
<Button size="lg">Next</Button>

// Mobile
<Button size="md">Next</Button>`}
        >
          <div className="flex flex-wrap items-end gap-8">
            <div className="flex flex-col gap-2">
              <span className="font-mono text-[11px] text-ink-muted">Desktop · Large, 54px</span>
              <Button size="lg" className="w-[180px]">
                Next
              </Button>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-mono text-[11px] text-ink-muted">Mobile · Medium, 42px</span>
              <Button size="md" className="w-[138px]">
                Next
              </Button>
            </div>
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Use cases {New}</>}>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="min-w-[200px] px-4 py-2 font-semibold">Where</th>
                <th className="min-w-[140px] px-4 py-2 font-semibold">Style</th>
                <th className="min-w-[110px] px-4 py-2 font-semibold">Size</th>
                <th className="min-w-[200px] px-4 py-2 font-semibold">Desktop and Tablet</th>
                <th className="min-w-[200px] px-4 py-2 font-semibold">Mobile</th>
              </tr>
            </thead>
            <tbody>
              {BUTTON_USE_CASES.map((u) => (
                <tr key={u.scenario} className="border-t border-neutral-200 align-top">
                  <td className="px-4 py-3 font-semibold text-ink">{u.scenario}</td>
                  <td className="px-4 py-3 text-ink-muted">{u.style}</td>
                  <td className="px-4 py-3 text-ink-muted">{u.size}</td>
                  <td className="px-4 py-3 text-ink-muted">{u.desktop}</td>
                  <td className="px-4 py-3 text-ink-muted">{u.mobile}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title={<>Widths {New}</>}>
        <Note>
          Width is separate from size. A button hugs its label by default, with the minimum side padding. When a layout
          needs a wider button, set the width and leave the height alone: the extra space goes into the horizontal
          padding. Figma draws the Large button at 274, 300, 346 and 552 pixels wide, all 54 tall. The dashed frame
          below is a 480px container.
        </Note>
        <Preview
          align="start"
          code={`<Button size="lg">Add to cart</Button>
<Button size="lg" className="w-[274px]">Add to cart</Button>
<Button size="lg" className="w-[346px]">Add to cart</Button>
<Button size="lg" className="w-full">Add to cart</Button>`}
        >
          <div className="flex w-[480px] flex-col gap-4 rounded-app-md border border-dashed border-neutral-400 p-4">
            {[
              { label: "Hug the label", note: "159px, label + 24px each side", cls: "" },
              { label: "Fixed width", note: "274px", cls: "w-[274px]" },
              { label: "Fixed width", note: "346px", cls: "w-[346px]" },
              { label: "Fill the container", note: "100% of the container (448px here)", cls: "w-full" },
            ].map((r) => (
              <div key={r.note} className="flex flex-col items-start gap-1.5">
                <span className="font-mono text-[11px] text-ink-muted">
                  {r.label} · {r.note}
                </span>
                <Button size="lg" className={r.cls}>
                  Add to cart
                </Button>
              </div>
            ))}
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Button styles {Updated}</>}>
        <Note>
          Four styles, each for a different job. The first three are for light backgrounds; Inverse is the outline
          button for dark backgrounds and photography.
        </Note>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {BUTTON_VARIANTS.map((v) => (
            <div key={v.key} className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
              <div
                className={`flex items-center justify-center px-6 py-8 ${v.surface === "dark" ? "bg-charcoal" : "bg-cream-100"}`}
              >
                <Button variant={v.key} size="lg">
                  Add to cart
                </Button>
              </div>
              <div className="border-t border-neutral-200 p-4">
                <div className="text-base font-bold text-ink">{v.name}</div>
                <p className="text-[13px] leading-[1.5] text-ink-muted">{v.use}</p>
                <code className="mt-2 block font-mono text-[11px] text-primary-dark">{`<Button variant="${v.key}" />`}</code>
                <code className="mt-1 block font-mono text-[11px] text-ink-muted">{`.tov-btn--${v.key}`}</code>
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title={<>States {New}</>}>
        <Note>
          Every style has five states. Hover and Pressed use the same colors. Focus draws a 2px ring in the style&apos;s
          border color, offset 2px outside the button, and appears for keyboard focus only. Disabled is the Default
          style at {DISABLED_OPACITY * 100}% opacity with no pointer events.
        </Note>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Style</th>
                {STATE_COLUMNS.map((c) => (
                  <th key={c.key} className="px-4 py-2 font-semibold">
                    {c.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {BUTTON_VARIANTS.map((v) => (
                <tr key={v.key} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">{v.name}</td>
                  {STATE_COLUMNS.map((c) => (
                    <td
                      key={c.key}
                      className={`px-4 py-3 ${v.surface === "dark" ? "bg-charcoal" : "bg-cream-100"}`}
                    >
                      <Button
                        variant={v.key}
                        size="md"
                        state={c.key === "hover" || c.key === "pressed" || c.key === "focus" ? c.key : undefined}
                        disabled={c.key === "disabled"}
                      >
                        Label
                      </Button>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Colors</h3>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Style</th>
                <th className="px-4 py-2 font-semibold">State</th>
                <th className="px-4 py-2 font-semibold">Background</th>
                <th className="px-4 py-2 font-semibold">Label</th>
                <th className="px-4 py-2 font-semibold">Border</th>
              </tr>
            </thead>
            <tbody>
              {BUTTON_VARIANTS.flatMap((v) => [
                { v, state: "Default", c: v.default },
                { v, state: "Hover and pressed", c: v.hover },
              ]).map(({ v, state, c }) => (
                <tr key={v.key + state} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-2.5 font-semibold">{state === "Default" ? v.name : ""}</td>
                  <td className="whitespace-nowrap px-4 py-2.5 text-ink-muted">{state}</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">
                    <Swatch color={c.bg} />
                    {c.bg}
                  </td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">
                    <Swatch color={c.text} />
                    {c.text}
                  </td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">
                    <Swatch color={c.border} />
                    {c.border}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Hover is a color change only, with no movement or scale. The color change runs for 150ms.
        </p>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Class names</h3>
        <Note>
          Put <Code>tov-btn</Code>, one style and one size on the button, for example{" "}
          <Code>{buttonClasses({ variant: "primary", size: "lg" })}</Code>. States are CSS selectors, not classes, so
          the same markup works for every state.
        </Note>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {BUTTON_CLASSES.map((r, i) => (
                <tr key={r.cls} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-2.5 align-top font-mono text-xs text-primary-dark">.{r.cls}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{r.adds}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title={<>Text links {New}</>}>
        <Note>
          Two text forms sit beside the buttons. The <strong>call to action</strong> link is bold, uppercase and
          underlined, for the lighter call to action under a tile or banner. The <strong>inline</strong> link is
          regular and sentence case, for a link inside a sentence. Both are underlined so they are never mistaken
          for plain text.
        </Note>
        <Preview
          align="start"
          code={`<TextLink href="#">Shop now</TextLink>
<TextLink href="#" size="sm">Living room</TextLink>
<TextLink href="#" form="inline">Learn more</TextLink>
<TextLink href="#" form="inline" size="sm">See examples</TextLink>`}
        >
          <div className="flex flex-wrap items-center gap-x-10 gap-y-4">
            <TextLink href="#">Shop now</TextLink>
            <TextLink href="#" size="sm">
              Living room
            </TextLink>
            <TextLink href="#" form="inline">
              Learn more
            </TextLink>
            <TextLink href="#" form="inline" size="sm">
              See examples
            </TextLink>
          </div>
        </Preview>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Forms, sizes and states</h3>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Link</th>
                <th className="px-4 py-2 font-semibold">Classes</th>
                {STATE_COLUMNS.map((c) => (
                  <th key={c.key} className="px-4 py-2 font-semibold">
                    {c.label}
                    <span className="block font-mono text-[11px] font-normal text-ink-muted">{STATE_SELECTORS[c.key]}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TEXT_LINK_ROWS.map((row) => (
                <tr key={row.name} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">{row.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-primary-dark">
                    {textLinkClasses(row)
                      .split(" ")
                      .map((c) => (
                        <span key={c} className="block whitespace-nowrap">
                          .{c}
                        </span>
                      ))}
                  </td>
                  {STATE_COLUMNS.map((c) => (
                    <td key={c.key} className={`px-4 py-3 ${row.inverse ? "bg-charcoal" : "bg-cream-100"}`}>
                      <TextLink
                        href="#"
                        form={row.form}
                        size={row.size}
                        inverse={row.inverse}
                        state={c.key === "hover" || c.key === "pressed" || c.key === "focus" ? c.key : undefined}
                        disabled={c.key === "disabled"}
                      >
                        Shop now
                      </TextLink>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Class names</h3>
        <Note>
          Put <Code>tov-link</Code>, one form and any modifiers on the anchor. States are CSS selectors, not classes, so
          the same markup works for every state.
        </Note>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {TEXT_LINK_CLASSES.map((r, i) => (
                <tr key={r.cls} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-2.5 align-top font-mono text-xs text-primary-dark">.{r.cls}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{r.adds}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Specification</h3>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Form</th>
                <th className="px-4 py-2 font-semibold">Size</th>
                <th className="px-4 py-2 font-semibold">Font / line</th>
                <th className="px-4 py-2 font-semibold">Weight and case</th>
                <th className="px-4 py-2 font-semibold">Letter-spacing</th>
                <th className="px-4 py-2 font-semibold">Color</th>
              </tr>
            </thead>
            <tbody>
              {TEXT_LINK_SIZES.map((s) => (
                <tr key={"cta" + s.key} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-2.5 font-semibold">Call to action</td>
                  <td className="whitespace-nowrap px-4 py-2.5">{s.name}</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">
                    {s.font} / {s.line}
                  </td>
                  <td className="whitespace-nowrap px-4 py-2.5 text-ink-muted">Bold, uppercase, underlined</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">+4.5%</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">#3F3D3E, hover #B15A63</td>
                </tr>
              ))}
              {TEXT_LINK_SIZES.map((s) => (
                <tr key={"inline" + s.key} className="border-t border-neutral-200">
                  <td className="whitespace-nowrap px-4 py-2.5 font-semibold">Inline</td>
                  <td className="whitespace-nowrap px-4 py-2.5">{s.name}</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">
                    {s.font} / {s.line}
                  </td>
                  <td className="whitespace-nowrap px-4 py-2.5 text-ink-muted">Regular, sentence case, underlined</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">0</td>
                  <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">#3F3D3E, hover #B15A63</td>
                </tr>
              ))}
              <tr className="border-t border-neutral-200">
                <td className="whitespace-nowrap px-4 py-2.5 font-semibold">Inverse (both)</td>
                <td className="px-4 py-2.5 text-ink-muted" colSpan={3}>
                  Same type, for dark backgrounds and photography
                </td>
                <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">as above</td>
                <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs">#FEFBF6, hover 80% opacity</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Underline is 1px, set 3px below the baseline. A link with no height of its own sits on the same line box as
          the text around it. Give a standalone link a 44px tap target by placing it in a container with padding.
        </p>
      </DocSection>

      <DocSection title={<>All call-to-action forms {New}</>}>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Form</th>
                <th className="px-4 py-2 font-semibold">Looks like</th>
                <th className="px-4 py-2 font-semibold">Use for</th>
                <th className="px-4 py-2 font-semibold">Component</th>
              </tr>
            </thead>
            <tbody>
              {CTA_FORMS.map((r) => (
                <tr key={r.form} className="border-t border-neutral-200 align-top">
                  <td className="whitespace-nowrap px-4 py-3 font-semibold">{r.form}</td>
                  <td className="min-w-[160px] px-4 py-3 text-ink-muted">{r.looks}</td>
                  <td className="min-w-[240px] px-4 py-3 text-ink-muted">{r.use}</td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs text-primary-dark">{r.code}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-ink-muted">
          Icon buttons are documented with their components:{" "}
          <Link href="/pages/product" className="font-medium text-primary-dark hover:underline">
            wishlist on the PDP
          </Link>
          ,{" "}
          <Link href="/components/carousel" className="font-medium text-primary-dark hover:underline">
            carousel arrows
          </Link>
          .
        </p>
      </DocSection>

      <DocSection title={<>Using buttons {New}</>}>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {RULES.map((r, i) => (
                <tr key={r.rule} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-3 align-top font-semibold text-ink">{r.rule}</td>
                  <td className="px-4 py-3 text-ink-muted">{r.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title={<>CSS reference {New}</>}>
        <Note>
          The button written as plain CSS with the class names above, for use outside the component library. Pick one
          style and one size; the height is fixed by the size and the width follows the label.
        </Note>
        <pre className="overflow-x-auto rounded-app-md bg-charcoal p-4 font-mono text-xs leading-5 text-neutral-100">{`.tov-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid transparent;  /* border is part of the height */
  border-radius: 999px;
  font-family: Montserrat, sans-serif;
  font-weight: 700;
  letter-spacing: 0.045em;
  text-transform: uppercase;
  white-space: nowrap;
  transition: background-color 150ms, color 150ms;
}

/* size */
.tov-btn--lg { height: 54px; padding: 0 24px; gap: 10px; font-size: 14px; line-height: 16px; }
.tov-btn--md { height: 42px; padding: 0 24px; gap: 8px;  font-size: 14px; line-height: 16px; }
.tov-btn--sm { height: 33px; padding: 0 16px; gap: 6px;  font-size: 12px; line-height: 14px; }

/* style */
.tov-btn--primary   { background: #3F3D3E; border-color: #3F3D3E; color: #FFFFFF; }
.tov-btn--secondary { background: #F9D2D2; border-color: transparent; color: #3F3D3E; }
.tov-btn--tertiary  { background: #FEFBF6; border-color: #3F3D3E; color: #3F3D3E; }
.tov-btn--inverse   { background: transparent; border-color: #FFFFFF; color: #FFFFFF; }

/* states */
.tov-btn--primary:hover,   .tov-btn--primary:active   { background: #FEFBF6; color: #3F3D3E; }
.tov-btn--secondary:hover, .tov-btn--secondary:active { background: #3F3D3E; color: #FFFFFF; }
.tov-btn--tertiary:hover,  .tov-btn--tertiary:active  { background: #3F3D3E; color: #FFFFFF; }
.tov-btn--inverse:hover,   .tov-btn--inverse:active   { background: #FFFFFF; color: #3F3D3E; }
.tov-btn:focus-visible { outline: 2px solid #3F3D3E; outline-offset: 2px; }
.tov-btn--inverse:focus-visible { outline-color: #FFFFFF; }
.tov-btn:disabled { opacity: 0.5; pointer-events: none; }`}</pre>
        <Note>
          <span className="mt-6 block" />
          The text link written as plain CSS, using the class names above.
        </Note>
        <pre className="overflow-x-auto rounded-app-md bg-charcoal p-4 font-mono text-xs leading-5 text-neutral-100">{`.tov-link {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: #3F3D3E;
  text-decoration: underline;
  text-decoration-thickness: 1px;
  text-underline-offset: 3px;
  white-space: nowrap;
  transition: color 150ms;
}
.tov-link--cta    { font: 700 14px/16px Montserrat, sans-serif; letter-spacing: 0.045em; text-transform: uppercase; }
.tov-link--inline { font: 400 14px/16px Montserrat, sans-serif; letter-spacing: 0; text-transform: none; }
.tov-link--lg     { font-size: 16px; line-height: 18px; }
.tov-link--sm     { font-size: 12px; line-height: 14px; }
.tov-link--inverse { color: #FEFBF6; }

.tov-link:hover,
.tov-link:active { color: #B15A63; }
.tov-link--inverse:hover,
.tov-link--inverse:active { color: #FEFBF6; opacity: 0.8; }
.tov-link:focus-visible { outline: 2px solid #3F3D3E; outline-offset: 4px; }
.tov-link--inverse:focus-visible { outline-color: #FEFBF6; }
.tov-link[aria-disabled="true"] { opacity: 0.5; pointer-events: none; }`}</pre>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "variant", type: '"primary" | "secondary" | "tertiary" | "inverse"', default: '"primary"', description: "Button style" },
            { name: "size", type: '"lg" | "md" | "sm"', default: '"md"', description: "Sets the fixed height, minimum side padding, font size and line height" },
            { name: "state", type: '"hover" | "pressed" | "focus"', description: "Forces a state for documentation and screenshots. Do not use in production code" },
            { name: "...rest", type: "ButtonHTMLAttributes", description: "Any native button prop (onClick, disabled, type, ...)" },
          ]}
        />
        <div className="mt-4" />
        <PropsTable
          rows={[
            { name: "form", type: '"cta" | "inline"', default: '"cta"', description: "Bold uppercase call to action, or regular sentence-case inline link" },
            { name: "size", type: '"lg" | "md" | "sm"', default: '"md"', description: "16/18, 14/16 or 12/14" },
            { name: "inverse", type: "boolean", default: "false", description: "Cream text for dark backgrounds" },
            { name: "disabled", type: "boolean", default: "false", description: "50% opacity, removed from tab order, no pointer events" },
            { name: "...rest", type: "AnchorHTMLAttributes", description: "Any native anchor prop (href, target, onClick, ...)" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="button" />
    </DocPage>
  );
}
