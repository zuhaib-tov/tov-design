import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { Tabs } from "@/components/ui/Tabs";

export default function TabsPage() {
  return (
    <DocPage title="Tabs" description="Used on PDP for Description / Details / Shipping content.">
      <DocSection title="Example">
        <Preview
          align="start"
          code={`<Tabs
  items={[
    { key: "desc", label: "Description", content: "..." },
    { key: "details", label: "Details", content: "..." },
    { key: "shipping", label: "Shipping", content: "..." },
  ]}
/>`}
        >
          <div className="w-full">
            <Tabs
              items={[
                { key: "desc", label: "Description", content: "Channel-tufted boucle upholstery over a solid beech frame." },
                { key: "details", label: "Details", content: "34\"W x 32\"D x 30\"H · Assembly required." },
                { key: "shipping", label: "Shipping", content: "Free curbside delivery in 5–7 business days." },
              ]}
            />
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "items", type: "TabItem[]", description: "{ key, label, content } for each tab" },
            { name: "defaultKey", type: "string", description: "Initially active tab key" },
          ]}
        />
      </DocSection>
    </DocPage>
  );
}
