import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import {
  MainNavDesktop,
  MainNavMobile,
  MainNavCondensed,
  MainNavMobileCondensed,
} from "@/components/ui/MainNav";
import { MegaMenu, MEGA_MENUS } from "@/components/ui/MegaMenu";
import {
  MobileNavMainMenu,
  MobileNavFurniture,
  MobileNavLighting,
  MobileNavOutdoor,
  MobileNavDecorTabletop,
} from "@/components/ui/MobileNav";
import { FooterDesktop, FooterMobile } from "@/components/ui/Footer";
import { FooterIconRowDesktop, FooterIconRowMobile } from "@/components/ui/FooterIconRow";
import { EmailSignUpDesktop, EmailSignUpMobile } from "@/components/ui/EmailSignUp";
import { SearchTypeADesktop, SearchTypeAMobile } from "@/components/ui/SearchTypeA";
import {
  SearchTypeBDesktopDefault,
  SearchTypeBDesktopBottomScroll,
  SearchTypeBDesktopCategorySelected,
  SearchTypeBMobile,
} from "@/components/ui/SearchTypeB";
import { SearchTypeCDesktop, SearchTypeCMobile } from "@/components/ui/SearchTypeC";
import { SearchTypeDDesktop, SearchTypeDMobile } from "@/components/ui/SearchTypeD";
import { SearchTypeEDesktop, SearchTypeEMobile } from "@/components/ui/SearchTypeE";
import { SearchTypeReturningDesktop, SearchTypeReturningMobile } from "@/components/ui/SearchTypeReturning";
import { SearchTypeNoResultsDesktop, SearchTypeNoResultsMobile } from "@/components/ui/SearchTypeNoResults";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function NavigationPage() {
  return (
    <DocPage
      title="Main Navigation"
      description="The site-wide navigation and footer system — how shoppers move through TOV's storefront, discover categories, search for products, and reach support or company information from any page: Main Nav, Category Mega-Menu, Mobile Navigation, Footer, Footer Icon Row, Email Sign Up, and Search."
    >
      <DocSection title={<>Main Nav <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The primary header shown across the storefront. It anchors brand
          recognition and gives shoppers persistent access to search, account,
          wishlist, and cart from anywhere on the site — search is always a full,
          ready-to-use bar, never a secondary action behind an icon. A condensed
          variant takes over once the shopper scrolls past the full header, keeping
          navigation and search available without holding onto screen space the
          content should have.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop — Default</p>
        <Preview align="start" code={`<MainNavDesktop />`}>
          <MainNavDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop — Condensed / sticky on scroll (Navbar 3)</p>
        <Preview align="start" code={`<MainNavCondensed />`}>
          <MainNavCondensed />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile — Default</p>
        <Preview align="start" code={`<MainNavMobile />`}>
          <MainNavMobile />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile — Condensed / sticky on scroll</p>
        <Preview align="start" code={`<MainNavMobileCondensed />`}>
          <MainNavMobileCondensed />
        </Preview>
      </DocSection>

      <DocSection title={<>Category Mega-Menu <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Category dropdown menus opened from the primary nav, letting shoppers
          browse deeper into a department without leaving the page they&apos;re on.
          Each menu pairs a quick-links column with several subcategory columns and
          a promotional panel, giving shoppers both a fast path to popular pages
          and full visibility into everything a category contains.
        </p>
        {Object.entries(MEGA_MENUS).map(([key, data]) => (
          <div key={key} className="mb-6">
            <p className="text-sm font-semibold text-ink mb-2">{data.category}</p>
            <Preview align="start" code={`<MegaMenu data={MEGA_MENUS["${key}"]} />`}>
              <MegaMenu data={data} />
            </Preview>
          </div>
        ))}
      </DocSection>

      <DocSection title={<>Mobile Navigation <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The mobile menu system, opened from the header&apos;s menu icon. It drills
          from a top-level department list into each category&apos;s own subcategories,
          letting a shopper narrow from a broad department down to a specific
          product type in a few taps. The collapsed entry point matches Main
          Nav&apos;s Mobile header, so it isn&apos;t shown again separately here.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Main Menu</p>
        <Preview align="start" code={`<MobileNavMainMenu />`}>
          <MobileNavMainMenu />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Furniture</p>
        <Preview align="start" code={`<MobileNavFurniture />`}>
          <MobileNavFurniture />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Lighting</p>
        <Preview align="start" code={`<MobileNavLighting />`}>
          <MobileNavLighting />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Outdoor</p>
        <Preview align="start" code={`<MobileNavOutdoor />`}>
          <MobileNavOutdoor />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Decor &amp; Tabletop</p>
        <Preview align="start" code={`<MobileNavDecorTabletop />`}>
          <MobileNavDecorTabletop />
        </Preview>
      </DocSection>

      <DocSection title={<>Footer <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The site-wide footer, present on every page. It surfaces support and
          company links, reinforces brand presence with a large-format wordmark
          treatment, and connects shoppers to TOV&apos;s social channels.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<FooterDesktop />`}>
          <FooterDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<FooterMobile />`}>
          <FooterMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Footer Icon Row <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Three value-proposition cards — Trade Program, Design Box, and Registry —
          shown directly beneath the footer to highlight programs and tools
          available to shoppers and trade partners.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<FooterIconRowDesktop />`}>
          <FooterIconRowDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<FooterIconRowMobile />`}>
          <FooterIconRowMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Email Sign Up <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The email capture banner shown when no sign-up pop-up is active, inviting
          visitors to join TOV&apos;s email list for early access to new arrivals,
          sales, and updates.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<EmailSignUpDesktop />`}>
          <EmailSignUpDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<EmailSignUpMobile />`}>
          <EmailSignUpMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Type A <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The default results layout for a direct product search — a single-column
          grid of matching products, with no category filter panel. Used when a
          shopper&apos;s query clearly identifies what they&apos;re looking for.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeADesktop />`}>
          <SearchTypeADesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeAMobile />`}>
          <SearchTypeAMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Type B <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The results layout for a broader material or attribute search (e.g. a
          fabric, finish, or style rather than a specific product). Pairs a visible
          category filter panel with the results grid, and supports a selected-
          category state so a shopper can see and refine which filter is active.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop — Default</p>
        <Preview align="start" code={`<SearchTypeBDesktopDefault />`}>
          <SearchTypeBDesktopDefault />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop — Bottom Scroll</p>
        <Preview align="start" code={`<SearchTypeBDesktopBottomScroll />`}>
          <SearchTypeBDesktopBottomScroll />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop — Category Selected</p>
        <Preview align="start" code={`<SearchTypeBDesktopCategorySelected />`}>
          <SearchTypeBDesktopCategorySelected />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeBMobile />`}>
          <SearchTypeBMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Type C <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The results layout for an exact SKU or product-name match — a single
          confident result surfaced immediately, rather than a full grid, since the
          shopper&apos;s query already identifies one specific product.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeCDesktop />`}>
          <SearchTypeCDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeCMobile />`}>
          <SearchTypeCMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Type D <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The results layout for a compound query that combines a product type with
          an attribute (for example, a specific style of chair). Uses the same
          single-column grid pattern as Type A.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeDDesktop />`}>
          <SearchTypeDDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeDMobile />`}>
          <SearchTypeDMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Type E <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The results layout for a collection or style-name search, returning every
          product in that collection as a complete set rather than a paginated
          list — the results header states the total count directly instead of
          offering a &quot;See all&quot; action.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeEDesktop />`}>
          <SearchTypeEDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeEMobile />`}>
          <SearchTypeEMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — Returning Users <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Shown when a shopper opens search with a browsing history already on
          file. An empty search bar pairs with a Recent Searches panel and a
          Recently Viewed product grid, helping a returning shopper pick back up
          where they left off instead of starting a search from scratch.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeReturningDesktop />`}>
          <SearchTypeReturningDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeReturningMobile />`}>
          <SearchTypeReturningMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Search — No Results <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Shown when a query returns no matching products. A centered message
          reassures the shopper and offers a clear next action, rather than
          leaving them at a dead end.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SearchTypeNoResultsDesktop />`}>
          <SearchTypeNoResultsDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SearchTypeNoResultsMobile />`}>
          <SearchTypeNoResultsMobile />
        </Preview>
      </DocSection>

      <ChangeLogTable page="navigation" />
    </DocPage>
  );
}
