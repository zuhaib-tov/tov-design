import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { Rating } from "@/components/ui/Rating";

export default function RatingPage() {
  return (
    <DocPage title="Rating" description="Star rating used on product cards, PDP, and review summaries.">
      <DocSection title="Examples">
        <Preview code={`<Rating value={4.6} count={128} />
<Rating value={3} />`}>
          <Rating value={4.6} count={128} />
          <Rating value={3} />
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "value", type: "number", description: "0–max rating; rounds to nearest whole star" },
            { name: "count", type: "number", description: "Optional review count shown in parentheses" },
            { name: "max", type: "number", default: "5", description: "Number of stars" },
          ]}
        />
      </DocSection>
    </DocPage>
  );
}
