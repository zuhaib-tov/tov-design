"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/FormFields";
import { Badge } from "@/components/ui/Badge";
import { Tabs } from "@/components/ui/Tabs";
import { MarketingUploads } from "@/components/assets/MarketingUploads";
import type { AssetRecord } from "@/lib/asset-store";
import { uploadFilesToLibrary } from "@/lib/upload-client";

interface FigmaNode {
  id: string;
  name: string;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function AssetLibraryPage() {
  const [assets, setAssets] = useState<AssetRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [folderFilter, setFolderFilter] = useState<string>("All");
  const [tagFilter, setTagFilter] = useState<string>("");
  const [dragOver, setDragOver] = useState(false);

  const [uploadTags, setUploadTags] = useState("");
  const [uploadFolder, setUploadFolder] = useState("Uncategorized");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [figmaUrl, setFigmaUrl] = useState("");
  const [figmaNodes, setFigmaNodes] = useState<FigmaNode[] | null>(null);
  const [figmaFileKey, setFigmaFileKey] = useState("");
  const [figmaFileName, setFigmaFileName] = useState("");
  const [figmaSelected, setFigmaSelected] = useState<Set<string>>(new Set());
  const [figmaBusy, setFigmaBusy] = useState(false);
  const [figmaError, setFigmaError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/assets");
    const data = await res.json();
    setAssets(data.assets ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Vercel Blob's index read can lag a few seconds right after a write (CDN
  // caching on the overwritten index blob), so re-fetching immediately after
  // an upload/delete/update can show stale data. Apply the mutation's own
  // response locally instead of trusting an immediate refresh() to see it.
  const upsertAssets = (updated: AssetRecord[]) => {
    setAssets((prev) => {
      const byId = new Map(prev.map((a) => [a.id, a]));
      updated.forEach((a) => byId.set(a.id, a));
      return Array.from(byId.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    });
  };
  const removeAssetsLocally = (ids: string[]) => {
    const idSet = new Set(ids);
    setAssets((prev) => prev.filter((a) => !idSet.has(a.id)));
  };

  const uploadFiles = async (files: FileList | File[]) => {
    setUploading(true);
    setUploadError(null);
    try {
      const tags = uploadTags.split(",").map((t) => t.trim()).filter(Boolean);
      const { uploaded, errors } = await uploadFilesToLibrary(files, { folder: uploadFolder, tags });
      if (uploaded.length) upsertAssets(uploaded);
      if (errors.length) {
        setUploadError(errors.map((e) => `${e.fileName}: ${e.message}`).join("; "));
      }
    } catch (err) {
      setUploadError((err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const toggleSelected = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const downloadSelected = async () => {
    const res = await fetch("/api/assets/download-zip", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: Array.from(selected) }),
    });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tov-assets.zip";
    a.click();
    URL.revokeObjectURL(url);
  };

  const removeAsset = async (id: string) => {
    const res = await fetch(`/api/assets/${id}`, { method: "DELETE" });
    if (res.ok) removeAssetsLocally([id]);
  };

  const loadFigmaFrames = async () => {
    setFigmaError(null);
    setFigmaBusy(true);
    setFigmaNodes(null);
    try {
      const res = await fetch(`/api/assets/figma-sync?file=${encodeURIComponent(figmaUrl)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setFigmaFileKey(data.fileKey);
      setFigmaFileName(data.fileName);
      setFigmaNodes(data.nodes);
      setFigmaSelected(new Set());
    } catch (err) {
      setFigmaError((err as Error).message);
    } finally {
      setFigmaBusy(false);
    }
  };

  const importFigmaSelected = async () => {
    setFigmaBusy(true);
    setFigmaError(null);
    try {
      const res = await fetch("/api/assets/figma-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileKey: figmaFileKey,
          fileName: figmaFileName,
          nodeIds: Array.from(figmaSelected),
          folder: figmaFileName || "Figma",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      upsertAssets(data.assets ?? []);
      setFigmaNodes(null);
      setFigmaUrl("");
    } catch (err) {
      setFigmaError((err as Error).message);
    } finally {
      setFigmaBusy(false);
    }
  };

  const generalAssets = assets.filter((a) => a.category !== "marketing");
  const folders = ["All", ...Array.from(new Set(generalAssets.map((a) => a.folder)))];
  const filtered = generalAssets.filter((a) => {
    if (folderFilter !== "All" && a.folder !== folderFilter) return false;
    if (tagFilter && !a.tags.some((t) => t.toLowerCase().includes(tagFilter.toLowerCase()))) return false;
    return true;
  });

  const generalUploadTab = (
    <div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
        {/* Upload */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
          }}
          className={`rounded-app-lg border-2 border-dashed p-6 flex flex-col gap-4 shadow-sm ${
            dragOver ? "border-primary bg-cream-100" : "border-neutral-200 bg-white"
          }`}
        >
          <h2 className="font-display text-lg">Upload images</h2>
          <div
            onClick={() => fileInputRef.current?.click()}
            className="rounded-app-md border border-neutral-200 bg-cream-50 p-8 text-center text-sm text-ink-muted cursor-pointer hover:border-primary"
          >
            Drag & drop, or click to choose files
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files && uploadFiles(e.target.files)}
            />
          </div>
          <div className="flex gap-3">
            <Input
              label="Folder"
              value={uploadFolder}
              onChange={(e) => setUploadFolder(e.target.value)}
            />
            <Input
              label="Tags (comma separated)"
              value={uploadTags}
              onChange={(e) => setUploadTags(e.target.value)}
              placeholder="pdp, sofa, lifestyle"
            />
          </div>
          {uploading && <p className="text-xs text-ink-muted">Uploading…</p>}
          {uploadError && <p className="text-xs text-sale">{uploadError}</p>}
        </div>

        {/* Figma sync */}
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 flex flex-col gap-4">
          <h2 className="font-display text-lg">Sync from Figma</h2>
          <p className="text-xs text-ink-muted">
            Paste a Figma file URL, pick the frames to pull in as images. Requires{" "}
            <code className="font-mono bg-cream-100 px-1">FIGMA_TOKEN</code> to be set
            in the server environment (see{" "}
            <code className="font-mono bg-cream-100 px-1">.env.local.example</code>).
          </p>
          <div className="flex gap-2">
            <Input
              className="flex-1"
              placeholder="https://www.figma.com/design/..."
              value={figmaUrl}
              onChange={(e) => setFigmaUrl(e.target.value)}
            />
            <Button size="sm" onClick={loadFigmaFrames} disabled={!figmaUrl || figmaBusy}>
              Load frames
            </Button>
          </div>
          {figmaError && <p className="text-xs text-sale">{figmaError}</p>}
          {figmaNodes && (
            <div className="flex flex-col gap-3">
              <div className="max-h-48 overflow-y-auto rounded-app-md border border-neutral-200 divide-y divide-neutral-200">
                {figmaNodes.length === 0 && (
                  <p className="p-3 text-xs text-ink-muted">No frames found on the first page.</p>
                )}
                {figmaNodes.map((n) => (
                  <label key={n.id} className="flex items-center gap-2 px-3 py-2 text-sm">
                    <input
                      type="checkbox"
                      checked={figmaSelected.has(n.id)}
                      onChange={() =>
                        setFigmaSelected((prev) => {
                          const next = new Set(prev);
                          next.has(n.id) ? next.delete(n.id) : next.add(n.id);
                          return next;
                        })
                      }
                    />
                    {n.name}
                  </label>
                ))}
              </div>
              <Button
                size="sm"
                onClick={importFigmaSelected}
                disabled={figmaSelected.size === 0 || figmaBusy}
              >
                Import {figmaSelected.size || ""} selected
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Gallery controls */}
      <div className="flex flex-wrap items-end gap-4 mb-4">
        <label className="flex flex-col gap-1 text-xs">
          <span className="font-semibold uppercase tracking-wide-ui text-ink-muted">Folder</span>
          <select
            value={folderFilter}
            onChange={(e) => setFolderFilter(e.target.value)}
            className="border border-black px-2 py-1.5 text-sm bg-white"
          >
            {folders.map((f) => (
              <option key={f}>{f}</option>
            ))}
          </select>
        </label>
        <Input
          label="Filter by tag"
          value={tagFilter}
          onChange={(e) => setTagFilter(e.target.value)}
        />
        <div className="flex-1" />
        {selected.size > 0 && (
          <Button size="sm" onClick={downloadSelected}>
            Download {selected.size} as .zip
          </Button>
        )}
      </div>

      {loading ? (
        <p className="text-sm text-ink-muted">Loading…</p>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-ink-muted rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 text-center">
          No assets yet — upload some files or sync from Figma above.
        </p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {filtered.map((asset) => (
            <div key={asset.id} className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white group relative">
              <label className="absolute top-2 left-2 z-10">
                <input
                  type="checkbox"
                  checked={selected.has(asset.id)}
                  onChange={() => toggleSelected(asset.id)}
                />
              </label>
              {asset.source.type === "figma" && (
                <span className="absolute top-2 right-2 z-10">
                  <Badge variant="new">Figma</Badge>
                </span>
              )}
              <div className="aspect-square bg-cream-200">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`/api/assets/${asset.id}`}
                  alt={asset.originalName}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-2">
                <p className="text-xs truncate" title={asset.originalName}>
                  {asset.originalName}
                </p>
                <p className="text-[11px] text-ink-muted">{formatBytes(asset.size)}</p>
                <div className="flex items-center justify-between mt-2">
                  <a
                    href={`/api/assets/${asset.id}?download=1`}
                    className="text-[11px] font-semibold uppercase tracking-wide-ui text-primary-dark hover:text-primary"
                  >
                    Download
                  </a>
                  <button
                    onClick={() => removeAsset(asset.id)}
                    className="text-[11px] text-ink-muted hover:text-sale"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-6xl px-8 py-10">
      <h1 className="font-display text-4xl text-primary-dark mb-2">Asset Library</h1>
      <p className="text-ink-muted max-w-2xl mb-8">
        The shared imagery store for TOV's website — drag files in, sync straight
        from Figma, and grab what you need for a page build in one click.
      </p>

      <Tabs
        defaultKey="general"
        items={[
          { key: "general", label: "General Upload", content: generalUploadTab },
          {
            key: "marketing",
            label: "Marketing Uploads",
            content: (
              <MarketingUploads
                assets={assets}
                upsertAssets={upsertAssets}
                removeAssetsLocally={removeAssetsLocally}
              />
            ),
          },
        ]}
      />
    </div>
  );
}
