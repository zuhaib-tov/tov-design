"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/FormFields";

interface FigmaImageFillUsage {
  nodeId: string;
  nodeName: string;
}

interface FigmaImageFill {
  imageRef: string;
  url: string;
  usages: FigmaImageFillUsage[];
}

function labelFor(image: FigmaImageFill): string {
  return image.usages[0]?.nodeName || image.imageRef;
}

export default function FigmaImageExportPage() {
  const [figmaUrl, setFigmaUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileKey, setFileKey] = useState("");
  const [fileName, setFileName] = useState("");
  const [images, setImages] = useState<FigmaImageFill[] | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [zipping, setZipping] = useState(false);

  const findImages = async () => {
    setLoading(true);
    setError(null);
    setImages(null);
    setSelected(new Set());
    try {
      const res = await fetch(`/api/figma-image-export?file=${encodeURIComponent(figmaUrl)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setFileKey(data.fileKey);
      setFileName(data.fileName);
      setImages(data.images);
      setSelected(new Set((data.images as FigmaImageFill[]).map((i) => i.imageRef)));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const toggleSelected = (ref: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(ref) ? next.delete(ref) : next.add(ref);
      return next;
    });
  };

  const toggleAll = () => {
    if (!images) return;
    setSelected((prev) => (prev.size === images.length ? new Set() : new Set(images.map((i) => i.imageRef))));
  };

  const downloadOne = (image: FigmaImageFill) => {
    const params = new URLSearchParams({ file: fileKey, ref: image.imageRef, name: labelFor(image) });
    window.location.href = `/api/figma-image-export/download?${params.toString()}`;
  };

  const downloadSelected = async () => {
    if (!images) return;
    setZipping(true);
    try {
      const chosen = images.filter((i) => selected.has(i.imageRef));
      const res = await fetch("/api/figma-image-export/zip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileKey,
          images: chosen.map((i) => ({ ref: i.imageRef, name: labelFor(i) })),
        }),
      });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileName || "figma-images"}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setZipping(false);
    }
  };

  return (
    <div className="max-w-6xl px-8 py-10">
      <h1 className="font-display text-4xl text-primary-dark mb-2">Figma Image Export</h1>
      <p className="text-ink-muted max-w-2xl mb-8">
        Paste a link to a frame, section, or page in Figma and pull out the real image files used
        in it — the original photo assets, not a flattened screenshot. This finds every image
        even when text or other layers are stacked on top, since it reads the underlying fill
        instead of rendering the composited layer.
      </p>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 flex flex-col gap-4 mb-10">
        <p className="text-xs text-ink-muted">
          In Figma, select the frame/section/page you want, right-click →{" "}
          <strong className="text-ink">&quot;Copy link to selection&quot;</strong>, then paste it
          below. Requires{" "}
          <code className="font-mono bg-cream-100 px-1">FIGMA_TOKEN</code> to be set in the server
          environment.
        </p>
        <div className="flex gap-2">
          <Input
            className="flex-1"
            placeholder="https://www.figma.com/design/..."
            value={figmaUrl}
            onChange={(e) => setFigmaUrl(e.target.value)}
          />
          <Button size="sm" onClick={findImages} disabled={!figmaUrl || loading}>
            {loading ? "Finding…" : "Find images"}
          </Button>
        </div>
        {error && <p className="text-xs text-sale">{error}</p>}
      </div>

      {images && (
        <>
          <div className="flex flex-wrap items-center gap-4 mb-4">
            <p className="text-sm text-ink-muted">
              {images.length} image{images.length === 1 ? "" : "s"} found in{" "}
              <span className="text-ink font-semibold">{fileName}</span>
            </p>
            <div className="flex-1" />
            <Button variant="ghost" size="sm" onClick={toggleAll}>
              {selected.size === images.length ? "Deselect all" : "Select all"}
            </Button>
            <Button size="sm" onClick={downloadSelected} disabled={selected.size === 0 || zipping}>
              {zipping ? "Zipping…" : `Download ${selected.size || ""} as .zip`}
            </Button>
          </div>

          {images.length === 0 ? (
            <p className="text-sm text-ink-muted rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 text-center">
              No image fills found under that selection.
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {images.map((image) => (
                <div
                  key={image.imageRef}
                  className="relative rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white"
                >
                  <label className="absolute top-2 left-2 z-10 block w-fit">
                    <input
                      type="checkbox"
                      checked={selected.has(image.imageRef)}
                      onChange={() => toggleSelected(image.imageRef)}
                    />
                  </label>
                  <div className="aspect-square bg-cream-200">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={image.url}
                      alt={labelFor(image)}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-2">
                    <p className="text-xs truncate" title={labelFor(image)}>
                      {labelFor(image)}
                    </p>
                    {image.usages.length > 1 && (
                      <p className="text-[11px] text-ink-muted">
                        used in {image.usages.length} places
                      </p>
                    )}
                    <button
                      onClick={() => downloadOne(image)}
                      className="mt-2 text-[11px] font-semibold uppercase tracking-wide-ui text-primary-dark hover:text-primary"
                    >
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
