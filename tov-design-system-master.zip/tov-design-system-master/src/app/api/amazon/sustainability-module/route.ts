import { NextRequest, NextResponse } from "next/server";
import { getPngDimensions, renderFigmaFrame } from "@/lib/figma";
import {
  SUSTAINABILITY_MODULE_EXPECTED_SIZE,
  SUSTAINABILITY_MODULE_FIGMA_FILE_KEY,
  SUSTAINABILITY_MODULE_NODE_ID,
} from "@/lib/amazon/figma-slots";

/**
 * Serves the Sustainability Module's single evergreen photo, guaranteed to
 * be exactly SUSTAINABILITY_MODULE_EXPECTED_SIZE (800x600, the frame's real
 * spec size) — not necessarily the raw uploaded photo asset's native
 * resolution, which Figma may crop/scale to fit the frame.
 *
 * Deliberately does NOT reuse the figma-image-export tool's fill-extraction
 * path (`getFigmaImageFillUrls`) — that returns the original image bytes
 * behind the fill, which for a FILL/FIT/CROP scaleMode can be a differently
 * sized or differently cropped file than what's actually shown at 800x600.
 * Instead this calls `renderFigmaFrame`, Figma's own image-render endpoint,
 * at scale 1 for this exact node — it composites the fill exactly as shown
 * and returns a PNG sized to the node's own layout box, sidestepping the
 * crop-vs-original-asset ambiguity entirely rather than trying to infer it
 * from `scaleMode`/`imageTransform`.
 *
 * Belt-and-suspenders: the real PNG dimensions are decoded and checked
 * against the expected size on every request. If the frame were ever
 * resized in Figma (or the wrong node id used), this refuses to serve a
 * silently wrong-size file rather than trusting the recorded spec.
 *
 * `?download=1` sets Content-Disposition to attachment (the download
 * button); omitted, the response is `inline` so the same route can back an
 * <img> preview on the doc page.
 */
export async function GET(req: NextRequest) {
  const download = req.nextUrl.searchParams.get("download") === "1";

  try {
    const url = await renderFigmaFrame(SUSTAINABILITY_MODULE_FIGMA_FILE_KEY, SUSTAINABILITY_MODULE_NODE_ID, 1);
    if (!url) {
      return NextResponse.json(
        {
          error:
            "Figma did not return a render for this node — the node id may no longer be valid, or the file may have changed.",
        },
        { status: 502 }
      );
    }

    const res = await fetch(url);
    if (!res.ok) {
      return NextResponse.json({ error: `Failed to fetch rendered image (${res.status})` }, { status: 502 });
    }
    const buffer = Buffer.from(await res.arrayBuffer());

    const dims = getPngDimensions(buffer);
    const { width: expectedWidth, height: expectedHeight } = SUSTAINABILITY_MODULE_EXPECTED_SIZE;
    if (!dims) {
      return NextResponse.json(
        { error: "Could not read PNG dimensions from Figma's render — refusing to serve an unverified file." },
        { status: 502 }
      );
    }
    if (dims.width !== expectedWidth || dims.height !== expectedHeight) {
      return NextResponse.json(
        {
          error: `Figma rendered this node at ${dims.width}x${dims.height}, not the expected ${expectedWidth}x${expectedHeight}. The frame may have been resized in Figma — refusing to silently serve the wrong size.`,
        },
        { status: 502 }
      );
    }

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "image/png",
        "Content-Disposition": `${download ? "attachment" : "inline"}; filename="sustainability-module-${dims.width}x${dims.height}.png"`,
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
