import { NextRequest, NextResponse } from "next/server";
import { checkForDrift } from "@/lib/figma-watch";

/**
 * Figma FILE_UPDATE webhook receiver. Inert until this app is deployed with
 * a public URL and the webhook is registered (Figma can't reach localhost):
 *
 *   POST https://api.figma.com/v2/webhooks
 *   { "event_type": "FILE_UPDATE", "team_id": "...", "endpoint": "<deployed-url>/api/figma-webhook",
 *     "passcode": "<FIGMA_WEBHOOK_PASSCODE>" }
 *
 * See FIGMA_SYSTEMS.md for the full setup note.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();

  if (body.passcode !== process.env.FIGMA_WEBHOOK_PASSCODE) {
    return NextResponse.json({ error: "Invalid passcode" }, { status: 401 });
  }

  // Figma also sends a one-time PING event when a webhook is first registered.
  if (body.event_type !== "FILE_UPDATE") {
    return NextResponse.json({ received: true, ignored: body.event_type });
  }

  const newDrift = await checkForDrift(body.file_key);
  return NextResponse.json({ received: true, newDriftCount: newDrift.length });
}
