import { NextRequest, NextResponse } from "next/server";
import { upsertAssetPatch, type AssetRecord } from "@/lib/asset-store";

/**
 * Assigns (or clears) an uploaded asset's precise Figma push target. This
 * only sets the target — it does NOT queue a push. Requesting the actual
 * push is a separate, explicit step (see figma-push-request/route.ts), so
 * picking a slot doesn't silently queue work before you're ready. Any
 * change to the target (including clearing it) resets prior request/pushed
 * status, since those applied to the old target.
 *
 * Takes the full asset (not just its id) so this can self-heal against the
 * index-propagation lag documented in asset-store.ts — the very common case
 * of assigning a slot right after uploading, before the index write has
 * caught up.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as {
    asset?: AssetRecord;
    figmaTargetFileKey?: string;
    figmaTargetNodeIds?: string[];
    figmaTargetLabel?: string;
  };
  if (!body.asset?.id) {
    return NextResponse.json({ error: "asset is required" }, { status: 400 });
  }

  const clearing = !body.figmaTargetNodeIds?.length;
  const updated = await upsertAssetPatch(body.asset, {
    figmaTargetFileKey: clearing ? undefined : body.figmaTargetFileKey,
    figmaTargetNodeIds: clearing ? undefined : body.figmaTargetNodeIds,
    figmaTargetLabel: clearing ? undefined : body.figmaTargetLabel,
    figmaPushRequestedAt: undefined,
    figmaPushedAt: undefined,
  });

  return NextResponse.json({ asset: updated });
}
