import { NextRequest, NextResponse } from "next/server";
import { deleteAsset, getAsset, getAssetBuffer } from "@/lib/asset-store";
import { CORS_HEADERS } from "@/lib/cors";

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const record = await getAsset(id);
  if (!record) {
    return NextResponse.json({ error: "Not found" }, { status: 404, headers: CORS_HEADERS });
  }

  let buffer: Buffer;
  try {
    buffer = await getAssetBuffer(record);
  } catch {
    // Source blob is gone (see upload-client.ts's verification step, added
    // after this happened in real use) — surface a clean 502 instead of an
    // unhandled exception, so the uploader's <img onError> can catch it.
    return NextResponse.json({ error: "Source file unavailable" }, { status: 502, headers: CORS_HEADERS });
  }
  const download = req.nextUrl.searchParams.get("download") === "1";

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      ...CORS_HEADERS,
      "Content-Type": record.mimeType,
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${record.originalName}"`,
      // Overrides CORS_HEADERS's no-store: actual image bytes for a given
      // id never change (a re-upload gets a new id), so long-lived caching
      // here is correct — the no-store concern only applies to the
      // figma-pending polling endpoint, not this one.
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const ok = await deleteAsset(id);
  return NextResponse.json({ deleted: ok });
}
