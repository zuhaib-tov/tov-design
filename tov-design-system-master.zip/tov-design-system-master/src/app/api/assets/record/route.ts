import { NextRequest, NextResponse } from "next/server";
import { recordAsset } from "@/lib/asset-store";

/**
 * Step 2 of a client upload: after the browser has put the file bytes
 * directly into Blob storage (see /api/assets/upload-token), it calls this
 * route with the resulting blob info plus the file's metadata so it can be
 * recorded in the library's index. This payload is tiny regardless of file
 * size, so it never hits the request body limit the old FormData upload did.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as {
    id?: string;
    url?: string;
    filename?: string;
    originalName?: string;
    mimeType?: string;
    size?: number;
    folder?: string;
    tags?: string[];
    category?: "general" | "marketing";
    campaign?: string;
    pageType?: string;
  };

  if (!body.id || !body.url || !body.filename || !body.originalName || !body.mimeType || typeof body.size !== "number") {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const record = await recordAsset({
    id: body.id,
    url: body.url,
    filename: body.filename,
    originalName: body.originalName,
    mimeType: body.mimeType,
    size: body.size,
    folder: body.folder || "Uncategorized",
    tags: body.tags ?? [],
    category: body.category === "marketing" ? "marketing" : "general",
    campaign: body.campaign,
    pageType: body.pageType,
    source: { type: "upload" },
  });

  return NextResponse.json({ asset: record });
}
