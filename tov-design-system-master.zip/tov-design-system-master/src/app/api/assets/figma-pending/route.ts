import { NextRequest, NextResponse } from "next/server";
import { listAssets } from "@/lib/asset-store";
import { CORS_HEADERS } from "@/lib/cors";

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}

/**
 * What the Figma plugin polls (see /figma-plugin). Scoped to one file key
 * at a time — the plugin only knows about the file it's currently running
 * inside (figma.fileKey), so there's no point returning pending pushes for
 * other files. imageUrl points at this app's own asset-serving route
 * (not the raw Blob URL) so the plugin's manifest only needs this app's
 * domain in networkAccess, not Blob's storage domain too.
 */
export async function GET(req: NextRequest) {
  const fileKey = req.nextUrl.searchParams.get("fileKey");
  if (!fileKey) {
    return NextResponse.json({ error: "fileKey is required" }, { status: 400, headers: CORS_HEADERS });
  }

  const assets = await listAssets();
  const pending = assets.filter(
    (a) => a.figmaTargetFileKey === fileKey && a.figmaPushRequestedAt && !a.figmaPushedAt
  );

  return NextResponse.json(
    {
      pending: pending.map((a) => ({
        id: a.id,
        label: a.figmaTargetLabel,
        nodeIds: a.figmaTargetNodeIds,
        imageUrl: `/api/assets/${a.id}`,
        originalName: a.originalName,
      })),
    },
    { headers: CORS_HEADERS }
  );
}
