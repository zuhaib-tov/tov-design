import { NextRequest, NextResponse } from "next/server";
import JSZip from "jszip";
import { getAsset, getAssetBuffer } from "@/lib/asset-store";

export async function POST(req: NextRequest) {
  const { ids } = (await req.json()) as { ids: string[] };
  if (!ids?.length) {
    return NextResponse.json({ error: "No ids provided" }, { status: 400 });
  }

  const zip = new JSZip();
  for (const id of ids) {
    const record = await getAsset(id);
    if (!record) continue;
    const buffer = await getAssetBuffer(record);
    zip.file(record.originalName, buffer);
  }

  const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });

  return new NextResponse(new Uint8Array(zipBuffer), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="tov-assets.zip"`,
    },
  });
}
