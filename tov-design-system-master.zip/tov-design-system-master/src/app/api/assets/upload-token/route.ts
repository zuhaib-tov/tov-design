import { handleUpload, type HandleUploadBody } from "@vercel/blob/client";
import { NextResponse } from "next/server";

/**
 * Issues short-lived client tokens for direct browser-to-Blob uploads (see
 * @vercel/blob/client's upload(), used from src/app/assets/page.tsx and
 * MarketingUploads.tsx). File bytes never pass through this server, which
 * matters: a plain FormData POST to a Next.js route handler is capped at
 * Vercel's ~4.5MB request body limit, easily hit by two or three real
 * photos — this is why uploads used to hang after the first couple of
 * files.
 */
export async function POST(request: Request): Promise<NextResponse> {
  const body = (await request.json()) as HandleUploadBody;

  try {
    const jsonResponse = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async () => ({
        allowedContentTypes: [
          "image/*",
          "video/*",
          "text/csv",
          "application/vnd.ms-excel",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ],
        addRandomSuffix: false,
      }),
    });
    return NextResponse.json(jsonResponse);
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 400 });
  }
}
