import { NextRequest, NextResponse } from "next/server";
import {
  figmaFileKeyFromUrl,
  figmaNodeIdFromUrl,
  listFigmaImageNodes,
  listFigmaNodeChildren,
  listFigmaPages,
  renderFigmaImages,
} from "@/lib/figma";
import { saveAsset } from "@/lib/asset-store";

/**
 * Step 1: list syncable nodes for a Figma file so the user can pick which to import.
 * If the pasted URL (or an explicit ?node=) points at a specific node-id, list that
 * node's immediate children instead of just the file's first page/canvas.
 * ?pages=1 instead lists the file's top-level pages (canvases), for files with
 * more than one page where you need to find the right one first.
 */
export async function GET(req: NextRequest) {
  const fileUrlOrKey = req.nextUrl.searchParams.get("file");
  if (!fileUrlOrKey) {
    return NextResponse.json({ error: "Missing ?file=" }, { status: 400 });
  }
  try {
    const fileKey = figmaFileKeyFromUrl(fileUrlOrKey);
    if (req.nextUrl.searchParams.get("pages") === "1") {
      const { fileName, pages } = await listFigmaPages(fileKey);
      return NextResponse.json({ fileKey, fileName, pages });
    }
    const nodeId = req.nextUrl.searchParams.get("node") ?? figmaNodeIdFromUrl(fileUrlOrKey);
    const { fileName, nodes } = nodeId
      ? await listFigmaNodeChildren(fileKey, nodeId)
      : await listFigmaImageNodes(fileKey);
    return NextResponse.json({ fileKey, fileName, nodes });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}

/** Step 2: render + download the chosen nodes into the asset library. */
export async function POST(req: NextRequest) {
  const { fileKey, fileName, nodeIds, folder, tags } = (await req.json()) as {
    fileKey: string;
    fileName?: string;
    nodeIds: string[];
    folder?: string;
    tags?: string[];
  };

  if (!fileKey || !nodeIds?.length) {
    return NextResponse.json({ error: "fileKey and nodeIds are required" }, { status: 400 });
  }

  try {
    const images = await renderFigmaImages(fileKey, nodeIds);
    const saved = [];
    for (const image of images) {
      const res = await fetch(image.imageUrl);
      const buffer = Buffer.from(await res.arrayBuffer());
      saved.push(
        await saveAsset({
          buffer,
          originalName: `${image.name}.png`,
          mimeType: "image/png",
          tags: tags ?? [],
          folder: folder || "Figma",
          source: { type: "figma", fileKey, fileName, nodeId: image.nodeId },
        })
      );
    }
    return NextResponse.json({ assets: saved });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
