import { NextResponse } from "next/server";
import { listAssets } from "@/lib/asset-store";

export async function GET() {
  const assets = await listAssets();
  return NextResponse.json({ assets });
}
