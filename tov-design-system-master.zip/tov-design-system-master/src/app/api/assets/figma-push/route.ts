import { NextRequest, NextResponse } from "next/server";
import { listAssets, updateAssets } from "@/lib/asset-store";
import { CORS_HEADERS } from "@/lib/cors";

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}

/**
 * There's no write-capable Figma REST API — actually placing images into a
 * Figma file requires the Plugin API, which only runs through an assisted
 * agent session (e.g. Claude Code), not this server. So this route doesn't
 * push anything itself; it just tracks which marketing uploads are
 * requested/pushed, so that agent session knows what to do next.
 *
 * POST { campaign, pageType, action: "request" } -> flags un-pushed image
 *   assets in that folder as requested.
 * POST { ids, action: "complete" } -> marks assets as pushed (called once
 *   the agent has actually placed them in Figma).
 */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as {
    action: "request" | "complete";
    campaign?: string;
    pageType?: string;
    ids?: string[];
  };

  if (body.action === "request") {
    if (!body.campaign || !body.pageType) {
      return NextResponse.json(
        { error: "campaign and pageType are required" },
        { status: 400, headers: CORS_HEADERS }
      );
    }
    const assets = await listAssets();
    const ids = assets
      .filter(
        (a) =>
          a.category === "marketing" &&
          a.campaign === body.campaign &&
          a.pageType === body.pageType &&
          a.mimeType.startsWith("image/") &&
          !a.figmaPushedAt
      )
      .map((a) => a.id);
    if (ids.length === 0) {
      return NextResponse.json({ requested: 0, assets: [] }, { headers: CORS_HEADERS });
    }
    const updated = await updateAssets(ids, { figmaPushRequestedAt: new Date().toISOString() });
    return NextResponse.json({ requested: updated.length, assets: updated }, { headers: CORS_HEADERS });
  }

  if (body.action === "complete") {
    if (!body.ids?.length) {
      return NextResponse.json({ error: "ids are required" }, { status: 400, headers: CORS_HEADERS });
    }
    const updated = await updateAssets(body.ids, {
      figmaPushedAt: new Date().toISOString(),
      figmaPushRequestedAt: undefined,
    });
    return NextResponse.json({ pushed: updated.length, assets: updated }, { headers: CORS_HEADERS });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400, headers: CORS_HEADERS });
}
