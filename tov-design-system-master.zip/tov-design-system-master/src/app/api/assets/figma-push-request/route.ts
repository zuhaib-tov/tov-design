import { NextRequest, NextResponse } from "next/server";
import { upsertAssetPatch, type AssetRecord } from "@/lib/asset-store";

/**
 * The "Push to Figma" button click on a precisely-slotted asset (see
 * figma-slot/route.ts, which only assigns the target and never queues a
 * push by itself). There's no write-capable Figma REST API — actually
 * placing the image still requires the Plugin API, which only runs through
 * an assisted agent session — so this just timestamps the request; the next
 * live session with Claude picks up everything with figmaPushRequestedAt
 * set and unset figmaPushedAt, places it via the Plugin API, then marks it
 * pushed.
 */
export async function POST(req: NextRequest) {
  const body = (await req.json()) as { asset?: AssetRecord };
  if (!body.asset?.id) {
    return NextResponse.json({ error: "asset is required" }, { status: 400 });
  }
  if (!body.asset.figmaTargetNodeIds?.length) {
    return NextResponse.json({ error: "asset has no assigned slot" }, { status: 400 });
  }

  const updated = await upsertAssetPatch(body.asset, {
    figmaPushRequestedAt: new Date().toISOString(),
  });

  return NextResponse.json({ asset: updated });
}
