import { NextRequest, NextResponse } from "next/server";
import { checkForDriftDetailed, readDriftLog, readStatus, markReviewed, WATCH_LIST, type DriftEntry } from "@/lib/figma-watch";
import { locateWatch } from "@/lib/watch/locate";

const withPages = (entries: DriftEntry[]) => entries.map((e) => ({ ...e, pages: locateWatch(e.watchId) }));

export const maxDuration = 300;

/** Manual trigger — the same code path the Figma webhook will call once deployed. */
export async function POST(req: NextRequest) {
  const { fileKey } = await req.json().catch(() => ({ fileKey: undefined }));
  try {
    const raw = await checkForDriftDetailed(fileKey);
    const result = { ...raw, newDrift: withPages(raw.newDrift) };
    if (result.failed.length > 0) {
      const total = result.checked + result.failed.length;
      return NextResponse.json(
        { ...result, newDriftCount: result.newDrift.length, error: `${result.failed.length} of ${total} watched nodes could not be checked (${result.failed[0].error})` },
        { status: 502 },
      );
    }
    return NextResponse.json({ ...result, newDriftCount: result.newDrift.length });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}

export async function GET() {
  const log = await readDriftLog();
  const status = await readStatus();
  return NextResponse.json({
    log: withPages(log),
    unreviewedCount: log.filter((e) => !e.reviewed).length,
    status,
    watchCount: WATCH_LIST.length,
    fileCount: new Set(WATCH_LIST.map((w) => w.fileKey)).size,
  });
}

export async function PATCH(req: NextRequest) {
  const { driftId } = await req.json();
  const ok = await markReviewed(driftId);
  return NextResponse.json({ reviewed: ok });
}
