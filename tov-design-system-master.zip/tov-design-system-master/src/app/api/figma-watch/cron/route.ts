import { NextRequest, NextResponse } from "next/server";
import { checkForDriftDetailed } from "@/lib/figma-watch";

export const maxDuration = 300;

/** Scheduled drift check. Vercel Cron calls this with `Authorization: Bearer $CRON_SECRET`. */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return NextResponse.json({ error: "CRON_SECRET is not configured" }, { status: 503 });
  if (req.headers.get("authorization") !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const result = await checkForDriftDetailed();
  // A node that cannot be fetched (expired FIGMA_TOKEN, deleted node) fails the run so it shows up in Vercel's logs.
  if (result.failed.length > 0) {
    return NextResponse.json({ ...result, newDriftCount: result.newDrift.length, error: `${result.failed.length} watched nodes could not be checked` }, { status: 502 });
  }
  return NextResponse.json({ ...result, newDriftCount: result.newDrift.length });
}
