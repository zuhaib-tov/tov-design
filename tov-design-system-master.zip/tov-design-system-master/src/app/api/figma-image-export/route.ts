import { NextRequest, NextResponse } from "next/server";
import { figmaFileKeyFromUrl, figmaNodeIdFromUrl, listFigmaImageFills } from "@/lib/figma";

/**
 * Lists the real image-fill assets (not flattened renders) under a Figma
 * node, so a "Copy link to selection" URL for a frame/page/section returns
 * every underlying photo used in it — including ones with text or other
 * layers stacked on top, since this reads the original fill asset rather
 * than rendering the composited node.
 */
export async function GET(req: NextRequest) {
  const fileUrlOrKey = req.nextUrl.searchParams.get("file");
  if (!fileUrlOrKey) {
    return NextResponse.json({ error: "Missing ?file=" }, { status: 400 });
  }

  const fileKey = figmaFileKeyFromUrl(fileUrlOrKey);
  const nodeId = req.nextUrl.searchParams.get("node") ?? figmaNodeIdFromUrl(fileUrlOrKey);
  if (!nodeId) {
    return NextResponse.json(
      {
        error:
          "No node-id found in that URL. In Figma, select the frame/page/section you want, right-click, and use \"Copy link to selection\" — that link includes the node-id this tool needs.",
      },
      { status: 400 }
    );
  }

  try {
    const { fileName, images } = await listFigmaImageFills(fileKey, nodeId);
    return NextResponse.json({ fileKey, fileName, nodeId, images });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
