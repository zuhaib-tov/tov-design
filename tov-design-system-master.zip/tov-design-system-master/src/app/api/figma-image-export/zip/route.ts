import { NextRequest, NextResponse } from "next/server";
import JSZip from "jszip";
import { extensionForContentType, getFigmaImageFillUrls, sanitizeFilename } from "@/lib/figma";

/**
 * Zips several image fills at once. Takes a fileKey + list of {ref, name}
 * pairs and re-resolves each download URL server-side via Figma's own API,
 * same reasoning as the single-file download route.
 */
export async function POST(req: NextRequest) {
  const { fileKey, images } = (await req.json()) as {
    fileKey: string;
    images: { ref: string; name: string }[];
  };
  if (!fileKey || !images?.length) {
    return NextResponse.json({ error: "fileKey and images are required" }, { status: 400 });
  }

  try {
    const urls = await getFigmaImageFillUrls(fileKey);
    const zip = new JSZip();
    const usedNames = new Set<string>();

    for (const { ref, name } of images) {
      const url = urls[ref];
      if (!url) continue;
      const res = await fetch(url);
      if (!res.ok) continue;
      const buffer = Buffer.from(await res.arrayBuffer());
      const ext = extensionForContentType(res.headers.get("content-type"));

      let filename = `${sanitizeFilename(name)}.${ext}`;
      let i = 2;
      while (usedNames.has(filename)) {
        filename = `${sanitizeFilename(name)}-${i}.${ext}`;
        i++;
      }
      usedNames.add(filename);

      zip.file(filename, buffer);
    }

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });
    return new NextResponse(new Uint8Array(zipBuffer), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="figma-images.zip"`,
      },
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
