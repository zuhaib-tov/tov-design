import { NextRequest, NextResponse } from "next/server";
import { extensionForContentType, getFigmaImageFillUrls, sanitizeFilename } from "@/lib/figma";

/**
 * Downloads a single image fill. Takes a fileKey + imageRef (not a raw URL)
 * and re-resolves the download URL server-side via Figma's own API — the
 * server never fetches an arbitrary client-supplied URL, so this can't be
 * used as an open proxy.
 */
export async function GET(req: NextRequest) {
  const fileKey = req.nextUrl.searchParams.get("file");
  const imageRef = req.nextUrl.searchParams.get("ref");
  const name = req.nextUrl.searchParams.get("name") ?? "image";
  if (!fileKey || !imageRef) {
    return NextResponse.json({ error: "file and ref are required" }, { status: 400 });
  }

  try {
    const urls = await getFigmaImageFillUrls(fileKey);
    const url = urls[imageRef];
    if (!url) {
      return NextResponse.json({ error: "Image not found for that ref" }, { status: 404 });
    }

    const res = await fetch(url);
    if (!res.ok) {
      return NextResponse.json({ error: `Failed to fetch image (${res.status})` }, { status: 502 });
    }
    const buffer = Buffer.from(await res.arrayBuffer());
    const ext = extensionForContentType(res.headers.get("content-type"));

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": res.headers.get("content-type") ?? "image/png",
        "Content-Disposition": `attachment; filename="${sanitizeFilename(name)}.${ext}"`,
      },
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
