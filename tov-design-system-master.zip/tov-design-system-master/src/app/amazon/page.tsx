import Link from "next/link";
import { PROPERTIES } from "@/lib/nav";

const AMAZON_NAV_SECTIONS = PROPERTIES.find((p) => p.key === "amazon")!.sections;

export default function AmazonOverview() {
  return (
    <div className="max-w-4xl px-8 py-10">
      <p className="text-xs font-semibold uppercase tracking-wide-ui text-primary mb-3">
        Version 0.1 · Internal
      </p>
      <h1 className="font-display text-5xl text-primary-dark mb-4">TOV x Amazon</h1>
      <p className="text-ink-muted max-w-2xl mb-10 text-lg">
        The design system for TOV&apos;s Amazon storefront — a separate property from the B2C site
        above, with its own components (nothing shared between the two). Built from 2-3 source
        Figma files covering the A+ Content and Store modules documented below.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {AMAZON_NAV_SECTIONS.filter((s) => s.title !== "Get started").map((section) => (
          <div key={section.title} className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
            <h2 className="font-display text-lg text-ink mb-3">{section.title}</h2>
            <ul className="flex flex-col gap-2">
              {section.items.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-primary-dark hover:text-primary hover:underline"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
