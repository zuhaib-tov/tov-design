import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import { AmazonComfortConstructionCard } from "@/components/ui/AmazonComfortConstructionCard";
import {
  COMFORT_CONSTRUCTION_FIGMA_FILE_KEY,
  COMFORT_CONSTRUCTION_FIGMA_FILE_URL,
  COMFORT_CONSTRUCTION_SLOTS,
} from "@/lib/amazon/figma-slots";

export default function ComfortConstructionPage() {
  return (
    <DocPage
      title="Comfort & Construction"
      description={
        'A+ Content module — a shared "Comfort and Construction modules" component reused ' +
        '36 times across two sections ("Module 4 Comfort", "Module 4 Construction", node ' +
        "23:792), each instance already showing a real photo. Unlike Category Hero, this " +
        'isn\'t one slot per category — categories repeat (multiple "Accent Chairs", ' +
        '"Sectionals" x3, etc.), a visual-variety grid rather than a 1:1 mapping. Every ' +
        "instance's fill stack is messy in the source (2-3 stacked images, only the top one " +
        "visible)."
      }
    >
      <DocSection
        title={
          <>
            Comfort / Construction Card <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Built from the canonical &quot;Comfort and Construction modules&quot; symbol (node
          16:193, inside section 16:189, 650x350) — a plain photo card: no overlay, no pill label,
          no icon, no text of any kind. &quot;Comfort&quot; and &quot;Construction&quot; are
          category labels on the instances, not visual variants, so one component covers both.
          Rendered at its native 650:350 (~1.86:1) aspect ratio.
        </p>
        <p className="text-sm text-ink-muted mb-4 max-w-2xl rounded-app-md bg-cream-100 px-4 py-3">
          Node 16:193&apos;s <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">cornerRadius</code> is 0 on all
          four corners — genuinely square. A live populated instance (18:908, &quot;Module 4
          Comfort - Accent Chairs 1&quot;) matches: cornerRadius 0, no child layers, no overlay,
          pill, icon, or text at the instance level either.
        </p>
        <Preview align="start" code={`<AmazonComfortConstructionCard />`}>
          <AmazonComfortConstructionCard />
          <AmazonComfortConstructionCard />
          <AmazonComfortConstructionCard />
        </Preview>
      </DocSection>

      <DocSection title="Per-instance uploads">
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          34 real instances across &quot;Module 4 Comfort&quot; and &quot;Module 4
          Construction&quot; (node 23:792) — the same node this slot list was built from. Upload a
          replacement image per instance below; this is a visual-variety grid, not a 1:1 category
          mapping, so some category names repeat across multiple slots (e.g. three
          &quot;Sectionals&quot;).
        </p>
        <FigmaSlotUploader
          folder="Amazon — Comfort & Construction"
          figmaFileKey={COMFORT_CONSTRUCTION_FIGMA_FILE_KEY}
          figmaFileUrl={COMFORT_CONSTRUCTION_FIGMA_FILE_URL}
          slots={COMFORT_CONSTRUCTION_SLOTS}
        />
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        This is a composition of atoms already under Components.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-comfort-construction" />
      </div>
    </DocPage>
  );
}
