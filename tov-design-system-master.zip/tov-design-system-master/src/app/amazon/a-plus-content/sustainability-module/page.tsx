import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Badge } from "@/components/ui/Badge";
import {
  SUSTAINABILITY_MODULE_EXPECTED_SIZE,
  SUSTAINABILITY_MODULE_FIGMA_FILE_URL,
} from "@/lib/amazon/figma-slots";

export default function SustainabilityModulePage() {
  const { width, height } = SUSTAINABILITY_MODULE_EXPECTED_SIZE;

  return (
    <DocPage
      title="Sustainability Module"
      description={
        "A+ Content module — a single evergreen lifestyle photo (a styled living-room " +
        "vignette: green chair, marble side table, brass floor lamp), reused as-is across " +
        "placements rather than swapped per category. There's nothing to upload here; the " +
        `requirement is a guaranteed pixel-exact ${width}×${height} download of this exact image.`
      }
    >
      <DocSection
        title={
          <>
            Evergreen photo <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          This is a real, finished photo — not a placeholder — at exactly {width}×{height}.
          The same underlying component is reused for the Storage and Collections modules.
        </p>

        <div className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white max-w-md">
          <div className="bg-cream-100 flex items-center justify-center p-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/api/amazon/sustainability-module"
              alt="Sustainability Module — evergreen lifestyle photo"
              width={width}
              height={height}
              className="max-w-full h-auto rounded-app-md"
            />
          </div>
          <div className="p-4 flex items-center justify-between gap-4">
            <p className="text-xs text-ink-muted">
              {width}×{height} PNG, rendered at scale 1 directly from node 18:520.
            </p>
            <a
              href="/api/amazon/sustainability-module?download=1"
              download={`sustainability-module-${width}x${height}.png`}
              className="inline-flex items-center justify-center gap-2 rounded-pill bg-charcoal text-white border border-charcoal hover:bg-cream-50 hover:text-charcoal transition-colors text-[11px] px-5 py-2.5 font-bold uppercase tracking-wide-ui whitespace-nowrap"
            >
              Download PNG
            </a>
          </div>
        </div>

        <p className="text-sm text-ink-muted mt-4 max-w-2xl rounded-app-md bg-cream-100 px-4 py-3">
          A Figma image *fill* is often a larger original photo cropped/scaled to fit its
          frame (`scaleMode: FILL/FIT/CROP/TILE`), so exporting &quot;the original fill
          asset&quot; the way the{" "}
          <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">
            figma-image-export
          </code>{" "}
          tool does could silently return something other than {width}×{height}. This
          page&apos;s image and download instead call Figma&apos;s own image-render
          endpoint (
          <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">
            renderFigmaFrame
          </code>{" "}
          in{" "}
          <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">
            src/lib/figma.ts
          </code>
          ) at scale 1 for node 18:520 directly — it composites the fill exactly as
          shown and returns a PNG sized to the node&apos;s own layout box, which
          sidesteps the crop-vs-original-asset question rather than trying to infer it
          from `scaleMode` metadata. The API route (
          <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">
            src/app/api/amazon/sustainability-module
          </code>
          ) also decodes the real PNG dimensions on every request and refuses to serve a
          mismatch.
        </p>

        <p className="text-xs text-ink-muted mt-3">
          Source:{" "}
          <a
            href={SUSTAINABILITY_MODULE_FIGMA_FILE_URL}
            target="_blank"
            rel="noreferrer"
            className="underline hover:text-ink"
          >
            Module 7 Sustainability in Figma
          </a>
        </p>
      </DocSection>
      <div className="mt-6">
        <ChangeLogTable page="amazon-sustainability-module" />
      </div>
    </DocPage>
  );
}
