import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { Badge } from "@/components/ui/Badge";
import { Logo } from "@/components/ui/Logo";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import {
  BRAND_STORY_FIGMA_FILE_KEY,
  BRAND_STORY_FIGMA_FILE_URL,
  BRAND_STORY_SLOTS,
} from "@/lib/amazon/figma-slots";

const LOOKS = [
  {
    name: "Tagline — dark",
    copy: '"TOV / Always en Vogue / Never overpriced" lockup, dark leopard-print panel',
  },
  {
    name: "Don't Be Boring — dark",
    copy: '"DON\'T BE BORING." bold copy, same dark leopard-print panel',
  },
  {
    name: "Don't Be Boring — light",
    copy: '"DON\'T BE BORING." bold copy, cream panel',
  },
];

export default function BrandStoryPage() {
  return (
    <div className="max-w-4xl px-8 py-10">
      <div className="flex items-center gap-3 mb-2">
        <h1 className="font-display text-4xl text-primary-dark">Brand Story</h1>
        <Badge variant="neutral">Not started</Badge>
      </div>
      <p className="text-ink-muted max-w-2xl mb-2">
        A+ Content module — a full-bleed hero used to open a product&apos;s A+ page. Node 3:4
        (&quot;Brand Story&quot;) in the &quot;TOV26 - Amazon - Premium A+ content&quot; file
        (fileKey P6ISgCbxCzraEqRtTr0j3P) contains two sibling frames: &quot;Background IMG&quot;
        (6 symbols) and &quot;Logos&quot; (2 symbols).
      </p>
      <p className="text-ink-muted max-w-2xl mb-2">
        &quot;Background IMG&quot; is <strong className="text-ink">3 real looks</strong>
        {" "}(a color-scheme + copy combination), each a Desktop/Mobile pair sharing the same
        underlying photo — not 6 unrelated variants. Every look&apos;s real photo fill lives one
        level below the symbol Figma gave us (same &quot;fill on the child frame, not the
        symbol&quot; trap as Category Hero&apos;s &quot;Frame 1260&quot;). Mobile is{" "}
        <strong className="text-ink">463px wide</strong>, not this app&apos;s usual 375px.
      </p>
      <p className="text-ink-muted max-w-2xl mb-6">
        The &quot;Don&apos;t Be Boring — dark&quot; look&apos;s Mobile node lists the same image
        reference as its Desktop/other-look siblings, but renders as Figma&apos;s blank
        checkerboard — a broken/orphaned image reference in the source file, not a mapping mistake
        here. See the code comment on{" "}
        <code className="font-mono text-xs bg-cream-100 rounded-app-sm px-1 py-0.5">
          BRAND_STORY_SLOTS
        </code>{" "}
        for the full node-level trail.
      </p>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 mb-6">
        <h2 className="font-display text-lg text-ink mb-4">Background looks</h2>
        <div className="flex flex-col gap-5">
          {LOOKS.map((look) => (
            <div key={look.name} className="flex flex-col sm:flex-row gap-3 sm:items-center">
              <div className="flex gap-2 shrink-0">
                <div className="bg-image-placeholder w-40 aspect-[868/625] rounded-app-md overflow-hidden border border-neutral-200" />
                <div className="bg-image-placeholder w-16 aspect-[463/625] rounded-app-md overflow-hidden border border-neutral-200" />
              </div>
              <div>
                <p className="text-sm font-semibold text-ink">{look.name}</p>
                <p className="text-xs text-ink-muted">{look.copy}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-ink-muted mt-4">
          Left swatch = Desktop (868×625 real fill frame), right = Mobile. Every look already
          carries a real photo in Figma except the gap noted above.
        </p>
      </div>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 mb-6">
        <h2 className="font-display text-lg text-ink mb-3">Logos</h2>
        <p className="text-sm text-ink-muted mb-4">
          The &quot;Logos&quot; frame&apos;s 2 symbols are finished, real brand lockups already
          part of the design system — not empty &quot;Background IMG&quot;-style placeholders.
          Since there&apos;s nothing to photograph or replace here (it&apos;s vector brand chrome,
          not merchandising photography), they&apos;re rendered directly below with the existing
          {" "}<code className="font-mono text-xs bg-cream-100 rounded-app-sm px-1 py-0.5">Logo</code>{" "}
          component instead of going through the upload-slot mechanism the looks above use.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-app-md bg-cream-100 p-8 flex items-center justify-center">
            <Logo className="h-10" />
          </div>
          <div className="rounded-app-md bg-cream-100 p-8 flex flex-col items-center justify-center text-center">
            <span className="flex items-center gap-1 text-xs font-semibold text-ink">
              <Logo className="h-4" />
            </span>
            <span className="font-display text-3xl text-ink leading-none mt-1">
              ALWAYS{" "}
              <em className="italic" style={{ color: "var(--color-brand-pink)" }}>
                en Vogue
              </em>
            </span>
            <span className="text-[10px] uppercase tracking-wide-ui text-ink-muted mt-2">
              Never overpriced.
            </span>
          </div>
        </div>
        <p className="text-xs text-ink-muted mt-3">
          &quot;Default&quot; = the plain TOV wordmark (exact match to the existing{" "}
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">Logo.tsx</code>).
          &quot;Variant2&quot; = a full &quot;TOV / Always en Vogue / Never overpriced&quot; tagline
          lockup — a different tagline than the &quot;Don&apos;t Be Boring&quot; lockups already in{" "}
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">public/brand/</code>,
          reproduced here inline rather than added as a new Core asset, since it&apos;s specific to
          Brand Story.
        </p>
      </div>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 mb-6">
        <h2 className="font-display text-lg text-ink mb-3">Planned page-level components</h2>
        <ul className="flex flex-col gap-2">
          {[
            "3 background looks (Tagline, Don't Be Boring — Dark, Don't Be Boring — Light), each Desktop + Mobile",
            "Logo lockup — wordmark",
            "Logo lockup — tagline",
          ].map((item) => (
            <li key={item} className="text-sm text-ink-muted flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <FigmaSlotUploader
        folder="Amazon — Brand Story"
        figmaFileKey={BRAND_STORY_FIGMA_FILE_KEY}
        figmaFileUrl={BRAND_STORY_FIGMA_FILE_URL}
        slots={BRAND_STORY_SLOTS}
      />

      <div className="mt-6 rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        These are compositions of the atoms already under Components — e.g. a Product Gallery
        combines Badge, Rating, and Price. Nothing on this page is built yet — this is a
        placeholder for the structure. See{" "}
        <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">FIGMA_SYSTEMS.md</code> for
        this system&apos;s Figma file and sync status.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-brand-story" />
      </div>
    </div>
  );
}
