import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import { AmazonCategoryHeroDesktop, AmazonCategoryHeroMobile } from "@/components/ui/AmazonCategoryHero";
import {
  CATEGORY_HERO_FIGMA_FILE_KEY,
  CATEGORY_HERO_FIGMA_FILE_URL,
  CATEGORY_HERO_SLOTS,
} from "@/lib/amazon/figma-slots";

function ViewportLabel({ children }: { children: string }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-wide-ui text-ink-muted mt-6 mb-2 first:mt-0">
      {children}
    </p>
  );
}

export default function CategoryHeroPage() {
  return (
    <DocPage
      title="Category Hero"
      description="A+ Content module — a hero banner per furniture category (22 categories: Living Room, Accent Chairs, Sofas, Sectionals, and more). One uploaded image per category fills both its Desktop and Mobile variant. Found in the 'Category Heros' section (node 23:688) on the '🟠 Sept - 2026' page, not the Components library page."
    >
      <DocSection
        title={
          <>
            Hero Module <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Built from the Components-page &quot;Hero Module&quot; set (node 9:324)&apos;s{" "}
          <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">desktop</code> /{" "}
          <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">mobile</code> variants
          (9:323 / 9:325, 1464x600 / 600x450) — a full-bleed photo with a bottom-left category pill
          and 2-line headline (last word italic, desktop only). There is no scrim/overlay in either
          variant, and the mobile variant&apos;s headline has no italic run at all (a real divergence
          from desktop, kept as-is). Full value-by-value detail is in the component file&apos;s own
          header comment.
        </p>
        <ViewportLabel>Desktop</ViewportLabel>
        <Preview align="start" code={`<AmazonCategoryHeroDesktop />`}>
          <AmazonCategoryHeroDesktop />
        </Preview>
        <ViewportLabel>Mobile</ViewportLabel>
        <Preview align="start" code={`<AmazonCategoryHeroMobile />`}>
          <AmazonCategoryHeroMobile />
        </Preview>
      </DocSection>

      <DocSection title="Per-category instances">
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          22 real furniture categories, each already carrying a real, finished photo in Figma — a
          replace, never a first-time fill-in. Upload a new image per category below and assign it
          to the exact Desktop + Mobile node pair.
        </p>
        <FigmaSlotUploader
          folder="Amazon — Category Hero"
          figmaFileKey={CATEGORY_HERO_FIGMA_FILE_KEY}
          figmaFileUrl={CATEGORY_HERO_FIGMA_FILE_URL}
          slots={CATEGORY_HERO_SLOTS}
        />
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        This is a composition of atoms already under Components — e.g. Logo plus the same pill
        treatment used by Badge&apos;s dark variants.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-category-hero" />
      </div>
    </DocPage>
  );
}
