import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { Badge } from "@/components/ui/Badge";
import { Preview } from "@/components/docs/Preview";
import { AmazonVideoThumbnail } from "@/components/ui/AmazonVideoThumbnail";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import {
  VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_KEY,
  VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_URL,
  VIDEO_THUMBNAIL_MODULE_SLOTS,
} from "@/lib/amazon/figma-slots";

export default function VideoThumbnailModulePage() {
  return (
    <div className="max-w-4xl px-8 py-10">
      <div className="flex items-center gap-3 mb-2">
        <h1 className="font-display text-4xl text-primary-dark">Video Thumbnail Module</h1>
        <Badge variant="success">Built</Badge>
      </div>
      <p className="text-ink-muted max-w-2xl mb-6">
        A+ Content module — a per-category photo, structurally simple compared to Materials/Hero
        Module: one design, no Desktop/Mobile split (canonical symbol &quot;Video Tumbnail
        Module&quot; — Figma&apos;s own typo, not carried into this component&apos;s name — node
        15:235, 800×600). 16 real category instances live under &quot;Module 3 - 2 Colum Text +
        Video&quot; (node 23:918).
      </p>

      <Preview
        code={`<AmazonVideoThumbnail category="Accent Chairs" imageSrc="/accent-chairs.jpg" />
<AmazonVideoThumbnail category="Bar & Counter Stools" />`}
      >
        <AmazonVideoThumbnail category="Accent Chairs" />
      </Preview>

      <div className="mt-6">
        <FigmaSlotUploader
          folder="Amazon — Video Thumbnail Module"
          figmaFileKey={VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_KEY}
          figmaFileUrl={VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_URL}
          slots={VIDEO_THUMBNAIL_MODULE_SLOTS}
        />
      </div>

      <div className="mt-6 rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        This is a composition of the atoms already under Components — same pattern as every other
        Amazon module page. See{" "}
        <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">FIGMA_SYSTEMS.md</code> for
        this system&apos;s Figma file and sync status.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-video-thumbnail-module" />
      </div>
    </div>
  );
}
