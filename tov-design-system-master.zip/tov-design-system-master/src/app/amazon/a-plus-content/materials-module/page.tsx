import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import { AmazonMaterialsCard, MATERIALS_CATEGORIES } from "@/components/ui/AmazonMaterialsModule";
import {
  MATERIALS_MODULE_FIGMA_FILE_KEY,
  MATERIALS_MODULE_FIGMA_FILE_URL,
  MATERIALS_MODULE_SLOTS,
} from "@/lib/amazon/figma-slots";

export default function MaterialsModulePage() {
  return (
    <DocPage
      title="Materials Module"
      description="A+ Content module — a single reusable card (full-bleed photo, category pill top-left, icon badge bottom-right) used 54 times across 4 categories in the real file: Design, Material, Durable, and Craftsmanship. Found in the Components page frame &quot;Materials&quot; (node 9:265, fileKey P6ISgCbxCzraEqRtTr0j3P) and resolved against the real, populated instance library (&quot;Module 2 - 4 Colum Images&quot;, node 18:893)."
    >
      <DocSection
        title={
          <>
            Materials Card <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Built from the Components-page &quot;Materials&quot; frame (9:265)&apos;s 4 symbols —
          still legacy <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">Property 1=</code>{" "}
          named, never trusted at face value. <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">Property 1=Variant3</code>{" "}
          and <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">Property 1=Variant4</code>{" "}
          only resolve to real names by cross-referencing the populated instance library — they
          are <strong>Durable</strong> and <strong>Craftsmanship</strong>, matching the real photo
          content behind &quot;Module 2 Durable&quot; (12 instances) and &quot;Module 2
          Craftsmanship&quot; (18 instances). <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">Design</code>{" "}
          and <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">Material</code>{" "}
          already matched by name.
        </p>
        <p className="text-sm text-ink-muted mb-4 max-w-2xl rounded-app-md bg-cream-100 px-4 py-3">
          The pill and badge both have a fully transparent fill (alpha 0), yet render as a soft
          white capsule on the empty/checkered state and a soft dark capsule on a real photo
          (e.g. &quot;Module 2 Design - Materials 1&quot;, node 18:896) — consistent with a
          background blur (&quot;frosted glass&quot;) effect. Reproduced with{" "}
          <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">backdrop-blur</code>{" "}
          + a low-opacity white fill, which gives the same behind-sampling look natively rather
          than a flat, static color — an approximation, not a pixel-measured blur radius.
        </p>
        <Preview
          align="start"
          code={MATERIALS_CATEGORIES.map((c) => `<AmazonMaterialsCard category="${c}" />`).join("\n")}
        >
          <div className="flex flex-wrap gap-4">
            {MATERIALS_CATEGORIES.map((category) => (
              <AmazonMaterialsCard key={category} category={category} />
            ))}
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Per-instance photos">
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          54 real instances across the 4 categories (17 Design, 7 Material, 12 Durable, 18
          Craftsmanship), every one already carrying a real, finished photo — a replace, never a
          first-time fill-in. Unlike Comfort &amp; Construction, these instances&apos; own Figma
          layer names are just an ordinal (&quot;Module 2 Design - Materials 1&quot;, etc.) with no
          real furniture category encoded — slot names below are ordinal per category for the same
          reason. Content varies (real product photography), there&apos;s just no better label to
          give each one.
        </p>
        <FigmaSlotUploader
          folder="Amazon — Materials Module"
          figmaFileKey={MATERIALS_MODULE_FIGMA_FILE_KEY}
          figmaFileUrl={MATERIALS_MODULE_FIGMA_FILE_URL}
          slots={MATERIALS_MODULE_SLOTS}
        />
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        This is a composition of atoms already under Components — the pill matches Badge&apos;s
        dark variants&apos; treatment, the icon badge is new to this component.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-materials-module" />
      </div>
    </DocPage>
  );
}
