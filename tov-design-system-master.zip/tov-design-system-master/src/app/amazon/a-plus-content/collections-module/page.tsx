import { PageSystemStub } from "@/components/docs/PageSystemStub";

export default function CollectionsModulePage() {
  return (
    <PageSystemStub
      title="Collections Module"
      description="A+ Content module — 'Module 9 Collections (Best Sellers)' in the working 'Feb - 2026' page (node 2005:1386). This reuses the same generic flexible module as the Storage and Sustainability modules elsewhere in the file — its instance is named 'Sustainability Module' in the source because all three share one underlying component."
      planned={["Collections / best-sellers card"]}
    />
  );
}
