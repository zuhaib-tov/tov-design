import { PageSystemStub } from "@/components/docs/PageSystemStub";

export default function AboutUsPage() {
  return (
    <PageSystemStub
      title="About Us"
      description="Amazon Store module — About Us page. No Figma source is mapped for this page yet; it will use the same 'Update images in Figma' uploader as the other Amazon Store pages once a source file is linked."
      planned={["Brand story / about content"]}
    />
  );
}
