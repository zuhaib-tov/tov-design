import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import { AmazonStorefrontBanner } from "@/components/ui/AmazonStorefrontBanner";
import { AmazonCategoryTile } from "@/components/ui/AmazonCategoryTile";
import {
  AMAZON_STORE_FIGMA_FILE_KEY,
  STOREFRONT_FIGMA_FILE_URL,
  STOREFRONT_HERO_SLOTS,
  STOREFRONT_CATEGORY_TILE_SLOTS,
  STOREFRONT_THREE_TILE_GRID_SLOTS,
} from "@/lib/amazon/figma-slots";

export default function StorefrontPage() {
  return (
    <DocPage
      title="Storefront"
      description={
        "Amazon Store module — the storefront landing page. Three sections carry real upload " +
        "slots — Banner images, Category images, and the 3-Tile Grid promo — each broken out " +
        "below with its own visual reference and uploader. The header and the video/content-" +
        "block section are text-only with no image fills, so neither gets upload slots."
      }
    >
      <DocSection
        title={
          <>
            Hero Banners <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Every Hero node (e.g. Desktop 34:1264, 1920x777, ~2.47:1) is a leaf frame with no child
          text layers — the headline, subhead, and CTA are baked directly into the photo. Mobile
          nodes (e.g. 34:1316) sit under a same-size 1500x1110 wrapper with no crop, ~1.35:1. Plain
          full-bleed image, no separate text props.
        </p>
        <Preview
          align="start"
          code={`<AmazonStorefrontBanner aspectRatio={1920 / 777} maxWidth={480} />`}
        >
          <AmazonStorefrontBanner aspectRatio={1920 / 777} maxWidth={480} imageAlt="Hero 1 — Desktop" />
          <AmazonStorefrontBanner aspectRatio={1500 / 1110} maxWidth={300} imageAlt="Hero 1 — Mobile" />
        </Preview>
        <FigmaSlotUploader
          folder="Amazon — Storefront — Hero Banners"
          figmaFileKey={AMAZON_STORE_FIGMA_FILE_KEY}
          figmaFileUrl={STOREFRONT_FIGMA_FILE_URL}
          slots={STOREFRONT_HERO_SLOTS}
        />
      </DocSection>

      <DocSection
        title={
          <>
            Category Tiles <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          <strong>Not</strong> a flat image like Hero/3-Tile Grid. Each tile is a photo (750x598)
          above a separate white caption block with two real Figma text layers: a 48px &quot;GT
          Ultra Fine&quot; title and a 36px underlined &quot;Gotham Book&quot; &quot;Shop
          now&quot; link, both in #3f3d3e — an exact match for this app&apos;s existing{" "}
          <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">--color-charcoal</code>{" "}
          token. Home Office, Outdoor, Lighting, and Decor&apos;s image nodes each sit next to
          their own matching caption text.
        </p>
        <Preview
          align="start"
          code={`<AmazonCategoryTile title="Home office" />\n<AmazonCategoryTile title="Outdoor" />\n<AmazonCategoryTile title="Decor" />`}
        >
          <AmazonCategoryTile title="Home office" className="w-[240px]" />
          <AmazonCategoryTile title="Outdoor" className="w-[240px]" />
          <AmazonCategoryTile title="Decor" className="w-[240px]" />
        </Preview>
        <FigmaSlotUploader
          folder="Amazon — Storefront — Category Tiles"
          figmaFileKey={AMAZON_STORE_FIGMA_FILE_KEY}
          figmaFileUrl={STOREFRONT_FIGMA_FILE_URL}
          slots={STOREFRONT_CATEGORY_TILE_SLOTS}
        />
      </DocSection>

      <DocSection
        title={
          <>
            3-Tile Grid <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Same flat, pre-composited shape as Hero — plain full-bleed image, headline/subhead/
          &quot;SHOP NOW&quot; pill baked into the photo, no separate text layers.
        </p>
        <p className="text-sm text-ink-muted mb-4 max-w-2xl rounded-app-md bg-cream-100 px-4 py-3">
          <strong>Dimensions are not uniform across the 3 tiles</strong> — Bedroom and Living
          Room&apos;s Desktop + Mobile nodes are all 1500x750 (2:1), but Nightstand Desktop
          (76:186) is 1500x1500, a full square. Nightstand&apos;s own Mobile node (76:204) is
          back to 1500x750 — Desktop and Mobile don&apos;t share a crop within the same tile.
        </p>
        <Preview
          align="start"
          code={`<AmazonStorefrontBanner aspectRatio={1500 / 750} maxWidth={280} />\n<AmazonStorefrontBanner aspectRatio={1} maxWidth={200} />`}
        >
          <AmazonStorefrontBanner aspectRatio={1500 / 750} maxWidth={280} imageAlt="3-Tile Grid — Bedroom — Desktop" />
          <AmazonStorefrontBanner aspectRatio={1500 / 750} maxWidth={280} imageAlt="3-Tile Grid — Living Room — Desktop" />
          <AmazonStorefrontBanner aspectRatio={1} maxWidth={200} imageAlt="3-Tile Grid — Nightstand — Desktop (square — not 2:1 like its siblings)" />
        </Preview>
        <FigmaSlotUploader
          folder="Amazon — Storefront — 3-Tile Grid"
          figmaFileKey={AMAZON_STORE_FIGMA_FILE_KEY}
          figmaFileUrl={STOREFRONT_FIGMA_FILE_URL}
          slots={STOREFRONT_THREE_TILE_GRID_SLOTS}
        />
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        These are compositions of the atoms already under Components. Best Sellers (embedded in
        this same Figma section but broken out as its own page,{" "}
        <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">store/best-sellers</code>)
        is still a bare &quot;Not started&quot; stub.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-storefront" />
      </div>
    </DocPage>
  );
}
