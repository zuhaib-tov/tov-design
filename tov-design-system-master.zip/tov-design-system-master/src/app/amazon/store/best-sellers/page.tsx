import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { Badge } from "@/components/ui/Badge";
import { FigmaSlotUploader } from "@/components/amazon/FigmaSlotUploader";
import {
  AMAZON_STORE_FIGMA_FILE_KEY,
  BEST_SELLERS_FIGMA_FILE_URL,
  BEST_SELLERS_SLOTS,
} from "@/lib/amazon/figma-slots";

export default function BestSellersPage() {
  return (
    <div className="max-w-4xl px-8 py-10">
      <div className="flex items-center gap-3 mb-2">
        <h1 className="font-display text-4xl text-primary-dark">Best Seller Page</h1>
        <Badge variant="neutral">Not started</Badge>
      </div>
      <p className="text-ink-muted max-w-2xl mb-6">
        Amazon Store module — the &quot;Best sellers&quot; banner (Desktop + Mobile). In Figma
        this lives embedded inside the Storefront&apos;s Banner Images section rather than as its
        own top-level frame, but it&apos;s broken out as its own page here to match how the site
        is actually organized. &quot;TOV25 - B2C - Amazon store&quot; file, &quot;Store front
        components&quot; page.
      </p>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 mb-6">
        <h2 className="font-display text-lg text-ink mb-3">Planned page-level components</h2>
        <ul className="flex flex-col gap-2">
          {["Best sellers banner — Desktop", "Best sellers banner — Mobile"].map((item) => (
            <li key={item} className="text-sm text-ink-muted flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <FigmaSlotUploader
        folder="Amazon — Best Sellers"
        figmaFileKey={AMAZON_STORE_FIGMA_FILE_KEY}
        figmaFileUrl={BEST_SELLERS_FIGMA_FILE_URL}
        slots={BEST_SELLERS_SLOTS}
      />

      <div className="mt-6 rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        These are compositions of the atoms already under Components — e.g. a Product Gallery
        combines Badge, Rating, and Price. Nothing on this page is built yet — this is a
        placeholder for the structure. See{" "}
        <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">FIGMA_SYSTEMS.md</code> for
        this system&apos;s Figma file and sync status.
      </div>
      <div className="mt-6">
        <ChangeLogTable page="amazon-best-sellers" />
      </div>
    </div>
  );
}
