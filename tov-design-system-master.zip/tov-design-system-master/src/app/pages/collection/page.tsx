import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { PLPProductCard } from "@/components/ui/PLPProductCard";
import { PLPListingCard, type PLPListingCardProps } from "@/components/ui/PLPListingCard";
import { PLPProductRowDesktop, PLPProductRowMobile } from "@/components/ui/PLPProductRow";
import { PLPCategoryHeroDesktop, PLPCategoryHeroMobile } from "@/components/ui/PLPCategoryHero";
import { PLPReviewsDesktop, PLPReviewsMobile } from "@/components/ui/PLPReviews";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const IMG = "/images/plp/";

/** The six card types from the Figma Product Display section, in Figma's order. */
const CARD_TYPES: { type: string; note: string; card: PLPListingCardProps }[] = [
  {
    type: "1 · Image badge only",
    note: "A badge on the photo, name and price. Nothing else.",
    card: {
      image: `${IMG}benito.jpg`,
      name: 'Benito 55" Concrete Indoor/Outdoor Coffee Table',
      price: "$799",
      badges: [{ variant: "new-arrival", label: "New Arrival" }],
    },
  },
  {
    type: "2 · Badge + callout",
    note: "Adds one callout line above the name.",
    card: {
      image: `${IMG}florence.jpg`,
      name: "Florence Linen Accent Chair",
      price: "$679",
      badges: [{ variant: "new-arrival", label: "New Arrival" }],
      performanceFabric: true,
    },
  },
  {
    type: "3 · Badge + callout, long name",
    note: "The name wraps to two lines and the price moves down with it.",
    card: {
      image: `${IMG}vivienne.jpg`,
      name: "Vivienne Upcycled Performance Velvet Accent Chair",
      price: "$849",
      badges: [{ variant: "new-arrival", label: "New Arrival" }],
      performanceFabric: true,
    },
  },
  {
    type: "4 · Two callouts",
    note: "Two callout lines. The price is a range.",
    card: {
      image: `${IMG}bara.jpg`,
      name: "Bara Performance Velvet Bed",
      price: "$1,199 – $1,399",
      badges: [{ variant: "new-arrival", label: "New Arrival" }],
      newColor: true,
      performanceFabric: true,
    },
  },
  {
    type: "5 · Two badges + sale price",
    note: "Two badges side by side. A sale range is followed by the original price struck through.",
    card: {
      image: `${IMG}skyla.jpg`,
      name: "Skyla Swivel Accent Chair",
      price: "$449 – $649",
      wasPrice: "$499",
      badges: [
        { variant: "new-arrival", label: "New Arrival" },
        { variant: "final-sale", label: "Final Sale" },
      ],
      performanceFabric: true,
    },
  },
  {
    type: "6 · Most callouts",
    note: "New color and new size share a line, with Performance Fabric under it.",
    card: {
      image: `${IMG}dex.jpg`,
      name: "Dex Ottoman",
      price: "$149 – $169",
      badges: [{ variant: "best-seller", label: "Best Seller" }],
      newColor: true,
      newSize: true,
      performanceFabric: true,
    },
  },
];

const CARD_SPEC: [string, string][] = [
  ["Card", "302px wide. The photo is 302 × 379px with a 16px radius on a #F0F0F0 ground"],
  ["Badges", "12px from the top and left of the photo, 6px apart. Medium badge size (27px tall)"],
  ["Heart", "28px target, 20px from the right and 16px from the top. 24px outline heart, 1.4px #3F3D3E"],
  ["Gap, photo to text", "20px. Inside the text: 4px after the delivery line, 2px between callouts and name, 5px before the price"],
  ["Delivery line", "14px gift icon, 4px gap, 10/12 SemiBold #713A40. A seasonal line above the callouts"],
  ["Callouts", "12/16. New color and New size: Medium, uppercase, #3F4B59 and #777777, joined by a +. Performance Fabric: ExtraBold, sentence case, #3F4B59"],
  ["Name", "18/27 Regular #333333. Wraps to two lines or more"],
  ["Price", "18/21 Bold #333333. A range reads $449 – $649. On sale: #A0585E Bold, then the original price struck through in #767676 Regular, 8px apart"],
];

export default function CollectionPage() {
  return (
    <DocPage
      title="Collection (PLP)"
      description="Category and search results — mapped from the OG 'TOV26 - PLP Designs System' file's '💠Components' page. Covers browsing and narrowing down a set of products."
    >
      <DocSection title={<>Product Card <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Real 3-variant set — Default (Desktop), Mobile, and a denser grid variant with a
          square image and a &quot;+N more&quot; swatch-overflow label. Every field in Figma is
          template placeholder content (empty checker image, literal &quot;Product name&quot;/
          &quot;$0000.00&quot;) — kept as placeholders rather than inventing product data.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPProductCard size="desktop" />`}>
          <PLPProductCard size="desktop" />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop — Quick Shop (hover)</p>
        <Preview align="start" code={`<PLPProductCard size="desktop" showQuickShop />`}>
          <PLPProductCard size="desktop" showQuickShop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPProductCard size="mobile" badge="New Arrival · Sale" />`}>
          <PLPProductCard size="mobile" badge="New Arrival · Sale" />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Dense grid</p>
        <Preview align="start" code={`<PLPProductCard size="dense" badge="New Arrival · Sale" />`}>
          <PLPProductCard size="dense" badge="New Arrival · Sale" />
        </Preview>
      </DocSection>

      <DocSection title={<>Product card types <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Six types of card that differ by what sits around the photo and name: badges, callout lines and the price. They come
          from the Figma frame &quot;Version 5 — Gift icon + text&quot; and use real products. Each is shown without and with
          the seasonal delivery line. Cards are drawn at real size, so the rows scroll sideways.
        </p>
        <div className="mb-5 overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <tbody>
              {CARD_SPEC.map(([k, v], i) => (
                <tr key={k} className={i > 0 ? "border-t border-neutral-200" : ""}>
                  <td className="whitespace-nowrap px-4 py-2.5 align-top font-semibold text-ink">{k}</td>
                  <td className="px-4 py-2.5 text-ink-muted">{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {[
          { title: "Without delivery line", delivery: undefined },
          { title: "With delivery line", delivery: "Get it by Dec. 4th" },
        ].map((row) => (
          <div key={row.title} className="mt-6 first-of-type:mt-0">
            <p className="text-sm font-semibold text-ink mb-2">{row.title}</p>
            <div className="overflow-x-auto rounded-app-lg border border-neutral-200 bg-white">
              <div className="flex w-max items-start gap-6 p-6">
                {CARD_TYPES.map((t) => (
                  <div key={t.type} className="w-[302px] shrink-0">
                    <p className="font-sans text-[11px] font-semibold uppercase leading-[13px] text-ink">{t.type}</p>
                    <p className="mb-3 mt-1 min-h-[42px] font-sans text-[11px] leading-[14px] text-ink-muted">{t.note}</p>
                    <PLPListingCard {...t.card} delivery={row.delivery} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Badge text is 10px Bold with the system&apos;s +4.5% all-caps spacing; Figma sets 2%. The delivery line is a seasonal
          message, so it is optional on every type.
        </p>
      </DocSection>

      <DocSection title={<>Product Row <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          A simple horizontal row of Product Cards, 10px gap — 4 cards Desktop, 2 Mobile.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPProductRowDesktop />`}>
          <PLPProductRowDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPProductRowMobile />`}>
          <PLPProductRowMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Root Category Hero <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Breadcrumb + display-font title + a placeholder sub-heading + a scrollable row of
          sub-category cards. The sub-heading is literally &quot;B1 - Sub heading 80–120
          characters&quot; in the source — a content-authoring placeholder describing the copy
          length to write, not real copy — kept verbatim.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPCategoryHeroDesktop />`}>
          <PLPCategoryHeroDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPCategoryHeroMobile />`}>
          <PLPCategoryHeroMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Reviews <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Mapped from the main design system file&apos;s &quot;💬Reviews&quot; canvas (node
          1612:4859) — trust header + rating breakdown/summary + filters + a 3-card review
          grid. Star fill is <code className="font-mono text-xs bg-cream-100 rounded-app-sm px-1 py-0.5">#F9D2D2</code>,
          an exact match for the existing <code className="font-mono text-xs bg-cream-100 rounded-app-sm px-1 py-0.5">brand-pink</code> token
          — built inline rather than reusing the PDP <code className="font-mono text-xs bg-cream-100 rounded-app-sm px-1 py-0.5">Rating</code> component,
          which uses a different color.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPReviewsDesktop />`}>
          <PLPReviewsDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPReviewsMobile />`}>
          <PLPReviewsMobile />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">Not yet mapped:</strong> this canvas also has a real
          10-variant set of individual review-card layouts (cards with photos/video — &quot;Frame
          1077&quot;, Desktop 1-4 / Mobile 1-4) and a full 8-variant &quot;Write a Review&quot;
          authoring flow (Desktop: Default/step 2/All Images/Success; Mobile: 4 steps) with its
          own image upload and success states. Both are substantial enough to be their own
          mapping pass, not rushed into this one.
        </div>
      </DocSection>

      <ChangeLogTable page="collection" />
    </DocPage>
  );
}
