import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { MarketingHeroDesktop, MarketingHeroMobile } from "@/components/ui/MarketingHero";
import {
  MarketingCategoryCardsDesktop,
  MarketingCategoryCardsMobile,
} from "@/components/ui/MarketingCategoryCards";
import { MarketingImageGridDesktop, MarketingImageGridMobile } from "@/components/ui/MarketingImageGrid";
import {
  MarketingProductCardsDesktop2Col,
  MarketingProductCardsDesktop3Col,
  MarketingProductCardsMobile,
} from "@/components/ui/MarketingProductCards";
import {
  MarketingBannerOverlayDesktop,
  MarketingBannerOverlayMobile,
  MarketingBannerSplitDesktop,
  MarketingBannerSplitMobile,
} from "@/components/ui/MarketingBanner";
import {
  MarketingContentBlockProductImageDesktop,
  MarketingContentBlockProductImageMobile,
  MarketingContentBlockRoomShotDesktop,
  MarketingContentBlockRoomShotMobile,
} from "@/components/ui/MarketingContentBlock";
import {
  MarketingAnnouncementBarDesktop,
  MarketingAnnouncementBarMobile,
} from "@/components/ui/MarketingAnnouncementBar";
import {
  MarketingTextBlockCenteredDesktop,
  MarketingTextBlockCenteredMobile,
  MarketingTextBlockWithListDesktop,
  MarketingTextBlockWithListMobile,
} from "@/components/ui/MarketingTextBlock";
import { MarketingSignOffDesktop, MarketingSignOffMobile } from "@/components/ui/MarketingSignOff";
import {
  MarketingCartReminderSingleDesktop,
  MarketingCartReminderSingleMobile,
  MarketingCartReminderMultiDesktop,
  MarketingCartReminderMultiMobile,
} from "@/components/ui/MarketingCartReminder";
import { MarketingIncentiveDesktop, MarketingIncentiveMobile } from "@/components/ui/MarketingIncentive";
import {
  MarketingStyledByYouDesktop,
  MarketingStyledByYouMobile,
} from "@/components/ui/MarketingStyledByYou";

function ViewportLabel({ children }: { children: string }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-wide-ui text-ink-muted mt-6 mb-2 first:mt-0">
      {children}
    </p>
  );
}

export default function MarketingEmailPage() {
  return (
    <DocPage
      title="Email"
      description="Marketing email components — mapped from the dedicated 'TOV — B2C — Design system' Figma file's '✉️ TOV Email Components' canvas, 'Marketing email components' section (node 1753:459). All 12 component sets are built. Every one is still Status=Draft in Figma."
    >
      <DocSection
        title={
          <>
            Hero <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          4 real variants: Full Width x Inset, each x Desktop x Mobile. Inset wraps the same
          card in extra outer margin (30px desktop / 10px mobile) rather than being a
          different component.
        </p>
        <ViewportLabel>Full Width — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingHeroDesktop />`}>
          <MarketingHeroDesktop />
        </Preview>
        <ViewportLabel>Inset — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingHeroDesktop inset />`}>
          <MarketingHeroDesktop inset />
        </Preview>
        <ViewportLabel>Full Width — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingHeroMobile />`}>
          <MarketingHeroMobile />
        </Preview>
        <ViewportLabel>Inset — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingHeroMobile inset />`}>
          <MarketingHeroMobile inset />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Category Cards <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Desktop is a 4-up row; Mobile is a 2x2 grid. Card bottom-padding is 12px desktop /
          14px mobile — a real divergence, not a shared value.
        </p>
        <ViewportLabel>4 Column — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingCategoryCardsDesktop />`}>
          <MarketingCategoryCardsDesktop />
        </Preview>
        <ViewportLabel>2x2 Grid — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingCategoryCardsMobile />`}>
          <MarketingCategoryCardsMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Image Grid <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Pure 2x2 photo grid, no text or CTA. Cell radius is 24px desktop / 16px mobile.
        </p>
        <ViewportLabel>2x2 Grid — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingImageGridDesktop />`}>
          <MarketingImageGridDesktop />
        </Preview>
        <ViewportLabel>2x2 Grid — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingImageGridMobile />`}>
          <MarketingImageGridMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Product Cards <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          3 real variants: 2 Column and 3 Column on Desktop, 2 Column on Mobile. Image radius
          is 24px (2-col desktop) vs 16px (3-col desktop + both mobile). Sale price uses
          --color-mauve; the strikethrough compare-at price uses an unbound #8a8788 (no
          matching token yet).
        </p>
        <ViewportLabel>2 Column — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingProductCardsDesktop2Col />`}>
          <MarketingProductCardsDesktop2Col />
        </Preview>
        <ViewportLabel>3 Column — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingProductCardsDesktop3Col />`}>
          <MarketingProductCardsDesktop3Col />
        </Preview>
        <ViewportLabel>2 Column — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingProductCardsMobile />`}>
          <MarketingProductCardsMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Banner <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          2 real variants: Image Overlay and Split, each Desktop/Mobile. Image Overlay
          stacks two scrims (23% + 20% black, ~38% combined). Split's product-image half is
          unrounded, unlike the rounded treatment used elsewhere in this section.
        </p>
        <ViewportLabel>Image Overlay — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingBannerOverlayDesktop />`}>
          <MarketingBannerOverlayDesktop />
        </Preview>
        <ViewportLabel>Image Overlay — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingBannerOverlayMobile />`}>
          <MarketingBannerOverlayMobile />
        </Preview>
        <ViewportLabel>Split — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingBannerSplitDesktop />`}>
          <MarketingBannerSplitDesktop />
        </Preview>
        <ViewportLabel>Split — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingBannerSplitMobile />`}>
          <MarketingBannerSplitMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Content Block <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          2 real variants: Product Image and Room Shot, each Desktop/Mobile. Uses an outline
          button (transparent fill, charcoal border) — not the shared Button.tsx system.
          Product Image wraps content in a cream card; Room Shot has no wrapper fill at all.
        </p>
        <ViewportLabel>Product Image — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingContentBlockProductImageDesktop />`}>
          <MarketingContentBlockProductImageDesktop />
        </Preview>
        <ViewportLabel>Product Image — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingContentBlockProductImageMobile />`}>
          <MarketingContentBlockProductImageMobile />
        </Preview>
        <ViewportLabel>Room Shot — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingContentBlockRoomShotDesktop />`}>
          <MarketingContentBlockRoomShotDesktop />
        </Preview>
        <ViewportLabel>Room Shot — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingContentBlockRoomShotMobile />`}>
          <MarketingContentBlockRoomShotMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Announcement Bar <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Background is a raw hex literal in Figma matching --color-charcoal — bound to the
          token here. Letter-spacing (20%) is unusually wide versus the rest of the section.
        </p>
        <ViewportLabel>Default — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingAnnouncementBarDesktop />`}>
          <MarketingAnnouncementBarDesktop />
        </Preview>
        <ViewportLabel>Default — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingAnnouncementBarMobile />`}>
          <MarketingAnnouncementBarMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Text Block <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          2 real variants: Centered and With List, each Desktop/Mobile. With List's item
          rows mix two real run styles per line — an underlined SKU code plus a plain
          product name, not one uniform style.
        </p>
        <ViewportLabel>Centered — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingTextBlockCenteredDesktop />`}>
          <MarketingTextBlockCenteredDesktop />
        </Preview>
        <ViewportLabel>Centered — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingTextBlockCenteredMobile />`}>
          <MarketingTextBlockCenteredMobile />
        </Preview>
        <ViewportLabel>With List — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingTextBlockWithListDesktop />`}>
          <MarketingTextBlockWithListDesktop />
        </Preview>
        <ViewportLabel>With List — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingTextBlockWithListMobile />`}>
          <MarketingTextBlockWithListMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Sign-off <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          No bound variables anywhere in this component — every color is a literal hex in
          the source file.
        </p>
        <ViewportLabel>Default — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingSignOffDesktop />`}>
          <MarketingSignOffDesktop />
        </Preview>
        <ViewportLabel>Default — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingSignOffMobile />`}>
          <MarketingSignOffMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Cart Reminder <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          2 real variants: Single Item and Multi Item, each Desktop/Mobile. Multi Item is a
          genuine structural fork, not a responsive reflow — Desktop pins price to the right
          of name/quantity, Mobile stacks price inline below quantity, left-aligned.
        </p>
        <ViewportLabel>Single Item — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingCartReminderSingleDesktop />`}>
          <MarketingCartReminderSingleDesktop />
        </Preview>
        <ViewportLabel>Single Item — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingCartReminderSingleMobile />`}>
          <MarketingCartReminderSingleMobile />
        </Preview>
        <ViewportLabel>Multi Item — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingCartReminderMultiDesktop />`}>
          <MarketingCartReminderMultiDesktop />
        </Preview>
        <ViewportLabel>Multi Item — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingCartReminderMultiMobile />`}>
          <MarketingCartReminderMultiMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Incentive <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          Code box border is dashed charcoal, not a plain solid line. Card background
          (--color-cream-50) is a different cream than Sign-off/Styled By You
          (--color-cream-200) — not interchangeable.
        </p>
        <ViewportLabel>Discount Code — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingIncentiveDesktop />`}>
          <MarketingIncentiveDesktop />
        </Preview>
        <ViewportLabel>Discount Code — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingIncentiveMobile />`}>
          <MarketingIncentiveMobile />
        </Preview>
      </DocSection>

      <DocSection
        title={
          <>
            Styled By You <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="text-sm text-ink-muted mb-4 max-w-2xl">
          The one component in this section whose headline is genuinely set in "GT Ultra
          Fine Trial" in Figma — uses the site's real font-display face rather than the
          Gotham → Montserrat substitution used everywhere else here.
        </p>
        <ViewportLabel>Default — Desktop</ViewportLabel>
        <Preview align="start" code={`<MarketingStyledByYouDesktop />`}>
          <MarketingStyledByYouDesktop />
        </Preview>
        <ViewportLabel>Default — Mobile</ViewportLabel>
        <Preview align="start" code={`<MarketingStyledByYouMobile />`}>
          <MarketingStyledByYouMobile />
        </Preview>
      </DocSection>

      <ChangeLogTable page="marketing-email" />
    </DocPage>
  );
}
