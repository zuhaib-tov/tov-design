import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { PLPProductRowDesktop, PLPProductRowMobile } from "@/components/ui/PLPProductRow";
import {
  TovEditsDirectoryBreadcrumb,
  TovEditsPageBreadcrumb,
  TovEditsHeading,
  TovEditsGrid,
  TovEditsHero,
  TovEditsFinishingTouchesBanner,
} from "@/components/ui/TovEditsSections";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function TovEditsPage() {
  return (
    <DocPage
      title="TOV Edits"
      description={
        'TOV\'s curated editorial "Edits" (styled stories/roundups) — mapped from the ' +
        "\"TOV26 - B2C - TOV Edits\" Figma file (node 1:4). Nothing in this file is labeled " +
        "with real page names (two frames even share the literal section name \"Edits - " +
        "Landing Page design\") — the two distinct pages below were identified from actual " +
        "content, not labels. See the callout and each component's JSDoc for the full " +
        "identification reasoning."
      }
    >
      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">Page identification:</strong>{" "}
        Two frames in the source share the exact section name &quot;Edits - Landing Page
        design.&quot; The short one (Desktop 1440×1172) has a &quot;TOV Edits&quot; H1 directly
        under the navbar and a 3-up grid of lifestyle tiles — no product content — matching{" "}
        <strong className="text-ink">the directory</strong> from the stub description. The tall
        one (Desktop 1440×4877) has a breadcrumb reading &quot;Home / TOV Edits / The [Name]
        Edit&quot; (a 3rd crumb level = a child page of the directory), then a hero + 24–32
        curated <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">PLPProductCard</code>s
        + a mid-page editorial banner — matching{" "}
        <strong className="text-ink">an individual Edit&apos;s own page</strong>. Two more
        sections in the file (&quot;Edits - Homepage Placements&quot; and &quot;Marketing
        Module&quot;) are Homepage content and a separate cross-sell promo card, not Edits pages
        themselves, and are out of scope here.
      </div>

      <DocSection title={<>Directory / Landing Page</>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8015:1447</code> (Desktop, 1440×1172) /{" "}
          <code className="font-mono">8015:1765</code> (Mobile, 375×2145). Real structure: navbar
          (existing <code className="font-mono">MainNav</code>) → breadcrumb (Home / TOV Edits,
          current page) → &quot;TOV Edits&quot; heading → a 3-tile grid → footer (existing{" "}
          <code className="font-mono">Footer</code>). Navbar/Footer aren&apos;t re-shown below.
        </p>

        <p className="text-sm font-semibold text-ink mb-2">Breadcrumb</p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:10393</code> — &quot;Home / TOV Edits&quot; only
          (one segment shorter than the individual page&apos;s crumb below), so it&apos;s a small
          inline variant rather than a call to the shared{" "}
          <code className="font-mono">PDPBreadCrumbs</code> component, whose shape is fixed at 2
          link segments after the icon.
        </p>
        <Preview align="start" code={`<TovEditsDirectoryBreadcrumb />`}>
          <TovEditsDirectoryBreadcrumb />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">
          Heading <Badge variant="sale">New · Unreviewed</Badge>
        </p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:7053</code> (Desktop) /{" "}
          <code className="font-mono">8023:9826</code> (Mobile) — centered display-font title +
          subcopy, no border (unlike New Arrivals&apos; bordered heading).
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<TovEditsHeading />`}>
          <TovEditsHeading />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<TovEditsHeading compact />`}>
          <TovEditsHeading compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">
          Tile Grid <Badge variant="sale">New · Unreviewed</Badge>
        </p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:7040</code> &quot;TOV - Edits - 3 Edits&quot;
          (Desktop) / <code className="font-mono">8080:3002</code> &quot;TOV - Edits - 2
          Edits&quot; — which, despite the name, actually contains 3 stacked tiles on the real
          Mobile page (another label-vs-content mismatch). A component-exploration area
          elsewhere in the file shows isolated 2-tile and 3-tile states of this same grid, read
          as &quot;supports 2 or 3 Edits,&quot; hence the <code className="font-mono">count</code>{" "}
          prop below. Desktop tiles center their text over a flat black gradient; Mobile tiles
          left-align text over a genuinely different duotone (mix-blend-multiply) gradient — a
          real per-viewport difference.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop (3 tiles)</p>
        <Preview align="start" code={`<TovEditsGrid />`}>
          <TovEditsGrid />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop (2 tiles)</p>
        <Preview align="start" code={`<TovEditsGrid count={2} />`}>
          <TovEditsGrid count={2} />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile (3 tiles, stacked)</p>
        <Preview align="start" code={`<TovEditsGrid compact />`}>
          <TovEditsGrid compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Individual Edit Page</>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:4971</code> (Desktop, 1440×4877) /{" "}
          <code className="font-mono">8023:5028</code> (Mobile, 375×6934). Real structure: navbar
          → breadcrumb (Home / TOV Edits / The [Name] Edit) → hero → curated product grid (24
          cards Desktop in 6 rows of 4, 32 cards Mobile in 16 rows of 2 — the two viewports don&apos;t
          reconcile to the same count in this draft file, reproduced as authored) with one
          mid-page editorial banner breaking up the grid after the 3rd Desktop row / 9th Mobile
          row → footer. Navbar/Footer aren&apos;t re-shown below.
        </p>

        <p className="text-sm font-semibold text-ink mb-2">Breadcrumb</p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:10413</code> — pixel-identical to the
          already-mapped &amp; already-synced <code className="font-mono">PDPBreadCrumbs</code>{" "}
          (15px home icon, 10px Montserrat #777, 0.5px/10px dot separators), reused directly
          rather than rebuilt.
        </p>
        <Preview align="start" code={`<TovEditsPageBreadcrumb />`}>
          <TovEditsPageBreadcrumb />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">
          Hero <Badge variant="sale">New · Unreviewed</Badge>
        </p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:4980</code> (Desktop) /{" "}
          <code className="font-mono">8023:5030</code> (Mobile) — full-bleed image, 33% black
          scrim, centered title + subcopy, 578px tall on both viewports. A hidden alternate hero
          draft sits in the same spot in the source (real copy: &quot;Amara&quot; / &quot;Warm,
          textural, and effortlessly inviting...&quot;) — excluded since Figma itself marks it{" "}
          <code className="font-mono">hidden</code>.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<TovEditsHero />`}>
          <TovEditsHero />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<TovEditsHero compact />`}>
          <TovEditsHero compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Product Grid</p>
        <p className="text-xs text-ink-muted mb-3">
          Reuses the already-mapped <code className="font-mono">PLPProductRowDesktop</code>/
          <code className="font-mono">PLPProductRowMobile</code> as-is — it matches this
          file&apos;s own &quot;Product card&quot; instances exactly (badge, price, swatch shape).
          Shown as one representative row pair per viewport; the real page repeats this 6 times
          (Desktop) / 16 times (Mobile) around the banner below.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPProductRowDesktop />\n<PLPProductRowDesktop />`}>
          <div className="flex flex-col gap-2.5 w-full">
            <PLPProductRowDesktop />
            <PLPProductRowDesktop />
          </div>
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPProductRowMobile />\n<PLPProductRowMobile />`}>
          <div className="flex flex-col gap-2.5 w-full">
            <PLPProductRowMobile />
            <PLPProductRowMobile />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">
          Mid-Page Editorial Banner &quot;The finishing touches.&quot;{" "}
          <Badge variant="sale">New · Unreviewed</Badge>
        </p>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8023:4992</code> (Desktop) /{" "}
          <code className="font-mono">8023:5173</code> (Mobile) — unlike every other placeholder
          in this file, this copy (&quot;Just landed&quot; / &quot;The finishing touches.&quot; /
          &quot;Accents that do the heavy lifting, from statement vases to side tables that earn
          their square footage.&quot;) reads as genuinely authored marketing copy, not a
          length-placeholder, so it&apos;s reproduced as real content. Structurally similar to{" "}
          <code className="font-mono">NewArrivalsGetTheLookBanner</code> (same bag-add→
          bag-outline.svg icon approximation) but a separate component, following that file&apos;s
          own precedent of not cross-reusing visually-similar banners between different Figma
          files/systems. Figma&apos;s source has no dark scrim on this banner (unlike the Hero and
          Grid tiles above) — reproduced faithfully, though that reads low-contrast over this
          project&apos;s gray placeholder image.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<TovEditsFinishingTouchesBanner />`}>
          <TovEditsFinishingTouchesBanner />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<TovEditsFinishingTouchesBanner compact />`}>
          <TovEditsFinishingTouchesBanner compact />
        </Preview>
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">New / unreviewed components:</strong> the Directory
        Heading, Tile Grid, individual-page Hero, and the &quot;finishing touches&quot;
        mid-page banner are new assembled patterns with no existing equivalent elsewhere in the
        design system — built and shown above, but{" "}
        <strong className="text-ink">not</strong> logged in FIGMA_SYSTEMS.md&apos;s Sync Log or
        COMPONENT_CHANGELOG.md as officially synced pieces. Only the reused pieces (Product Grid = existing{" "}
        <code className="font-mono">PLPProductRowDesktop</code>/
        <code className="font-mono">PLPProductRowMobile</code>, and the individual page&apos;s
        breadcrumb = existing <code className="font-mono">PDPBreadCrumbs</code>) are logged
        below as officially synced.
      </div>

      <ChangeLogTable page="tov-edits" />
    </DocPage>
  );
}
