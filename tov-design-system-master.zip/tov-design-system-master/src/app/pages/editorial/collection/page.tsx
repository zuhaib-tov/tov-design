import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { PLPProductRowDesktop, PLPProductRowMobile } from "@/components/ui/PLPProductRow";
import {
  CollectionBanner,
  CollectionTile,
  CollectionsLandingHeading,
  SignatureCollectionsHeading,
} from "@/components/ui/CollectionsLandingSections";
import {
  CollectionHero,
  CollectionLookbookBlock,
  CollectionShapeTheLook,
} from "@/components/ui/CollectionPageSections";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const IMG = "/images/collections-lp";

export default function EditorialCollectionPage() {
  return (
    <DocPage
      title="Collection"
      description={
        'TOV\'s curated editorial collections — a "Collections" concept distinct from the ' +
        "standard category/PLP browsing pages under Pages. Covers both the directory listing " +
        "every collection (\"Collections Landing\") and each individual collection's own page, " +
        "mapped from two separate Figma files below."
      }
    >
      {/* ================================================================ */}
      {/* Collections Landing                                             */}
      {/* ================================================================ */}
      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">Collections Landing</strong> — mapped from &quot;TOV26 - B2C -
        Explore collections LP&quot; (fileKey <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">oO2Li1XutYUUAgUUs4f3lJ</code>,
        node <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">1:5</code>).
        Structure: navbar (existing{" "}
        <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">MainNav</code>) →
        heading → 4 repeats of [a full-bleed Collection Banner + a row of 4/2 Product Cards] → a
        &quot;Signature collections&quot; heading + a row/grid of 4 smaller Collection Tiles →
        footer (existing <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">Footer</code>).
        Navbar and Footer aren&apos;t re-shown below.
      </div>

      <DocSection title={<>Heading</>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">6084:486</code> (Desktop) / <code className="font-mono">6052:1392</code> (Mobile).
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<CollectionsLandingHeading />`}>
          <CollectionsLandingHeading />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<CollectionsLandingHeading compact />`}>
          <CollectionsLandingHeading compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Collection Banner <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Desktop: 1240×500 image inset 100px in the 1440 frame, rounded 36px. Mobile: 335×400
          inset 20px in the 375 frame, rounded 16px. Real lifestyle photography + a bordered
          (outline, not filled) &quot;Shop the collection&quot; pill. The &quot;Hump&quot;
          banner&apos;s title is set to <code className="font-mono">opacity:0</code> in the source
          and is shown here with the title restored. The &quot;Cynthia&quot; banner uses the exact
          same background photo as &quot;Amara&quot;&apos;s (a byte-identical file) — likely a
          mislabeled photo in the source, reproduced as-is. See the component&apos;s own doc
          comment for Mobile&apos;s duplicated/mismatched banner instances.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop — 4 real instances</p>
        <Preview align="start" code={`<CollectionBanner image="..." name="The Cynthia Collection" />`}>
          <div className="flex flex-col gap-4 w-full">
            <CollectionBanner image={`${IMG}/banner-cynthia-amara-shared.png`} name="The Cynthia Collection" />
            <CollectionBanner image={`${IMG}/banner-cynthia-amara-shared.png`} name="Amara" />
            <CollectionBanner image={`${IMG}/banner-hump.jpg`} name="Hump" />
            <CollectionBanner image={`${IMG}/banner-marlow.jpg`} name="Marlow" />
          </div>
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<CollectionBanner compact image="..." name="The Cynthia Collection" />`}>
          <div className="flex flex-col gap-4 w-full max-w-sm">
            <CollectionBanner compact image={`${IMG}/banner-cynthia-amara-shared.png`} name="The Cynthia Collection" />
            <CollectionBanner compact image={`${IMG}/banner-hump.jpg`} name="Hump" />
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Product Grid</>}>
        <p className="text-xs text-ink-muted mb-3">
          Reuses the already-mapped Collection (PLP) <code className="font-mono">PLPProductRowDesktop</code>/
          <code className="font-mono">PLPProductRowMobile</code> as-is (4/2 <code className="font-mono">PLPProductCard</code>s),
          rather than forking a new card for this file&apos;s round swatches, real photography, and
          no-badge treatment.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPProductRowDesktop />`}>
          <PLPProductRowDesktop />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPProductRowMobile />`}>
          <PLPProductRowMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Signature Collections — Collection Tile <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The smaller variant of the same banner pattern. Desktop: 306.25×362, rounded 36px,
          4-up row. Mobile: full-width×190, rounded 16px, 2×2 grid. CTA copy genuinely differs by
          viewport — &quot;Shop collection&quot; (Desktop) vs. lowercase &quot;shop Now&quot;
          (Mobile) — reproduced verbatim.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<SignatureCollectionsHeading />\n<CollectionTile image="..." name="Hotlist" />`}>
          <div className="flex flex-col gap-4 w-full">
            <SignatureCollectionsHeading />
            <div className="grid grid-cols-4 gap-4">
              <CollectionTile image={`${IMG}/tile-hotlist.png`} name="Hotlist" />
              <CollectionTile image={`${IMG}/tile-eco-conscious.png`} name="Eco-conscious" />
              <CollectionTile image={`${IMG}/tile-performance-fabric.png`} name="Performance Fabric" />
              <CollectionTile image={`${IMG}/tile-inspire-home-decor.png`} name="Inspire me home decor" />
            </div>
          </div>
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<SignatureCollectionsHeading compact />\n<CollectionTile compact image="..." name="Hotlist" />`}>
          <div className="flex flex-col gap-4 w-full max-w-sm">
            <SignatureCollectionsHeading compact />
            <div className="grid grid-cols-2 gap-3">
              <CollectionTile compact image={`${IMG}/tile-hotlist.png`} name="Hotlist" />
              <CollectionTile compact image={`${IMG}/tile-eco-conscious.png`} name="Eco-conscious" />
              <CollectionTile compact image={`${IMG}/tile-performance-fabric.png`} name="Performance Fabric" />
              <CollectionTile compact image={`${IMG}/tile-inspire-home-decor.png`} name="Inspire me home decor" />
            </div>
          </div>
        </Preview>
      </DocSection>

      {/* ================================================================ */}
      {/* Collection — Individual Page                                    */}
      {/* ================================================================ */}
      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
        <strong className="text-ink">Collection — Individual Page</strong> — a single curated
        collection&apos;s own page (hero, description, product grid), as opposed to the
        Collections Landing directory above. Mapped from a <strong className="text-ink">separate</strong> Figma
        file, &quot;TOV26 - B2C - Collections on TOV&quot; (fileKey{" "}
        <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">9xYNBPcAsKBOCCGP5X6wJ9</code>,
        node <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">2159:2814</code>).
        Real structure: navbar → a full-bleed Hero (photo + name + description, all in one banner)
        → a product grid interleaved with (genuinely empty, unfilled) lifestyle image blocks → a
        &quot;[Collection] + you / Shape the Look&quot; masonry gallery + a &quot;View more&quot;
        button → footer. Its own Desktop/Mobile frames are both literally named &quot;Colections -
        D&quot; in the source — Mobile was found only by its actual 375px width, not its label.
      </div>

      <DocSection title={<>Hero <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">2159:2824</code> (Desktop) / <code className="font-mono">2159:3152</code> (Mobile)
          — full-bleed real lifestyle photo (the exact same source image as Collections
          Landing&apos;s Cynthia/Amara banner above), 33% black overlay, centered name + subtitle +
          description, no CTA button. A hidden duplicate draft hero exists in the source
          (`2159:2817`) — an abandoned earlier version, excluded here.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<CollectionHero image="..." />`}>
          <CollectionHero image={`${IMG}/banner-cynthia-amara-shared.png`} />
        </Preview>
        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<CollectionHero compact image="..." />`}>
          <CollectionHero compact image={`${IMG}/banner-cynthia-amara-shared.png`} />
        </Preview>
      </DocSection>

      <DocSection title={<>Product Grid + Lookbook Imagery</>}>
        <p className="text-xs text-ink-muted mb-3">
          The product grid again reuses <code className="font-mono">PLPProductRowDesktop</code>/
          <code className="font-mono">PLPProductRowMobile</code> as-is. It&apos;s interleaved with
          full-width lifestyle image blocks (<Badge variant="sale" size="sm">New · Unreviewed</Badge> —
          node area <code className="font-mono">2159:2872</code>) that are genuinely empty/unfilled
          image slots in this Figma file, reproduced as placeholders rather than invented photos.
        </p>
        <Preview align="start" code={`<PLPProductRowDesktop />\n<CollectionLookbookBlock />`}>
          <div className="flex flex-col gap-4 w-full">
            <PLPProductRowDesktop />
            <CollectionLookbookBlock />
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>&quot;Shape the Look&quot; Gallery <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">2159:3481</code> — a 2-column masonry image gallery
          headed &quot;[Collection] + you / Shape the Look&quot;, ending in a &quot;View more&quot;
          button (reuses the existing <code className="font-mono">Button</code> <code className="font-mono">tertiary</code> variant).
          Simplified to a uniform grid of 6 placeholder cells rather than the source&apos;s 7 cells
          of varying height — a documented scope simplification for an already-unreviewed
          component.
        </p>
        <Preview align="start" code={`<CollectionShapeTheLook collectionName="Amara" />`}>
          <CollectionShapeTheLook collectionName="Amara" />
        </Preview>
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">New / unreviewed components:</strong> Collection Banner,
        Collection Tile (Collections Landing) and Hero, Lookbook Block, Shape the Look (Individual
        Page) are new assembled patterns with no existing equivalent elsewhere in the system —
        built and shown above, but <strong className="text-ink">not</strong> logged in
        FIGMA_SYSTEMS.md&apos;s Sync Log or COMPONENT_CHANGELOG.md as officially synced pieces.
        Only the Product Grid (a straight reuse of the already-approved Collection (PLP) Product
        Row/Card) is logged below.
      </div>

      <ChangeLogTable page="editorial-collection" />
    </DocPage>
  );
}
