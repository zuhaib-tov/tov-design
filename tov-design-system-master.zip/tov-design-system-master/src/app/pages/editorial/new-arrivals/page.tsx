import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { PLPProductRowDesktop, PLPProductRowMobile } from "@/components/ui/PLPProductRow";
import {
  NewArrivalsHeading,
  NewArrivalsSocialCtaHeader,
  NewArrivalsGetTheLookBanner,
  NewArrivalsLoadMore,
} from "@/components/ui/NewArrivalsSections";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function NewArrivalsPage() {
  return (
    <DocPage
      title="New Arrivals"
      description="A single editorial landing page surfacing the newest products across the catalog — mapped from the 'TOV26 - B2C - New Arrivals Refresh' Figma file (node 1:7), the first file for the Editorial Pages system."
    >
      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">Real page structure:</strong> navbar
        (existing <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">MainNav</code>) →
        heading → 4 repeats of [2 product rows (8 cards) + a Social CTA Header + a &quot;Get the
        Look&quot; banner] → a &quot;showing X of Y&quot; / load-more block → footer (existing{" "}
        <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">Footer</code>). Navbar and
        Footer aren&apos;t re-shown below — see the Navigation &amp; Footer doc page for those, already
        mapped and unchanged here.
      </div>

      <DocSection title={<>Heading <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8001:469</code> (Desktop) / <code className="font-mono">8001:865</code> (Mobile)
          — a bordered display-font title, no other content.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<NewArrivalsHeading />`}>
          <NewArrivalsHeading />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<NewArrivalsHeading compact />`}>
          <NewArrivalsHeading compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Product Grid</>}>
        <p className="text-xs text-ink-muted mb-3">
          Reuses the already-mapped Collection (PLP) <code className="font-mono">PLPProductRowDesktop</code>/
          <code className="font-mono">PLPProductRowMobile</code> as-is (4/2 <code className="font-mono">PLPProductCard</code>s,
          10px gap) — no changes to those components. In the real page, 2 rows (8 cards) repeat between
          each Social CTA Header / banner pair, 4 times total (32 products), then the load-more block.
          Shown here as one representative pair of rows per viewport.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PLPProductRowDesktop />\n<PLPProductRowDesktop />`}>
          <div className="flex flex-col gap-2.5 w-full">
            <PLPProductRowDesktop />
            <PLPProductRowDesktop />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PLPProductRowMobile />\n<PLPProductRowMobile />`}>
          <div className="flex flex-col gap-2.5 w-full">
            <PLPProductRowMobile />
            <PLPProductRowMobile />
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Social CTA Header <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8001:5033</code> (Desktop) / <code className="font-mono">8005:5286</code> (Mobile)
          — a dark (#333) strip. Real content is an image-spec annotation for the design team, not
          finished UI copy (&quot;Collection [will be the same image as LP]: Lifestyle Image | Desktop
          1920 x 720&quot; / &quot;Category image: Lifestyle Image | Mobile size - can use 474 x
          375&quot;) — reproduced verbatim as the project&apos;s placeholder-copy convention. Desktop
          and Mobile genuinely differ in font, size, and alignment, not just padding.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<NewArrivalsSocialCtaHeader />`}>
          <NewArrivalsSocialCtaHeader />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<NewArrivalsSocialCtaHeader compact />`}>
          <NewArrivalsSocialCtaHeader compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Get the Look Banner <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8001:586</code> (Desktop) / <code className="font-mono">8001:977</code> (Mobile)
          — full-bleed lifestyle image (Figma&apos;s own empty checkered fill, reproduced as a
          placeholder rather than invented) with an Eyebrow/Header/Sub copy overlay. Desktop adds a
          &quot;Get the look&quot; pill CTA (real <code className="font-mono">bag-add</code> icon
          approximated with the existing <code className="font-mono">bag-outline</code> icon, same
          precedent as Homepage&apos;s Social module) — Mobile genuinely has no CTA button at all,
          absent from its own node tree rather than dropped by mistake.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<NewArrivalsGetTheLookBanner />`}>
          <NewArrivalsGetTheLookBanner />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<NewArrivalsGetTheLookBanner compact />`}>
          <NewArrivalsGetTheLookBanner compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Load More <Badge variant="sale">New · Unreviewed</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Node <code className="font-mono">8001:849</code> (Desktop) / <code className="font-mono">8001:1332</code> (Mobile)
          — a &quot;showing X of Y&quot; caption + progress bar, and a &quot;load more
          products&quot; CTA that reuses the existing <code className="font-mono">Button</code>{" "}
          (<code className="font-mono">primary</code>/<code className="font-mono">lg</code>) rather than
          rebuilding a pill button from scratch. The two floating circular icons (chat launcher, back
          to top) read as generic site-wide chrome rather than New-Arrivals-specific content, and reuse
          existing icons (<code className="font-mono">chat.svg</code>, <code className="font-mono">arrow-up.svg</code>)
          instead of exporting new ones.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<NewArrivalsLoadMore />`}>
          <NewArrivalsLoadMore />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<NewArrivalsLoadMore compact />`}>
          <NewArrivalsLoadMore compact />
        </Preview>
      </DocSection>

      <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">New / unreviewed components:</strong> Heading, Social CTA Header,
        Get the Look Banner, and Load More are new assembled patterns with no existing equivalent
        elsewhere in the system — built and shown above, but{" "}
        <strong className="text-ink">not</strong> logged in FIGMA_SYSTEMS.md&apos;s Sync Log or
        COMPONENT_CHANGELOG.md as officially synced pieces. Only the Product Grid (a straight reuse
        of the already-approved Collection (PLP) Product Row/Card) and the Load More button
        (reusing the existing Button component) are logged below.
      </div>

      <ChangeLogTable page="new-arrivals" />
    </DocPage>
  );
}
