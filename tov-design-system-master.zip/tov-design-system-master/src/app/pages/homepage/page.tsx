import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { HomepageGlobalPromoBanner } from "@/components/ui/HomepageGlobalPromoBanner";
import { HomepageLogoBar } from "@/components/ui/HomepageLogoBar";
import { HomepageCategoryCard } from "@/components/ui/HomepageCategoryCard";
import { HomepageMobileCategories } from "@/components/ui/HomepageMobileCategories";
import { HomepageNewArrivalsHero, HomepageNewArrivalsProductRow } from "@/components/ui/HomepageNewArrivals";
import { HomepagePromoBanner } from "@/components/ui/HomepagePromoBanner";
import { HomepageInStockDesktop, HomepageInStockMobile } from "@/components/ui/HomepageInStock";
import { HomepageCollectionsHero, HomepageCollectionsSubCards } from "@/components/ui/HomepageCollections";
import { HomepageAboutUs } from "@/components/ui/HomepageAboutUs";
import {
  HomepageSocialCtaHeader,
  HomepageSocialPostContainer,
  HomepageSocial,
  HomepageGetTheLook,
} from "@/components/ui/HomepageSocial";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const CATEGORY_CARDS = ["Living room", "Accent chairs", "Outdoor", "Storage"];

export default function HomepagePage() {
  return (
    <DocPage
      title="Homepage & Marketing"
      description="The storefront landing page — mapped from the OG file's dedicated 'Homepage Components' canvas (node 1059:3763). That canvas had never been migrated to the Version=/Viewport=/Status= naming convention before this sync; see FIGMA_SYSTEMS.md for the rename pass that came first."
    >
      <DocSection title={<>Page layout <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          How the components below are assembled into the homepage, Desktop at 1440px and Mobile at
          375px, from the Mock-up frames in Figma. Scroll inside each frame to read the whole page.
        </p>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
          <figure className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
            <div className="max-h-[640px] overflow-y-auto bg-cream-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/homepage/page-layout/desktop.webp"
                alt="Homepage, Desktop layout at 1440px"
                className="block h-auto w-full"
              />
            </div>
            <figcaption className="border-t border-neutral-200 px-4 py-2 text-xs text-ink-muted">
              Desktop · 1440px
            </figcaption>
          </figure>
          <figure className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
            <div className="max-h-[640px] overflow-y-auto bg-cream-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/homepage/page-layout/mobile.webp"
                alt="Homepage, Mobile layout at 375px"
                className="block h-auto w-full"
              />
            </div>
            <figcaption className="border-t border-neutral-200 px-4 py-2 text-xs text-ink-muted">
              Mobile · 375px
            </figcaption>
          </figure>
        </div>
        <ol className="mt-4 grid max-w-3xl list-decimal grid-cols-1 gap-x-8 gap-y-1 pl-5 text-sm text-ink-muted sm:grid-cols-2">
          <li>Main Navigation</li>
          <li>Hero banner</li>
          <li>Categories</li>
          <li>New Arrivals</li>
          <li>New Arrivals Product Row</li>
          <li>New Arrivals</li>
          <li>In Stock</li>
          <li>Dynamic content blocks</li>
          <li>Social CTA Header</li>
          <li>Get the Look</li>
          <li>Footer, with icon row</li>
        </ol>
      </DocSection>

      <DocSection title={<>Global Promo Banner <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Both Live variants share one layout: a 56px cream pill with a 10px radius and one centered
          line of 14/16 copy, offer in bold. Only the side margin differs (100px Desktop, 20px
          Mobile).
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<HomepageGlobalPromoBanner />`}>
          <HomepageGlobalPromoBanner />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<HomepageGlobalPromoBanner compact />`}>
          <HomepageGlobalPromoBanner compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Logo Bar <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Four Live variants: two looks on two screens (&quot;Logo Bar&quot; and &quot;Logo Bar
          2&quot;). Each is a cream pill of press logos at 50% opacity; the difference is which
          side gets the outer margin.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop — inset (Logo Bar)</p>
        <Preview align="start" code={`<HomepageLogoBar />`}>
          <HomepageLogoBar />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop — full-bleed (Logo Bar 2)</p>
        <Preview align="start" code={`<HomepageLogoBar inset={false} />`}>
          <HomepageLogoBar inset={false} />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile — full-bleed (Logo Bar)</p>
        <Preview align="start" code={`<HomepageLogoBar viewport="mobile" />`}>
          <HomepageLogoBar viewport="mobile" />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile — inset (Logo Bar 2)</p>
        <Preview align="start" code={`<HomepageLogoBar viewport="mobile" inset />`}>
          <HomepageLogoBar viewport="mobile" inset />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> in Figma the logo row is an infinite-scroll
          marquee. Here it is the resting frame: the same eleven logos in the same order at the
          same offset, without the animation. Logos are 15px tall with a 120px gap on Desktop and
          22px on Mobile.
        </div>
      </DocSection>

      <DocSection title={<>Categories <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          4 separate Desktop component sets (Living Room, Accent Chairs, Outdoor, Storage) —
          each a full-bleed image card with a centered, uppercase white label. Mobile is a
          different, separate component with its own category set.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<HomepageCategoryCard label="Living room" />`}>
          <div className="grid grid-cols-4 gap-2.5 w-full">
            {CATEGORY_CARDS.map((label) => (
              <HomepageCategoryCard key={label} label={label} />
            ))}
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<HomepageMobileCategories />`}>
          <HomepageMobileCategories />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> Mobile Categories shows a different set of four
          categories than Desktop: Living room, Home office, Outdoor and Bedroom. Cards carry real
          photography; Bedroom uses the Storage photo. Desktop labels are 20px on a 32px line
          height and Mobile labels are 12px underlined, both uppercase with the shared all-caps
          tracking.
        </div>
      </DocSection>

      <DocSection title={<>New Arrivals <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Two separate pieces stacked on the page: a lifestyle hero, then a product row below
          it.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Hero — Desktop</p>
        <Preview align="start" code={`<HomepageNewArrivalsHero />`}>
          <HomepageNewArrivalsHero />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Hero — Desktop, with product card</p>
        <Preview align="start" code={`<HomepageNewArrivalsHero showProductCard />`}>
          <HomepageNewArrivalsHero showProductCard />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Hero — Mobile</p>
        <Preview align="start" code={`<HomepageNewArrivalsHero compact />`}>
          <HomepageNewArrivalsHero compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Product Row — Desktop</p>
        <Preview align="start" code={`<HomepageNewArrivalsProductRow />`}>
          <HomepageNewArrivalsProductRow />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Product Row — Mobile</p>
        <Preview align="start" code={`<HomepageNewArrivalsProductRow compact />`}>
          <HomepageNewArrivalsProductRow compact />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the hero uses the lifestyle photo under a
          20% black wash (Mobile adds a bottom multiply gradient). The heading is 46/50 on Desktop
          and 38/42 on Mobile in GT Ultra Fine, and the caption is 14/33 bold, uppercase and
          underlined. Desktop has a 44px add-to-cart icon button; the second Desktop variant swaps
          it for a frosted product card with a &quot;Buy now&quot; button (
          <code className="font-mono text-xs">showProductCard</code>). The product row sets four
          product photos on a white tile with a 6% black wash, 36px radius on Desktop and 16px on
          Mobile.
        </div>
      </DocSection>

      <DocSection title={<>Promo Banner <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Two variants: Default (Live), a full-width cream card with a 36px radius, and Promo Banner 2
          (Draft), a compact centered 335px card with a 16px radius. The copy is the module&apos;s own
          placeholder text in Figma.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Default (Live)</p>
        <Preview align="start" code={`<HomepagePromoBanner />`}>
          <HomepagePromoBanner />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Promo Banner 2 (Draft)</p>
        <Preview align="start" code={`<HomepagePromoBanner version="promo-banner-2" />`}>
          <HomepagePromoBanner version="promo-banner-2" />
        </Preview>
      </DocSection>

      <DocSection title={<>In Stock <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Desktop Live, Desktop Draft (the first tile shows the product name and price) and Mobile
          Live, all <code className="font-mono">Version=In Stock</code>; Status distinguishes them.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<HomepageInStockDesktop />`}>
          <HomepageInStockDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop (Draft)</p>
        <Preview align="start" code={`<HomepageInStockDesktop status="draft" />`}>
          <HomepageInStockDesktop status="draft" />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<HomepageInStockMobile />`}>
          <HomepageInStockMobile />
        </Preview>
      </DocSection>

      <DocSection title={<>Collections <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          A full-bleed hero (Desktop and Mobile) followed by four product tiles (Chair, Storage,
          Nightstand, Side Table) and a 2 x 2 Mobile product grid.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Hero</p>
        <Preview align="start" code={`<HomepageCollectionsHero />`}>
          <HomepageCollectionsHero />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Hero (Mobile)</p>
        <Preview align="start" code={`<HomepageCollectionsHero compact />`}>
          <HomepageCollectionsHero compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Product tiles</p>
        <Preview align="start" code={`<HomepageCollectionsSubCards />`}>
          <HomepageCollectionsSubCards />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Product grid (Mobile)</p>
        <Preview align="start" code={`<HomepageCollectionsSubCards compact />`}>
          <HomepageCollectionsSubCards compact />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the Live tiles carry no text; each photo is
          a product cut-out on a light-grey tile (white with a 6% black overlay).
        </div>
      </DocSection>

      <DocSection title={<>About Us <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Both Live variants — a full-bleed media hero. The Figma source is a video; the app shows
          its poster frame.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<HomepageAboutUs />`}>
          <HomepageAboutUs />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<HomepageAboutUs compact />`}>
          <HomepageAboutUs compact />
        </Preview>
      </DocSection>

      <DocSection title={<>Social <Badge variant="new">Updated</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Four components: a CTA header, a row of shoppable post cards (Short, Medium, Tall), a
          small Desktop/Mobile Social card pair, and a Get the Look card. Each has Desktop and
          Mobile versions where Figma defines them.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">CTA Header — Desktop</p>
        <Preview align="start" code={`<HomepageSocialCtaHeader />`}>
          <HomepageSocialCtaHeader />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">CTA Header — Mobile</p>
        <Preview align="start" code={`<HomepageSocialCtaHeader compact />`}>
          <HomepageSocialCtaHeader compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Post Container — Short / Medium / Tall</p>
        <Preview align="start" code={`<HomepageSocialPostContainer size="short" />`}>
          <div className="grid grid-cols-3 gap-2.5 w-full">
            <HomepageSocialPostContainer size="short" />
            <HomepageSocialPostContainer size="medium" />
            <HomepageSocialPostContainer size="tall" />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Social — Desktop / Mobile</p>
        <Preview align="start" code={`<HomepageSocial />`}>
          <div className="grid grid-cols-2 gap-2.5 w-full max-w-xs">
            <HomepageSocial />
            <HomepageSocial compact />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Get the Look — Desktop</p>
        <Preview align="start" code={`<HomepageGetTheLook />`}>
          <HomepageGetTheLook />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Get the Look — Mobile</p>
        <Preview align="start" code={`<HomepageGetTheLook compact />`}>
          <HomepageGetTheLook compact />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the post cards&apos; circular button is the
          <code className="font-mono text-xs"> bag-add</code> glyph on a 44px glass circle (charcoal
          at 20% with a 4px blur). The CTA header&apos;s button is a plain transparent outline pill
          with a 1px charcoal border, so it is built inline rather than stretching a filled{" "}
          <code className="font-mono text-xs">Button</code> variant. Get the Look&apos;s product row
          shows real content: name, price and a small Add to cart pill.
        </div>
      </DocSection>

      <ChangeLogTable page="homepage" />
    </DocPage>
  );
}
