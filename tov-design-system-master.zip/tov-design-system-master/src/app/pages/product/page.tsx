import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { PDPPrice } from "@/components/ui/PDPPrice";
import { PDPProductName } from "@/components/ui/PDPProductName";
import { PDPFabricSelection } from "@/components/ui/PDPFabricSelection";
import { PDPQuantity } from "@/components/ui/PDPQuantity";
import { PDPAddToCartRow } from "@/components/ui/PDPAddToCartRow";
import { PDPStickyAddToCart } from "@/components/ui/PDPStickyAddToCart";
import { PDPWhyWeLoveIt } from "@/components/ui/PDPWhyWeLoveIt";
import { PDPShippingAlert } from "@/components/ui/PDPShippingAlert";
import { PDPValueProps } from "@/components/ui/PDPValueProps";
import { PDPVariantSelection } from "@/components/ui/PDPVariantSelection";
import { PDPClubTov } from "@/components/ui/PDPClubTov";
import { PDPGalleryDesktop, PDPGalleryMobile } from "@/components/ui/PDPGallery";
import { PDPBreadCrumbs } from "@/components/ui/PDPBreadCrumbs";
import { PDPBnpl } from "@/components/ui/PDPBnpl";
import { PDPAccordion, PDPDimensionGroup, PDPDimensionGroupList, PDPDimensionDiagrams, PDPMeasureLink } from "@/components/ui/PDPAccordion";
import { PDPComfortLevel, COMFORT_LEVELS } from "@/components/ui/PDPComfortLevel";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const MOCK_SWATCHES = [
  { color: "#F1F1F1" },
  { color: "#F1F1F1", selected: true },
  { color: "#F1F1F1" },
  { color: "#F1F1F1" },
  { color: "#F1F1F1" },
];

const BELOW_THE_FOLD_DRAFT = [
  "Get the Look", "Pairs Well With", "Recently Viewed", "You May Also Like",
  "Shop the Collection", "Our Pieces Styled by You", "Reviews", "Trust Banner",
];

export default function ProductPage() {
  return (
    <DocPage
      title="PDP"
      description="The product detail page — mapped from the dedicated PDP Design System Figma file (its own file, not built against the OG library) — see FIGMA_SYSTEMS.md. This file is the sole source of truth for PDP; it is not cross-checked against the live site."
    >
      <DocSection title={<>Gallery <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Standalone components (not a Version=/Viewport=/Status= set) — Desktop and Mobile
          differ structurally, not just in scale.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PDPGalleryDesktop />`}>
          <PDPGalleryDesktop />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PDPGalleryMobile wishlistCount={249} />`}>
          <PDPGalleryMobile wishlistCount={249} />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> every image slot in Figma itself (main
          image and every thumbnail, both viewports) is an empty/missing image fill, rendered as
          Figma&apos;s own light-gray checkerboard — not real photography yet. Reproduced with
          the same subtle checker pattern (<code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">.bg-image-placeholder</code>,
          globals.css) instead of colorful stand-in imagery. Desktop&apos;s thumbnail rail ends
          in a non-photo tile (real extracted &quot;dimensions&quot; ruler icon). Mobile&apos;s
          heart+count pill and dot pagination reuse the same heart glyph as ATC Stack. The 5-up
          icon+text strip that was below the Desktop main image has been removed — it traced
          back to a legacy frame, not the current design.
        </div>
      </DocSection>

      <DocSection title={<>Bread Crumbs <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Universal — same layout on every device. Figma&apos;s own content is template
          placeholder text (&quot;Menu Item&quot;, &quot;[Prod Name] TOV-000000&quot;),
          reproduced as-is.
        </p>
        <Preview align="start" code={`<PDPBreadCrumbs />`}>
          <PDPBreadCrumbs />
        </Preview>
      </DocSection>

      <DocSection title={<>Product Name <Badge variant="new">New</Badge></>}>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview
          align="start"
          code={`<PDPProductName name="TOV Product Name" />
<PDPProductName name="TOV Product Name" grade="Contract Grade" />
<PDPProductName name="TOV Product Name" grade="Contract Grade" genuineLeather />`}
        >
          <div className="flex flex-col gap-6 w-full">
            <PDPProductName name="TOV Product Name" />
            <PDPProductName name="TOV Product Name" grade="Contract Grade" />
            <PDPProductName name="TOV Product Name" grade="Contract Grade" genuineLeather />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview
          align="start"
          code={`<PDPProductName name="TOV Product Name" compact />
<PDPProductName name="TOV Product Name" grade="Contract Grade" compact />
<PDPProductName name="TOV Product Name" grade="Contract Grade" genuineLeather compact />`}
        >
          <div className="flex flex-col gap-6 w-full">
            <PDPProductName name="TOV Product Name" compact />
            <PDPProductName name="TOV Product Name" grade="Contract Grade" compact />
            <PDPProductName name="TOV Product Name" grade="Contract Grade" genuineLeather compact />
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Price <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">Universal — same layout on every device.</p>
        <Preview
          align="start"
          code={`<PDPPrice amount={1499} rating={4.9} reviewCount={2} />
<PDPPrice amount={1199} originalAmount={1499} rating={4.9} reviewCount={2} />`}
        >
          <div className="flex flex-col gap-6 w-72">
            <PDPPrice amount={1499} rating={4.9} reviewCount={2} />
            <PDPPrice amount={1199} originalAmount={1499} rating={4.9} reviewCount={2} />
          </div>
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> font is Montserrat throughout — the
          Figma file&apos;s own text styles say &quot;Gotham,&quot; which is stale.
          Affirm/financing, shipping-message, and SKU content has been removed — it was
          stale/hidden in Figma despite the &quot;Status=Live&quot; naming, not real content.
          Distinct from the simpler{" "}
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">Price</code> atom
          used on PLP/cart.
        </div>
      </DocSection>

      <DocSection title={<>Variant Selector — Swatch <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          One swatch selector with three labels: Fabric, Color and Finish.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview
          align="start"
          code={`<PDPFabricSelection label="Fabric" swatches={swatches} />
<PDPFabricSelection label="Color" swatches={swatches} />
<PDPFabricSelection label="Finish" swatches={swatches} />`}
        >
          <div className="flex flex-col gap-6 w-full">
            <PDPFabricSelection label="Fabric" swatches={MOCK_SWATCHES} />
            <PDPFabricSelection label="Color" swatches={MOCK_SWATCHES} />
            <PDPFabricSelection label="Finish" swatches={MOCK_SWATCHES} />
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview
          align="start"
          code={`<PDPFabricSelection label="Fabric" swatches={swatches} showViewDetails />
<PDPFabricSelection label="Color" swatches={swatches} />
<PDPFabricSelection label="Finish" swatches={swatches} />`}
        >
          <div className="flex flex-col gap-6 w-full">
            <PDPFabricSelection label="Fabric" swatches={MOCK_SWATCHES} showViewDetails />
            <PDPFabricSelection label="Color" swatches={MOCK_SWATCHES} />
            <PDPFabricSelection label="Finish" swatches={MOCK_SWATCHES} />
          </div>
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the Mobile Fabric selector adds the
          &quot;View Fabric Details&quot; link and the Fabric selector carries the &quot;Free
          fabric swatch&quot; link; Color and Finish show neither. Swatches are 50px targets
          holding a 46px chip, spaced 2.7px apart. Unselected chips are flat with a 0.5px{" "}
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">#CECECE</code>{" "}
          border; the selected chip adds a 1px charcoal ring and the soft drop shadow.
        </div>
      </DocSection>

      <DocSection title={<>Quantity <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">Universal — same layout on every device.</p>
        <Preview align="start" code={`<PDPQuantity value={1} />`}>
          <PDPQuantity value={1} />
        </Preview>
      </DocSection>

      <DocSection title={<>Add to Cart <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The primary Add to Cart: the system&apos;s primary large button beside the wishlist
          circle.
        </p>
        <Preview align="start" code={`<PDPAddToCartRow />`}>
          <PDPAddToCartRow />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Sticky ATC (Mobile)</p>
        <Preview align="start" code={`<PDPStickyAddToCart price="$1,169.10" />`}>
          <PDPStickyAddToCart price="$1,169.10" />
        </Preview>
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the primary Add to Cart uses the
          system&apos;s primary large button at 54px tall beside a 54px wishlist circle with a 5px
          gap. The mobile fixed bar is the Fixed ATC variant (node 13:193): a white pill with 9px
          padding holding the quantity stepper and one Add to Cart button whose label and price
          share a single line. Its stepper is the same pill as the Quantity component, at 49px tall.
        </div>
      </DocSection>

      <DocSection title={<>Why You&apos;ll Love It <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Universal — same layout on every device. Figma names the component &quot;Why We Love
          It&quot; but it displays &quot;Why You&apos;ll Love It.&quot;
        </p>
        <Preview
          align="start"
          code={`<PDPWhyWeLoveIt
  bullets={[
    "Seats up to 8 comfortably.",
    "Crafted from natural burl wood veneer, making each piece unique.",
    "Durable finish designed for everyday use.",
  ]}
  description="The [Product Name] combines striking burl wood with a sculptural silhouette..."
/>`}
        >
          <PDPWhyWeLoveIt
            bullets={[
              "Seats up to 8 comfortably.",
              "Crafted from natural burl wood veneer, making each piece unique.",
              "Durable finish designed for everyday use.",
            ]}
            description="The [Product Name] combines striking burl wood with a sculptural silhouette to create a bold focal point for any dining space. Its timeless design blends modern sophistication with organic warmth, making it equally suited for everyday meals and special gatherings."
          />
        </Preview>
      </DocSection>

      <DocSection title={<>Shipping Alert <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          All 6 Live variants, labeled by what they actually say (Figma&apos;s own names are
          misleading — see below).
        </p>
        <Preview align="start" code={`<PDPShippingAlert status="in-stock" />`}>
          <div className="flex flex-col gap-2 items-start">
            <PDPShippingAlert status="in-stock" />
            <PDPShippingAlert status="in-stock-eta" />
            <PDPShippingAlert status="preorder" />
            <PDPShippingAlert status="preorder-eta" />
            <PDPShippingAlert status="low-stock" />
            <PDPShippingAlert status="low-stock-ai" />
          </div>
        </Preview>
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> Figma names &quot;PO&quot; and
          &quot;PO-EST&quot; the opposite of what they suggest — &quot;PO&quot; is the one{" "}
          <em>with</em> a restock estimate, &quot;PO-EST&quot; is the one without. Labeled by
          actual content instead: In Stock, In Stock — Ships in 1-3 Days, Preorder, Preorder —
          With Restock Estimate, Low Stock — With Restock Estimate, Low Stock — AI Inventory
          Estimate. Green is <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">#1FC16B</code> —
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">--color-success</code> was
          updated to match (previously <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">#2E7D4F</code>).
        </div>
      </DocSection>

      <DocSection title={<>Value Props <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Universal — &quot;Value Props Updated&quot; variant, same layout on every device.
        </p>
        <Preview
          align="start"
          code={`<PDPValueProps
  items={[
    { icon: "delivery-box", segments: [{ text: "Includes " }, { text: "free shipping", bold: true }] },
    { icon: "verified", segments: [{ text: "Includes " }, { text: "warranty ", bold: true }, { text: "+ extended options." }] },
    { icon: "box-remove", segments: [{ text: "Returns " }, { text: "available", bold: true }, { text: ". " }, { text: "Learn more.", underline: true }] },
    { icon: "truck-schedule", segments: [{ text: "Delivery upgrades ", bold: true }, { text: "available. " }, { text: "Learn more.", underline: true }] },
  ]}
/>`}
        >
          <PDPValueProps
            items={[
              { icon: "delivery-box", segments: [{ text: "Includes " }, { text: "free shipping", bold: true }] },
              { icon: "verified", segments: [{ text: "Includes " }, { text: "warranty ", bold: true }, { text: "+ extended options." }] },
              { icon: "box-remove", segments: [{ text: "Returns " }, { text: "available", bold: true }, { text: ". " }, { text: "Learn more.", underline: true }] },
              { icon: "truck-schedule", segments: [{ text: "Delivery upgrades ", bold: true }, { text: "available. " }, { text: "Learn more.", underline: true }] },
            ]}
          />
        </Preview>
      </DocSection>

      <DocSection title={<>Variant Selection <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          All 4 variants are included here even though none are Live yet in Figma.
        </p>
        <Preview
          align="start"
          code={`<PDPVariantSelection label="Size:" options={["King", "Queen", "Full", "Twin"]} />
<PDPVariantSelection label="Size:" options={["King", "Queen", "Full", "Twin"]} selected="King" />`}
        >
          <div className="flex flex-col gap-6 w-full">
            <PDPVariantSelection label="Size:" options={["King", "Queen", "Full", "Twin"]} />
            <PDPVariantSelection label="Size:" options={["King", "Queen", "Full", "Twin"]} selected="King" />
            <PDPVariantSelection label="Fill Type:" options={["Pillow Cover Only", "With Pillow Insert"]} />
            <PDPVariantSelection
              label="Fill Type:"
              options={["Pillow Cover Only", "With Pillow Insert"]}
              selected="Pillow Cover Only"
            />
          </div>
        </Preview>
      </DocSection>

      <DocSection title={<>Club TOV <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Draft in Figma (Desktop: &quot;Default&quot;, Mobile: &quot;Club TOV&quot;), included
          here even though it&apos;s still draft. Mobile is meaningfully more compact than
          Desktop, not just a smaller copy of it.
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
        <Preview align="start" code={`<PDPClubTov points={6291} />`}>
          <PDPClubTov points={6291} />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
        <Preview align="start" code={`<PDPClubTov points={6291} compact />`}>
          <PDPClubTov points={6291} compact />
        </Preview>
      </DocSection>

      <DocSection title={<>BNPL <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Both Live variants — same content and layout, Desktop is simply larger (not a
          copy/layout difference like Club TOV&apos;s compact mode).
        </p>
        <p className="text-sm font-semibold text-ink mb-2">Mobile</p>
        <Preview align="start" code={`<PDPBnpl monthlyPrice="$188.85" compact />`}>
          <PDPBnpl monthlyPrice="$188.85" compact />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Desktop</p>
        <Preview align="start" code={`<PDPBnpl monthlyPrice="$188.85" />`}>
          <PDPBnpl monthlyPrice="$188.85" />
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> Klarna/Afterpay/Affirm are real
          extracted logo images (<code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">public/brand/payment/</code>);
          Shop Pay is a real extracted vector (bolt + wordmark, <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">#5433EB</code>) —
          none are generic stand-ins.
        </div>
      </DocSection>

      <DocSection title={<>Comfort Level <Badge variant="new">New</Badge></>}>
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mb-5">
          <strong className="text-ink">Where it shows:</strong> only on products with seat
          cushioning, such as accent chairs and sofas, as the first block of the Details tab. Beds,
          tables, dressers and other pieces without a cushion do not get it. Matched to the live
          product pages; the Figma accordion only has the text line &quot;Comfort level: Plush&quot;.
        </div>

        <p className="text-sm font-semibold text-ink mb-2">Desktop — 423px wide</p>
        <Preview align="start" code={`<PDPComfortLevel level="Medium" />`}>
          <div className="flex w-[423px] flex-col gap-6">
            {COMFORT_LEVELS.map((l) => (
              <PDPComfortLevel key={l} level={l} />
            ))}
          </div>
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile — 311px wide</p>
        <Preview align="start" code={`<PDPComfortLevel level="Medium" />`}>
          <div className="flex w-[311px] flex-col gap-6">
            {COMFORT_LEVELS.map((l) => (
              <PDPComfortLevel key={l} level={l} />
            ))}
          </div>
        </Preview>

        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> a 14/14 bold title, an 8px gap, then a
          16px track (#E8E8E8 at 58%) with a charcoal pill one quarter of its width that moves one
          step per level. Under it, four columns hold a 7px dot (#D9D9D9, charcoal when active) and
          a 14/14 label (#A4A4A4, charcoal when active). The track and labels sit 15px in from the
          container edge.
        </div>
      </DocSection>

      <DocSection title={<>Product Info Accordion <Badge variant="new">New</Badge></>}>
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mb-5">
          <strong className="text-ink">Heads up:</strong> all 6 variants in Figma are
          <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5 mx-1">Status=Draft</code>,
          and unlike Variant Selection/Club TOV, every single
          variant is <code className="font-mono text-xs bg-white rounded-app-sm px-1 py-0.5">Viewport=Desktop</code> —
          there&apos;s no Mobile variant at all yet. All 6 are included anyway since each shows
          genuinely different, product-specific content (a chair&apos;s Dimensions table looks
          nothing like a dresser&apos;s or a bed&apos;s Details tab). Mobile still needs a real
          design pass.
        </div>

        <p className="text-sm font-semibold text-ink mb-2">Default (all collapsed)</p>
        <Preview align="start" code={`<PDPAccordion items={[...]} />`}>
          <PDPAccordion
            items={[
              { label: "Details", content: null },
              { label: "Dimensions", content: null },
              { label: "Care", content: null },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Accent Chair — Details</p>
        <p className="text-xs text-ink-muted mb-2">
          Upholstered seating opens with the Comfort level scale. Content is from the live product
          page (Florence Linen Accent Chair); Figma did not document this tab for a chair.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Details",
                content: (
                  <div className="flex flex-col gap-4 text-sm leading-[21px] text-ink-muted">
                    <PDPComfortLevel level="Medium" />
                    <div>
                      <p className="text-ink font-semibold mb-1">Specifications</p>
                      <p>SKU: TOV-S55092<br />Color: Blue<br />Leg color: Dark Wood &amp; Blue<br />Weight Capacity: 285 lbs<br />Support Type: Webbing<br />Seat fill material: Fiber-Wrapped Foam<br />Easy Clean: yes</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Materials</p>
                      <p>Linen<br />Plywood<br />Wood</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Features</p>
                      <p>Product Dimensions: 31.9&quot;W x 30.2&quot;D x 27.8&quot;H<br />Curved arms and a rounded back create a sculptural silhouette with cozy, modern appeal</p>
                    </div>
                  </div>
                ),
              },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Accent Chair — Dimensions</p>
        <p className="text-xs text-ink-muted mb-2">
          Only Dimensions is shown — Figma didn&apos;t document Details or Care content for this
          product, so those tabs aren&apos;t included here rather than expanding to nothing.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Dimensions",
                content: (
                  <div className="flex flex-col gap-4">
                    <PDPDimensionDiagrams />
                    <PDPDimensionGroupList>
                      <PDPDimensionGroup
                        title="Overall Dimensions"
                        rows={[{ label: "Width:", value: "33.2”" }, { label: "Depth:", value: "33.2”" }, { label: "Height:", value: "27.5”" }]}
                      />
                      <PDPDimensionGroup
                        title="Seat Dimensions"
                        rows={[{ label: "Width:", value: "26.8”" }, { label: "Depth:", value: "23.2”" }, { label: "Height:", value: "17.5”" }]}
                      />
                      <PDPDimensionGroup title="Arm Height" rows={[{ label: "Height:", value: "23.7”" }]} />
                      <PDPDimensionGroup title="Back Height" rows={[{ label: "Height:", value: "12”" }]} />
                      <PDPDimensionGroup title="Weight" rows={[{ label: "", value: "47.6 lbs" }]} />
                      <PDPDimensionGroup
                        title="Package Dimensions"
                        rows={[{ label: "", value: "35.0\" x 33.7\" x 29.9\"" }, { label: "Weight:", value: "67.5 lbs" }]}
                      />
                      <PDPMeasureLink />
                    </PDPDimensionGroupList>
                  </div>
                ),
              },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Dresser — Dimensions</p>
        <p className="text-xs text-ink-muted mb-2">
          Only Dimensions is shown — Figma didn&apos;t document Details or Care content for this
          product, so those tabs aren&apos;t included here rather than expanding to nothing.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Dimensions",
                content: (
                  <div className="flex flex-col gap-4">
                    <PDPDimensionDiagrams />
                    <PDPDimensionGroupList>
                      <PDPDimensionGroup
                        title="Overall Dimensions"
                        rows={[{ label: "Width:", value: "55.9”" }, { label: "Depth:", value: "20”" }, { label: "Height:", value: "32.5”" }]}
                      />
                      <PDPDimensionGroup
                        title="Top Left & Right Drawer"
                        rows={[{ label: "Width:", value: "12.8”" }, { label: "Depth:", value: "13.2”" }, { label: "Height:", value: "2.4”" }]}
                      />
                      <PDPDimensionGroup
                        title="Top Center Drawer"
                        rows={[{ label: "Width:", value: "21.7”" }, { label: "Depth:", value: "13.2”" }, { label: "Height:", value: "2.4”" }]}
                      />
                      <PDPDimensionGroup
                        title="Bottom Left & Right Drawer"
                        rows={[{ label: "Width:", value: "12.8”" }, { label: "Depth:", value: "13.2”" }, { label: "Height:", value: "3.9”" }]}
                      />
                      <PDPDimensionGroup title="Weight" rows={[{ label: "", value: "190.7 lbs" }]} />
                      <PDPDimensionGroup
                        title="Package Dimensions"
                        rows={[
                          { label: "", value: "Ships in 4 Boxes" },
                          { label: "Box 1:", value: "23.4\" x 19.8\" x 30.5\"" },
                          { label: "Box 2:", value: "30.3\" x 7.5\" x 26.4\"" },
                          { label: "Box 3:", value: "62\" x 26.8\" x 10\"" },
                          { label: "Box 4:", value: "23.4\" x 19.8\" x 30.5\"" },
                          { label: "Shipment Weight:", value: "67.5 lbs" },
                        ]}
                      />
                      <PDPMeasureLink />
                    </PDPDimensionGroupList>
                  </div>
                ),
              },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Nesting Tables — Dimensions</p>
        <p className="text-xs text-ink-muted mb-2">
          Only Dimensions is shown — Figma didn&apos;t document Details or Care content for this
          product, so those tabs aren&apos;t included here rather than expanding to nothing.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Dimensions",
                content: (
                  <div className="flex flex-col gap-4">
                    <PDPDimensionDiagrams />
                    <PDPDimensionGroupList>
                      <PDPDimensionGroup
                        title="Large Table Dimensions"
                        rows={[{ label: "Width:", value: "34.0”" }, { label: "Diameter:", value: "32.0”" }, { label: "Height:", value: "10.2”" }]}
                      />
                      <PDPDimensionGroup
                        title="Medium Table Dimensions"
                        rows={[{ label: "Width:", value: "28.0”" }, { label: "Diameter:", value: "25.0”" }, { label: "Height:", value: "14.3”" }]}
                      />
                      <PDPDimensionGroup
                        title="Small Table Dimensions"
                        rows={[{ label: "Width:", value: "21.3”" }, { label: "Diameter:", value: "17.7”" }, { label: "Height:", value: "18.2”" }]}
                      />
                      <PDPDimensionGroup title="Weight" rows={[{ label: "", value: "255.4 lbs" }]} />
                      <PDPDimensionGroup
                        title="Package Dimensions"
                        rows={[
                          { label: "", value: "Ships in 4 Boxes" },
                          { label: "Box 1:", value: "39.0\" x 37.0\" x 6.5\"" },
                          { label: "Box 2:", value: "24.2\" x 21.0\" x 13.8\"" },
                          { label: "Box 3:", value: "31.6\" x 28.8\" x 20.0\"" },
                          { label: "Box 4:", value: "25.5\" x 22.3\" x 16.3\"" },
                          { label: "Shipment Weight:", value: "255.4 lbs" },
                        ]}
                      />
                      <PDPMeasureLink />
                    </PDPDimensionGroupList>
                  </div>
                ),
              },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Bed — Details</p>
        <p className="text-xs text-ink-muted mb-2">
          Only Details is shown — Figma didn&apos;t document Dimensions or Care content for this
          product, so those tabs aren&apos;t included here rather than expanding to nothing.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Details",
                content: (
                  <div className="flex flex-col gap-4 text-sm leading-[21px] text-ink-muted">
                    <div>
                      <p className="text-ink font-semibold mb-1">Specifications</p>
                      <p>SKU: TOV-B54447<br />Color: Forest Green<br />Materials: Velvet, Veneer, Wood<br />Leg color: Brown<br />Weight Capacity: 725 lbs</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Materials</p>
                      <p>Upholstery: Velvet 100% polyester<br />Frame: Solid wood frame, wood veneer finish<br />Legs: Wood legs, with a brown finish</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Features</p>
                      <p>Product Dimensions: 79.9&quot;W x 85.1&quot;D x 47.2&quot;H<br />Available in Queen &amp; King sizes<br />No box spring required and slats are included<br />Dark wood grain finish with a choice of Forest Green or Taupe velvet</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Assembly</p>
                      <p>Minor Assembly Required<br />No of people needed: 3 people<br />Tools included: Yes</p>
                    </div>
                    <div>
                      <p className="text-ink font-semibold mb-1">Need more information?</p>
                      <a href="#" className="text-mauve underline">Download assembly guide</a>
                    </div>
                  </div>
                ),
              },
            ]}
          />
        </Preview>

        <p className="text-sm font-semibold text-ink mt-6 mb-2">Upholstered piece — Care</p>
        <p className="text-xs text-ink-muted mb-2">
          Only Care is shown — Figma didn&apos;t document Details or Dimensions content for this
          product, so those tabs aren&apos;t included here rather than expanding to nothing.
        </p>
        <Preview align="start" code={`<PDPAccordion defaultOpenIndex={0} items={[...]} />`}>
          <PDPAccordion
            defaultOpenIndex={0}
            items={[
              {
                label: "Care",
                content: (
                  <div className="flex flex-col gap-4 text-sm leading-[21px] text-ink-muted">
                    <ul className="list-disc pl-4 flex flex-col gap-1">
                      <li>Use a mild water-based cleaner for spot cleaning.</li>
                      <li>Blot spills immediately with a clean, absorbent white cloth.</li>
                      <li>Professional cleaning recommended for stubborn stains.</li>
                    </ul>
                    <div>
                      <p className="text-ink font-semibold mb-1">Fabric Care instructions</p>
                      <p>
                        Blot spills immediately with a clean, absorbent cloth. Spot clean with a
                        damp cloth and a mild water-based detergent or upholstery cleaner. Allow
                        the fabric to air dry completely after cleaning. For stubborn or set
                        stains, work with a professional upholstery clearing service. (Cleaning
                        Code: W).
                      </p>
                    </div>
                    <div>
                      <p>For more details, check out our care guide.</p>
                      <a href="#" className="text-mauve underline">View care guide</a>
                    </div>
                  </div>
                ),
              },
            ]}
          />
        </Preview>
      </DocSection>

      <DocSection title="Not yet mapped">
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6">
          <p className="text-sm text-ink-muted mb-3">
            &quot;PDP - Below the Fold&quot; (100% Draft in Figma — not started):
          </p>
          <ul className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
            {BELOW_THE_FOLD_DRAFT.map((item) => (
              <li key={item} className="text-sm text-ink-muted flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-300 shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </DocSection>

      <ChangeLogTable page="product" />
    </DocPage>
  );
}
