import type { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import {
  AccountButtonSmall,
  AccountToggle,
  AccountNav,
  AccountPointsBanner,
  AccountWelcomeCard,
  AccountOrderCard,
  AccountContactInfo,
  AccountAddresses,
  AccountMarketingPreferences,
  AccountSignOut,
  AccountPageLayout,
} from "@/components/ui/Account";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Viewports({
  desktop,
  mobile,
  desktopCode,
  mobileCode,
}: {
  desktop: ReactNode;
  mobile: ReactNode;
  desktopCode: string;
  mobileCode: string;
}) {
  return (
    <>
      <p className="text-sm font-semibold text-ink mb-2">Desktop</p>
      <Preview align="start" code={desktopCode}>
        {desktop}
      </Preview>
      <p className="text-sm font-semibold text-ink mt-6 mb-2">Mobile</p>
      <Preview align="start" code={mobileCode}>
        {mobile}
      </Preview>
    </>
  );
}

export default function AccountPage() {
  return (
    <DocPage
      title="Account"
      description="The customer account (Orders + Profile), mapped from the OG file's '👤 Account Components' canvas (node 1777:1912), built from the live Shopify-hosted account on tovfurniture.com and restyled with the file's own tokens and components. Every set is still Status=Draft in Figma because the live site hasn't been updated to match."
    >
      <DocSection title={<>Account Nav <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The same 4 links as the live account (Home, Orders, Profile, Logout). Current page in
          SemiBold charcoal, the rest <code>#777</code>. Desktop is a left rail, Mobile a row.
        </p>
        <Viewports
          desktop={<div className="flex gap-16"><AccountNav active="Orders" /><AccountNav active="Profile" /></div>}
          mobile={<div className="flex flex-col gap-4"><AccountNav active="Orders" compact /><AccountNav active="Profile" compact /></div>}
          desktopCode={`<AccountNav active="Orders" />`}
          mobileCode={`<AccountNav active="Orders" compact />`}
        />
      </DocSection>

      <DocSection title={<>Points Banner <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">TOV Points loyalty message at the top of Orders, matching the live account.</p>
        <Viewports
          desktop={<AccountPointsBanner />}
          mobile={<AccountPointsBanner compact />}
          desktopCode={`<AccountPointsBanner />`}
          mobileCode={`<AccountPointsBanner compact />`}
        />
      </DocSection>

      <DocSection title={<>Welcome Card <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The Orders empty state (&quot;Welcome, [name] / Ready to shop?&quot;). Reuses the real
          primary <code>Button</code> at Figma&apos;s 244×54, full width on Mobile.
        </p>
        <Viewports
          desktop={<AccountWelcomeCard />}
          mobile={<AccountWelcomeCard compact />}
          desktopCode={`<AccountWelcomeCard name="Customer" />`}
          mobileCode={`<AccountWelcomeCard name="Customer" compact />`}
        />
      </DocSection>

      <DocSection title={<>Order Card <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Status + date, product thumbnails, order number, total, View order.
        </p>
        <Viewports
          desktop={<AccountOrderCard />}
          mobile={<AccountOrderCard compact />}
          desktopCode={`<AccountOrderCard />`}
          mobileCode={`<AccountOrderCard compact />`}
        />
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          The reference account has no live orders, so this card follows the standard Shopify
          customer-account order list layout rather than a real TOV order example.
        </div>
      </DocSection>

      <DocSection title={<>Contact Info <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">Profile: name + Edit, then Email and Phone rows. Rows stack on Mobile.</p>
        <Viewports
          desktop={<AccountContactInfo />}
          mobile={<AccountContactInfo compact />}
          desktopCode={`<AccountContactInfo />`}
          mobileCode={`<AccountContactInfo compact />`}
        />
      </DocSection>

      <DocSection title={<>Addresses <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          2 versions: Empty (the live account&apos;s state) and Saved.
        </p>
        <Viewports
          desktop={<div className="flex flex-col gap-6"><AccountAddresses /><AccountAddresses saved /></div>}
          mobile={<div className="flex flex-col gap-6"><AccountAddresses compact /><AccountAddresses saved compact /></div>}
          desktopCode={`<AccountAddresses />\n<AccountAddresses saved />`}
          mobileCode={`<AccountAddresses compact />\n<AccountAddresses saved compact />`}
        />
        <div className="rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted mt-4">
          <strong className="text-ink">In code:</strong> the reference account has no saved
          addresses, so the Saved state isn&apos;t shown against a live example. The icon is the
          approved General-set <code>pin</code>, a pushpin rather than the live site&apos;s map
          marker — the only map marker in the file comes from the imported generic icon kit.
        </div>
      </DocSection>

      <DocSection title={<>Marketing Preferences <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          Email opt-in with the new Account Toggle. The live site shows an envelope icon beside
          &quot;Email&quot;. It&apos;s left out because the only envelope in the file comes from the
          imported generic icon kit.
        </p>
        <Viewports
          desktop={<AccountMarketingPreferences />}
          mobile={<AccountMarketingPreferences compact />}
          desktopCode={`<AccountMarketingPreferences />`}
          mobileCode={`<AccountMarketingPreferences compact />`}
        />
      </DocSection>

      <DocSection title={<>Sign Out <Badge variant="new">New</Badge></>}>
        <Viewports
          desktop={<AccountSignOut />}
          mobile={<AccountSignOut compact />}
          desktopCode={`<AccountSignOut />`}
          mobileCode={`<AccountSignOut compact />`}
        />
      </DocSection>

      <DocSection title={<>Small Button &amp; Toggle <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          2 small pieces the account needed that the system didn&apos;t have: a 12px pill button
          (Outline / Filled) and an on/off switch.
        </p>
        <Preview align="start" code={`<AccountButtonSmall label="Edit" />\n<AccountButtonSmall label="Edit" filled />\n<AccountToggle on />\n<AccountToggle on={false} />`}>
          <AccountButtonSmall label="Edit" />
          <AccountButtonSmall label="Edit" filled />
          <AccountToggle on />
          <AccountToggle on={false} />
        </Preview>
      </DocSection>

      <DocSection title={<>Full pages <Badge variant="new">New</Badge></>}>
        <p className="text-xs text-ink-muted mb-3">
          The 6 page layouts from the Figma canvas: the real Navbar + Footer around the account
          body. The live account uses Shopify&apos;s minimal header (logo + avatar) and policy-link
          footer. The design uses the full site chrome instead.
        </p>
        {(
          [
            ["Orders", false, "Orders"],
            ["Orders", true, "Orders (empty)"],
            ["Profile", false, "Profile"],
          ] as const
        ).map(([page, empty, label]) => (
          <div key={label}>
            <p className="text-sm font-semibold text-ink mt-6 mb-2">{label}: Desktop</p>
            <Preview align="start" code={`<AccountPageLayout page="${page}"${empty ? " empty" : ""} />`}>
              <AccountPageLayout page={page} empty={empty} />
            </Preview>
            <p className="text-sm font-semibold text-ink mt-6 mb-2">{label}: Mobile</p>
            <Preview align="start" code={`<AccountPageLayout page="${page}"${empty ? " empty" : ""} compact />`}>
              <AccountPageLayout page={page} empty={empty} compact />
            </Preview>
          </div>
        ))}
      </DocSection>

      <ChangeLogTable page="account" />
    </DocPage>
  );
}
