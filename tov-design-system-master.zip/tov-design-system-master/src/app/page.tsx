import Link from "next/link";
import { PROPERTIES } from "@/lib/nav";
import { FigmaSyncStatus } from "@/components/docs/FigmaSyncStatus";

const B2C_NAV_SECTIONS = PROPERTIES.find((p) => p.key === "b2c")!.sections;

export default function Home() {
  return (
    <div className="max-w-4xl px-8 py-10">
      <p className="text-xs font-semibold uppercase tracking-wide-ui text-primary mb-3">
        Version 0.1 · Internal
      </p>
      <h1 className="font-display text-5xl text-primary-dark mb-4">
        TOV Design System
      </h1>
      <p className="text-ink-muted max-w-2xl mb-10 text-lg">
        The single source of truth for how TOV Furniture's website looks and
        behaves — foundations, ecommerce components, and the shared imagery
        library. Modeled after Material Design's structure, scoped to only
        what our storefront actually needs.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {B2C_NAV_SECTIONS.filter((s) => s.title !== "Get started").map((section) => (
          <div key={section.title} className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
            <h2 className="font-display text-lg text-ink mb-3">{section.title}</h2>
            <ul className="flex flex-col gap-2">
              {section.items.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-primary-dark hover:text-primary hover:underline"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <FigmaSyncStatus />
      </div>

      <div className="mt-10 rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        <strong className="text-ink">Where this system comes from:</strong> every
        token, component, and pattern here is mapped directly from TOV&apos;s Figma
        files — the source of truth for the brand — and cross-referenced against
        the live site at tovfurniture.com to confirm what&apos;s actually shipped.
        As Figma evolves, this system is updated to stay in sync, so it remains an
        accurate, living reference for anyone building on the TOV brand.
      </div>
    </div>
  );
}
