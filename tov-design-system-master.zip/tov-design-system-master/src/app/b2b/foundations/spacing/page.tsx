import { DocPage, DocSection } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { spacingTokens, radiusTokens, breakpointMargins } from "@/lib/b2bTokens";

/** A solid margin block would visually compete with the content block, so the
 * gutter reads as "excluded space" via a diagonal stripe, a common convention
 * for margin/safe-area diagrams. */
const MARGIN_STRIPE = {
  backgroundImage:
    "repeating-linear-gradient(-45deg, var(--color-primary) 0, var(--color-primary) 1px, transparent 1px, transparent 6px)",
  backgroundColor: "var(--color-cream-200)",
};

const SWATCH = "rounded-sm bg-cream-200 border border-neutral-300";

function SpacingPreview({ value }: { value: number }) {
  return (
    <div className="flex items-center" style={{ gap: value }}>
      <div className={`h-8 w-8 ${SWATCH}`} />
      <div className={`h-8 w-8 ${SWATCH}`} />
    </div>
  );
}

function MarginRuler() {
  const maxRefWidth = Math.max(...breakpointMargins.map((b) => b.width));

  return (
    <div className="flex flex-col gap-5 rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
      {breakpointMargins.map((b) => {
        const barPct = (b.width / maxRefWidth) * 100;
        const marginPct = (b.margin / maxRefWidth) * 100;
        return (
          <div key={b.breakpoint}>
            <div className="flex items-baseline gap-2 mb-1.5">
              <span className="text-sm font-semibold text-ink">{b.breakpoint}</span>
              <span className="text-xs font-mono text-ink-muted">{b.width}px</span>
            </div>
            <div className="flex h-9" style={{ width: `${barPct}%` }}>
              <div
                className="h-full shrink-0 flex items-center justify-center"
                style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }}
              >
                {marginPct >= 4 && (
                  <span className="text-[9px] font-mono text-primary-dark bg-white/80 px-0.5 rounded-sm">
                    {b.margin}
                  </span>
                )}
              </div>
              <div className="h-full flex-1 min-w-0 bg-cream-50 border-y border-neutral-300 flex items-center justify-center">
                <span className="text-[10px] font-mono text-ink-muted truncate px-1">{b.contentArea} content</span>
              </div>
              <div
                className="h-full shrink-0"
                style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }}
              />
            </div>
          </div>
        );
      })}
      <p className="text-xs text-ink-muted mt-1">
        Bars are scaled proportionally to each breakpoint&apos;s width; the
        striped edges are the page margin.
      </p>
    </div>
  );
}

export default function B2BSpacingPage() {
  return (
    <DocPage
      title="Spacing & Radius"
      description="Spacing tokens bind to auto-layout gaps/padding; radius tokens to corners."
    >
      <DocSection title="Page margin, by breakpoint">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Desktop uses a 75px side margin (1290px content), Tablet uses 40px and
          Mobile uses 20px.
        </p>
        <MarginRuler />
      </DocSection>

      <DocSection title="Spacing scale">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          A single linear scale, used for gaps and padding alike — pick the
          step that matches how related the two elements are, from tightest
          (2xs) to loosest (5xl).
        </p>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 shadow-sm bg-white">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Preview</th>
                <th className="px-4 py-2 font-semibold">Token</th>
                <th className="px-4 py-2 font-semibold">Value</th>
                <th className="px-4 py-2 font-semibold">Usage</th>
                <th className="px-4 py-2 font-semibold">Variable</th>
              </tr>
            </thead>
            <tbody>
              {spacingTokens.map((t) => (
                <tr key={t.name} className="border-t border-neutral-200 align-top">
                  <td className="px-4 py-3">
                    <SpacingPreview value={t.value} />
                  </td>
                  <td className="px-4 py-3 font-semibold whitespace-nowrap">{t.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{t.value}px</td>
                  <td className="px-4 py-3 text-ink-muted">{t.usage}</td>
                  <td className="px-4 py-3 font-mono text-xs text-primary-dark whitespace-nowrap">
                    var({t.css})
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title="Radius">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {radiusTokens.map((r) => (
            <div key={r.name} className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-4 text-center">
              <div
                className="h-16 bg-primary mx-auto mb-3"
                style={{ width: "100%", borderRadius: r.value }}
              />
              <div className="text-sm font-semibold">{r.name}</div>
              <div className="text-xs font-mono text-ink-muted">{r.value}</div>
              <div className="text-xs text-ink-muted mt-1">{r.usage}</div>
            </div>
          ))}
        </div>
      </DocSection>

      <ChangeLogTable page="b2b-spacing" />
    </DocPage>
  );
}
