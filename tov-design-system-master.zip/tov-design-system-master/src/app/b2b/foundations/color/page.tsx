import { DocPage, DocSection } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import {
  colorPrimitives,
  semanticBg,
  semanticText,
  semanticBorder,
  semanticIcon,
  type SemanticColorToken,
} from "@/lib/b2bTokens";

function SemanticGroup({ title, tokens }: { title: string; tokens: SemanticColorToken[] }) {
  return (
    <div>
      <h3 className="font-semibold text-ink mb-3">{title}</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {tokens.map((t) => (
          <div key={t.name} className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white">
            <div className="h-20" style={{ background: t.hex }} />
            <div className="p-3">
              <div className="text-sm font-semibold">{t.name}</div>
              <div className="text-xs font-mono text-ink-muted">
                {t.hex} · {t.mapsTo}
              </div>
              <div className="text-xs text-ink-muted mt-1">{t.usage}</div>
              <code className="text-[11px] font-mono text-primary-dark">var({t.css})</code>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function B2BColorPage() {
  return (
    <DocPage
      title="Color"
      description="Primitives hold raw brand values; semantic tokens (bg / text / border / icon) alias them and are what components bind to."
    >
      <DocSection title="Primitives">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Raw brand values. Never reference a primitive directly from a
          component — use the semantic token that aliases it, so a future
          palette change only needs to happen in one place.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
          {colorPrimitives.map((p) => (
            <div key={p.name} className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white">
              <div className="h-14" style={{ background: p.hex }} />
              <div className="p-2.5">
                <div className="text-xs font-semibold">{p.name}</div>
                <div className="text-[11px] font-mono text-ink-muted">{p.hex}</div>
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Semantic · bg">
        <SemanticGroup title="Background roles" tokens={semanticBg} />
      </DocSection>

      <DocSection title="Semantic · text">
        <SemanticGroup title="Text roles" tokens={semanticText} />
      </DocSection>

      <DocSection title="Semantic · border">
        <SemanticGroup title="Border roles" tokens={semanticBorder} />
      </DocSection>

      <DocSection title="Semantic · icon">
        <SemanticGroup title="Icon roles" tokens={semanticIcon} />
      </DocSection>

      <ChangeLogTable page="b2b-color" />
    </DocPage>
  );
}
