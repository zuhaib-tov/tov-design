import { DocPage, DocSection } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { fontFamilies, typeRamp, type TypeStep } from "@/lib/b2bTokens";

function weightToCss(weight: TypeStep["weight"]): number {
  switch (weight) {
    case "Light":
      return 300;
    case "Regular":
      return 400;
    case "Medium":
      return 500;
    case "SemiBold":
      return 600;
    case "Bold":
      return 700;
  }
}

function StyleRow({ step }: { step: TypeStep }) {
  const fontClass = step.family === "GT Ultra Fine Trial" ? "font-display" : "font-sans";
  return (
    <div className="flex items-baseline gap-4 py-3 border-t border-neutral-200 first:border-t-0">
      <div className="w-36 shrink-0">
        <div className="text-xs font-mono font-semibold text-ink">{step.name}</div>
        <div className="text-[11px] text-ink-muted">
          {step.family} · {step.weight}
        </div>
      </div>
      <p
        className={`${fontClass} text-ink flex-1 min-w-0 truncate`}
        style={{
          fontSize: step.size,
          lineHeight: step.lineHeight === "auto" ? "normal" : `${step.lineHeight}px`,
          fontWeight: weightToCss(step.weight),
          letterSpacing: step.letterSpacing ? `${step.letterSpacing}px` : undefined,
          textTransform: step.uppercase ? "uppercase" : undefined,
        }}
      >
        {step.uppercase ? "Professional program" : "Elevated design, never overpriced"}
      </p>
      <span className="ml-auto shrink-0 text-xs font-mono text-ink-muted whitespace-nowrap">
        {step.size}px / {step.lineHeight === "auto" ? "auto" : `${step.lineHeight}px`}
      </span>
    </div>
  );
}

export default function B2BTypographyPage() {
  return (
    <DocPage
      title="Typography"
      description="Two families: GT Ultra Fine (serif) for display and headings, Montserrat for body, labels and UI. On Mobile, headings step down by one level (e.g. H1 46 becomes H3 26)."
    >
      <DocSection title="Type families">
        <div className="flex flex-col gap-6">
          {fontFamilies.map((f) => (
            <div key={f.name} className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
              <div className="text-xs font-semibold uppercase tracking-wide-ui text-ink-muted mb-1">
                {f.name}
              </div>
              <div className="text-xs text-ink-muted mb-3">{f.stack}</div>
              <p className={f.name === "GT Ultra Fine Trial" ? "font-display text-4xl" : "font-sans text-2xl"}>
                Elevated design, never overpriced
              </p>
              <p className="text-xs text-ink-muted mt-2">{f.usage}</p>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Type styles">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          The full named style ramp, from the largest display size down to
          button and label text. Reference a style by name
          (e.g. <code className="font-mono text-[11px]">Heading/H3</code>) rather than hard-coding its
          size and line-height.
        </p>
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white px-5">
          {typeRamp.map((step) => (
            <StyleRow key={step.name} step={step} />
          ))}
        </div>
      </DocSection>

      <ChangeLogTable page="b2b-typography" />
    </DocPage>
  );
}
