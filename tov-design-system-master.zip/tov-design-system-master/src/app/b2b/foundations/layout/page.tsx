import Link from "next/link";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { breakpointMargins, sectionRhythm } from "@/lib/b2bTokens";

const MARGIN_STRIPE = {
  backgroundImage:
    "repeating-linear-gradient(-45deg, var(--color-primary) 0, var(--color-primary) 1px, transparent 1px, transparent 6px)",
  backgroundColor: "var(--color-cream-200)",
};

function ColumnGridRow({ b, maxRefWidth }: { b: (typeof breakpointMargins)[number]; maxRefWidth: number }) {
  const barPct = (b.width / maxRefWidth) * 100;
  const marginPct = (b.margin / maxRefWidth) * 100;
  const gutterPct = (b.gutter / maxRefWidth) * 100;
  return (
    <div>
      <div className="flex items-baseline gap-2 mb-1.5">
        <span className="text-sm font-semibold text-ink">{b.breakpoint}</span>
        <span className="text-xs font-mono text-ink-muted">{b.width}px</span>
      </div>
      <div className="flex h-12" style={{ width: `${barPct}%` }}>
        <div className="h-full shrink-0" style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }} />
        <div className="h-full flex-1 min-w-0 flex" style={{ gap: `${gutterPct}%` }}>
          {Array.from({ length: b.columns }).map((_, i) => (
            <div key={i} className="h-full flex-1 bg-cream-200 border border-neutral-300 rounded-sm" />
          ))}
        </div>
        <div className="h-full shrink-0" style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }} />
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-2 text-xs text-ink-muted">
        <span><span className="font-semibold text-ink">{b.columns}</span> columns</span>
        <span><span className="font-semibold text-ink">{b.gutter}px</span> gutter</span>
        <span><span className="font-semibold text-ink">{b.margin}px</span> margin</span>
        <span><span className="font-semibold text-ink">{b.contentArea}</span> content area</span>
      </div>
    </div>
  );
}

function ColumnGrid() {
  const maxRefWidth = Math.max(...breakpointMargins.map((b) => b.width));
  return (
    <div className="flex flex-col gap-6 rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
      {breakpointMargins.map((b) => (
        <ColumnGridRow key={b.breakpoint} b={b} maxRefWidth={maxRefWidth} />
      ))}
      <p className="text-xs text-ink-muted -mt-2">
        Bars are scaled proportionally to each breakpoint&apos;s width. Values are
        defined in the Layout variable collection (Desktop / Tablet / Mobile
        modes) and as Layout grid styles.
      </p>
    </div>
  );
}

function SectionRhythmExample() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
      {sectionRhythm.map((s) => (
        <div key={s.name} className="rounded-app-lg border border-neutral-200 bg-cream-100 p-4">
          <h3 className="text-sm font-semibold text-ink mb-1">{s.name}</h3>
          <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-ink-muted mb-2">
            <span><span className="font-semibold text-ink">Desktop: </span>{s.desktop}</span>
            {s.mobile && (
              <span><span className="font-semibold text-ink">Mobile: </span>{s.mobile}</span>
            )}
          </div>
          <p className="text-xs text-ink-muted">{s.usage}</p>
        </div>
      ))}
    </div>
  );
}

export default function B2BLayoutPage() {
  return (
    <DocPage
      title="Layout & Breakpoints"
      description="Page margins are 75px on Desktop (1440 wide, 1290px content area), 40px on Tablet (768 wide) and 20px on Mobile (390 wide)."
    >
      <DocSection title="Composition rule">
        <div className="rounded-app-lg border border-neutral-200 bg-cream-100 p-4">
          <p className="text-xs text-ink-muted">
            <span className="font-semibold text-ink">A component owns its
            internal padding, never its outer margin. </span>
            The parent — a stack, a grid, or a section — owns the space
            between things, using the tokens on this page and on{" "}
            <Link href="/b2b/foundations/spacing" className="text-primary-dark hover:underline font-medium">
              Spacing &amp; Radius
            </Link>
            .
          </p>
        </div>
      </DocSection>

      <DocSection title="Breakpoints & column grid">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          12 columns on Desktop, 8 on Tablet, 4 on Mobile, each with its own
          gutter and margin.
        </p>
        <ColumnGrid />
      </DocSection>

      <DocSection title="Section rhythm">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          The vertical padding used between stacked sections, plus one
          documented exception.
        </p>
        <SectionRhythmExample />
      </DocSection>

      <ChangeLogTable page="b2b-layout" />
    </DocPage>
  );
}
