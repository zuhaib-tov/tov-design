import Link from "next/link";
import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { B2BAnnouncementBar } from "@/components/ui/B2BAnnouncementBar";
import { B2BHeader } from "@/components/ui/B2BHeader";
import { B2BHero } from "@/components/ui/B2BHero";
import { B2BWhyTov } from "@/components/ui/B2BWhyTov";
import { B2BProductCarousel, type B2BCarouselProduct } from "@/components/ui/B2BProductCarousel";
import { B2BBenefitsBar } from "@/components/ui/B2BBenefitsBar";
import { B2BCollectionFeature } from "@/components/ui/B2BCollectionFeature";
import { B2BTradePrograms } from "@/components/ui/B2BTradePrograms";
import { B2BBrowseByCategory } from "@/components/ui/B2BBrowseByCategory";
import { B2BPromoBanner } from "@/components/ui/B2BPromoBanner";
import { B2BHowItWorks } from "@/components/ui/B2BHowItWorks";
import { B2BSpacesSection } from "@/components/ui/B2BSpacesSection";
import { B2BTestimonialsSection } from "@/components/ui/B2BTestimonialsSection";
import { B2BTradeAgentBanner } from "@/components/ui/B2BTradeAgentBanner";
import { B2BFooter } from "@/components/ui/B2BFooter";
import { B2BEmailSignUp } from "@/components/ui/B2BEmailSignUp";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const IMG = "/images/b2b/homepage";
const LOGO = `${IMG}/logos`;

function Screen({ children }: { children: ReactNode }) {
  return <div className="w-[1440px] bg-white font-sans">{children}</div>;
}

const NEW_ARRIVALS: B2BCarouselProduct[] = [
  {
    tag: "New Arrival",
    eyebrow: "New Color",
    name: "Cynthia Indoor/Outdoor Side Table",
    image: `${IMG}/product-side-table.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Contract Grade",
    eyebrowStyle: "strong",
    name: "Rafaelle Natural Solid Ashe Bed",
    image: `${IMG}/product-ash-bed.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Performance Fabric",
    eyebrowStyle: "strong",
    name: "Lina Accent Chair",
    image: `${IMG}/product-accent-chair.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Performance Fabric",
    eyebrowStyle: "strong",
    name: "Oodle Vegan Mohair Stool",
    price: "$170 - $180",
    image: `${IMG}/product-mohair-stool.webp`,
  },
];

const BEST_SELLERS: B2BCarouselProduct[] = [
  {
    tag: "Best Seller",
    eyebrow: "Performance Fabric",
    eyebrowStyle: "strong",
    name: "Dex Striped Linen Ottoman",
    nameSize: "base",
    image: `${IMG}/product-striped-ottoman.webp`,
  },
  {
    tag: "Best Seller",
    name: "Atolla Tassel Table Lamp",
    nameSize: "base",
    image: `${IMG}/product-tassel-lamp.webp`,
  },
  {
    tag: "Best Seller",
    name: "Hump 54” Arched Console Table",
    nameSize: "base",
    image: `${IMG}/product-arched-console.webp`,
  },
  {
    tag: "Best Seller",
    name: "Maiori Striped Papier Mache Table Lamp",
    nameSize: "base",
    price: "$59 - $60",
    image: `${IMG}/product-papier-mache-lamp.webp`,
  },
  {
    tag: "New Arrival",
    eyebrow: "New Color",
    name: "Cynthia Indoor/Outdoor Side Table",
    price: "$1,599",
    image: `${IMG}/product-side-table.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Contract Grade",
    eyebrowStyle: "strong",
    name: "Rafaelle Natural Solid Ashe Bed",
    price: "$575 - $625",
    image: `${IMG}/product-ash-bed.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Performance Fabric",
    eyebrowStyle: "strong",
    name: "Lina Accent Chair",
    price: "$365",
    image: `${IMG}/product-accent-chair.webp`,
  },
  {
    tag: "New Arrivals",
    eyebrow: "Performance Fabric",
    eyebrowStyle: "strong",
    name: "Oodle Vegan Mohair Stool",
    price: "$170 - $180",
    image: `${IMG}/product-mohair-stool.webp`,
  },
];

const CONTRACT_GRADE_PRODUCTS = [
  { tag: "Sustainable", image: `${IMG}/product-sofa.webp` },
  { tag: "Best Seller", image: `${IMG}/product-swivel-chair.webp` },
  { tag: "New Arrival", image: `${IMG}/product-striped-table.webp` },
  { tag: "Best Seller", image: `${IMG}/product-boucle-bed.webp` },
];

const CATEGORIES = [
  { label: "Accent Chairs", image: `${IMG}/category-accent-chairs.jpg` },
  { label: "Dining Chairs", image: `${IMG}/category-dining-chairs.jpg` },
  { label: "Dining Tables", image: `${IMG}/category-dining-tables.jpg` },
  { label: "Coffee & Tables", image: `${IMG}/category-coffee-tables.jpg` },
  { label: "Sofas", image: `${IMG}/category-sofas.jpg` },
];

const SPACES = [
  { title: "Restaurants & Bars", image: `${IMG}/space-restaurants-bars.jpg` },
  { title: "Short-Term Rentals", image: `${IMG}/space-short-term-rentals.jpg` },
  { title: "Hotels & Boutique Lodging", image: `${IMG}/space-hotels-lodging.jpg` },
  { title: "Events & Pop-Ups", image: `${IMG}/space-events-pop-ups.jpg` },
];

const TESTIMONIALS = [
  {
    quote:
      "The pricing works for the project and the pieces still look like something. My partner handles logistics so I stay in the design.",
    name: "Maya Ellison",
    role: "Principal, Ellison Studio",
  },
  {
    quote:
      "We furnished 42 units on a tight timeline. Everything shipped in-stock and on schedule — no last-minute substitutions.",
    name: "Devin Cho",
    role: "Procurement, Northwind Living",
  },
  {
    quote:
      "Contract-grade where it counts, and the finishes photograph beautifully. It’s become our go-to for hospitality lobbies.",
    name: "Priya Raman",
    role: "Design Director, Atelier Sur",
  },
];

const PARTNERS = [
  { name: "Almond + Oak", src: `${LOGO}/partner-almond-oak.svg`, width: 105, height: 11 },
  { name: "Wren & Willow", src: `${LOGO}/partner-wren-willow.svg`, width: 105, height: 18 },
  { name: "Saffron", src: `${LOGO}/partner-saffron.svg`, width: 83, height: 18 },
  { name: "Cordova", src: `${LOGO}/partner-cordova.svg`, width: 120, height: 21 },
  { name: "Linnea", src: `${LOGO}/partner-linnea.svg`, width: 113, height: 18 },
  { name: "Solène", src: `${LOGO}/partner-solene.svg`, width: 80, height: 25 },
  { name: "Maison Olive", src: `${LOGO}/partner-maison-olive.svg`, width: 113, height: 31 },
];

const SECTIONS: { section: string; component: string; href?: string }[] = [
  { section: "Announcement bar", component: "Announcement Bar", href: "/b2b/components/banners" },
  { section: "Header and category navigation", component: "Navigation", href: "/b2b/components/navigation" },
  { section: "Hero", component: "Hero", href: "/b2b/components/banners" },
  { section: "Why TOV", component: "Why TOV", href: "/b2b/components/why-tov" },
  { section: "New Arrivals", component: "Carousel (New Arrivals)", href: "/b2b/components/carousel" },
  { section: "Program benefits", component: "Benefits Bar", href: "/b2b/components/benefits-programs" },
  { section: "Contract Grade", component: "Collection Feature", href: "/b2b/components/feature-card" },
  { section: "Trade Program and Wholesale", component: "Trade Programs", href: "/b2b/components/benefits-programs" },
  { section: "Browse by category", component: "Browse by Category", href: "/b2b/components/category-tile" },
  { section: "Closeout offer", component: "Promo Banner", href: "/b2b/components/banners" },
  { section: "Best Sellers", component: "Carousel (Best Sellers)", href: "/b2b/components/carousel" },
  { section: "How it works", component: "How It Works" },
  { section: "Get inspired", component: "Spaces Section" },
  { section: "Trusted by the trade", component: "Testimonials Section" },
  { section: "Talk to a trade agent", component: "Trade Agent Banner" },
  { section: "Footer", component: "Footer" },
  { section: "Email sign up", component: "Email Sign Up" },
];

export default function B2BHomepagePage() {
  return (
    <DocPage
      title="Homepage"
      description="The Professional Program homepage. A single desktop composition that introduces the program, presents the Trade Program and Wholesale offers, merchandises new and best-selling product, and closes with social proof, trade support and email sign up."
    >
      <DocSection title="Full page">
        <Preview
          align="start"
          code={`<Screen>
  <B2BAnnouncementBar />
  <B2BHeader navStyle="centered" />
  <B2BHero variant="centered" image="…" … />
  <B2BWhyTov accentUnits />
  <B2BProductCarousel variant="new-arrivals" featureImage="…" products={newArrivals} />
  <B2BBenefitsBar />
  <B2BCollectionFeature layout="even" image="…" products={contractGrade} />
  <B2BTradePrograms />
  <B2BBrowseByCategory categories={categories} labelAlign="center" />
  <B2BPromoBanner />
  <B2BProductCarousel variant="best-sellers" featureImage="…" products={bestSellers} />
  <B2BHowItWorks />
  <B2BSpacesSection spaces={spaces} />
  <B2BTestimonialsSection testimonials={testimonials} partners={partners} />
  <B2BTradeAgentBanner />
  <B2BFooter />
  <B2BEmailSignUp />
</Screen>`}
        >
          <Screen>
            <div className="bg-white pt-5">
              <B2BAnnouncementBar />
            </div>
            <B2BHeader navStyle="centered" />
            <B2BHero
              variant="centered"
              image={`${IMG}/hero.jpg`}
              eyebrow="Professional Program"
              headline="Welcome to TOV’s Professional Program"
              body="From interior designers and architects to trade and wholesale partners, our Professional Program is built for the industry. Enjoy exclusive benefits, insider resources, and dedicated service designed around how you work."
              ctaLabel="Join TOV Professional"
            />
            <B2BWhyTov accentUnits />
            <B2BProductCarousel
              variant="new-arrivals"
              featureImage={`${IMG}/new-arrivals-feature.jpg`}
              products={NEW_ARRIVALS}
              className="pb-[29px]!"
              arrowClassName="right-[75px]! top-[156px]!"
            />
            <div className="bg-white pb-10">
              <B2BBenefitsBar />
            </div>
            <B2BCollectionFeature layout="even" image={`${IMG}/contract-grade-feature.jpg`} products={CONTRACT_GRADE_PRODUCTS} />
            <B2BTradePrograms />
            <div className="bg-white">
              <B2BBrowseByCategory categories={CATEGORIES} labelAlign="center" />
            </div>
            <div className="bg-white pb-10">
              <B2BPromoBanner />
            </div>
            <div className="bg-white pb-10">
              <B2BProductCarousel
                variant="best-sellers"
                featureImage={`${IMG}/best-sellers-feature.jpg`}
                products={BEST_SELLERS}
                arrowClassName="right-[75px]! top-[156px]!"
              />
            </div>
            <B2BHowItWorks />
            <B2BSpacesSection spaces={SPACES} />
            <B2BTestimonialsSection testimonials={TESTIMONIALS} partners={PARTNERS} />
            <B2BTradeAgentBanner />
            <B2BFooter />
            <B2BEmailSignUp />
          </Screen>
        </Preview>
      </DocSection>

      <DocSection title="Sections">
        <div className="overflow-x-auto rounded-app-md border border-neutral-200 shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-200 text-left">
              <tr>
                <th className="px-3 py-2 font-semibold">Section</th>
                <th className="px-3 py-2 font-semibold">Component</th>
              </tr>
            </thead>
            <tbody>
              {SECTIONS.map((row) => (
                <tr key={row.section} className="border-t border-neutral-200">
                  <td className="px-3 py-2">{row.section}</td>
                  <td className="px-3 py-2">
                    {row.href ? (
                      <Link href={row.href} className="text-primary underline underline-offset-2">
                        {row.component}
                      </Link>
                    ) : (
                      row.component
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <ChangeLogTable page="b2b-page-homepage" />
    </DocPage>
  );
}
