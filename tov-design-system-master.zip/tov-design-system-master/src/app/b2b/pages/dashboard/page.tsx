import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import {
  B2BDashboardMainNavDesktop,
} from "@/components/ui/B2BDashboardMainNav";
import {
  B2BDashboardSidebar,
  type DashboardSidebarPage,
} from "@/components/ui/B2BDashboardSidebar";
import { B2BDashboardWelcomeHeader } from "@/components/ui/B2BDashboardWelcomeHeader";
import { B2BDashboardQuickActions } from "@/components/ui/B2BDashboardQuickActions";
import { B2BDashboardTrackOrdersCard } from "@/components/ui/B2BDashboardTrackOrdersCard";
import { B2BDashboardSalesChartCard } from "@/components/ui/B2BDashboardSalesChartCard";
import { B2BDashboardQuarterGoalCard } from "@/components/ui/B2BDashboardQuarterGoalCard";
import { B2BDashboardSavedProjectsStrip } from "@/components/ui/B2BDashboardSavedProjectsStrip";
import { B2BDashboardPageHeader } from "@/components/ui/B2BDashboardPageHeader";
import { B2BDashboardFilterBar } from "@/components/ui/B2BDashboardFilterBar";
import { B2BDashboardOrdersTable } from "@/components/ui/B2BDashboardOrdersTable";
import { B2BDashboardPaginationBar } from "@/components/ui/B2BDashboardPaginationBar";
import { B2BDashboardFormCard } from "@/components/ui/B2BDashboardFormCard";
import { B2BDashboardAccountRepCard } from "@/components/ui/B2BDashboardAccountRepCard";
import { B2BDashboardAgentProfile } from "@/components/ui/B2BDashboardAgentProfile";
import { B2BDashboardAssetCard } from "@/components/ui/B2BDashboardAssetCard";
import { B2BDashboardTipBanner } from "@/components/ui/B2BDashboardTipBanner";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Screen({
  active,
  minHeight = 960,
  children,
}: {
  active: DashboardSidebarPage;
  minHeight?: number;
  children: ReactNode;
}) {
  return (
    <div className="w-[1440px] bg-white font-sans">
      <B2BDashboardMainNavDesktop />
      <div className="flex items-start gap-7" style={{ minHeight }}>
        <B2BDashboardSidebar activePage={active} className="h-auto! self-stretch" />
        <div className="flex w-[1000px] flex-col gap-5 py-10">{children}</div>
      </div>
    </div>
  );
}

const ASSETS = [
  { count: "142 assets", title: "Social Media Assets", description: "Posts, stories, and banner templates designed for all major social platforms." },
  { count: "48 assets", title: "Email Templates", description: "Newsletter, promotional, and automated campaign email layouts." },
  { count: "35 assets", title: "Brochures & Flyers", description: "Print-ready promotional materials, leaflets, and physical handouts." },
  { count: "24 assets", title: "Brand Logos & Guidelines", description: "Official logo marks, color palettes, vector files, and typography guides." },
  { count: "18 assets", title: "Presentations", description: "Polished slide decks, client pitch templates, and internal reports." },
  { count: "64 assets", title: "Banner Ads", description: "Web and display advertising templates for digital campaigns." },
  { count: "210 assets", title: "Product Photography", description: "High-resolution product imagery and authentic lifestyle shoot assets." },
  { count: "15 assets", title: "Video Assets", description: "Branded intro clips, animated lower thirds, and motion graphics packages." },
];

export default function B2BDashboardPage() {
  return (
    <DocPage
      title="Dashboard"
      description="The signed-in account dashboard for Professional Program and Wholesale buyers. Every screen shares one frame — the logged-in Main Nav across the top and the Sidebar down the left, with the active page highlighted — and is assembled only from Dashboard organisms, so a change to a component updates every screen that uses it."
    >
      <DocSection title="Overview">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          The landing screen: a personalized welcome with headline account metrics, quick
          access to core tools, live order tracking, sales insights against the quarter
          goal, and the buyer&apos;s saved projects.
        </p>
        <Preview
          align="start"
          code={`<Screen active="overview">
  <B2BDashboardWelcomeHeader />
  <B2BDashboardQuickActions />
  <B2BDashboardTrackOrdersCard />
  <div className="flex gap-5">
    <B2BDashboardSalesChartCard />
    <B2BDashboardQuarterGoalCard />
  </div>
  <B2BDashboardSavedProjectsStrip />
</Screen>`}
        >
          <Screen active="overview" minHeight={1436}>
            <B2BDashboardWelcomeHeader />
            <B2BDashboardQuickActions />
            <B2BDashboardTrackOrdersCard />
            <div className="flex w-full items-stretch gap-5">
              <B2BDashboardSalesChartCard />
              <B2BDashboardQuarterGoalCard />
            </div>
            <B2BDashboardSavedProjectsStrip />
          </Screen>
        </Preview>
      </DocSection>

      <DocSection title="Orders">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          The full order history: a page header with the primary action, a filter bar for
          search, date range and status, the orders table, and pagination.
        </p>
        <Preview
          align="start"
          code={`<Screen active="orders">
  <B2BDashboardPageHeader />
  <B2BDashboardFilterBar />
  <B2BDashboardOrdersTable />
  <B2BDashboardPaginationBar />
</Screen>`}
        >
          <Screen active="orders">
            <B2BDashboardPageHeader
              title="Orders"
              subtitle="Track, filter and export every trade order."
              actionLabel="+ Place new order"
              className="w-full!"
            />
            <B2BDashboardFilterBar className="w-full!" />
            <B2BDashboardOrdersTable className="w-full!" />
            <B2BDashboardPaginationBar
              rangeStart={1}
              rangeEnd={8}
              total={54}
              perPage={10}
              currentPage={1}
              lastPage={7}
              className="w-full!"
            />
          </Screen>
        </Preview>
      </DocSection>

      <DocSection title="Account Info">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Account management in two columns: personal details on the left, company
          details and the assigned account representative on the right.
        </p>
        <Preview
          align="start"
          code={`<Screen active="account-info">
  <B2BDashboardPageHeader title="Account Info" actionLabel="Update Account" />
  <div className="flex gap-6">
    <B2BDashboardFormCard variant="personal" />
    <div className="flex flex-col gap-6">
      <B2BDashboardFormCard variant="company" />
      <B2BDashboardAccountRepCard />
    </div>
  </div>
</Screen>`}
        >
          <Screen active="account-info">
            <B2BDashboardPageHeader
              title="Account Info"
              subtitle="Manage your personal details, company profile, and shipping preferences."
              actionLabel="Update Account"
              className="w-full!"
            />
            <div className="flex w-full items-start gap-6">
              <div className="w-[488px]">
                <B2BDashboardFormCard variant="personal" className="w-full!" />
              </div>
              <div className="flex w-[488px] flex-col gap-6">
                <B2BDashboardFormCard variant="company" className="w-full!" />
                <B2BDashboardAccountRepCard className="w-full!" />
              </div>
            </div>
          </Screen>
        </Preview>
      </DocSection>

      <DocSection title="Support">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Direct access to the buyer&apos;s support agent, with contact details and
          one-click email and call actions.
        </p>
        <Preview
          align="start"
          code={`<Screen active="support">
  <B2BDashboardPageHeader title="Support" />
  <B2BDashboardAgentProfile />
</Screen>`}
        >
          <Screen active="support">
            <B2BDashboardPageHeader
              title="Support"
              subtitle="Get help from our team or submit a quick message."
              className="w-full!"
            />
            <B2BDashboardAgentProfile className="w-full!" />
          </Screen>
        </Preview>
      </DocSection>

      <DocSection title="Marketing Materials">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          A browsable library of official brand collateral: search and filter by format,
          a grid of asset categories with counts, and a tip banner about available file
          formats.
        </p>
        <Preview
          align="start"
          code={`<Screen active="marketing-materials">
  <B2BDashboardPageHeader title="Marketing Materials" />
  <B2BDashboardFilterBar actionLabel="Download All (.zip)" />
  <div className="grid grid-cols-3 gap-6">
    {assets.map((a) => <B2BDashboardAssetCard key={a.title} {...a} />)}
  </div>
  <B2BDashboardTipBanner text="…" />
</Screen>`}
        >
          <Screen active="marketing-materials">
            <B2BDashboardPageHeader
              title="Marketing Materials"
              subtitle="Access and download official brand collateral, social templates, and advertising assets."
              className="w-full!"
            />
            <B2BDashboardFilterBar
              searchPlaceholder="Search templates..."
              dateRangeLabel="Format:"
              dateRangeValue="All Formats"
              statusLabel="Sort:"
              statusValue="Most Popular"
              actionLabel="Download All (.zip)"
              className="w-full!"
            />
            <div className="grid w-full grid-cols-3 gap-6">
              {ASSETS.map((a) => (
                <B2BDashboardAssetCard key={a.title} {...a} className="w-full!" />
              ))}
            </div>
            <B2BDashboardTipBanner
              lead="Tip:"
              text="All templates are available in Figma, Photoshop, and Illustrator formats. Brand logos and vector elements are provided as high-quality SVGs."
              className="w-full!"
            />
          </Screen>
        </Preview>
      </DocSection>

      <ChangeLogTable page="b2b-page-dashboard" />
    </DocPage>
  );
}
