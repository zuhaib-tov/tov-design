import { ReactNode } from "react";
import { Library } from "lucide-react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BBenefitItem } from "@/components/ui/B2BBenefitItem";
import { B2BBenefitsBar } from "@/components/ui/B2BBenefitsBar";
import { B2BStep } from "@/components/ui/B2BStep";
import { B2BProgramCard, TRADE_PROGRAM_PERKS, WHOLESALE_PERKS } from "@/components/ui/B2BProgramCard";
import { B2BTradePrograms } from "@/components/ui/B2BTradePrograms";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const TRADE_DESCRIPTION =
  "Perfect For interior designers, staging companies, hospitality projects and event planners.";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

export default function BenefitsProgramsPage() {
  return (
    <DocPage
      title="Benefits & Programs"
      description="Content blocks that explain what the Professional Program offers and how to join it: the Benefit Item and the Benefits Bar that groups it, numbered onboarding Steps, and the Program Card and Trade Programs section that compare the Trade and Wholesale offers."
    >
      <DocSection title="Benefit Item">
        <Intro>
          Single icon-led program benefit with a heading and short explanation. It renders in white and is
          always composed on a mauve (brand) background, as in the Benefits Bar.
        </Intro>
        <Example label="On a brand background">
          <Preview
            code={`<B2BBenefitItem icon={Library} title="Digital Asset Library" description="Access an expansive library of digital assets for projects of every scale." />`}
          >
            <div className="rounded-app-md bg-primary p-8">
              <B2BBenefitItem
                icon={Library}
                title="Digital Asset Library"
                description="Access an expansive library of digital assets for projects of every scale."
              />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "icon", type: "LucideIcon", description: "Icon component rendered above the title" },
            { name: "title", type: "string", description: "Benefit heading" },
            { name: "description", type: "string", description: "Supporting explanation" },
          ]}
        />
      </DocSection>

      <DocSection title="Benefits Bar">
        <Intro>
          Grouped program benefits using repeated Benefit Items. Desktop and Mobile layouts share the benefit
          story; maintain clear icon-to-label relationships.
        </Intro>
        <Example label="Desktop">
          <Preview align="start" code={`<B2BBenefitsBar />`}>
            <B2BBenefitsBar />
          </Preview>
        </Example>
        <Example label="Mobile">
          <Preview align="start" code={`<B2BBenefitsBar compact />`}>
            <div className="max-w-[390px]">
              <B2BBenefitsBar compact />
            </div>
          </Preview>
        </Example>
      </DocSection>

      <DocSection title="Step">
        <Intro>
          Numbered onboarding instruction with a title and supporting description. Repeat for a clear sequence
          and keep step numbers in order.
        </Intro>
        <Example label="Desktop">
          <Preview
            code={`<B2BStep number="01" title="Apply in minutes" description="Tell us about your business. No resale certificate and no minimum buy-in required to get started." />`}
          >
            <B2BStep
              number="01"
              title="Apply in minutes"
              description="Tell us about your business. No resale certificate and no minimum buy-in required to get started."
            />
          </Preview>
        </Example>
        <Example label="Mobile">
          <Preview
            code={`<B2BStep compact number="01" title="Apply in minutes" description="Tell us about your business. No resale certificate required to get started today." />`}
          >
            <B2BStep
              compact
              number="01"
              title="Apply in minutes"
              description="Tell us about your business. No resale certificate required to get started today."
            />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "number", type: "string", description: 'Two-digit step number, e.g. "01"' },
            { name: "title", type: "string", description: "Step title" },
            { name: "description", type: "string", description: "Supporting instruction copy" },
            { name: "compact", type: "boolean", default: "false", description: "Renders the Mobile variant (left-aligned, cream card)" },
          ]}
        />
      </DocSection>

      <DocSection title="Program Card">
        <Intro>
          Detailed program offer for Trade Program or Wholesale, including audience, benefits and requirements.
          Both program versions have Desktop and Mobile variants; keep eligibility and pricing copy approved.
          Mobile renders as a cream-filled card with no border, in place of Desktop&apos;s bordered, transparent
          panel.
        </Intro>
        <Example label="Trade Program · Desktop">
          <Preview
            align="start"
            code={`<B2BProgramCard title="Trade Program" description="${TRADE_DESCRIPTION}" perks={TRADE_PROGRAM_PERKS} />`}
          >
            <B2BProgramCard title="Trade Program" description={TRADE_DESCRIPTION} perks={TRADE_PROGRAM_PERKS} />
          </Preview>
        </Example>
        <Example label="Wholesale · Desktop">
          <Preview
            align="start"
            code={`<B2BProgramCard title="Wholesale" tierBadge="Tier II" tierLabel="PREMIUM" description="Perfect for brick & mortar stores and stocking dealers." perks={WHOLESALE_PERKS} />`}
          >
            <B2BProgramCard
              title="Wholesale"
              tierBadge="Tier II"
              tierLabel="PREMIUM"
              description="Perfect for brick & mortar stores and stocking dealers."
              perks={WHOLESALE_PERKS}
            />
          </Preview>
        </Example>
        <Example label="Trade Program · Mobile">
          <Preview
            align="start"
            code={`<B2BProgramCard compact title="Trade Program" description="${TRADE_DESCRIPTION}" perks={TRADE_PROGRAM_PERKS} />`}
          >
            <B2BProgramCard compact title="Trade Program" description={TRADE_DESCRIPTION} perks={TRADE_PROGRAM_PERKS} />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "title", type: "string", description: 'Program name, e.g. "Trade Program"' },
            { name: "description", type: "string", description: "Audience description" },
            { name: "tierBadge", type: "string", description: "Small filled pill next to the title — Wholesale only" },
            { name: "tierLabel", type: "string", description: "Uppercase label at the right of the title row — Wholesale only" },
            { name: "perks", type: "B2BProgramPerk[]", description: "Icon + title + description rows" },
            { name: "compact", type: "boolean", default: "false", description: "Renders the Mobile variant" },
          ]}
        />
      </DocSection>

      <DocSection title="Trade Programs">
        <Intro>
          Complete partnership section combining Program Cards and introductory messaging. Use to compare the
          Trade Program and Wholesale offers at the appropriate viewport.
        </Intro>
        <Example label="Desktop">
          <Preview align="start" code={`<B2BTradePrograms />`}>
            <B2BTradePrograms />
          </Preview>
        </Example>
        <Example label="Mobile">
          <Preview align="start" code={`<B2BTradePrograms compact />`}>
            <div className="max-w-[390px]">
              <B2BTradePrograms compact />
            </div>
          </Preview>
        </Example>
      </DocSection>

      <ChangeLogTable page="b2b-benefits-programs" />
    </DocPage>
  );
}
