import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BRatingStars } from "@/components/ui/B2BRatingStars";
import { B2BTestimonialCard } from "@/components/ui/B2BTestimonialCard";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const QUOTE =
  "The pricing works for the project and the pieces still look like something. My partner handles logistics so I stay in the design.";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

export default function ReviewsPage() {
  return (
    <DocPage
      title="Reviews"
      description="Social proof for the Professional Program: the five-star Rating Stars and the Testimonial Card that pairs a customer quote with its attribution and rating."
    >
      <DocSection title="Rating Stars">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Five-star visual used with social proof and testimonials. Always renders five stars; it is not a
          variable-rating control.
        </p>
        <Example label="5 Stars">
          <Preview code={`<B2BRatingStars />`}>
            <B2BRatingStars />
          </Preview>
        </Example>
        <PropsTable
          rows={[{ name: "className", type: "string", description: "Additional classes for the star row" }]}
        />
      </DocSection>

      <DocSection title="Testimonials">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Customer quote with attribution and rating imagery. Use as social proof and preserve the quotation,
          author and role as a single content unit.
        </p>
        <Example label="Desktop">
          <Preview
            code={`<B2BTestimonialCard quote="${QUOTE}" name="Maya Ellison" role="Principal, Ellison Studio" />`}
          >
            <B2BTestimonialCard quote={QUOTE} name="Maya Ellison" role="Principal, Ellison Studio" />
          </Preview>
        </Example>
        <Example label="Mobile">
          <Preview
            code={`<B2BTestimonialCard compact quote="${QUOTE}" name="Maya Ellison" role="Principal, Ellison Studio" />`}
          >
            <B2BTestimonialCard compact quote={QUOTE} name="Maya Ellison" role="Principal, Ellison Studio" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "quote", type: "string", description: "Customer quote" },
            { name: "name", type: "string", description: "Attribution name" },
            { name: "role", type: "string", description: "Attribution role/title" },
            { name: "rating", type: "number", default: "5", description: "Out of 5 stars" },
            { name: "compact", type: "boolean", default: "false", description: "Renders the Mobile variant" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-reviews" />
    </DocPage>
  );
}
