import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BProductCarousel } from "@/components/ui/B2BProductCarousel";
import { B2BSpaceCarousel } from "@/components/ui/B2BSpaceCarousel";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const NEW_ARRIVALS_PRODUCTS = [
  { tag: "New Arrival", eyebrow: "Contract Grade", name: "Rafaelle Natural Solid Ashe Bed" },
  { tag: "New Arrival", eyebrow: "Performance Fabric", name: "Lina Accent Chair" },
  { tag: "New Arrival", eyebrow: "Performance Fabric", name: "Oodle Vegan Mohair Stool" },
];

const BEST_SELLERS_PRODUCTS = [
  { tag: "Best Seller", eyebrow: "Performance Fabric", name: "Dex Striped Linen Ottoman" },
  { tag: "Best Seller", eyebrow: "Performance Fabric", name: "Atolla Tassel Table Lamp" },
  { tag: "Best Seller", eyebrow: "Performance Fabric", name: "Hump 54” Arched Console Table" },
];

const SPACES = [
  { title: "Restaurants & Bars" },
  { title: "Hotels & Lodging" },
  { title: "Offices & Workspaces" },
  { title: "Outdoor & Patio" },
  { title: "Senior Living" },
  { title: "Retail & Showrooms" },
];

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

export default function CarouselPage() {
  return (
    <DocPage
      title="Carousel"
      description="Horizontally scrolling rows that merchandise products and introduce spaces. Two carousels share the same behavior — a row that runs past the page edge so the next card peeks, with a next arrow on Desktop and touch scrolling on Mobile: the Product Carousel and the Spaces We Love Carousel."
    >
      <DocSection title="Product Carousel">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Merchandising section that opens with a feature card and continues into a row of Product Cards.
          New Arrivals and Best Sellers each have Desktop and Mobile variants.
        </p>

        <Example label="New Arrivals · Desktop">
          <Preview
            align="start"
            code={`<B2BProductCarousel variant="new-arrivals" viewport="desktop" products={products} />`}
          >
            <B2BProductCarousel variant="new-arrivals" viewport="desktop" products={NEW_ARRIVALS_PRODUCTS} />
          </Preview>
        </Example>

        <Example label="Best Sellers · Desktop">
          <Preview
            align="start"
            code={`<B2BProductCarousel variant="best-sellers" viewport="desktop" products={products} />`}
          >
            <B2BProductCarousel variant="best-sellers" viewport="desktop" products={BEST_SELLERS_PRODUCTS} />
          </Preview>
        </Example>

        <Example label="New Arrivals · Mobile">
          <Preview
            align="start"
            code={`<B2BProductCarousel variant="new-arrivals" viewport="mobile" products={products} />`}
          >
            <B2BProductCarousel variant="new-arrivals" viewport="mobile" products={NEW_ARRIVALS_PRODUCTS} />
          </Preview>
        </Example>

        <PropsTable
          rows={[
            { name: "variant", type: '"new-arrivals" | "best-sellers"', default: '"new-arrivals"', description: "Feature card copy and carousel content" },
            { name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Layout tier" },
            { name: "products", type: "{ tag?, eyebrow?, name }[]", description: "Product Card content for the scrolling row" },
          ]}
        />
      </DocSection>

      <DocSection title="Spaces We Love Carousel">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          A row of image-led Space Cards that introduces the spaces and project applications TOV furnishes,
          each with a clear View All destination.
        </p>

        <Example label="Desktop">
          <Preview align="start" code={`<B2BSpaceCarousel viewport="desktop" spaces={spaces} />`}>
            <B2BSpaceCarousel viewport="desktop" spaces={SPACES} />
          </Preview>
        </Example>

        <Example label="Mobile">
          <Preview align="start" code={`<B2BSpaceCarousel viewport="mobile" spaces={spaces} />`}>
            <B2BSpaceCarousel viewport="mobile" spaces={SPACES} />
          </Preview>
        </Example>

        <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">
          <li>Each card pairs a space name with a View All link; keep names short enough to stay on one line.</li>
          <li>Show at least four cards so the row reads as scrollable and the next card peeks past the edge.</li>
          <li>The next arrow appears on Desktop only; Mobile relies on touch scrolling.</li>
        </ul>

        <PropsTable
          rows={[
            { name: "spaces", type: "{ title: string; linkLabel?: string }[]", description: "Cards to render, in order" },
            { name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Layout tier" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-carousel" />
    </DocPage>
  );
}
