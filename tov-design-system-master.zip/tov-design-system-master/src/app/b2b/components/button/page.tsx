import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BButton } from "@/components/ui/B2BButton";
import { B2BCarouselArrow } from "@/components/ui/B2BCarouselArrow";
import { B2BWishlistButton } from "@/components/ui/B2BWishlistButton";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function B2BButtonPage() {
  return (
    <DocPage
      title="Button"
      description="The button family: action buttons, the Carousel Arrow and the Wishlist Button. Use Primary for the main call to action; Outline Inverse treatments belong on dark or image backgrounds; Header Join and Header Sign In support account entry."
    >
      <DocSection title="Primary">
        <Preview
          code={`<B2BButton>Join today</B2BButton>
<B2BButton size="mobile">Join Today</B2BButton>`}
        >
          <B2BButton>Join today</B2BButton>
          <B2BButton size="mobile">Join Today</B2BButton>
        </Preview>
      </DocSection>

      <DocSection title="Outline Inverse (dark or image backgrounds)">
        <Preview
          code={`<B2BButton variant="outline-inverse">View sale items</B2BButton>
<B2BButton variant="outline-inverse" size="mobile">Contact Us</B2BButton>`}
        >
          <div className="flex flex-wrap items-center gap-4 rounded-app-md bg-charcoal p-6">
            <B2BButton variant="outline-inverse">View sale items</B2BButton>
            <B2BButton variant="outline-inverse" size="mobile">Contact Us</B2BButton>
          </div>
        </Preview>
        <p className="text-xs text-ink-muted mt-3">
          Shown here on a charcoal surface — white border and label are invisible on a
          white or light background; place this variant on dark surfaces only.
        </p>
      </DocSection>

      <DocSection title="Outline Inverse Compact">
        <Preview code={`<B2BButton variant="outline-inverse-compact">Contact us</B2BButton>`}>
          <div className="rounded-app-md bg-charcoal p-6">
            <B2BButton variant="outline-inverse-compact">Contact us</B2BButton>
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Header Join & Header Sign In">
        <Preview
          code={`<B2BButton variant="header-join">Join Today</B2BButton>
<B2BButton variant="header-sign-in">Sign in</B2BButton>`}
        >
          <B2BButton variant="header-join">Join Today</B2BButton>
          <B2BButton variant="header-sign-in">Sign in</B2BButton>
        </Preview>
        <p className="text-xs text-ink-muted mt-3">
          The desktop header&apos;s account-entry pair — a mauve outline for existing
          members, a filled mauve pill with a profile glyph for sign-in. Both keep
          sentence case, unlike the three variants above which are uppercase.
        </p>
      </DocSection>

      <DocSection title="Button props">
        <PropsTable
          rows={[
            {
              name: "variant",
              type: '"primary" | "outline-inverse" | "outline-inverse-compact" | "header-join" | "header-sign-in"',
              default: '"primary"',
              description: "Visual treatment",
            },
            {
              name: "size",
              type: '"desktop" | "mobile"',
              default: '"desktop"',
              description: "Padding scale — only Primary and Outline Inverse ship both",
            },
            {
              name: "icon",
              type: "boolean",
              default: "true for header-sign-in, false otherwise",
              description: "Leading profile glyph",
            },
            { name: "...rest", type: "ButtonHTMLAttributes", description: "Any native button prop" },
          ]}
        />
      </DocSection>

      <DocSection title="Carousel Arrow">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Directional control for carousels. Use the Next appearance to advance the row; a mirrored
          Previous arrow is available for carousels that scroll in both directions.
        </p>
        <Preview
          code={`<B2BCarouselArrow />
<B2BCarouselArrow direction="previous" />`}
        >
          <div className="flex items-center gap-4 rounded-app-md bg-neutral-200 p-6">
            <B2BCarouselArrow />
            <B2BCarouselArrow direction="previous" />
          </div>
        </Preview>
        <PropsTable
          rows={[
            {
              name: "direction",
              type: '"next" | "previous"',
              default: '"next"',
              description: '"next" is the default; "previous" mirrors it',
            },
          ]}
        />
      </DocSection>

      <DocSection title="Wishlist Button">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Heart-shaped action used on product imagery to represent a wishlist affordance. It uses a
          single translucent outline appearance and sits over product photography.
        </p>
        <Preview code={`<B2BWishlistButton />`}>
          <div className="rounded-app-md bg-neutral-200 p-6">
            <B2BWishlistButton />
          </div>
        </Preview>
        <PropsTable
          rows={[{ name: "className", type: "string", description: "Additional classes for the 45×45 hit target" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-button" />
    </DocPage>
  );
}
