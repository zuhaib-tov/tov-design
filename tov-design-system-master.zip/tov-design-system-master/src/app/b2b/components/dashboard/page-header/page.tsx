import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardPageHeader } from "@/components/ui/B2BDashboardPageHeader";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function PageHeaderPage() {
  return (
    <DocPage
      title="Page Header"
      description="Serif page title with a subtitle, and an optional right-aligned Brand Outline action button — used at the top of every dashboard page."
    >
      <DocSection title="With Action">
        <Preview
          align="start"
          code={`<B2BDashboardPageHeader title="Orders" subtitle="Track, filter and export every trade order." actionLabel="+ Place new order" />`}
        >
          <div className="w-full">
            <B2BDashboardPageHeader
              title="Orders"
              subtitle="Track, filter and export every trade order."
              actionLabel="+ Place new order"
            />
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "title", type: "string", description: "Page title, rendered in the display serif" },
            { name: "subtitle", type: "string", description: "Supporting line" },
            { name: "actionLabel", type: "string", description: "Optional right-aligned Brand Outline button label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-page-header" />
    </DocPage>
  );
}
