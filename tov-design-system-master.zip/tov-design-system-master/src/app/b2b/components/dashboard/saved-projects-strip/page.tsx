import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardSavedProjectsStrip } from "@/components/ui/B2BDashboardSavedProjectsStrip";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function SavedProjectsStripPage() {
  return (
    <DocPage
      title="Saved Projects Strip"
      description="The Overview page's saved-projects preview — a header with the total project count and a View all link, over three image-led Project Feature Cards."
    >
      <DocSection title="Default">
        <Preview align="start" code={`<B2BDashboardSavedProjectsStrip projectCount={12} />`}>
          <B2BDashboardSavedProjectsStrip projectCount={12} />
        </Preview>
      </DocSection>

      <DocSection title="Usage">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-muted">
          <li>Each Dashboard/Project Feature Card is a full-bleed project photo under a dark gradient, with a small &quot;Created [date]&quot; stamp above the project name, item count, and a &quot;View Project&quot; link.</li>
          <li>This strip always shows exactly three cards — the newest saved projects — with &quot;View all&quot; routing to the full Saved Projects page.</li>
        </ul>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[{ name: "projectCount", type: "number", default: "12", description: "Total saved-project count shown in the header" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-saved-projects-strip" />
    </DocPage>
  );
}
