import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardOrdersTable } from "@/components/ui/B2BDashboardOrdersTable";
import { B2BDashboardTableHeader } from "@/components/ui/B2BDashboardTableHeader";
import { B2BDashboardTableRow } from "@/components/ui/B2BDashboardTableRow";
import { B2BDashboardStatusBadge } from "@/components/ui/B2BDashboardStatusBadge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

const CELL_BASE = "flex min-h-[44px] w-[98px] shrink-0 items-center bg-white px-0 font-sans text-[13px] font-medium";

const CELL_TYPES: { name: string; note: string; cell: ReactNode }[] = [
  { name: "Text", note: "Primary values such as order and date", cell: <p className="text-charcoal">SO-2024-0847</p> },
  { name: "Muted text", note: "Secondary references such as PO number", cell: <p className="text-[#8e8e8e]">PO-78234</p> },
  { name: "Status", note: "Status Badge", cell: <B2BDashboardStatusBadge status="shipped" /> },
  {
    name: "Link",
    note: "Tracking number, brand color, underlined",
    cell: <p className="text-xs text-primary underline underline-offset-2">1Z999AA10012345</p>,
  },
  { name: "Currency, left", note: "Order total", cell: <p className="text-charcoal">$4,250.00</p> },
  { name: "Currency, right", note: "Amounts aligned to the trailing edge", cell: <p className="w-full text-right text-charcoal">$3,850.00</p> },
  { name: "Muted currency, right", note: "Shipping amount", cell: <p className="w-full text-right text-[#8e8e8e]">$400.00</p> },
  { name: "Empty", note: "Dash where a value does not apply, such as a cancelled order", cell: <p className="text-charcoal">-</p> },
];

const COLUMN_SPEC = [
  ["SO Order", "Sales order number", "98px", "Left", "Text"],
  ["PO Number", "Customer purchase order", "98px", "Left", "Muted text"],
  ["Order Date", "Date the order was placed", "98px", "Left", "Text"],
  ["Status", "Order state", "98px", "Left", "Status Badge"],
  ["Est Ship", "Estimated ship date", "98px", "Left", "Text; dash when cancelled"],
  ["Act Ship", "Actual ship date", "98px", "Left", "Text; dash when cancelled"],
  ["Tracking", "Carrier tracking number", "98px", "Left", "Link; dash when cancelled"],
  ["Carrier", "Shipping carrier", "98px", "Left", "Text; dash when cancelled"],
  ["Method", "Shipping method", "98px", "Left", "Text; dash when cancelled"],
  ["Total", "Order total", "98px", "Left", "Currency"],
  ["Items", "Merchandise subtotal", "98px", "Right", "Currency"],
  ["Shipping", "Shipping charge", "77px", "Right", "Muted currency"],
];

export default function B2BDashboardTablesPage() {
  return (
    <DocPage
      title="Tables"
      description="How dashboard data tables are built, from the full Orders Table down to the Table Header, Table Row and the individual cells inside each row."
    >
      <DocSection title="Orders Table">
        <Intro>
          The full Orders page data table — a cream header row over order rows carrying SO/PO numbers, status,
          shipping detail and totals. It is a bordered, 1066px table that scrolls horizontally when its twelve
          columns exceed the available width.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardOrdersTable />`}>
            <B2BDashboardOrdersTable />
          </Preview>
        </Example>
        <Usage>
          <li>Status uses the Status Badge (Shipped, Processing, Delivered, Cancelled) — see Elements for its color mapping.</li>
          <li>A Cancelled row replaces every shipping-related cell (Est Ship, Act Ship, Tracking, Carrier, Method) with a dash; the order-level cells stay populated.</li>
          <li>The Tracking cell is an underlined, brand-rose link on every non-cancelled row.</li>
        </Usage>
      </DocSection>

      <DocSection title="Table Header">
        <Intro>
          Data-table header row: uppercase bold 11px column labels on a cream background with a bottom border.
          Pairs with Table Row to form the Orders Table.
        </Intro>
        <Example label="Orders">
          <Preview align="start" code={`<B2BDashboardTableHeader />`}>
            <div className="w-full overflow-x-auto">
              <B2BDashboardTableHeader />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "columns", type: "string[]", description: "Overrides the default Orders column set (Items and Shipping are always appended)" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Table Row">
        <Intro>
          Orders-table body row with a Status Badge in the Status cell. Four status variants: Shipped, Processing,
          Delivered and Cancelled. Cancelled shows dashes across every shipping-related column while Total, Items
          and Shipping stay populated.
        </Intro>
        <Example label="Variants (with Table Header)">
          <Preview
            align="start"
            code={`<B2BDashboardTableHeader />
<B2BDashboardTableRow status="shipped" />
<B2BDashboardTableRow status="processing" />
<B2BDashboardTableRow status="delivered" />
<B2BDashboardTableRow status="cancelled" />`}
          >
            <div className="w-full overflow-x-auto">
              <B2BDashboardTableHeader />
              <B2BDashboardTableRow status="shipped" />
              <B2BDashboardTableRow status="processing" />
              <B2BDashboardTableRow status="delivered" />
              <B2BDashboardTableRow status="cancelled" />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "status", type: '"shipped" | "processing" | "delivered" | "cancelled"', default: '"shipped"', description: "Order status — drives the Status Badge and dash behavior" },
            { name: "soOrder, poNumber, orderDate, estShip, actShip, tracking, carrier, method, total, items, shipping", type: "string", description: "Cell values" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Cells">
        <Intro>
          Every row is a horizontal run of fixed-width cells with 13px gaps and 16px side padding. Cell width is 98px
          except the trailing Shipping cell at 77px. Cell text is 13px Medium; the header label is 11px Bold
          uppercase.
        </Intro>
        <Example label="Cell types">
          <div className="overflow-x-auto rounded-app-md border border-neutral-300 bg-white">
            <div className="grid grid-cols-2 gap-x-6 gap-y-4 p-5 sm:grid-cols-4">
              {CELL_TYPES.map((c) => (
                <div key={c.name}>
                  <div className="mb-2 rounded-app-sm border border-dashed border-neutral-300 px-3">
                    <div className={CELL_BASE}>{c.cell}</div>
                  </div>
                  <p className="text-xs font-semibold text-ink">{c.name}</p>
                  <p className="text-xs text-ink-muted">{c.note}</p>
                </div>
              ))}
            </div>
          </div>
        </Example>
        <Example label="Column breakdown">
          <div className="overflow-x-auto rounded-app-md border border-neutral-300">
            <table className="w-full text-left text-sm">
              <thead className="bg-cream-100 text-xs uppercase tracking-wide-ui text-ink-muted">
                <tr>
                  <th className="px-4 py-3">Column</th>
                  <th className="px-4 py-3">Content</th>
                  <th className="px-4 py-3">Width</th>
                  <th className="px-4 py-3">Align</th>
                  <th className="px-4 py-3">Cell type</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-300">
                {COLUMN_SPEC.map(([col, content, width, align, type]) => (
                  <tr key={col}>
                    <td className="px-4 py-3 font-semibold text-ink">{col}</td>
                    <td className="px-4 py-3 text-ink-muted">{content}</td>
                    <td className="px-4 py-3 font-mono text-xs">{width}</td>
                    <td className="px-4 py-3 text-ink-muted">{align}</td>
                    <td className="px-4 py-3 text-ink-muted">{type}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Example>
        <Usage>
          <li>Keep numeric columns right-aligned so amounts line up on the decimal; left-align everything else.</li>
          <li>Use a dash, never a blank, for a value that does not apply.</li>
          <li>Secondary references use the muted gray (#8e8e8e) so the order number leads the row.</li>
        </Usage>
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-tables" />
    </DocPage>
  );
}
