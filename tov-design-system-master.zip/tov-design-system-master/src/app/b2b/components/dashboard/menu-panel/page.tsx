import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardNavItem } from "@/components/ui/B2BDashboardNavItem";
import { B2BDashboardAccountSummary } from "@/components/ui/B2BDashboardAccountSummary";
import { B2BDashboardHelpCard } from "@/components/ui/B2BDashboardHelpCard";
import {
  B2BDashboardSidebar,
  type DashboardSidebarPage,
} from "@/components/ui/B2BDashboardSidebar";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const PANEL_STATES: { page: DashboardSidebarPage; label: string }[] = [
  { page: "overview", label: "Overview" },
  { page: "orders", label: "Orders" },
  { page: "saved-projects", label: "Saved Projects" },
  { page: "marketing-materials", label: "Marketing Materials" },
  { page: "downloads", label: "Downloads" },
  { page: "invoices", label: "Invoices" },
  { page: "account-info", label: "Account Info" },
  { page: "support", label: "Support" },
];

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

export default function B2BDashboardMenuPanelPage() {
  return (
    <DocPage
      title="Menu Panel"
      description="The dashboard's left navigation and everything it is made of: the Menu Panel itself, the Nav Item rows in its Main and Account groups, the Account Summary at the top and the Help Card at the bottom."
    >
      <DocSection title="Menu Panel">
        <Intro>
          Account Summary, two nav groups (Main and Account) and a Help Card, stacked in a fixed 318 × 960 desktop
          panel. Every dashboard page uses its own state of the panel, with that page&apos;s Nav Item marked
          active.
        </Intro>
        <Example label="Active states">
          <Preview
            align="start"
            code={`<B2BDashboardSidebar activePage="overview" />
<B2BDashboardSidebar activePage="orders" />
<B2BDashboardSidebar activePage="saved-projects" />
<B2BDashboardSidebar activePage="marketing-materials" />
<B2BDashboardSidebar activePage="downloads" />
<B2BDashboardSidebar activePage="invoices" />
<B2BDashboardSidebar activePage="account-info" />
<B2BDashboardSidebar activePage="support" />`}
          >
            {PANEL_STATES.map((s) => (
              <div key={s.page} className="w-[318px]">
                <p className="mb-2 text-xs font-semibold text-ink-muted">{s.label}</p>
                <B2BDashboardSidebar activePage={s.page} />
              </div>
            ))}
          </Preview>
        </Example>
        <Usage>
          <li>Eight states: Overview, Orders, Saved Projects, Marketing Materials, Downloads, Invoices, Account Info and Support. Exactly one Nav Item is active in each.</li>
          <li>The Main group holds Overview, Orders, Saved Projects, Marketing Materials and Downloads; the Account group holds Invoices, Account Info and Support.</li>
          <li>The Account Summary and Help Card are identical in every state. The panel is desktop-only and keeps a fixed width.</li>
        </Usage>
        <PropsTable
          rows={[
            {
              name: "activePage",
              type: '"overview" | "orders" | "saved-projects" | "marketing-materials" | "downloads" | "invoices" | "account-info" | "support"',
              default: '"overview"',
              description: "Which Nav Item renders active",
            },
            { name: "customerName", type: "string", default: '"Sarah Holloway"', description: "Account Summary name" },
            { name: "customerId", type: "string", default: '"CUS656273"', description: "Account Summary id" },
            { name: "repName", type: "string", default: '"Quinn Parker"', description: "Help Card contact name" },
            { name: "repTitle", type: "string", default: '"Account Executive"', description: "Help Card contact title" },
          ]}
        />
      </DocSection>

      <DocSection title="Nav Item">
        <Intro>
          A single row in the panel. Each row pairs a 24px line icon with a label; the current section is marked
          with a white pill and a brand-colored icon and label.
        </Intro>
        <Example label="States">
          <Preview
            code={`<B2BDashboardNavItem label="Overview" />
<B2BDashboardNavItem label="Overview" active />`}
          >
            <div className="flex flex-wrap items-start gap-6 rounded-app-md bg-cream-100 p-6">
              <B2BDashboardNavItem label="Overview" />
              <B2BDashboardNavItem label="Overview" active />
            </div>
          </Preview>
        </Example>
        <Example label="Stacked in the panel">
          <Preview
            code={`<B2BDashboardNavItem label="Overview" active />
<B2BDashboardNavItem label="Orders" />
<B2BDashboardNavItem label="Assets" />`}
          >
            <div className="flex flex-col gap-1 rounded-app-md bg-cream-100 p-4">
              <B2BDashboardNavItem label="Overview" active />
              <B2BDashboardNavItem label="Orders" />
              <B2BDashboardNavItem label="Assets" />
            </div>
          </Preview>
        </Example>
        <Usage>
          <li>Swap the icon and edit the label for each destination. The icon inherits its color from the state: #8e8e8e by default, #b15a63 when Active.</li>
          <li>Exactly one item is Active at a time; it carries <code>aria-current=&quot;page&quot;</code>.</li>
          <li>Default labels are Regular weight; the Active label is Bold, which keeps the row width stable enough for a fixed 270px panel.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "label", type: "string", default: '"Overview"', description: "Row label" },
            { name: "active", type: "boolean", default: "false", description: "Marks the current section" },
            { name: "icon", type: "ReactNode", description: "24px line icon using currentColor strokes" },
            { name: "href", type: "string", default: '"#"', description: "Link target" },
          ]}
        />
      </DocSection>

      <DocSection title="Account Summary">
        <Intro>Customer name, ID and a gradient membership banner, shown at the top of the Menu Panel.</Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardAccountSummary name="Sarah Holloway" customerId="CUS656273" />`}>
            <B2BDashboardAccountSummary name="Sarah Holloway" customerId="CUS656273" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "name", type: "string", description: "Customer name" },
            { name: "customerId", type: "string", description: 'Customer ID, e.g. "CUS656273"' },
            { name: "tierLabel", type: "string", default: '"Pro Tier Member"', description: "Banner headline" },
            { name: "tierNote", type: "string", default: '"Active 20% discount applied"', description: "Banner subtext" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Help Card">
        <Intro>
          Support callout pairing an account manager&apos;s Avatar and name/role with a direct-contact Brand
          button, shown at the bottom of the Menu Panel.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardHelpCard name="Quinn Parker" role="Account Executive" buttonLabel="Contact Quinn" />`}>
            <B2BDashboardHelpCard name="Quinn Parker" role="Account Executive" buttonLabel="Contact Quinn" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "title", type: "string", default: '"Need help?"', description: "Card headline" },
            { name: "subtitle", type: "string", default: '"Contact your account manager"', description: "Supporting line" },
            { name: "name", type: "string", description: "Account manager name" },
            { name: "role", type: "string", description: "Account manager role" },
            { name: "buttonLabel", type: "string", description: 'Button label, e.g. "Contact Quinn"' },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-menu-panel" />
    </DocPage>
  );
}
