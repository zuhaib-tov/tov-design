import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardKpiCard } from "@/components/ui/B2BDashboardKpiCard";
import { B2BDashboardActionTile } from "@/components/ui/B2BDashboardActionTile";
import { B2BDashboardTipBanner } from "@/components/ui/B2BDashboardTipBanner";
import { B2BDashboardAssetCard } from "@/components/ui/B2BDashboardAssetCard";
import { B2BDashboardDownloadCard } from "@/components/ui/B2BDashboardDownloadCard";
import { B2BDashboardProjectCard } from "@/components/ui/B2BDashboardProjectCard";
import { B2BDashboardProjectFeatureCard } from "@/components/ui/B2BDashboardProjectFeatureCard";
import { B2BDashboardSalesChartCard } from "@/components/ui/B2BDashboardSalesChartCard";
import { B2BDashboardQuarterGoalCard } from "@/components/ui/B2BDashboardQuarterGoalCard";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const TIP_TEXT =
  "All templates are available in Figma, Photoshop, and Illustrator formats. Brand logos and vector elements are provided as high-quality SVGs.";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

export default function B2BDashboardCardsTilesPage() {
  return (
    <DocPage
      title="Cards & Tiles"
      description="The self-contained content blocks that dashboard screens are composed from: the KPI Card, Action Tile, Tip Banner, Asset Card, Download Card, Project Card, Project Feature Card, Sales Chart Card and Quarter Goal Card."
    >
      <DocSection title="KPI Card">
        <Intro>
          Overview metric used in dashboard summary rows: a label, a headline figure and an arrow link into the
          detail view.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardKpiCard label="Active Orders" value="12" />`}>
            <B2BDashboardKpiCard label="Active Orders" value="12" />
            <B2BDashboardKpiCard label="Open Quotes" value="4" />
            <B2BDashboardKpiCard label="Saved Projects" value="9" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "label", type: "string", description: 'Metric label, e.g. "Active Orders"' },
            { name: "value", type: "string", description: 'Headline figure, e.g. "12"' },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Action Tile">
        <Intro>
          Clickable quick-action card: a tinted Icon Tile, a label and an arrow. Used in dashboard quick-action
          grids (Downloads, Reorder, Support, and so on).
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardActionTile label="Downloads" />`}>
            <B2BDashboardActionTile label="Downloads" />
            <B2BDashboardActionTile label="Reorder" />
            <B2BDashboardActionTile label="Support" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "icon", type: "ReactNode", description: "Glyph shown in the rose Icon Tile" },
            { name: "label", type: "string", default: '"Downloads"', description: "Action label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Tip Banner">
        <Intro>
          Full-width inline help strip shown at the bottom of resource pages — a bold lead-in followed by
          supporting copy.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardTipBanner text="${TIP_TEXT}" />`}>
            <B2BDashboardTipBanner text={TIP_TEXT} />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "lead", type: "string", default: '"Tip:"', description: "Bold lead-in" },
            { name: "text", type: "string", description: "Tip copy" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Asset Card">
        <Intro>
          Marketing-materials category card: icon, a Count Badge, title, description and a &ldquo;Browse
          Assets&rdquo; link into the resource library.
        </Intro>
        <Example label="Default">
          <Preview
            code={`<B2BDashboardAssetCard
  count="142 assets"
  title="Social Media Assets"
  description="Posts, stories, and banner templates designed for all major social platforms."
/>`}
          >
            <B2BDashboardAssetCard
              count="142 assets"
              title="Social Media Assets"
              description="Posts, stories, and banner templates designed for all major social platforms."
            />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "icon", type: "ReactNode", description: "Icon shown in the rose chip" },
            { name: "count", type: "string", description: 'Count badge text, e.g. "142 assets"' },
            { name: "title", type: "string", description: "Category title" },
            { name: "description", type: "string", description: "Supporting copy" },
            { name: "linkLabel", type: "string", default: '"Browse Assets"', description: "Link label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Download Card">
        <Intro>
          Downloads bucket: icon, a file Count Badge, title, description and a full &ldquo;Download All&rdquo;
          button. Taller and narrower than the Asset Card, and it ends in a full call-to-action button instead of
          a text link.
        </Intro>
        <Example label="Default">
          <Preview
            code={`<B2BDashboardDownloadCard
  count="24 files"
  title="All Product Data"
  description="Product spec sheets, catalogs, compliance documents, and downloadable data files."
/>`}
          >
            <B2BDashboardDownloadCard
              count="24 files"
              title="All Product Data"
              description="Product spec sheets, catalogs, compliance documents, and downloadable data files."
            />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "icon", type: "ReactNode", description: "Icon shown in the rose chip" },
            { name: "count", type: "string", description: 'Count badge text, e.g. "24 files"' },
            { name: "title", type: "string", description: "Bucket title" },
            { name: "description", type: "string", description: "Supporting copy" },
            { name: "buttonLabel", type: "string", default: '"Download All"', description: "Button label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Project Card">
        <Intro>
          Saved-project grid card: photo thumbnail, name, item count and a trailing chevron. Used in project
          grids where every card carries equal visual weight.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardProjectCard title="Modern Living Room" itemCount={12} />`}>
            <B2BDashboardProjectCard title="Modern Living Room" itemCount={12} />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "title", type: "string", description: "Project name" },
            { name: "itemCount", type: "number", description: "Saved item count" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Project Feature Card">
        <Intro>
          Image-led saved-project card used on the Overview: a full-bleed photo with a dark gradient scrim, a
          created-date stamp, and the project name and quantity plus a &ldquo;View Project&rdquo; link over the
          image. Unlike the Project Card, there is no separate white content area or chevron.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardProjectFeatureCard title="Project Name" quantityLabel="Qty: 12 Items" dateLabel="Created Jun 30" />`}>
            <B2BDashboardProjectFeatureCard title="Project Name" quantityLabel="Qty: 12 Items" dateLabel="Created Jun 30" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "title", type: "string", description: "Project name" },
            { name: "quantityLabel", type: "string", description: 'Item count label, e.g. "Qty: 12 Items"' },
            { name: "dateLabel", type: "string", description: 'Created-date stamp, e.g. "Created Jun 30"' },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Sales Chart Card">
        <Intro>
          A year-to-date sales area chart for the Overview page — a Monthly Sales plot against Jan–Aug, paired
          with Top Month and Top Sale highlights.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardSalesChartCard />`}>
            <B2BDashboardSalesChartCard />
          </Preview>
        </Example>
        <Usage>
          <li>The heading states the chart excludes cancelled orders — the plot reflects shippable, invoiced sales only.</li>
          <li>Gridlines are drawn at 0 / 10k / 20k / 50k / 100k, with month ticks across the bottom from January through the current month.</li>
          <li>Two Stat Pill highlights sit below the plot — Top Month (the highest-volume month and year) and Top Sale (the largest single order and a running total).</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "topMonth", type: "string", default: '"Aug"', description: "Top Month pill value" },
            { name: "topMonthYear", type: "string", default: '"2026"', description: "Top Month pill year" },
            { name: "topSaleValue", type: "string", default: '"50K"', description: "Top Sale pill value" },
            { name: "topSaleCaption", type: "string", default: '"96K sold so far"', description: "Top Sale pill caption" },
          ]}
        />
      </DocSection>

      <DocSection title="Quarter Goal Card">
        <Intro>
          A semi-circle progress gauge toward the buyer&apos;s quarterly sales goal, with the percentage centered
          beneath the arc and a link to All goals.
        </Intro>
        <Example label="Variants">
          <Preview
            code={`<B2BDashboardQuarterGoalCard value={84} />
<B2BDashboardQuarterGoalCard value={42} />`}
          >
            <B2BDashboardQuarterGoalCard value={84} />
            <B2BDashboardQuarterGoalCard value={42} />
          </Preview>
        </Example>
        <Usage>
          <li>The gauge is a single semi-circle arc — a brand-rose progress stroke drawn over a blush track, both rounded-cap.</li>
          <li>The percentage is the gauge&apos;s single focal number; no supporting copy explains the underlying target on the card itself.</li>
          <li>Fixed 400 × 375 card.</li>
        </Usage>
        <PropsTable
          rows={[{ name: "value", type: "number", default: "84", description: "Percent complete toward the quarter goal" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-cards-tiles" />
    </DocPage>
  );
}
