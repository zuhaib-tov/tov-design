import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardAccountRepCard } from "@/components/ui/B2BDashboardAccountRepCard";
import { B2BDashboardAgentProfile } from "@/components/ui/B2BDashboardAgentProfile";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

export default function B2BDashboardAccountRepsPage() {
  return (
    <DocPage
      title="Account Rep & Agent"
      description="The two ways the dashboard introduces a person from TOV: the Account Rep Card for the buyer's assigned account representative, and the Agent Profile for the support agent on the Support page."
    >
      <DocSection title="Account Rep Card">
        <Intro>
          A card introducing the buyer&apos;s assigned account rep — Avatar, name, role, contact details, and a
          Contact Rep button.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardAccountRepCard />`}>
            <B2BDashboardAccountRepCard />
          </Preview>
        </Example>
        <Usage>
          <li>The rep&apos;s role line is set in brand rose, the only colored text in the card besides the Contact Rep button.</li>
          <li>Contact details (email, phone) are plain text, not links — the button is the card&apos;s only call to action.</li>
          <li>Pairs with the Avatar at its Small size.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "repName", type: "string", default: '"Quinn Parker"', description: "Rep's name" },
            { name: "repTitle", type: "string", default: '"Senior Account Manager"', description: "Rep's role" },
            { name: "email", type: "string", default: '"quinn.parker@tovprofessional.com"', description: "Rep's email" },
            { name: "phone", type: "string", default: '"(212) 555-0190 ext. 412"', description: "Rep's phone and extension" },
          ]}
        />
      </DocSection>

      <DocSection title="Agent Profile">
        <Intro>
          A support-agent profile card on the Support page — Large Avatar, serif name, live availability status,
          three contact rows, and Email Now / Call Now actions.
        </Intro>
        <Example label="Default">
          <div className="overflow-x-auto">
            <Preview align="start" code={`<B2BDashboardAgentProfile name="Sarah Mitchell" />`}>
              <B2BDashboardAgentProfile name="Sarah Mitchell" />
            </Preview>
          </div>
        </Example>
        <Usage>
          <li>The identity side carries a live-status dot and label (&ldquo;Online &amp; available&rdquo;) in a teal that doesn&apos;t appear anywhere else in the Dashboard system.</li>
          <li>The three Contact Rows (Direct Phone, Direct Email, Availability) each pair a cream icon tile with an uppercase label and bold value.</li>
          <li>Email Now is a solid brand-rose pill; Call Now is its outline counterpart — the card&apos;s only two actions, always shown together.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "name", type: "string", default: '"Sarah Mitchell"', description: "Agent's name" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-account-reps" />
    </DocPage>
  );
}
