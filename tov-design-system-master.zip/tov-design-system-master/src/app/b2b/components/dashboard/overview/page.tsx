import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardWelcomeHeader } from "@/components/ui/B2BDashboardWelcomeHeader";
import { B2BDashboardQuickActions } from "@/components/ui/B2BDashboardQuickActions";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

export default function B2BDashboardOverviewPage() {
  return (
    <DocPage
      title="Dashboard Overview"
      description="The sections that make up the dashboard's landing screen, in the order they appear: the personalized Welcome Header with headline account metrics, followed by the Quick Actions shortcut row."
    >
      <DocSection title="Welcome Header">
        <Intro>
          The Overview page&apos;s personalized greeting — a &ldquo;Welcome back&rdquo; headline over a row of KPI
          Cards (Active Orders, Orders, Spend, Saved Items) and a Place new order link.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardWelcomeHeader companyName="Holloway Design Studio" />`}>
            <B2BDashboardWelcomeHeader companyName="Holloway Design Studio" />
          </Preview>
        </Example>
        <Usage>
          <li>The headline renders the buyer&apos;s company name in a lighter weight against a bold &ldquo;Welcome back,&rdquo;.</li>
          <li>Each KPI Card pairs a label, a value, and a small arrow link into that metric&apos;s own page (Active Orders and Orders both link into the Orders page; Spend and Saved Items link to their own sections).</li>
          <li>&ldquo;+ Place new order&rdquo; sits at the end of the KPI row as a standalone link, not a card.</li>
        </Usage>
        <PropsTable
          rows={[{ name: "companyName", type: "string", default: '"Holloway Design Studio"', description: "Buyer company name in the greeting" }]}
        />
      </DocSection>

      <DocSection title="Quick Actions">
        <Intro>
          A row of four shortcut tiles under the Overview page&apos;s section title — Downloads, Invoices, Quick
          Order, and Item Lookup — each with its own tinted icon.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardQuickActions />`}>
            <B2BDashboardQuickActions />
          </Preview>
        </Example>
        <Usage>
          <li>Each tile pairs a 48px tinted Icon Tile with a label and a trailing rose arrow link — the tint is unique per tile (rose, sage, sand, blue) and carries no other meaning.</li>
          <li>Tiles are equal width and always render all four together as one row; the set is not partial or reordered.</li>
        </Usage>
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-overview" />
    </DocPage>
  );
}
