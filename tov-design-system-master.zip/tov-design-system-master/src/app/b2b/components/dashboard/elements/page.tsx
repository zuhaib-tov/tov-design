import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardStatusBadge } from "@/components/ui/B2BDashboardStatusBadge";
import { B2BDashboardCountBadge } from "@/components/ui/B2BDashboardCountBadge";
import { B2BDashboardIconTile } from "@/components/ui/B2BDashboardIconTile";
import { B2BDashboardPaginationBar } from "@/components/ui/B2BDashboardPaginationBar";
import { B2BDashboardFilterBar } from "@/components/ui/B2BDashboardFilterBar";
import { B2BDashboardPaginationItem } from "@/components/ui/B2BDashboardPaginationItem";
import { B2BDashboardQuantityStepper } from "@/components/ui/B2BDashboardQuantityStepper";
import { B2BDashboardSearchField } from "@/components/ui/B2BDashboardSearchField";
import { B2BDashboardSelect } from "@/components/ui/B2BDashboardSelect";
import { B2BDashboardTextField } from "@/components/ui/B2BDashboardTextField";
import { B2BDashboardAvatar } from "@/components/ui/B2BDashboardAvatar";
import {
  B2BDashboardViewToggle,
  B2BDashboardViewToggleOption,
} from "@/components/ui/B2BDashboardViewToggle";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const STATUS_COLORS = [
  ["Shipped", "#ebf3fc", "#1f78c1", "status-info"],
  ["Processing", "#fffbeb", "#d1af52", "status-warning"],
  ["Delivered", "#ecfdf5", "#32c11f", "status-success"],
  ["Cancelled", "#fee2e2", "#ef4444", "status-danger"],
];

const ICON_TILE_TINTS = [
  ["Rose", "#fdf1f2", "#b15a63", "Folder download"],
  ["Sage", "#eaf4f0", "#82736c", "Document"],
  ["Sand", "#faf3e7", "#9e8567", "Home"],
  ["Blue", "#eef2fc", "#4766e1", "Arrow right"],
];

const DATE_RANGE = [
  { value: "all", label: "All Time" },
  { value: "30", label: "Last 30 Days" },
  { value: "90", label: "Last 90 Days" },
];

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

function Usage({ children }: { children: ReactNode }) {
  return <ul className="mb-4 list-disc space-y-1.5 pl-5 text-sm text-ink-muted">{children}</ul>;
}

export default function B2BDashboardElementsPage() {
  return (
    <DocPage
      title="Elements"
      description="The small, single-purpose pieces that dashboard screens are built from: Status and Count Badges, Icon Tiles, Pagination, Quantity Stepper, Search Field, Select, Text Field, Filter Bar, Avatar and View Toggle."
    >
      <DocSection title="Status Badge">
        <Intro>
          A compact, color-coded pill that communicates the current state of an order. Used in order tables and
          order detail headers.
        </Intro>
        <Example label="Statuses">
          <Preview
            code={`<B2BDashboardStatusBadge status="shipped" />
<B2BDashboardStatusBadge status="processing" />
<B2BDashboardStatusBadge status="delivered" />
<B2BDashboardStatusBadge status="cancelled" />`}
          >
            <B2BDashboardStatusBadge status="shipped" />
            <B2BDashboardStatusBadge status="processing" />
            <B2BDashboardStatusBadge status="delivered" />
            <B2BDashboardStatusBadge status="cancelled" />
          </Preview>
        </Example>
        <Usage>
          <li>One badge per order. The label is the status name in uppercase; never abbreviate it.</li>
          <li>Each status pairs a tinted background with a saturated foreground from the same hue family. The color is paired with a text label, so status is never conveyed by color alone.</li>
          <li>The badge is non-interactive. Place filtering or navigation on the surrounding row or control.</li>
        </Usage>
        <Example label="Color mapping">
          <div className="overflow-x-auto rounded-app-md border border-neutral-300">
            <table className="w-full text-left text-sm">
              <thead className="bg-cream-100 text-xs uppercase tracking-wide-ui text-ink-muted">
                <tr>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Background</th>
                  <th className="px-4 py-3">Text</th>
                  <th className="px-4 py-3">Token</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-300 font-mono text-xs">
                {STATUS_COLORS.map(([name, bg, fg, token]) => (
                  <tr key={name}>
                    <td className="px-4 py-3 font-sans text-sm text-ink">{name}</td>
                    <td className="px-4 py-3">{bg}</td>
                    <td className="px-4 py-3">{fg}</td>
                    <td className="px-4 py-3">{token}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Example>
        <PropsTable
          rows={[
            {
              name: "status",
              type: '"shipped" | "processing" | "delivered" | "cancelled"',
              default: '"shipped"',
              description: "Selects the color pair and default label",
            },
            { name: "children", type: "ReactNode", description: "Optional label override" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Count Badge">
        <Intro>
          A small chip that reports how many assets or files a resource card contains, such as a collection,
          folder or download set.
        </Intro>
        <Example label="Default">
          <Preview
            code={`<B2BDashboardCountBadge>142 assets</B2BDashboardCountBadge>
<B2BDashboardCountBadge>24 files</B2BDashboardCountBadge>`}
          >
            <B2BDashboardCountBadge>142 assets</B2BDashboardCountBadge>
            <B2BDashboardCountBadge>24 files</B2BDashboardCountBadge>
          </Preview>
        </Example>
        <Usage>
          <li>Pair the number with its unit in a single string, for example &ldquo;142 assets&rdquo;.</li>
          <li>Place it in the metadata area of a resource card, next to the title or beneath it.</li>
          <li>The badge is informational and non-interactive. It has a single Default treatment.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "children", type: "ReactNode", description: "Count and unit label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Icon Tile">
        <Intro>
          A tinted rounded square that holds a single 24px icon. It gives cards and list rows a quiet,
          color-coded glyph marker.
        </Intro>
        <Example label="Tints">
          <Preview
            code={`<B2BDashboardIconTile tint="rose" />
<B2BDashboardIconTile tint="sage" />
<B2BDashboardIconTile tint="sand" />
<B2BDashboardIconTile tint="blue" />`}
          >
            <B2BDashboardIconTile tint="rose" />
            <B2BDashboardIconTile tint="sage" />
            <B2BDashboardIconTile tint="sand" />
            <B2BDashboardIconTile tint="blue" />
          </Preview>
        </Example>
        <Example label="Tint reference">
          <div className="overflow-x-auto rounded-app-md border border-neutral-300">
            <table className="w-full text-left text-sm">
              <thead className="bg-cream-100 text-xs uppercase tracking-wide-ui text-ink-muted">
                <tr>
                  <th className="px-4 py-3">Tint</th>
                  <th className="px-4 py-3">Tile fill</th>
                  <th className="px-4 py-3">Icon stroke</th>
                  <th className="px-4 py-3">Default glyph</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-300 font-mono text-xs">
                {ICON_TILE_TINTS.map(([name, bg, fg, glyph]) => (
                  <tr key={name}>
                    <td className="px-4 py-3 font-sans text-sm text-ink">{name}</td>
                    <td className="px-4 py-3">{bg}</td>
                    <td className="px-4 py-3">{fg}</td>
                    <td className="px-4 py-3 font-sans text-sm text-ink-muted">{glyph}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Example>
        <Usage>
          <li>Each tint ships with its own default glyph. Swap the icon for other 24px line glyphs; keep the stroke in the tint&apos;s foreground color.</li>
          <li>Tints are decorative category markers, not status indicators. Use Status Badge for state.</li>
          <li>The tile is a fixed 48px square with a 12px radius.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "tint", type: '"rose" | "sage" | "sand" | "blue"', default: '"rose"', description: "Tile fill, icon color and default glyph" },
            { name: "icon", type: "ReactNode", description: "Replaces the default glyph; use currentColor strokes" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Pagination Item">
        <Intro>
          A single page-number button used to move between pages of a table. The current page is filled with
          the brand color; all other pages are plain text.
        </Intro>
        <Example label="States">
          <Preview
            code={`<B2BDashboardPaginationItem active>1</B2BDashboardPaginationItem>
<B2BDashboardPaginationItem>2</B2BDashboardPaginationItem>`}
          >
            <B2BDashboardPaginationItem active>1</B2BDashboardPaginationItem>
            <B2BDashboardPaginationItem>2</B2BDashboardPaginationItem>
          </Preview>
        </Example>
        <Example label="In a row">
          <Preview
            code={`<div className="flex items-center gap-1">
  <B2BDashboardPaginationItem active>1</B2BDashboardPaginationItem>
  <B2BDashboardPaginationItem>2</B2BDashboardPaginationItem>
  <B2BDashboardPaginationItem>3</B2BDashboardPaginationItem>
</div>`}
          >
            <div className="flex items-center gap-1">
              <B2BDashboardPaginationItem active>1</B2BDashboardPaginationItem>
              <B2BDashboardPaginationItem>2</B2BDashboardPaginationItem>
              <B2BDashboardPaginationItem>3</B2BDashboardPaginationItem>
            </div>
          </Preview>
        </Example>
        <Usage>
          <li>Exactly one item is Active at a time, and it carries <code>aria-current=&quot;page&quot;</code>.</li>
          <li>Active uses 13px Bold white on the brand fill; Default uses 13px Medium charcoal with no fill.</li>
          <li>Both states share the same 12px horizontal / 6px vertical padding, so switching pages never shifts the row.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "active", type: "boolean", default: "false", description: "Marks the current page" },
            { name: "children", type: "ReactNode", description: "Page number" },
            { name: "...rest", type: "ButtonHTMLAttributes", description: "Any native button prop" },
          ]}
        />
      </DocSection>

      <DocSection title="Pagination Bar">
        <Intro>
          Full pagination control: a result-count summary with a per-page select, a run of Pagination Items
          (with an ellipsis and next/last arrows), and a go-to-page jump control. Sits directly below a data
          table.
        </Intro>
        <Example label="Default">
          <Preview align="start" code={`<B2BDashboardPaginationBar />`}>
            <div className="w-full overflow-x-auto">
              <B2BDashboardPaginationBar />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "rangeStart", type: "number", default: "1", description: "First item index shown" },
            { name: "rangeEnd", type: "number", default: "8", description: "Last item index shown" },
            { name: "total", type: "number", default: "54", description: "Total result count" },
            { name: "perPage", type: "number", default: "10", description: "Per-page select value" },
            { name: "currentPage", type: "number", default: "1", description: "Active page number" },
            { name: "lastPage", type: "number", default: "7", description: "Last page number" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Quantity Stepper">
        <Intro>A minus / value / plus control for adjusting the quantity of a project line item.</Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardQuantityStepper defaultValue={1} />`}>
            <B2BDashboardQuantityStepper defaultValue={1} />
          </Preview>
        </Example>
        <Example label="With a range">
          <Preview code={`<B2BDashboardQuantityStepper defaultValue={4} min={1} max={6} />`}>
            <B2BDashboardQuantityStepper defaultValue={4} min={1} max={6} />
          </Preview>
        </Example>
        <Usage>
          <li>Use on project line items where the buyer sets a unit count.</li>
          <li>The value sits between the two controls and starts at 1. The minus button disables at the minimum and the plus button disables at the maximum.</li>
          <li>The control is a single pill, 111px wide by 40px tall, on a light gray (#e5e5e5) surface with charcoal glyphs.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "value", type: "number", description: "Controlled value" },
            { name: "defaultValue", type: "number", default: "1", description: "Initial value when uncontrolled" },
            { name: "min", type: "number", default: "1", description: "Lowest allowed quantity" },
            { name: "max", type: "number", default: "999", description: "Highest allowed quantity" },
            { name: "onChange", type: "(value: number) => void", description: "Called with the clamped next value" },
          ]}
        />
      </DocSection>

      <DocSection title="Search Field">
        <Intro>
          The search input used in dashboard filter bars. It pairs a magnifier glyph with a single-line text
          input and filters the list or table beneath it.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardSearchField placeholder="Search orders..." />`}>
            <B2BDashboardSearchField placeholder="Search orders..." />
          </Preview>
        </Example>
        <Example label="With a value">
          <Preview code={`<B2BDashboardSearchField defaultValue="TOV-10482" />`}>
            <B2BDashboardSearchField defaultValue="TOV-10482" />
          </Preview>
        </Example>
        <Usage>
          <li>Place at the leading edge of a filter bar, ahead of Select controls and the View Toggle.</li>
          <li>Placeholder text names what is searched, for example &ldquo;Search orders...&rdquo;.</li>
          <li>Default width is 280px; override the container width where the filter bar needs more room.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "placeholder", type: "string", default: '"Search orders..."', description: "Placeholder text" },
            { name: "containerClassName", type: "string", description: "Classes for the outer bordered container (e.g. width)" },
            { name: "...rest", type: "InputHTMLAttributes", description: "Any native input prop" },
          ]}
        />
      </DocSection>

      <DocSection title="Select">
        <Intro>
          A labelled dropdown filter that reads as Label: Value with a trailing chevron. Use it to narrow a
          dashboard list or table by a single dimension.
        </Intro>
        <Example label="Default">
          <Preview
            code={`<B2BDashboardSelect
  label="Date Range:"
  defaultValue="all"
  options={[
    { value: "all", label: "All Time" },
    { value: "30", label: "Last 30 Days" },
    { value: "90", label: "Last 90 Days" },
  ]}
/>`}
          >
            <B2BDashboardSelect label="Date Range:" defaultValue="all" options={DATE_RANGE} />
          </Preview>
        </Example>
        <Example label="In a filter bar">
          <Preview
            code={`<B2BDashboardSelect label="Date Range:" options={dateRange} />
<B2BDashboardSelect
  label="Status:"
  options={[{ value: "all", label: "All" }, { value: "shipped", label: "Shipped" }]}
/>`}
          >
            <B2BDashboardSelect label="Date Range:" defaultValue="all" options={DATE_RANGE} />
            <B2BDashboardSelect
              label="Status:"
              defaultValue="all"
              options={[
                { value: "all", label: "All" },
                { value: "shipped", label: "Shipped" },
                { value: "delivered", label: "Delivered" },
              ]}
            />
          </Preview>
        </Example>
        <Usage>
          <li>The label is muted gray and ends with a colon; the selected value is charcoal. Together they read as one phrase, so no separate field label is needed.</li>
          <li>Always show a selected value. Use &ldquo;All&rdquo; or &ldquo;All Time&rdquo; as the unfiltered option rather than an empty state.</li>
          <li>Use Text Field, not Select, when the user types free-form input.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "label", type: "string", description: "Muted label before the value" },
            { name: "options", type: "{ value: string; label: string }[]", description: "Selectable values" },
            { name: "containerClassName", type: "string", description: "Classes for the outer bordered container" },
            { name: "...rest", type: "SelectHTMLAttributes", description: "Any native select prop" },
          ]}
        />
      </DocSection>

      <DocSection title="Text Field">
        <Intro>
          The standard form field for dashboard forms: an uppercase label sits above a bordered single-line
          input.
        </Intro>
        <Example label="Default">
          <Preview code={`<B2BDashboardTextField label="First Name" defaultValue="Sarah" />`}>
            <B2BDashboardTextField label="First Name" defaultValue="Sarah" />
          </Preview>
        </Example>
        <Example label="Form row">
          <Preview
            code={`<B2BDashboardTextField label="First Name" defaultValue="Sarah" />
<B2BDashboardTextField label="Last Name" defaultValue="Mitchell" />
<B2BDashboardTextField label="Company" placeholder="Company name" />`}
          >
            <B2BDashboardTextField label="First Name" defaultValue="Sarah" />
            <B2BDashboardTextField label="Last Name" defaultValue="Mitchell" />
            <B2BDashboardTextField label="Company" placeholder="Company name" />
          </Preview>
        </Example>
        <Usage>
          <li>Labels are short, uppercase and always visible. They are tied to the input with a <code>for</code> association so the label also focuses the field.</li>
          <li>The field is 225.5px wide by default and 62px tall; set the container width to fit the form grid.</li>
          <li>Use Select for choosing from a fixed list and Search Field for filtering.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "label", type: "string", description: "Uppercase field label" },
            { name: "containerClassName", type: "string", description: "Classes for the wrapper (e.g. width)" },
            { name: "...rest", type: "InputHTMLAttributes", description: "Any native input prop" },
          ]}
        />
      </DocSection>

      <DocSection title="Filter Bar">
        <Intro>
          A Search Field and two Select filters with a &ldquo;Reset Filters&rdquo; link, and a secondary action
          button pinned to the right. Sits directly above a data table or an asset grid.
        </Intro>
        <Example label="Orders">
          <Preview align="start" code={`<B2BDashboardFilterBar />`}>
            <div className="w-full overflow-x-auto">
              <B2BDashboardFilterBar />
            </div>
          </Preview>
        </Example>
        <Example label="Marketing Materials">
          <Preview
            align="start"
            code={`<B2BDashboardFilterBar
  searchPlaceholder="Search templates..."
  dateRangeLabel="Format:"
  dateRangeValue="All Formats"
  statusLabel="Sort:"
  statusValue="Most Popular"
  actionLabel="Download All (.zip)"
/>`}
          >
            <div className="w-full overflow-x-auto">
              <B2BDashboardFilterBar
                searchPlaceholder="Search templates..."
                dateRangeLabel="Format:"
                dateRangeValue="All Formats"
                statusLabel="Sort:"
                statusValue="Most Popular"
                actionLabel="Download All (.zip)"
              />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "searchPlaceholder", type: "string", default: '"Search orders..."', description: "Search field placeholder" },
            { name: "dateRangeLabel", type: "string", default: '"Date Range:"', description: "Label of the first Select" },
            { name: "dateRangeValue", type: "string", default: '"All Time"', description: "Value of the first Select" },
            { name: "statusLabel", type: "string", default: '"Status:"', description: "Label of the second Select" },
            { name: "statusValue", type: "string", default: '"All Statuses"', description: "Value of the second Select" },
            { name: "actionLabel", type: "string", default: '"Export"', description: "Label of the right-aligned action button" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="Avatar">
        <Intro>
          A circular portrait of the account manager or agent assigned to a customer. It appears at a compact
          size in lists and headers, and at a large size on profile and contact surfaces.
        </Intro>
        <Example label="Sizes">
          <Preview
            code={`<B2BDashboardAvatar size="small" src="/images/b2b-dashboard/avatar-small.jpg" alt="Account manager" />
<B2BDashboardAvatar size="large" src="/images/b2b-dashboard/avatar-large.jpg" alt="Account manager" />`}
          >
            <B2BDashboardAvatar size="small" src="/images/b2b-dashboard/avatar-small.jpg" alt="Account manager" />
            <B2BDashboardAvatar size="large" src="/images/b2b-dashboard/avatar-large.jpg" alt="Account manager" />
          </Preview>
        </Example>
        <Example label="Initials fallback">
          <Preview
            code={`<B2BDashboardAvatar size="small" name="Quinn Parker" />
<B2BDashboardAvatar size="large" name="Quinn Parker" />`}
          >
            <B2BDashboardAvatar size="small" name="Quinn Parker" />
            <B2BDashboardAvatar size="large" name="Quinn Parker" />
          </Preview>
        </Example>
        <Usage>
          <li>Small is 40px and fully rounded; Large is 110px and fully rounded. Both crop the photo to fill the circle.</li>
          <li>When no photo is available, the avatar renders the person&apos;s initials on a cream surface in the brand color.</li>
          <li>Use a head-and-shoulders portrait with the face centered so the crop reads at 40px, and provide alt text naming the person when the avatar is not accompanied by their name.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "size", type: '"small" | "large"', default: '"small"', description: "40px or 110px diameter" },
            { name: "src", type: "string", description: "Photo URL" },
            { name: "alt", type: "string", description: "Accessible description" },
            { name: "name", type: "string", description: "Source for the fallback initials" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <DocSection title="View Toggle">
        <Intro>A pair of icon buttons that switches a project view between a grid layout and a list layout.</Intro>
        <Example label="Options">
          <Preview
            code={`<B2BDashboardViewToggleOption mode="grid" selected />
<B2BDashboardViewToggleOption mode="list" />`}
          >
            <div className="flex items-center gap-4 rounded-app-md bg-cream-100 p-6">
              <B2BDashboardViewToggleOption mode="grid" selected />
              <B2BDashboardViewToggleOption mode="list" />
            </div>
          </Preview>
        </Example>
        <Example label="Interactive pair">
          <Preview code={`<B2BDashboardViewToggle defaultValue="grid" />`}>
            <div className="rounded-app-md bg-cream-100 p-6">
              <B2BDashboardViewToggle defaultValue="grid" />
            </div>
          </Preview>
        </Example>
        <Usage>
          <li>Grid (Selected) is a white tile with a thin warm-gray border; List is the unselected treatment, a bare sand-colored glyph.</li>
          <li>Exactly one option is selected at a time; the selected button reports <code>aria-pressed</code>.</li>
          <li>Place at the trailing edge of a filter bar, after Search Field and Select controls. The control only switches layout; it does not filter or sort.</li>
        </Usage>
        <PropsTable
          rows={[
            { name: "value", type: '"grid" | "list"', description: "Controlled mode" },
            { name: "defaultValue", type: '"grid" | "list"', default: '"grid"', description: "Initial mode when uncontrolled" },
            { name: "onChange", type: "(mode) => void", description: "Called when the layout changes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-elements" />
    </DocPage>
  );
}
