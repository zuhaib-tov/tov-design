import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardOrderRow } from "@/components/ui/B2BDashboardOrderRow";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function OrderRowPage() {
  return (
    <DocPage
      title="Order Row"
      description="Compact order line-item used inside the Track Your Orders card, with 3 status variants: Shipped, Processing, Delivered."
    >
      <DocSection title="Variants">
        <Preview align="start" code={`<B2BDashboardOrderRow orderId="492-3024" date="Jun 30" itemCount={12} status="shipped" />
<B2BDashboardOrderRow orderId="884-1102" date="Jun 28" itemCount={5} status="processing" />
<B2BDashboardOrderRow orderId="755-9081" date="Jun 24" itemCount={24} status="delivered" />`}>
          <div className="flex w-[400px] max-w-full flex-col gap-2">
            <B2BDashboardOrderRow orderId="492-3024" date="Jun 30" itemCount={12} status="shipped" />
            <B2BDashboardOrderRow orderId="884-1102" date="Jun 28" itemCount={5} status="processing" />
            <B2BDashboardOrderRow orderId="755-9081" date="Jun 24" itemCount={24} status="delivered" />
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "orderId", type: "string", description: "Order number, e.g. \"492-3024\"" },
            { name: "date", type: "string", description: "Short date, e.g. \"Jun 30\"" },
            { name: "itemCount", type: "number", description: "Item count" },
            { name: "status", type: '"shipped" | "processing" | "delivered"', default: '"shipped"', description: "Status — drives dot color and label" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-order-row" />
    </DocPage>
  );
}
