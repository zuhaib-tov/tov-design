import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardFormCard } from "@/components/ui/B2BDashboardFormCard";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function FormCardPage() {
  return (
    <DocPage
      title="Form Card"
      description="An editable account-settings section on the Account Info page — a title over rows of labeled, bordered fields. Two variants: Personal Information and Company Information."
    >
      <DocSection title="Personal Information">
        <Preview align="start" code={`<B2BDashboardFormCard variant="personal" />`}>
          <B2BDashboardFormCard variant="personal" />
        </Preview>
      </DocSection>

      <DocSection title="Company Information">
        <Preview align="start" code={`<B2BDashboardFormCard variant="company" />`}>
          <B2BDashboardFormCard variant="company" />
        </Preview>
      </DocSection>

      <DocSection title="Usage">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-muted">
          <li>Personal Information pairs First Name and Last Name in one row, then Email Address and Phone Number each on their own full-width row.</li>
          <li>Company Information runs Company Name, Job Title, and Company Website each on their own full-width row.</li>
          <li>Every field is a Dashboard/Text Field — an uppercase muted label above a bordered input showing the current value.</li>
        </ul>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[{ name: "variant", type: '"personal" | "company"', default: '"personal"', description: "Which Form Card variant renders" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-form-card" />
    </DocPage>
  );
}
