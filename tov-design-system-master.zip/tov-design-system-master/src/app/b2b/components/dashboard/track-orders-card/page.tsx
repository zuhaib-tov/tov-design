import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardTrackOrdersCard } from "@/components/ui/B2BDashboardTrackOrdersCard";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function TrackOrdersCardPage() {
  return (
    <DocPage
      title="Track Orders Card"
      description="The Overview page's recent-activity card — a short list of the buyer's latest orders, each with a status dot, order id, date and item count, and a colored status label."
    >
      <DocSection title="Default">
        <Preview align="start" code={`<B2BDashboardTrackOrdersCard activeCount={12} />`}>
          <B2BDashboardTrackOrdersCard activeCount={12} />
        </Preview>
      </DocSection>

      <DocSection title="Usage">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-muted">
          <li>The header pairs the card title with an &quot;N Active&quot; count — the number of orders currently in flight, not the number of rows shown.</li>
          <li>Each Dashboard/Order Row sits on the sidebar&apos;s cream surface, not white, to read as a distinct list within the white card.</li>
          <li>Status color follows the order&apos;s lifecycle stage: Shipped is brand rose, Processing is tan, Delivered is a muted truffle — the same three states as the Orders Table, rendered more compactly here.</li>
        </ul>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[{ name: "activeCount", type: "number", default: "12", description: "Active-order count shown in the header" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-track-orders-card" />
    </DocPage>
  );
}
