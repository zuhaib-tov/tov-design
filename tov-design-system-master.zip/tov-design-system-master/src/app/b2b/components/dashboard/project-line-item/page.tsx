import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardProjectLineItem } from "@/components/ui/B2BDashboardProjectLineItem";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function ProjectLineItemPage() {
  return (
    <DocPage
      title="Project Line Item"
      description="A single product inside a saved project: an image with a Wishlist Button, name + price, a Quantity Stepper, a Soft 'Add to cart' button and a remove icon. Stack multiple to form a project's item list."
    >
      <DocSection title="Default">
        <Preview align="start" code={`<B2BDashboardProjectLineItem productName="Product name" price="$0000.00" quantity={1} />`}>
          <B2BDashboardProjectLineItem productName="Product name" price="$0000.00" quantity={1} />
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "productName", type: "string", description: "Product name" },
            { name: "price", type: "string", description: "Price, e.g. \"$0000.00\"" },
            { name: "quantity", type: "number", default: "1", description: "Quantity shown in the stepper" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-project-line-item" />
    </DocPage>
  );
}
