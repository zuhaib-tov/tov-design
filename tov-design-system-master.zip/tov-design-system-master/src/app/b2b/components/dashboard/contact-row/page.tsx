import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BDashboardContactRow } from "@/components/ui/B2BDashboardContactRow";
import { Mail, Clock } from "lucide-react";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function ContactRowPage() {
  return (
    <DocPage
      title="Contact Row"
      description="Icon tile + uppercase label + value, for a single contact line — phone, email or hours."
    >
      <DocSection title="Variants">
        <Preview align="start" code={`<B2BDashboardContactRow label="Direct Phone" value="(800) 555-8392" />
<B2BDashboardContactRow icon={<Mail size={18} />} label="Email" value="trade@tovfurniture.com" />
<B2BDashboardContactRow icon={<Clock size={18} />} label="Hours" value="Mon–Fri, 9am–6pm ET" />`}>
          <div className="flex flex-col gap-4">
            <B2BDashboardContactRow label="Direct Phone" value="(800) 555-8392" />
            <B2BDashboardContactRow icon={<Mail size={18} strokeWidth={1.75} />} label="Email" value="trade@tovfurniture.com" />
            <B2BDashboardContactRow icon={<Clock size={18} strokeWidth={1.75} />} label="Hours" value="Mon–Fri, 9am–6pm ET" />
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "icon", type: "ReactNode", description: "Glyph shown in the icon tile — defaults to a phone" },
            { name: "label", type: "string", default: '"Direct Phone"', description: "Uppercase label" },
            { name: "value", type: "string", default: '"(800) 555-8392"', description: "Contact value" },
            { name: "className", type: "string", description: "Additional classes" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-dashboard-contact-row" />
    </DocPage>
  );
}
