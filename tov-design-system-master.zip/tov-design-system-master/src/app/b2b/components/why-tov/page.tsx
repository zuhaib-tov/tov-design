import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview } from "@/components/docs/Preview";
import { B2BWhyTov } from "@/components/ui/B2BWhyTov";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function WhyTovPage() {
  return (
    <DocPage
      title="Why TOV"
      description="Brand-value section pairing the Why TOV message with supporting statistics. Keep evidence-bearing metric copy consistent with the source Stat Cards."
    >
      <DocSection title="Desktop">
        <Preview align="start" code={`<B2BWhyTov />`}>
          <B2BWhyTov />
        </Preview>
      </DocSection>

      <DocSection title="Mobile">
        <Preview align="start" code={`<B2BWhyTov compact />`}>
          <div className="max-w-[390px]">
            <B2BWhyTov compact />
          </div>
        </Preview>
      </DocSection>

      <ChangeLogTable page="b2b-why-tov" />
    </DocPage>
  );
}
