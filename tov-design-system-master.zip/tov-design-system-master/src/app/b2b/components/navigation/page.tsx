import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BHeader } from "@/components/ui/B2BHeader";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function NavigationPage() {
  return (
    <DocPage
      title="Navigation"
      description="Global brand and shopping navigation with account entry. Use the matching viewport variant; Desktop exposes category links while Mobile uses compact navigation."
    >
      <DocSection title="Desktop">
        <Preview code={`<B2BHeader viewport="desktop" />`} align="start">
          <B2BHeader viewport="desktop" />
        </Preview>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          A utility bar (logo and &ldquo;Professional&rdquo; wordmark, Support link, Join Today and Sign in, and
          search, wishlist and cart) over a category row with nine links: New, Furniture, Rugs, Lighting, Decor
          &amp; Tabletop, Pillows &amp; Throws, Outdoor, Wall Art &amp; Mirrors and Sale.
        </p>
      </DocSection>

      <DocSection title="Mobile">
        <Preview code={`<B2BHeader viewport="mobile" />`} align="start">
          <B2BHeader viewport="mobile" />
        </Preview>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Collapses to a hamburger, a centered logo lockup, and a search icon with a Sign In pill. The category
          row and the Join Today button are not shown at this viewport.
        </p>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[{ name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Selects the desktop or mobile layout" }]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-navigation" />
    </DocPage>
  );
}
