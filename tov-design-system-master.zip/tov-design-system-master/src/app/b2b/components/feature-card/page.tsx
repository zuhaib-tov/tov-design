import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BFeatureCard } from "@/components/ui/B2BFeatureCard";
import { B2BCollectionFeature } from "@/components/ui/B2BCollectionFeature";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

export default function FeatureCardPage() {
  return (
    <DocPage
      title="Feature Card"
      description="Editorial merchandising features. The Feature Card combines imagery, a heading and a collection CTA; the Collection Feature builds on it to tell a focused collection story with product imagery."
    >
      <DocSection title="Feature Card">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Editorial merchandising card combining imagery, a heading and a collection CTA. Standard is
          available for Desktop and Mobile; Large is Desktop only.
        </p>

        <Example label="Standard · Desktop">
          <Preview
            code={`<B2BFeatureCard
  eyebrow="In stock"
  title="New Arrivals"
  linkLabel="See All New"
  showStatusDot
  size="standard"
  viewport="desktop"
/>`}
          >
            <div className="w-[469px]">
              <B2BFeatureCard eyebrow="In stock" title="New Arrivals" linkLabel="See All New" showStatusDot size="standard" viewport="desktop" />
            </div>
          </Preview>
        </Example>

        <Example label="Large · Desktop">
          <Preview
            code={`<B2BFeatureCard
  eyebrow="The best performance"
  title="Contract Grade"
  linkLabel="All Contract Grade"
  size="large"
  viewport="desktop"
/>`}
          >
            <div className="w-[640px]">
              <B2BFeatureCard eyebrow="The best performance" title="Contract Grade" linkLabel="All Contract Grade" size="large" viewport="desktop" />
            </div>
          </Preview>
        </Example>

        <Example label="Standard · Mobile">
          <Preview
            code={`<B2BFeatureCard
  eyebrow="In stock"
  title="New Arrivals"
  linkLabel="See All New"
  showStatusDot
  size="standard"
  viewport="mobile"
/>`}
          >
            <div className="w-[350px]">
              <B2BFeatureCard eyebrow="In stock" title="New Arrivals" linkLabel="See All New" showStatusDot size="standard" viewport="mobile" />
            </div>
          </Preview>
        </Example>

        <PropsTable
          rows={[
            { name: "eyebrow", type: "string", description: "Small uppercase line above the title" },
            { name: "title", type: "string", description: "Display heading" },
            { name: "linkLabel", type: "string", description: "Collection CTA text" },
            { name: "showStatusDot", type: "boolean", default: "false", description: "Live-stock status dot next to the eyebrow" },
            { name: "size", type: '"standard" | "large"', default: '"standard"', description: "Large is desktop only" },
            { name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Layout tier" },
          ]}
        />
      </DocSection>

      <DocSection title="Collection Feature">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Contract Grade merchandising feature that combines collection messaging with product imagery. Use
          for a focused collection story; replace sample product details with approved content. Mobile shows a
          scrolling row of product tiles with name and price beneath each image; Desktop&apos;s 2x2 grid is
          image-only.
        </p>

        <Example label="Contract Grade · Desktop">
          <Preview align="start" code={`<B2BCollectionFeature />`}>
            <B2BCollectionFeature />
          </Preview>
        </Example>

        <Example label="Contract Grade · Mobile">
          <Preview align="start" code={`<B2BCollectionFeature compact />`}>
            <div className="max-w-[390px]">
              <B2BCollectionFeature compact />
            </div>
          </Preview>
        </Example>
      </DocSection>

      <ChangeLogTable page="b2b-feature-card" />
    </DocPage>
  );
}
