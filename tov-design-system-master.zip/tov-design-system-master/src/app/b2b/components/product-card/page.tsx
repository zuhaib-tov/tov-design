import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BProductCard } from "@/components/ui/B2BProductCard";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function ProductCardPage() {
  return (
    <DocPage
      title="Product Card"
      description="Product preview for merchandising grids and carousels. Default variants carry product details; Image Only is available for desktop. Replace sample product names and prices with approved content."
    >
      <DocSection title="Default · Desktop">
        <Preview
          code={`<B2BProductCard
  tag="New Arrival"
  eyebrow="New Color"
  name="Cynthia Indoor/Outdoor Side Table"
  viewport="desktop"
/>`}
        >
          <B2BProductCard tag="New Arrival" eyebrow="New Color" name="Cynthia Indoor/Outdoor Side Table" viewport="desktop" />
        </Preview>
      </DocSection>

      <DocSection title="Default · Mobile">
        <Preview
          code={`<B2BProductCard
  tag="New Arrivals"
  name="Product name"
  price="$0000.00"
  swatchCount={3}
  selectedSwatch={0}
  viewport="mobile"
/>`}
        >
          <B2BProductCard tag="New Arrivals" name="Product name" price="$0000.00" swatchCount={3} selectedSwatch={0} viewport="mobile" />
        </Preview>
      </DocSection>

      <DocSection title="Image Only · Desktop">
        <Preview
          code={`<B2BProductCard
  tag="New Arrival"
  name="Cynthia Indoor/Outdoor Side Table"
  variant="image-only"
  viewport="desktop"
/>`}
        >
          <B2BProductCard tag="New Arrival" name="Cynthia Indoor/Outdoor Side Table" variant="image-only" viewport="desktop" />
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "tag", type: "string", default: '"New Arrival"', description: "Overlay tag text" },
            { name: "name", type: "string", description: "Product name" },
            { name: "eyebrow", type: "string", description: "Desktop-only line above the product name" },
            { name: "price", type: "string", description: "Mobile-only price" },
            { name: "swatchCount", type: "number", default: "0", description: "Mobile-only number of color swatches" },
            { name: "selectedSwatch", type: "number", default: "0", description: "Index of the selected swatch" },
            { name: "variant", type: '"default" | "image-only"', default: '"default"', description: "Whether the Details block renders" },
            { name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Layout tier" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-product-card" />
    </DocPage>
  );
}
