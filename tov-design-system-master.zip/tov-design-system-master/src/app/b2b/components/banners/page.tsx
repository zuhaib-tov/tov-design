import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BAnnouncementBar } from "@/components/ui/B2BAnnouncementBar";
import { B2BPromoBanner } from "@/components/ui/B2BPromoBanner";
import { B2BHero } from "@/components/ui/B2BHero";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const HERO_BODY =
  "From interior designers and architects to trade and wholesale partners, our Professional Program is built for the industry. Enjoy exclusive benefits, insider resources, and dedicated service designed around how you work.";

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

export default function BannersPage() {
  return (
    <DocPage
      title="Banners"
      description="Full-width message and introduction surfaces, from the slim Announcement Bar at the top of the page to the Promo Banner and the image-led Hero. Each has Desktop and Mobile compositions."
    >
      <DocSection title="Announcement Bar">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Top-of-page message strip for brief shipping or promotional notices. Keep messaging short and
          approved before release.
        </p>
        <Example label="Desktop">
          <Preview code={`<B2BAnnouncementBar viewport="desktop" />`} align="start">
            <B2BAnnouncementBar viewport="desktop" />
          </Preview>
        </Example>
        <Example label="Mobile">
          <Preview code={`<B2BAnnouncementBar viewport="mobile" />`} align="start">
            <B2BAnnouncementBar viewport="mobile" />
          </Preview>
        </Example>
        <PropsTable
          rows={[{ name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Selects the desktop or mobile layout" }]}
        />
      </DocSection>

      <DocSection title="Promo Banner">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Closeout promotion with a headline, supporting message and sale CTA. Keep the offer and destination
          aligned; verify promotional claims before publishing. Desktop pairs the headline with the Outline
          Inverse button (&ldquo;View sale items&rdquo;); Mobile replaces it with a plain text link
          (&ldquo;Shop sale&rdquo;).
        </p>
        <Example label="Closeout · Desktop">
          <Preview code={`<B2BPromoBanner viewport="desktop" />`} align="start">
            <B2BPromoBanner viewport="desktop" />
          </Preview>
        </Example>
        <Example label="Closeout · Mobile">
          <Preview code={`<B2BPromoBanner viewport="mobile" />`} align="start">
            <B2BPromoBanner viewport="mobile" />
          </Preview>
        </Example>
        <PropsTable
          rows={[{ name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Selects the desktop or mobile layout" }]}
        />
      </DocSection>

      <DocSection title="Hero">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Image-led Professional Program introduction with a headline and membership CTA. Use near the top
          of the page; retain text contrast and choose the correct viewport composition. Mobile drops the
          body copy — eyebrow, headline and CTA only.
        </p>
        <Example label="Professional Program · Desktop">
          <Preview
            align="start"
            code={`<B2BHero eyebrow="Professional Program" headline="Welcome to TOV's Professional Program" body="…" ctaLabel="Join TOV Professional" />`}
          >
            <B2BHero
              eyebrow="Professional Program"
              headline="Welcome to TOV's Professional Program"
              body={HERO_BODY}
              ctaLabel="Join TOV Professional"
            />
          </Preview>
        </Example>
        <Example label="Professional Program · Mobile">
          <Preview
            align="start"
            code={`<B2BHero compact eyebrow="Professional Program" headline="Welcome to TOV's Professional Program" ctaLabel="Join today" />`}
          >
            <div className="max-w-[390px]">
              <B2BHero
                compact
                eyebrow="Professional Program"
                headline="Welcome to TOV's Professional Program"
                ctaLabel="Join today"
              />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "eyebrow", type: "string", description: "Small uppercase label above the headline" },
            { name: "headline", type: "string", description: "Main hero statement" },
            { name: "body", type: "string", description: "Desktop only — supporting copy below the headline" },
            { name: "ctaLabel", type: "string", description: "CTA button label" },
            { name: "compact", type: "boolean", default: "false", description: "Renders the Mobile variant" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-banners" />
    </DocPage>
  );
}
