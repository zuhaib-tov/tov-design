import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BCategoryTile } from "@/components/ui/B2BCategoryTile";
import { B2BBrowseByCategory } from "@/components/ui/B2BBrowseByCategory";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

const CATEGORIES = ["Accent Chairs", "Dining Chairs", "Dining Tables", "Coffee & Tables", "Sofas"];

function Example({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-6 last:mb-0">
      <h3 className="mb-2 text-sm font-semibold text-ink">{label}</h3>
      {children}
    </div>
  );
}

export default function CategoryTilePage() {
  return (
    <DocPage
      title="Category Tile"
      description="Category entry points: the image-led Category Tile, and the Browse by Category section that lays a row of tiles out for discovering the collection by product type."
    >
      <DocSection title="Category Tile">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Image-led category entry with a short category name. Use inside Browse by Category and keep labels
          consistent with the catalog taxonomy.
        </p>
        <Example label="Default · Desktop">
          <Preview code={`<B2BCategoryTile label="Accent Chairs" size="lg" />`}>
            <div className="w-[250px]">
              <B2BCategoryTile label="Accent Chairs" size="lg" />
            </div>
          </Preview>
        </Example>
        <Example label="Default · Mobile">
          <Preview code={`<B2BCategoryTile label="Accent Chairs" size="sm" />`}>
            <div className="w-[167px]">
              <B2BCategoryTile label="Accent Chairs" size="sm" />
            </div>
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "label", type: "string", description: "Category name, rendered uppercase" },
            { name: "size", type: '"sm" | "lg"', default: '"lg"', description: "18px label on lg (desktop), 14px on sm (mobile)" },
          ]}
        />
      </DocSection>

      <DocSection title="Browse by Category">
        <p className="mb-4 max-w-2xl text-xs text-ink-muted">
          Category discovery section built from Category Tiles. Use for browsing the collection by product
          type and maintain consistent category naming.
        </p>
        <Example label="Default · Desktop">
          <Preview align="start" code={`<B2BBrowseByCategory categories={categories} viewport="desktop" />`}>
            <B2BBrowseByCategory categories={CATEGORIES} viewport="desktop" />
          </Preview>
        </Example>
        <Example label="Default · Mobile">
          <Preview align="start" code={`<B2BBrowseByCategory categories={categories} viewport="mobile" />`}>
            <B2BBrowseByCategory categories={CATEGORIES} viewport="mobile" />
          </Preview>
        </Example>
        <PropsTable
          rows={[
            { name: "categories", type: "string[]", description: "Category labels, rendered as Category Tiles" },
            { name: "viewport", type: '"desktop" | "mobile"', default: '"desktop"', description: "Layout tier" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-category-tile" />
    </DocPage>
  );
}
