import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BIcon } from "@/components/ui/B2BIcon";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function B2BIconPage() {
  return (
    <DocPage
      title="Icon"
      description="Supporting symbols for benefit messaging: Book Library, Shield, Delivery Truck and Pencil Edit. Pair each symbol with a clear text label."
    >
      <DocSection title="Variants">
        <Preview
          code={`<B2BIcon name="book-library" withBackground />
<B2BIcon name="shield" withBackground />
<B2BIcon name="delivery-truck" withBackground />
<B2BIcon name="pencil-edit" withBackground />`}
        >
          <div className="flex flex-col items-center gap-2">
            <B2BIcon name="book-library" withBackground />
            <span className="text-xs text-ink-muted">Book Library</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <B2BIcon name="shield" withBackground />
            <span className="text-xs text-ink-muted">Shield</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <B2BIcon name="delivery-truck" withBackground />
            <span className="text-xs text-ink-muted">Delivery Truck</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <B2BIcon name="pencil-edit" withBackground />
            <span className="text-xs text-ink-muted">Pencil Edit</span>
          </div>
        </Preview>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            {
              name: "name",
              type: '"book-library" | "shield" | "delivery-truck" | "pencil-edit"',
              description: "Which of the 4 glyphs to render",
            },
            { name: "size", type: "number", default: "24", description: "Glyph size in px" },
            {
              name: "withBackground",
              type: "boolean",
              default: "false",
              description: "Wraps the glyph in the mauve circular chip used for benefit messaging",
            },
            { name: "className", type: "string", description: "Additional classes on the raw glyph" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-icon" />
    </DocPage>
  );
}
