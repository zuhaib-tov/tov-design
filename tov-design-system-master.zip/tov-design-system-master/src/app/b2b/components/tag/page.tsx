import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Preview, PropsTable } from "@/components/docs/Preview";
import { B2BTag } from "@/components/ui/B2BTag";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";

export default function B2BTagPage() {
  return (
    <DocPage
      title="Tag"
      description="Short product labels such as New Arrival. Use concise copy to keep the badge legible over product imagery."
    >
      <DocSection title="Sizes">
        <Preview
          code={`<B2BTag size="desktop">New Arrival</B2BTag>
<B2BTag size="mobile">New Arrivals</B2BTag>`}
        >
          <B2BTag size="desktop">New Arrival</B2BTag>
          <B2BTag size="mobile">New Arrivals</B2BTag>
        </Preview>
        <p className="text-xs text-ink-muted mt-3">
          Desktop and Mobile share one appearance, with Mobile scaled down for smaller
          screens.
        </p>
      </DocSection>

      <DocSection title="Props">
        <PropsTable
          rows={[
            { name: "size", type: '"desktop" | "mobile"', default: '"desktop"', description: "Selects the desktop or mobile scale" },
            { name: "children", type: "ReactNode", description: "Label text" },
          ]}
        />
      </DocSection>

      <ChangeLogTable page="b2b-tag" />
    </DocPage>
  );
}
