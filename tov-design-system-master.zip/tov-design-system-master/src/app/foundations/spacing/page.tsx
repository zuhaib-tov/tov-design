import { DocPage, DocSection } from "@/components/docs/DocPage";
import { radiusTokens, widthTokens } from "@/lib/tokens";
import { SPACE_STEPS, PAGE_MARGIN } from "@/lib/spacingScale";

/** A solid margin block would visually compete with the content block, so the
 * gutter reads as "excluded space" via a diagonal stripe, a common convention
 * for margin/safe-area diagrams. */
const MARGIN_STRIPE = {
  backgroundImage:
    "repeating-linear-gradient(-45deg, var(--color-primary) 0, var(--color-primary) 1px, transparent 1px, transparent 6px)",
  backgroundColor: "var(--color-cream-200)",
};

const SCREENS = [
  { key: "desktop", label: "Desktop", from: "1024px and up" },
  { key: "tablet", label: "Tablet", from: "768px to 1023px" },
  { key: "mobile", label: "Mobile", from: "under 768px" },
] as const;

/** The three reference screens, each drawn at the width its page margin is specified for. */
const MARGIN_SCREENS = [
  { breakpoint: "Desktop", width: "1024px and up", refWidth: 1440, margin: PAGE_MARGIN.desktop },
  { breakpoint: "Tablet", width: "768px to 1023px", refWidth: 768, margin: PAGE_MARGIN.tablet },
  { breakpoint: "Mobile", width: "under 768px", refWidth: 375, margin: PAGE_MARGIN.mobile },
];

function MarginRuler() {
  const maxRefWidth = Math.max(...MARGIN_SCREENS.map((b) => b.refWidth));

  return (
    <div className="flex flex-col gap-5 rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
      {MARGIN_SCREENS.map((b) => {
        const barPct = (b.refWidth / maxRefWidth) * 100;
        const marginPct = (b.margin / maxRefWidth) * 100;
        const contentWidth = b.refWidth - b.margin * 2;
        return (
          <div key={b.breakpoint}>
            <div className="flex items-baseline gap-2 mb-1.5">
              <span className="text-sm font-semibold text-ink">{b.breakpoint}</span>
              <span className="text-xs font-mono text-ink-muted">{b.width}</span>
            </div>
            <div className="flex h-9" style={{ width: `${barPct}%` }}>
              <div
                className="h-full shrink-0 flex items-center justify-center"
                style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }}
              >
                {marginPct >= 6 && (
                  <span className="text-[9px] font-mono text-primary-dark bg-white/80 px-0.5 rounded-sm">
                    {b.margin}
                  </span>
                )}
              </div>
              <div className="h-full flex-1 min-w-0 bg-cream-50 border-y border-neutral-300 flex items-center justify-center">
                <span className="text-[10px] font-mono text-ink-muted truncate px-1">{contentWidth}px content</span>
              </div>
              <div
                className="h-full shrink-0"
                style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }}
              />
            </div>
          </div>
        );
      })}
      <p className="text-xs text-ink-muted mt-1">
        Bars are scaled to fit the page, not 1:1 pixels — the striped edges are
        the margin, sized proportionally to each breakpoint&apos;s real width.
        The content-area label is the real pixel width at that breakpoint.
      </p>
    </div>
  );
}

function Bar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-3 shrink-0 rounded-sm border border-neutral-300 bg-cream-200" style={{ width: value }} />
      <span className="font-mono text-xs text-ink">{value}</span>
    </div>
  );
}

export default function SpacingPage() {
  return (
    <DocPage
      title="Spacing & Radius"
      description="One spacing scale, written as classes. Each class has a Desktop, Tablet and Mobile value and is listed from the largest space to the smallest."
    >
      <DocSection title="Spacing classes">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          Use a class by its name in any spacing utility: <code className="font-mono">p-space-md</code>,{" "}
          <code className="font-mono">gap-space-xs</code>, <code className="font-mono">mt-space-3xl</code>,{" "}
          <code className="font-mono">py-space-2xl</code>. The value switches with the screen, so a class never
          needs a responsive prefix. Mobile is the base; Tablet applies from 768px and Desktop from 1024px.
          The steps from <code className="font-mono">xl</code> up change by screen size. From{" "}
          <code className="font-mono">xs</code> down they hold one value on every screen.
        </p>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 shadow-sm bg-white">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Class</th>
                {SCREENS.map((s) => (
                  <th key={s.key} className="px-4 py-2 font-semibold">
                    <div>{s.label}</div>
                    <div className="text-[11px] font-normal text-ink-muted">{s.from}</div>
                  </th>
                ))}
                <th className="min-w-[280px] px-4 py-2 font-semibold">Use for</th>
              </tr>
            </thead>
            <tbody>
              {SPACE_STEPS.map((step) => (
                <tr key={step.name} className="border-t border-neutral-200 align-top">
                  <td className="px-4 py-3 font-mono text-xs font-semibold text-primary-dark whitespace-nowrap">
                    space-{step.name}
                  </td>
                  {SCREENS.map((s) => (
                    <td key={s.key} className="px-4 py-3 whitespace-nowrap">
                      <Bar value={step[s.key]} />
                    </td>
                  ))}
                  <td className="min-w-[280px] px-4 py-3 text-ink-muted">{step.usage}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 max-w-2xl text-xs text-ink-muted">
          Values are in pixels. In code, the class resolves to the{" "}
          <code className="font-mono">--space-*</code> variable, for example{" "}
          <code className="font-mono">p-space-md</code> is <code className="font-mono">padding: var(--space-md)</code>.
        </p>
      </DocSection>

      <DocSection title="Page margin">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          The outer inset of every full-width section is one class,{" "}
          <code className="font-mono">px-space-page</code>. It is 100px on Desktop, 32px on Tablet and 20px on
          Mobile, the same margins the column grid uses on the Layout page.
        </p>
        <div className="mb-4">
          <MarginRuler />
        </div>
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 shadow-sm bg-white">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Class</th>
                {SCREENS.map((s) => (
                  <th key={s.key} className="px-4 py-2 font-semibold">
                    <div>{s.label}</div>
                    <div className="text-[11px] font-normal text-ink-muted">{s.from}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-neutral-200">
                <td className="px-4 py-3 font-mono text-xs font-semibold text-primary-dark whitespace-nowrap">
                  space-{PAGE_MARGIN.name}
                </td>
                {SCREENS.map((s) => (
                  <td key={s.key} className="px-4 py-3 whitespace-nowrap">
                    <span className="font-mono text-xs text-ink">{PAGE_MARGIN[s.key]}</span>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title="Content width">
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 shadow-sm bg-white">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Token</th>
                <th className="px-4 py-2 font-semibold">Value</th>
                <th className="px-4 py-2 font-semibold">Use for</th>
                <th className="px-4 py-2 font-semibold">Class</th>
              </tr>
            </thead>
            <tbody>
              {widthTokens.map((t) => (
                <tr key={t.name} className="border-t border-neutral-200 align-top">
                  <td className="px-4 py-3 font-semibold whitespace-nowrap">{t.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{t.value}px</td>
                  <td className="px-4 py-3 text-ink-muted">{t.usage}</td>
                  <td className="px-4 py-3 font-mono text-xs text-primary-dark whitespace-nowrap">{t.css}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DocSection>

      <DocSection title="Radius">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {radiusTokens.map((r) => (
            <div key={r.name} className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-4 text-center">
              <div
                className="h-16 bg-primary mx-auto mb-3"
                style={{ width: "100%", borderRadius: r.value }}
              />
              <div className="text-sm font-semibold">{r.name}</div>
              <div className="text-xs font-mono text-ink-muted">{r.value}</div>
              <div className="text-xs text-ink-muted mt-1">{r.usage}</div>
            </div>
          ))}
        </div>
      </DocSection>
    </DocPage>
  );
}
