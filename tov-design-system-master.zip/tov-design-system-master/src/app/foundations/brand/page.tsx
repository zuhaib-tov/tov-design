import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Logo } from "@/components/ui/Logo";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { LogoConstruction, LogoClearSpace } from "@/components/docs/LogoGuidelines";
import { LogoColorways, LogoColorwayDownload } from "@/components/docs/LogoColorways";
import { BrandAssetDownload, DownloadAllBrandAssets } from "@/components/docs/BrandDownloads";

export default function BrandPage() {
  return (
    <DocPage
      title="Brand"
      description={
        'The logo is the cornerstone of the brand\'s identity — designed to represent TOV with clarity and consistency across every medium. Primary, secondary, and tertiary variations keep it flexible without sacrificing recognizability.'
      }
    >
      <DocSection title="Download">
        <DownloadAllBrandAssets />
      </DocSection>

      <DocSection title="Primary logo">
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col sm:flex-row gap-8 items-center">
          <div className="shrink-0 rounded-app-md bg-cream-100 p-8">
            <Logo className="h-16 text-ink" />
          </div>
          <p className="text-sm text-ink-muted max-w-lg">
            The primary logo is the most recognizable element in the UI, representing
            the brand at its highest level. It anchors the visual identity, reinforces
            recognition, and builds trust. Use it wherever there&apos;s no reason to
            reach for the secondary or tertiary variants.
          </p>
          <LogoColorwayDownload colorway="primary" />
        </div>
      </DocSection>

      <DocSection title="Secondary logo — dark backgrounds">
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col sm:flex-row gap-8 items-center">
          <div className="shrink-0 rounded-app-md bg-charcoal p-8">
            <Logo className="h-16 text-white" />
          </div>
          <p className="text-sm text-ink-muted max-w-lg">
            Designed specifically for dark backgrounds, so the brand stays clear,
            legible, and consistent when the primary logo can&apos;t be applied —
            footers, dark sections, photography overlays.
          </p>
          <LogoColorwayDownload colorway="white" />
        </div>
      </DocSection>

      <DocSection title="Tertiary logo — monochrome">
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col sm:flex-row gap-8 items-center">
          <div className="shrink-0 rounded-app-md bg-cream-100 p-8">
            <Logo className="h-16 text-ink" accentColor="currentColor" />
          </div>
          <p className="text-sm text-ink-muted max-w-lg">
            A single-color version that can render in any of TOV&apos;s neutral
            colors. Use it only when accessibility requirements or production
            limitations rule out the primary or secondary logo.
          </p>
          <LogoColorwayDownload colorway="black" />
        </div>
      </DocSection>

      <DocSection
        title={
          <>
            Logo mark <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col sm:flex-row gap-8 items-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/logo-mark.svg" alt="TOV logo mark" className="w-28 h-28 shrink-0" />
          <p className="text-sm text-ink-muted max-w-lg">
            A standalone circular mark for contexts too small or square for the full
            wordmark — app icons, favicons, social avatars.
          </p>
          <BrandAssetDownload asset="mark" />
        </div>
      </DocSection>

      <DocSection
        title={
          <>
            Logo construction <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="mb-4 max-w-2xl text-sm text-ink-muted">
          The wordmark is built on a 1000-unit grid. Every edge lands on a whole unit. The three letterforms share
          one stroke weight and one baseline, and the O carries the only optical correction in the mark.
        </p>
        <LogoConstruction />
      </DocSection>

      <DocSection
        title={
          <>
            Clear space and scale <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="mb-4 max-w-2xl text-sm text-ink-muted">
          Minimum clear space on all four sides equals the height of the O: 176 units, or the full cap height of the
          wordmark.
        </p>
        <LogoClearSpace />
      </DocSection>

      <DocSection
        title={
          <>
            Colorways and assets <Badge variant="new">New</Badge>
          </>
        }
      >
        <p className="mb-4 max-w-2xl text-sm text-ink-muted">
          Four approved variants. Download each as a tight-cropped SVG or a transparent PNG. The primary lockup is the
          default; the single-color variants exist for constrained surfaces.
        </p>
        <LogoColorways />
      </DocSection>

      <DocSection title="Tagline">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col gap-4 items-center">
            <div className="flex flex-1 items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/tagline-bold.svg" alt="Don't Be Boring — bold lockup" className="max-w-full h-auto" />
            </div>
            <BrandAssetDownload asset="tagline-bold" />
          </div>
          <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 flex flex-col gap-4 items-center">
            <div className="flex flex-1 items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/tagline-script.svg" alt="Don't Be Boring — script lockup" className="max-w-full h-auto" />
            </div>
            <BrandAssetDownload asset="tagline-script" />
          </div>
        </div>
        <p className="text-sm text-ink-muted mt-3">
          &ldquo;Don&apos;t Be Boring&rdquo; — TOV&apos;s tagline, in its two approved
          lockups. The bold version is the default for UI use; the script version is
          reserved for marketing/lifestyle contexts.
        </p>
      </DocSection>

      <ChangeLogTable page="brand" />
    </DocPage>
  );
}
