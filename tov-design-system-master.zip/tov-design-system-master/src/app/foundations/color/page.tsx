import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { colorTokens } from "@/lib/tokens";
import { BRAND_PALETTE } from "@/lib/brandPalette";

export default function ColorPage() {
  return (
    <DocPage
      title="Color"
      description="TOV's full brand color palette, organized by role — Primary, Secondary, Tertiary, Neutral, and Status. Functional tokens further down map each UI role (text, surfaces, badges, states) onto this palette, so every color used in product is traceable back to a named brand color."
    >
      <DocSection
        title={
          <>
            Brand Palette <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <div className="flex flex-col gap-8">
          {BRAND_PALETTE.map((group) => (
            <div key={group.title}>
              <h3 className="font-semibold text-ink mb-1">{group.title}</h3>
              <p className="text-xs text-ink-muted mb-3 max-w-2xl">{group.description}</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
                {group.colors.map((c) => (
                  <div
                    key={c.name}
                    className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white"
                  >
                    <div className="h-14" style={{ background: c.value }} />
                    <div className="p-2.5">
                      <div className="text-xs font-semibold">{c.name}</div>
                      <div className="text-[11px] font-mono text-ink-muted">{c.value}</div>
                      {c.mapsTo && (
                        <div className="text-[10px] text-primary-dark font-mono mt-0.5">
                          = --color-{c.mapsTo}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Functional tokens">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          The UI-role tokens components should reference directly. Always use the
          CSS class below, never a raw hex value, so the system stays consistent as
          colors evolve.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {colorTokens.map((c) => (
            <div key={c.name} className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white">
              <div
                className="h-20"
                style={{ background: c.value }}
              />
              <div className="p-3">
                <div className="text-sm font-semibold">{c.name}</div>
                <div className="text-xs font-mono text-ink-muted">{c.value}</div>
                <div className="text-xs text-ink-muted mt-1">{c.usage}</div>
                <code className="text-[11px] font-mono text-primary-dark">{c.css}</code>
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <ChangeLogTable page="color" />
    </DocPage>
  );
}
