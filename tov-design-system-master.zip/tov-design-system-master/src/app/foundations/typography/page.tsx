import { ReactNode } from "react";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { Badge } from "@/components/ui/Badge";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { fontTokens } from "@/lib/tokens";
import {
  HEADINGS,
  BODY,
  LABELS,
  UI_TEXT,
  TEXT_LINKS,
  typeClass,
  BREAKPOINTS,
  WEIGHT_USAGE,
  WEIGHT_VALUE,
  TRACKING_CAPS,
  type TypeStyle,
  type HeadingStyle,
} from "@/lib/typeScale";

function spec(s: TypeStyle) {
  const tracking = s.uppercase ? "+4.5%" : "0";
  return `${s.size} / ${s.lineHeight} · ${s.weight} · ${tracking}`;
}

function StyleTable({ styles, sample }: { styles: TypeStyle[]; sample: string }) {
  return (
    <div className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
      {styles.map((s, i) => (
        <div key={s.name} className={`px-5 py-4 ${i > 0 ? "border-t border-neutral-200" : ""}`}>
          <div className="mb-2 flex flex-wrap items-baseline gap-x-4 gap-y-1">
            <span className="font-mono text-xs font-semibold text-ink">{s.name}</span>
            <span className="font-mono text-xs text-ink-muted">{spec(s)}</span>
            <span className="font-mono text-xs text-primary-dark">{typeClass(s.name).split(" ").map((c) => `.${c}`).join(" ")}</span>
            <span className="text-xs text-ink-muted">{s.usage}</span>
          </div>
          <p
            className={`${s.fontFamily === "GT Ultra Fine" ? "font-display" : "font-sans"} min-w-0 text-ink`}
            style={{
              fontSize: s.size,
              lineHeight: `${s.lineHeight}px`,
              fontWeight: WEIGHT_VALUE[s.weight],
              textTransform: s.uppercase ? "uppercase" : s.capitalize ? "capitalize" : undefined,
              textDecoration: s.underline ? "underline" : undefined,
              textUnderlineOffset: s.underline ? 3 : undefined,
              textDecorationThickness: s.underline ? 1 : undefined,
              letterSpacing: s.uppercase ? TRACKING_CAPS : undefined,
            }}
          >
            {sample}
          </p>
        </div>
      ))}
    </div>
  );
}

const SCREENS: { key: "size" | "tablet" | "mobile"; label: string }[] = [
  { key: "size", label: "Desktop" },
  { key: "tablet", label: "Tablet" },
  { key: "mobile", label: "Mobile" },
];

function sizeFor(h: HeadingStyle, key: "size" | "tablet" | "mobile") {
  return key === "size" ? { size: h.size, lineHeight: h.lineHeight } : h[key];
}

function HeadingTable({ styles, sample }: { styles: HeadingStyle[]; sample: string }) {
  return (
    <div className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
      {styles.map((h, i) => (
        <div key={h.name} className={`px-5 py-4 ${i > 0 ? "border-t border-neutral-200" : ""}`}>
          <div className="mb-3 flex flex-wrap items-baseline gap-x-4 gap-y-1">
            <span className="font-mono text-xs font-semibold text-ink">{h.name}</span>
            <span className="font-mono text-xs text-primary-dark">.{typeClass(h.name)}</span>
            <span className="text-xs text-ink-muted">{h.usage}</span>
          </div>
          <div className="flex flex-col gap-3">
            {SCREENS.map(({ key, label }) => {
              const v = sizeFor(h, key);
              return (
                <div key={key} className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-4">
                  <span className="w-40 shrink-0 font-mono text-xs text-ink-muted">
                    {label} · {v.size} / {v.lineHeight}
                  </span>
                  <p
                    className="min-w-0 font-display text-ink"
                    style={{ fontSize: v.size, lineHeight: `${v.lineHeight}px`, fontWeight: WEIGHT_VALUE[h.weight] }}
                  >
                    {sample}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function Intro({ children }: { children: ReactNode }) {
  return <p className="mb-4 max-w-2xl text-xs text-ink-muted">{children}</p>;
}

export default function TypographyPage() {
  return (
    <DocPage
      title="Typography"
      description="Two typefaces carry every TOV page: GT Ultra Fine for headings and display moments, Montserrat for body copy, labels and interface text. Letter-spacing is zero everywhere except button text and all-caps text."
    >
      <div className="mb-10 rounded-app-lg border border-neutral-200 bg-cream-100 p-5">
        <h2 className="mb-2 font-display text-lg text-ink">Standard type and accent type</h2>
        <p className="max-w-2xl text-sm text-ink-muted">
          The styles on this page are TOV&apos;s standard type. They set the default for every page and
          component. Some modules also use accent type, a larger or more expressive treatment for a single
          campaign, hero or editorial moment. Accent type sits outside the standard scale and is specified per
          design, so each instance is defined in its own Figma file and is not added to these styles.
        </p>
      </div>

      <DocSection title="Type families">
        <div className="flex flex-col gap-6">
          {fontTokens.map((f) => (
            <div key={f.name} className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
              <div className="mb-1 text-xs font-semibold uppercase tracking-wide-ui text-ink-muted">
                {f.name} · <code className="font-mono">{f.variable}</code>
              </div>
              <div className="mb-3 text-xs text-ink-muted">{f.stack}</div>
              <p className={f.name === "Display" ? "font-display text-4xl" : "font-sans text-2xl"}>
                Trend-forward furniture
              </p>
              <p className="mt-2 text-xs text-ink-muted">{f.usage}</p>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection
        title={
          <>
            Headings <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <Intro>
          GT Ultra Fine, Regular weight only, no letter-spacing. H4 to H7 cover page titles, section headings
          and module titles; H1 to H3 are display sizes reserved for promotional moments.
        </Intro>
        <HeadingTable styles={HEADINGS} sample="Modern living" />

        <h3 className="mb-2 mt-6 text-sm font-semibold text-ink">Screen sizes</h3>
        <Intro>
          Every heading has a Desktop, Tablet and Mobile size. Mobile is the base style; Tablet applies from{" "}
          {BREAKPOINTS.tablet}px and Desktop from {BREAKPOINTS.desktop}px. Mobile runs at roughly 0.6 of Desktop for the display sizes and
          eases to 0.9 for the smallest heading; Tablet sits at the midpoint. No heading falls below 20px on Mobile. In code, use the{" "}
          <code className="font-mono">type-h1</code> to <code className="font-mono">type-h7</code> classes, which
          switch size and line-height at those widths.
        </Intro>
        <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
          <div className="mb-2 font-mono text-xs text-ink-muted">type-h4 · scales with this window</div>
          <p className="type-h4 text-ink">Trend-forward furniture</p>
        </div>
      </DocSection>

      <DocSection
        title={
          <>
            Body <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <Intro>
          Montserrat, Regular by default, no letter-spacing. Every size uses a 1.5 line-height so paragraphs
          share one rhythm.
        </Intro>
        <StyleTable
          styles={BODY}
          sample="Statement furniture at prices that make sense for how you live."
        />
      </DocSection>

      <DocSection
        title={
          <>
            Labels, buttons and badges <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <Intro>
          Montserrat in all caps. Labels, button text and badge text are the only styles that carry letter-spacing:
          +4.5% ({TRACKING_CAPS}) at every size.
        </Intro>
        <StyleTable styles={LABELS} sample="Shop now" />
      </DocSection>

      <DocSection
        title={
          <>
            Text links <Badge variant="new">New</Badge>
          </>
        }
      >
        <Intro>
          Underlined, 1px thick and 3px below the baseline. The call to action is bold caps with +4.5% ({TRACKING_CAPS});
          the inline link is regular with no letter-spacing. Medium is the default size.
        </Intro>
        <StyleTable styles={TEXT_LINKS.filter((s) => s.name.includes("CTA"))} sample="Shop now" />
        <div className="mt-4">
          <StyleTable styles={TEXT_LINKS.filter((s) => s.name.includes("Inline"))} sample="Learn more" />
        </div>
      </DocSection>

      <DocSection
        title={
          <>
            Interface text <Badge variant="new">Updated</Badge>
          </>
        }
      >
        <Intro>
          Navigation, product names and prices. Set in sentence or title case with no letter-spacing.
        </Intro>
        <StyleTable styles={UI_TEXT.filter((s) => !s.name.startsWith("Price"))} sample="Accent Chairs" />
        <div className="mt-4">
          <StyleTable styles={UI_TEXT.filter((s) => s.name.startsWith("Price"))} sample="$1,299" />
        </div>
      </DocSection>

      <DocSection title="Weights">
        <div className="overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          {WEIGHT_USAGE.map((w, i) => (
            <div
              key={w.weight}
              className={`grid grid-cols-[110px_1fr_1fr] items-center gap-6 px-5 py-4 ${i > 0 ? "border-t border-neutral-200" : ""}`}
            >
              <span className="font-mono text-xs text-ink-muted">
                {w.weight} · {WEIGHT_VALUE[w.weight]}
              </span>
              <p className="font-sans text-lg text-ink" style={{ fontWeight: WEIGHT_VALUE[w.weight] }}>
                Trend-forward furniture
              </p>
              <p className="text-xs text-ink-muted">{w.usage}</p>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Letter-spacing">
        <div className="rounded-app-lg border border-neutral-200 bg-cream-100 p-5">
          <p className="text-sm text-ink">
            <span className="font-semibold">All text uses 0 letter-spacing, except button text and all-caps
            text, which use +4.5%.</span>{" "}
            Headings, body copy, navigation, product names and prices are never tracked out. In code, apply it
            with the <code className="font-mono text-xs">tracking-wide-ui</code> utility.
          </p>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
            <p className="mb-2 text-xs font-semibold text-ink-muted">+4.5%</p>
            <p
              className="font-sans text-sm font-bold uppercase text-ink"
              style={{ letterSpacing: TRACKING_CAPS }}
            >
              Shop now
            </p>
            <p className="mt-2 text-xs text-ink-muted">Button text and all-caps labels.</p>
          </div>
          <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
            <p className="mb-2 text-xs font-semibold text-ink-muted">0</p>
            <p className="font-sans text-sm text-ink">Accent chairs and statement seating</p>
            <p className="mt-2 text-xs text-ink-muted">Everything else.</p>
          </div>
        </div>
      </DocSection>

      <ChangeLogTable page="typography" />
    </DocPage>
  );
}
