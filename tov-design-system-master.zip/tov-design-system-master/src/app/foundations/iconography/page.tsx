import { DocPage } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { IconLibrary } from "@/components/docs/IconLibrary";

const ECOMMERCE = [
  "arrive", "box", "admin", "bag", "buy", "cart", "certified", "deliver", "delivery",
  "discount", "flash-sale", "laptop", "member-discount", "menu", "mobile", "return",
  "sale", "scan", "shopping-bag", "tag", "totebag", "wallet", "web",
];

// "Info icons" — the OG file's own name for this whole set (a single flat
// group, not sub-categorized in Figma). Real PDP/support icons.
const INFO_ICONS = [
  "tools", "hammer", "adjustable-height", "light", "no-light", "adjustable-light",
  "headboard", "headboard-and-footboard", "shelves", "wall-mount",
  "mattress", "no-mattress", "no-slip-rug", "removable-cushion", "zipper",
  "indoor-outdoor", "wood", "weight", "sustainable", "easy-clean", "wall",
  "gift-ribbons", "gift-no-ribbons", "bag-outline", "edit", "warranty", "chat",
  "customer-service", "happy-chat", "sos", "clipboard", "phone", "percentage",
  "location-change", "care", "change", "service-return", "install-1", "install-2", "install-3",
  "in-room-1", "in-room-2", "in-room-3",
];

// "General" and "Arrows" — the same two categories removed earlier for being
// pulled from an unrelated section (Weather/Finance/Health/Emojis mixed in).
// Re-added from the correct source: Figma's own "General"/"Arrows" categories
// inside the same reference kit, extracted with the cleaned-up technique
// (export as SVG, background rect stripped) and rendered before committing.
const GENERAL_UI = [
  "home", "setting", "bell", "bell-slash", "zoom-in", "zoom-out", "pencil-edit", "filter", "pin",
  "add", "minus", "tick", "checkbox", "checkbox-checked", "minus-square", "add-square", "cross-square",
  "add-circle", "cross-circle", "minus-circle", "tick-circle", "radio-button", "radio-button-selected",
  "arrow-up-circle", "arrow-left-circle", "arrow-down-circle", "arrow-right-circle",
  "slash-circle", "slash-hexagon", "info-circle", "alert-triangle", "question-mark-circle", "verified",
  "sliders-v", "sliders-h", "suitcase", "bin", "bin-empty", "send", "share", "flag", "archive",
  "gift", "bag-alt-light", "profile", "heart", "search",
];

const ARROWS = [
  "arrow-up", "arrow-down", "arrow-left", "arrow-right", "arrows-vertical", "arrows-horizontal",
  "move", "expand", "shrink", "corner-up-right", "corner-down-left", "corner-down-right",
  "corner-left-down", "chevron-down", "corner-left-up", "chevron-left", "corner-right-down",
  "corner-right-up", "chevron-right", "chevron-up", "corner-up-left",
  "caret-down-circle", "caret-left-circle", "caret-right-circle", "caret-up-circle",
  "caret-left-square", "caret-down-square", "caret-right-square", "caret-up-square",
];

export default function IconographyPage() {
  return (
    <DocPage
      title="Iconography"
      description="TOV's icon library — 142 icons across Ecommerce, Info, General UI, and Arrows. Every icon shares the same stroke weight and visual family, so any combination reads as one consistent system across the site. Select one or more icons to download them as SVG files."
    >
      <IconLibrary
        sections={[
          { title: "Ecommerce", files: ECOMMERCE },
          { title: "Info icons", updated: true, files: INFO_ICONS },
          { title: "General UI", updated: true, files: GENERAL_UI },
          { title: "Arrows", updated: true, files: ARROWS },
        ]}
      />

      <ChangeLogTable page="iconography" />
    </DocPage>
  );
}
