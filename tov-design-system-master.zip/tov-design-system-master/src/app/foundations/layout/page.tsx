import Link from "next/link";
import { DocPage, DocSection } from "@/components/docs/DocPage";
import { ChangeLogTable } from "@/components/docs/ChangeLogTable";
import { columnGrids, layoutModes } from "@/lib/tokens";
import { SPACE_STEPS, PAGE_MARGIN, type SpaceStep } from "@/lib/spacingScale";

const MARGIN_STRIPE = {
  backgroundImage:
    "repeating-linear-gradient(-45deg, var(--color-primary) 0, var(--color-primary) 1px, transparent 1px, transparent 6px)",
  backgroundColor: "var(--color-cream-200)",
};

const step = (name: string): SpaceStep => {
  const s = SPACE_STEPS.find((x) => x.name === name);
  if (!s) throw new Error(`Unknown spacing step: ${name}`);
  return s;
};

type ScreenKey = "desktop" | "tablet" | "mobile";

function Values({ s }: { s: Pick<SpaceStep, "desktop" | "tablet" | "mobile"> }) {
  return (
    <span className="font-mono text-xs text-ink">
      {s.desktop} / {s.tablet} / {s.mobile}
    </span>
  );
}

function ClassBadge({ children }: { children: string }) {
  return <code className="rounded-app-sm bg-cream-100 px-1.5 py-0.5 font-mono text-[11px] text-primary-dark">{children}</code>;
}

function ColumnGridRow({ g, maxRefWidth }: { g: (typeof columnGrids)[number]; maxRefWidth: number }) {
  const barPct = (g.width / maxRefWidth) * 100;
  const marginPct = (g.margin / maxRefWidth) * 100;
  const gutterPct = (g.gutter / maxRefWidth) * 100;
  return (
    <div>
      <div className="flex items-baseline gap-2 mb-1.5">
        <span className="text-sm font-semibold text-ink">{g.breakpoint}</span>
        <span className="text-xs font-mono text-ink-muted">{g.width}px</span>
      </div>
      <div className="flex h-12" style={{ width: `${barPct}%` }}>
        <div className="h-full shrink-0" style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }} />
        <div className="h-full flex-1 min-w-0 flex" style={{ gap: `${gutterPct}%` }}>
          {Array.from({ length: g.columns }).map((_, i) => (
            <div key={i} className="h-full flex-1 bg-cream-200 border border-neutral-300 rounded-sm" />
          ))}
        </div>
        <div className="h-full shrink-0" style={{ width: `${marginPct}%`, ...MARGIN_STRIPE }} />
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-2 text-xs text-ink-muted">
        <span><span className="font-semibold text-ink">{g.columns}</span> columns</span>
        <span><span className="font-semibold text-ink">{g.gutter}px</span> gutter</span>
        <span><span className="font-semibold text-ink">{g.margin}px</span> margin</span>
        <span><span className="font-semibold text-ink">{g.contentArea}</span> content area</span>
      </div>
    </div>
  );
}

function ColumnGrid() {
  const maxRefWidth = Math.max(...columnGrids.map((g) => g.width));
  return (
    <div className="flex flex-col gap-6 rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
      {columnGrids.map((g) => (
        <ColumnGridRow key={g.breakpoint} g={g} maxRefWidth={maxRefWidth} />
      ))}
      <p className="text-xs text-ink-muted -mt-2">
        Bars are scaled to fit the page, not 1:1 pixels. Column count, gutter and margin are the three values
        that change by screen; every other space on the page comes from the spacing classes.
      </p>
    </div>
  );
}

const CODE = "rounded-app-md bg-ink px-4 py-3 font-mono text-xs leading-5 text-cream-50 overflow-x-auto";

function LiveGrid() {
  return (
    <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
      <p className="mb-3 text-xs text-ink-muted">
        Live. Resize the window: the grid is 4 columns under 768px, 8 columns from 768px and 12 columns from
        1024px, and the gutter follows <code className="font-mono">gap-space-sm</code>.
      </p>
      <div className="grid grid-cols-4 gap-space-sm md:grid-cols-8 lg:grid-cols-12">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="flex h-12 items-center justify-center rounded-sm border border-neutral-300 bg-cream-200 font-mono text-[11px] text-ink-muted"
          >
            {i + 1}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProductGridExample() {
  return (
    <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
      <p className="mb-3 text-xs text-ink-muted">
        A product grid on that structure: 2 cards per row on Mobile, 4 on Tablet, 4 on Desktop. Each card spans
        2 columns on Mobile and Tablet and 3 on Desktop.
      </p>
      <div className="grid grid-cols-4 gap-space-sm md:grid-cols-8 lg:grid-cols-12">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="col-span-2 flex flex-col gap-space-2xs lg:col-span-3">
            <div className="aspect-[4/5] rounded-sm border border-neutral-300 bg-cream-200" />
            <div className="h-2 w-3/4 rounded-sm bg-cream-200" />
            <div className="h-2 w-1/3 rounded-sm bg-cream-200" />
          </div>
        ))}
      </div>
      <pre className={`${CODE} mt-4`}>{`<section className="px-space-page">
  <div className="grid grid-cols-4 gap-space-sm md:grid-cols-8 lg:grid-cols-12">
    <article className="col-span-2 flex flex-col gap-space-2xs lg:col-span-3">…</article>
  </div>
</section>`}</pre>
    </div>
  );
}

function SectionRhythmExample() {
  const tiers = [
    { label: "Tight", s: step("2xl"), note: "Closely related modules, such as the blocks inside one product details area." },
    { label: "Standard", s: step("3xl"), note: "The default rhythm between stacked sections on a page." },
    { label: "Loose", s: step("5xl"), note: "A hero-to-content transition, or a break between unrelated sections." },
  ];
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
      {tiers.map((t) => (
        <div key={t.label}>
          <p className="mb-2 text-xs text-ink-muted">{t.note}</p>
          <div className="flex flex-col" style={{ gap: `var(--space-${t.s.name})` }}>
            <div className="h-10 rounded-sm border border-neutral-300 bg-cream-200" />
            <div className="h-10 rounded-sm border border-neutral-300 bg-cream-200" />
          </div>
          <p className="mt-3 text-sm font-semibold text-ink">{t.label}</p>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <ClassBadge>{`gap-space-${t.s.name}`}</ClassBadge>
            <Values s={t.s} />
          </div>
        </div>
      ))}
    </div>
  );
}

function SectionMarginExample() {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex h-10 w-full">
        <div className="h-full shrink-0" style={{ width: 28, ...MARGIN_STRIPE }} />
        <div className="h-full flex-1 bg-cream-50 border-y border-neutral-300 flex items-center justify-center">
          <span className="text-[10px] font-mono text-ink-muted">content</span>
        </div>
        <div className="h-full shrink-0" style={{ width: 28, ...MARGIN_STRIPE }} />
      </div>
      <p className="text-[11px] text-ink-muted text-center">
        28px shown here ≈ 100px at real desktop scale — 32px on Tablet and 20px on Mobile
      </p>
    </div>
  );
}

function GridMarginExample() {
  const cardWidth = 62;
  const gap = 8;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex h-10 w-full overflow-hidden">
        <div className="h-full shrink-0" style={{ width: 20, ...MARGIN_STRIPE }} />
        <div className="h-full flex shrink-0" style={{ gap }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-full shrink-0 bg-cream-50 border border-neutral-300 rounded-sm"
              style={{ width: cardWidth }}
            />
          ))}
        </div>
      </div>
      <p className="text-[11px] text-ink-muted text-center">
        Fixed 20px inset at every breakpoint — the row overflows the frame on
        purpose, so the next card peeks and hints that it scrolls
      </p>
    </div>
  );
}

const GUTTERS = [
  { label: "Dense", s: step("2xs"), note: "Dense card grids and tight rows." },
  { label: "Standard", s: step("xs"), note: "Most card and tile rows, such as In Stock." },
  { label: "Column gutter", s: step("sm"), note: "The page grid's own gutter, and wide or featured rows." },
];

export default function LayoutPage() {
  return (
    <DocPage
      title="Layout"
      description="How the page grid, margins and rhythm are built from the spacing classes. Every gap and inset on this page is a class from Spacing & Radius, with a Desktop, Tablet and Mobile value."
    >
      <DocSection title="Composition rule">
        <div className="rounded-app-lg border border-neutral-200 bg-cream-100 p-4">
          <p className="text-xs text-ink-muted">
            <span className="font-semibold text-ink">A component owns its
            internal padding, never its outer margin. </span>
            The parent — a stack, a grid, or a section — owns the space
            between things, using the classes on this page and on{" "}
            <Link href="/foundations/spacing" className="text-primary-dark hover:underline font-medium">
              Spacing &amp; Radius
            </Link>
            . If a component needs a margin-top or margin-left to sit
            correctly next to its sibling, that spacing belongs on the parent
            instead — otherwise it doubles up or collapses the next time that
            component is reused in a new context.
          </p>
        </div>
      </DocSection>

      <DocSection title="Column grid">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          The structure every page section is composed against: 12 columns on Desktop, 8 on Tablet and 4 on
          Mobile. The gutter and the outer margin are spacing classes, so the grid and the rest of the page share
          one set of values.
        </p>
        <div className="mb-4 overflow-x-auto rounded-app-lg border border-neutral-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">Screen</th>
                <th className="px-4 py-2 font-semibold">Columns</th>
                <th className="px-4 py-2 font-semibold">Gutter</th>
                <th className="px-4 py-2 font-semibold">Margin</th>
              </tr>
            </thead>
            <tbody>
              {columnGrids.map((g) => {
                const key = g.breakpoint.toLowerCase() as ScreenKey;
                return (
                  <tr key={g.breakpoint} className="border-t border-neutral-200 align-top">
                    <td className="px-4 py-3 font-semibold whitespace-nowrap">{g.breakpoint}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-xs">{g.columns}</span>{" "}
                      <code className="font-mono text-[11px] text-primary-dark">
                        {key === "desktop" ? "lg:grid-cols-12" : key === "tablet" ? "md:grid-cols-8" : "grid-cols-4"}
                      </code>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-xs">{step("sm")[key]}px</span>{" "}
                      <code className="font-mono text-[11px] text-primary-dark">gap-space-sm</code>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-xs">{PAGE_MARGIN[key]}px</span>{" "}
                      <code className="font-mono text-[11px] text-primary-dark">px-space-page</code>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mb-4">
          <ColumnGrid />
        </div>
        <div className="mb-4">
          <LiveGrid />
        </div>
        <ProductGridExample />
      </DocSection>

      <DocSection title="Two layout modes">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          Full-bleed sections and horizontally-scrollable rows use genuinely
          different outer margins. Both are intentional, and neither is a bug to reconcile into one number.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {layoutModes.map((mode) => (
            <div
              key={mode.name}
              className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-ink">{mode.name}</h3>
                <code className="text-[11px] font-mono text-primary-dark bg-cream-100 rounded-app-sm px-1.5 py-0.5">
                  {mode.css}
                </code>
              </div>
              <div className="mb-4">
                {mode.name === "Section margin" ? <SectionMarginExample /> : <GridMarginExample />}
              </div>
              <p className="text-xs text-ink-muted mb-1">
                <span className="font-semibold text-ink">Margin: </span>
                {mode.margin}
              </p>
              <p className="text-xs text-ink-muted mb-1">
                <span className="font-semibold text-ink">Used for: </span>
                {mode.usedFor}
              </p>
              <p className="text-xs text-ink-muted">
                <span className="font-semibold text-ink">Examples: </span>
                {mode.example}
              </p>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Section rhythm">
        <p className="text-xs text-ink-muted mb-4 max-w-2xl">
          The vertical gap between major stacked sections (Hero, Categories, New Arrivals, Promo Banner and so
          on) uses the large spacing classes. Pick the tier by how related the two sections are. Values are
          Desktop / Tablet / Mobile.
        </p>
        <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5 mb-3">
          <SectionRhythmExample />
        </div>
        <div className="rounded-app-lg border border-neutral-200 bg-cream-100 p-4">
          <p className="text-xs text-ink-muted">
            <span className="font-semibold text-ink">Rule: </span>
            every page is a single vertical stack. Apply one gap class once, on that stack, such as{" "}
            <code className="text-[11px] font-mono text-primary-dark">flex flex-col gap-space-3xl</code>, and never a
            one-off margin on an individual section.
          </p>
        </div>
      </DocSection>

      <DocSection title="Grid gutters">
        <p className="text-xs text-ink-muted mb-3 max-w-2xl">
          The gap between cards inside a row. The column grid always uses{" "}
          <code className="font-mono">gap-space-sm</code>; rows of cards can use a smaller or larger class by
          density. Values are Desktop / Tablet / Mobile.
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {GUTTERS.map((g) => (
            <div key={g.label} className="rounded-app-lg border border-neutral-200 bg-white p-4 shadow-sm">
              <div className="flex" style={{ gap: `var(--space-${g.s.name})` }}>
                <div className="h-10 flex-1 rounded-sm bg-cream-200" />
                <div className="h-10 flex-1 rounded-sm bg-cream-200" />
                <div className="h-10 flex-1 rounded-sm bg-cream-200" />
              </div>
              <p className="mt-3 text-sm font-semibold text-ink">{g.label}</p>
              <p className="text-xs text-ink-muted">{g.note}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <ClassBadge>{`gap-space-${g.s.name}`}</ClassBadge>
                <Values s={g.s} />
              </div>
            </div>
          ))}
        </div>
      </DocSection>

      <DocSection title="Choosing a mode">
        <div className="overflow-x-auto rounded-app-lg border border-neutral-200 shadow-sm bg-white">
          <table className="w-full text-sm">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="px-4 py-2 font-semibold">If the section is&hellip;</th>
                <th className="px-4 py-2 font-semibold">Use</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-neutral-200">
                <td className="px-4 py-2.5 text-ink-muted">A single full-bleed hero, banner, or promo block</td>
                <td className="px-4 py-2.5 font-mono text-xs text-primary-dark whitespace-nowrap">px-space-page</td>
              </tr>
              <tr className="border-t border-neutral-200">
                <td className="px-4 py-2.5 text-ink-muted">A horizontally-scrollable row of cards (products, categories)</td>
                <td className="px-4 py-2.5 font-mono text-xs text-primary-dark whitespace-nowrap">px-grid-margin</td>
              </tr>
              <tr className="border-t border-neutral-200">
                <td className="px-4 py-2.5 text-ink-muted">A fixed, non-scrolling grid that should never bleed (e.g. a 2x2 image grid)</td>
                <td className="px-4 py-2.5 font-mono text-xs text-primary-dark whitespace-nowrap">px-space-page</td>
              </tr>
            </tbody>
          </table>
        </div>
      </DocSection>

      <ChangeLogTable page="layout" />
    </DocPage>
  );
}
