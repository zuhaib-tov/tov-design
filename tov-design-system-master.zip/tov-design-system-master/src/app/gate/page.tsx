import { Logo } from "@/components/ui/Logo";

export const metadata = { title: "TOV Design System — Sign in" };

export default async function GatePage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const { next = "", error } = await searchParams;

  return (
    <div className="flex min-h-screen items-center justify-center bg-cream-100 px-6">
      <form
        method="post"
        action="/api/gate"
        className="w-full max-w-sm rounded-app-lg border border-neutral-200 bg-white p-8 shadow-sm"
      >
        <Logo className="mb-6 h-5 text-charcoal" />
        <h1 className="font-display text-3xl text-primary-dark">TOV Design System</h1>
        <p className="mt-2 text-sm text-ink-muted">Enter the password to view the design system.</p>

        <input type="hidden" name="next" value={next} />
        <label htmlFor="password" className="mt-6 block text-[11px] font-semibold uppercase tracking-wide-ui text-ink-muted">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoFocus
          autoComplete="current-password"
          className="mt-1.5 w-full rounded-md border border-neutral-300 px-4 py-2.5 text-sm text-ink outline-none focus:border-primary"
        />
        {error && (
          <p role="alert" className="mt-2 text-sm text-sale">
            That password isn&apos;t right. Try again.
          </p>
        )}
        <button
          type="submit"
          className="mt-6 w-full rounded-pill bg-charcoal px-6 py-3 text-xs font-bold uppercase tracking-wide-ui text-white hover:bg-primary"
        >
          View design system
        </button>
      </form>
    </div>
  );
}
