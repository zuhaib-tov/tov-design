/**
 * Minimal Figma REST API client for the "Sync from Figma" action.
 *
 * Requires a Figma personal access token in FIGMA_TOKEN (server env, see
 * .env.local.example). Generate one at figma.com -> account settings ->
 * Personal access tokens. This calls Figma's public REST API directly and
 * is independent of any MCP/Claude tooling — it runs from the deployed app
 * itself, for anyone on the team who opens this page.
 */

const FIGMA_API = "https://api.figma.com/v1";

export function figmaFileKeyFromUrl(input: string): string {
  const match = input.match(/figma\.com\/(?:file|design)\/([a-zA-Z0-9]+)/);
  return match ? match[1] : input.trim();
}

/** Extracts a `node-id=1234-5678` param from a Figma URL and returns it as `1234:5678`. */
export function figmaNodeIdFromUrl(input: string): string | null {
  const match = input.match(/node-id=([0-9]+-[0-9]+)/);
  return match ? match[1].replace("-", ":") : null;
}

async function figmaFetch(pathname: string) {
  const token = process.env.FIGMA_TOKEN;
  if (!token) {
    throw new Error(
      "FIGMA_TOKEN is not set. Add it to .env.local (see .env.local.example) to enable Figma sync."
    );
  }
  const res = await fetch(`${FIGMA_API}${pathname}`, {
    headers: { "X-Figma-Token": token },
  });
  if (!res.ok) {
    throw new Error(`Figma API error (${res.status}): ${await res.text()}`);
  }
  return res.json();
}

export interface FigmaImageNode {
  nodeId: string;
  name: string;
  imageUrl: string;
}

/** Lists top-level image-able nodes (frames/components) in a file's first page. */
export async function listFigmaImageNodes(fileKey: string): Promise<{
  fileName: string;
  nodes: { id: string; name: string }[];
}> {
  const data = await figmaFetch(`/files/${fileKey}?depth=2`);
  const page = data.document?.children?.[0];
  const nodes = (page?.children ?? [])
    .filter((n: { type: string }) => ["FRAME", "COMPONENT", "COMPONENT_SET", "GROUP"].includes(n.type))
    .map((n: { id: string; name: string }) => ({ id: n.id, name: n.name }));
  return { fileName: data.name, nodes };
}

/** Lists the file's top-level pages (canvases). */
export async function listFigmaPages(fileKey: string): Promise<{
  fileName: string;
  pages: { id: string; name: string }[];
}> {
  const data = await figmaFetch(`/files/${fileKey}?depth=1`);
  const pages = ((data.document?.children ?? []) as { id: string; name: string }[]).map((p) => ({
    id: p.id,
    name: p.name,
  }));
  return { fileName: data.name, pages };
}

/** Lists the immediate children (pages, or frames within a page/section) of a specific node. */
export async function listFigmaNodeChildren(
  fileKey: string,
  nodeId: string
): Promise<{ fileName: string; nodes: { id: string; name: string; type: string }[] }> {
  const data = await figmaFetch(`/files/${fileKey}/nodes?ids=${nodeId}&depth=1`);
  const nodeData = data.nodes?.[nodeId];
  const children = (nodeData?.document?.children ?? []) as { id: string; name: string; type: string }[];
  return {
    fileName: data.name,
    nodes: children.map((n) => ({ id: n.id, name: n.name, type: n.type })),
  };
}

export interface FigmaImageFillUsage {
  nodeId: string;
  nodeName: string;
}

export interface FigmaImageFill {
  imageRef: string;
  url: string;
  usages: FigmaImageFillUsage[];
}

interface FigmaFillLike {
  type?: string;
  visible?: boolean;
  imageRef?: string;
}

interface FigmaTreeNode {
  id: string;
  name: string;
  fills?: FigmaFillLike[];
  children?: FigmaTreeNode[];
}

/**
 * Finds the real underlying image assets used as fills anywhere under a
 * node — not a rendered/flattened screenshot of the node (which is what
 * listFigmaImageNodes + renderFigmaImages produce, and would bake in any
 * overlaid text/shapes). Each distinct image is returned once with every
 * node that uses it, since the same photo is often reused across several
 * layers (e.g. a banner's background instance and a duplicate elsewhere).
 */
export async function listFigmaImageFills(
  fileKey: string,
  nodeId: string
): Promise<{ fileName: string; images: FigmaImageFill[] }> {
  const data = await figmaFetch(`/files/${fileKey}/nodes?ids=${nodeId}`);
  const nodeData = data.nodes?.[nodeId];
  const root = nodeData?.document as FigmaTreeNode | undefined;
  if (!root) {
    throw new Error("Node not found in file — check the URL includes a valid node-id.");
  }

  const usagesByRef = new Map<string, FigmaImageFillUsage[]>();
  function walk(node: FigmaTreeNode) {
    for (const fill of node.fills ?? []) {
      if (fill.type === "IMAGE" && fill.visible !== false && fill.imageRef) {
        const usages = usagesByRef.get(fill.imageRef) ?? [];
        usages.push({ nodeId: node.id, nodeName: node.name });
        usagesByRef.set(fill.imageRef, usages);
      }
    }
    for (const child of node.children ?? []) walk(child);
  }
  walk(root);

  if (usagesByRef.size === 0) {
    return { fileName: data.name, images: [] };
  }

  const urlByRef = await getFigmaImageFillUrls(fileKey);
  const images: FigmaImageFill[] = [];
  for (const [imageRef, usages] of usagesByRef) {
    const url = urlByRef[imageRef];
    if (url) images.push({ imageRef, url, usages });
  }
  return { fileName: data.name, images };
}

/** Raw imageRef -> download URL map for every image fill in the file (the original uploaded bytes, not a render). */
export async function getFigmaImageFillUrls(fileKey: string): Promise<Record<string, string>> {
  const data = await figmaFetch(`/files/${fileKey}/images`);
  // Unlike most other endpoints used here, this one wraps its payload under `meta`
  // (`{ error, status, meta: { images: {...} }, i18n }`) rather than at the top level.
  return (data.meta?.images ?? {}) as Record<string, string>;
}

const EXT_BY_CONTENT_TYPE: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/gif": "gif",
  "image/webp": "webp",
};

export function extensionForContentType(contentType: string | null): string {
  if (!contentType) return "png";
  const base = contentType.split(";")[0].trim().toLowerCase();
  return EXT_BY_CONTENT_TYPE[base] ?? "png";
}

export function sanitizeFilename(name: string): string {
  return name.trim().replace(/[^a-z0-9\-_. ]/gi, "").replace(/\s+/g, "-").slice(0, 80) || "image";
}

/**
 * Renders a single node as a PNG at an exact pixel scale via Figma's own
 * image-render endpoint. Unlike `getFigmaImageFillUrls` (which returns the
 * ORIGINAL uploaded image bytes for a fill — often a larger photo that gets
 * cropped/scaled to fit its frame via `scaleMode: FILL/FIT/CROP/TILE`), this
 * endpoint composites whatever fill treatment the node actually uses and
 * returns a PNG sized to the node's own layout box times `scale`. A
 * scale-1 render is therefore pixel-exact to the frame's real dimensions
 * regardless of the underlying photo asset's native size or crop — use this
 * whenever the exact rendered size must be guaranteed, not the fill-export
 * path above.
 */
export async function renderFigmaFrame(
  fileKey: string,
  nodeId: string,
  scale: 1 | 2 | 3 | 4 = 1
): Promise<string | null> {
  const data = await figmaFetch(`/images/${fileKey}?ids=${nodeId}&format=png&scale=${scale}`);
  return (data.images?.[nodeId] as string | null | undefined) ?? null;
}

/**
 * Reads width/height straight out of a PNG's IHDR chunk (bytes 16-23, big
 * endian) — no image-processing dependency needed just to verify a file a
 * route is about to serve as "exact size" really is that size. Returns null
 * if the buffer isn't a PNG (or is too short to contain an IHDR chunk).
 */
export function getPngDimensions(buffer: Buffer): { width: number; height: number } | null {
  if (buffer.length < 24) return null;
  const isPng =
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a;
  if (!isPng) return null;
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

export async function renderFigmaImages(
  fileKey: string,
  nodeIds: string[]
): Promise<FigmaImageNode[]> {
  const idsParam = nodeIds.join(",");
  const data = await figmaFetch(`/images/${fileKey}?ids=${idsParam}&format=png&scale=2`);
  const nodeNames = await listFigmaImageNodes(fileKey);
  const nameById = new Map(nodeNames.nodes.map((n) => [n.id, n.name]));

  return Object.entries(data.images as Record<string, string | null>)
    .filter(([, url]) => !!url)
    .map(([nodeId, url]) => ({
      nodeId,
      name: nameById.get(nodeId) ?? nodeId,
      imageUrl: url as string,
    }));
}
