/**
 * Brand artwork served from /public/brand that the Brand page offers for
 * download, besides the four generated logo colorways in logoGuidelines.ts.
 * Width and height are the SVG's own size; PNG exports are drawn at
 * BRAND_PNG_SCALE times that so they stay sharp.
 */

export interface BrandAsset {
  key: "mark" | "tagline-bold" | "tagline-script";
  name: string;
  src: string;
  width: number;
  height: number;
  file: string;
  usage: string;
}

export const BRAND_PNG_SCALE = 4;

export const BRAND_ASSETS: BrandAsset[] = [
  {
    key: "mark",
    name: "Logo mark",
    src: "/brand/logo-mark.svg",
    width: 150,
    height: 150,
    file: "tov-logo-mark",
    usage: "The circular mark for app icons, favicons and social avatars.",
  },
  {
    key: "tagline-bold",
    name: "Tagline, bold",
    src: "/brand/tagline-bold.svg",
    width: 200,
    height: 130,
    file: "tov-tagline-bold",
    usage: "Don't Be Boring. The default lockup for UI use.",
  },
  {
    key: "tagline-script",
    name: "Tagline, script",
    src: "/brand/tagline-script.svg",
    width: 226,
    height: 226,
    file: "tov-tagline-script",
    usage: "Don't Be Boring. For marketing and lifestyle use.",
  },
];

export function brandAsset(key: BrandAsset["key"]): BrandAsset {
  const a = BRAND_ASSETS.find((x) => x.key === key);
  if (!a) throw new Error(`Unknown brand asset ${key}`);
  return a;
}
