import { promises as fs } from "fs";
import path from "path";
import { put, list } from "@vercel/blob";
import type { WatchItem } from "./watch/types";
import { PDP_EDITORIAL_WATCH } from "./watch/pdp-editorial";
import { AMAZON_WATCH } from "./watch/amazon";
import { B2B_WATCH } from "./watch/b2b";
import { OG_ADDITIONS_WATCH } from "./watch/og-additions";
import { FORMS_WATCH } from "./watch/forms";

/**
 * Automatic drift detection for the curated set of Figma nodes we've
 * deliberately pulled into this codebase (not "watch everything" — see
 * FIGMA_SYSTEMS.md).
 *
 * How it's triggered: a Figma webhook (FILE_UPDATE) hitting
 * /api/figma-webhook once this app is deployed publicly (Figma can't reach
 * localhost) — see .env.local.example for the FIGMA_WEBHOOK_PASSCODE it
 * needs. Until then, use POST /api/figma-watch/check to run the same check
 * on demand.
 *
 * What it does NOT do: touch any code/asset files. Per Shay's call, this
 * only detects and logs drift for a human to review — syncing the actual
 * change into code stays a deliberate, separate step (same as every other
 * transfer in FIGMA_SYSTEMS.md).
 */

export type { WatchItem } from "./watch/types";

export const WATCH_LIST: WatchItem[] = [
  {
    id: "logo-mark",
    label: "Logo mark (circular icon)",
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "8:41",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=8-41",
  },
  {
    id: "tagline-bold",
    label: 'Tagline — bold ("DON\'T BE BORING.")',
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "8:52",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=8-52",
  },
  {
    id: "tagline-script",
    label: 'Tagline — script ("Don\'t Be Boring")',
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "8:70",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=8-70",
  },
  {
    id: "logo-variant-default",
    label: "Logo component — Default variant",
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "2:176",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=2-176",
  },
  {
    id: "logo-variant-light",
    label: "Logo component — Light variant",
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "2:182",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=2-182",
  },
  {
    id: "logo-variant-dark",
    label: "Logo component — Dark variant",
    fileKey: "5aVhd2ZmqVDG61uN3Ruas5",
    nodeId: "2:184",
    figmaUrl: "https://www.figma.com/design/5aVhd2ZmqVDG61uN3Ruas5?node-id=2-184",
  },
  {
    // Lives in the OG file, not Core — per Shay (2026-09-16), the OG file's
    // "🖌️ TOV Styles" page (Color/Typography/Spacing/Radius/Effects/Grid
    // Export Sheets) is the direct source of truth for foundational tokens,
    // watched here same as everything else.
    id: "brand-color-palette",
    label: "Brand Palette — Color Export Sheet",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "22:32960",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=22-32960",
  },
  {
    id: "type-scale",
    label: "Type Scale — Typography Export Sheet",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "22:33269",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=22-33269",
  },
  {
    id: "button-frame",
    label: "Button — Primary/Secondary/Tertiary, all states",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "64:91",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1611-4711",
  },
  {
    id: "badge-tags",
    label: "Badge — 9 product tags (New Arrival, Best Seller, Sale, Hot List, Limited Edition, ...)",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "65:2102",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1611-4711",
  },
  {
    id: "homepage-global-promo-banner",
    label: "Homepage — Global Promo Banner",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1060:1915",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1060-1915",
  },
  {
    id: "homepage-logo-bar",
    label: "Homepage — Logo Bar",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1060:1704",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1060-1704",
  },
  {
    id: "homepage-categories",
    label: "Homepage — Categories (Living Room)",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:1669",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-1669",
  },
  {
    id: "homepage-new-arrivals",
    label: "Homepage — New Arrivals",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:2001",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-2001",
  },
  {
    id: "homepage-promo-banner",
    label: "Homepage — Promo Banner",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:2215",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-2215",
  },
  {
    id: "homepage-in-stock",
    label: "Homepage — In Stock",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:2295",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-2295",
  },
  {
    id: "homepage-collections",
    label: "Homepage — Collections",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:2467",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-2467",
  },
  {
    id: "homepage-about-us",
    label: "Homepage — About Us",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:2626",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-2626",
  },
  {
    id: "homepage-social",
    label: "Homepage — Social",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1063:5051",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1063-5051",
  },
  {
    id: "nav-main-nav",
    label: "Main Nav (Navbar) — all 11 variants, incl. the 6 category mega-menus",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1340:3009",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1340-3009",
  },
  {
    id: "nav-footer",
    label: "Footer",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "65:1143",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=65-1143",
  },
  {
    id: "nav-footer-icon-row",
    label: "Footer Icon Row",
    fileKey: "DTjIdCKhnDUVvJhEfpn10v",
    nodeId: "1688:3759",
    figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1688-3759",
  },
  { id: "account-nav", label: "Account — Nav", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:32", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-32" },
  { id: "account-points-banner", label: "Account — Points Banner", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:41", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-41" },
  { id: "account-welcome-card", label: "Account — Welcome Card", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:56", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-56" },
  { id: "account-order-card", label: "Account — Order Card", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:196", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-196" },
  { id: "account-contact-info", label: "Account — Contact Info", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:221", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-221" },
  { id: "account-addresses", label: "Account — Addresses", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:300", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-300" },
  { id: "account-marketing-preferences", label: "Account — Marketing Preferences", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:236", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-236" },
  { id: "account-sign-out", label: "Account — Sign Out", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:245", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-245" },
  { id: "account-button-small", label: "Account — Button - small", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:6", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-6" },
  { id: "account-toggle", label: "Account — Toggle", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:11", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-11" },
  { id: "account-page-orders-desktop", label: "Account — Orders page (Desktop)", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:961", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-961" },
  { id: "account-page-profile-desktop", label: "Account — Profile page (Desktop)", fileKey: "DTjIdCKhnDUVvJhEfpn10v", nodeId: "1778:1304", figmaUrl: "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v?node-id=1778-1304" },
  ...PDP_EDITORIAL_WATCH,
  ...AMAZON_WATCH,
  ...B2B_WATCH,
  ...OG_ADDITIONS_WATCH,
  ...FORMS_WATCH,
];

interface FigmaPaint {
  type: string;
  color?: { r: number; g: number; b: number; a?: number };
  gradientStops?: { position: number; color: { r: number; g: number; b: number; a?: number } }[];
}

interface FigmaTypeStyle {
  fontFamily?: string;
  fontPostScriptName?: string;
  fontWeight?: number;
  fontSize?: number;
  lineHeightPx?: number;
}

interface FigmaNodeDoc {
  id: string;
  name: string;
  type?: string;
  description?: string;
  cornerRadius?: number;
  fills?: FigmaPaint[];
  children?: FigmaNodeDoc[];
  componentPropertyDefinitions?: Record<string, unknown>;
  style?: FigmaTypeStyle;
}

export interface Fingerprint {
  name: string;
  description: string;
  cornerRadius: number | null;
  fills: { id: string; hex: string }[];
  variantProps: string[];
  textStyles: { id: string; name: string; font: string; size: number; lineHeight: number }[];
}

function toHex(c: { r: number; g: number; b: number }): string {
  const ch = (v: number) => Math.round(v * 255).toString(16).padStart(2, "0");
  return `#${ch(c.r)}${ch(c.g)}${ch(c.b)}`.toUpperCase();
}

function collectFills(doc: FigmaNodeDoc, acc: { id: string; hex: string }[]) {
  if (doc.fills) {
    for (const p of doc.fills) {
      if (p.type === "SOLID" && p.color) acc.push({ id: doc.id, hex: toHex(p.color) });
      // Gradients (e.g. the Limited Edition badge) — track each stop as its
      // own fingerprint entry so a stop color/position edit still trips
      // drift, not just a switch away from SOLID.
      if (p.type.startsWith("GRADIENT") && p.gradientStops) {
        p.gradientStops.forEach((stop, i) => {
          acc.push({ id: `${doc.id}:stop${i}@${stop.position.toFixed(3)}`, hex: toHex(stop.color) });
        });
      }
    }
  }
  for (const child of doc.children ?? []) collectFills(child, acc);
  return acc;
}

function collectTextStyles(
  doc: FigmaNodeDoc,
  acc: { id: string; name: string; font: string; size: number; lineHeight: number }[]
) {
  if (doc.type === "TEXT" && doc.style) {
    acc.push({
      id: doc.id,
      name: doc.name,
      font: doc.style.fontPostScriptName ?? doc.style.fontFamily ?? "",
      size: doc.style.fontSize ?? 0,
      lineHeight: doc.style.lineHeightPx ?? 0,
    });
  }
  for (const child of doc.children ?? []) collectTextStyles(child, acc);
  return acc;
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function figmaApi(pathname: string) {
  const token = process.env.FIGMA_TOKEN;
  if (!token) throw new Error("FIGMA_TOKEN is not set — see .env.local.example");

  // Figma rate-limits by token; on 429 wait as long as it asks (or back off) and retry.
  for (let attempt = 0; ; attempt++) {
    const res = await fetch(`https://api.figma.com/v1${pathname}`, {
      headers: { "X-Figma-Token": token },
    });
    if (res.status === 429 && attempt < 5) {
      const retryAfter = Number(res.headers.get("retry-after"));
      await sleep(Math.min(Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : 4000 * 2 ** attempt, 30000));
      continue;
    }
    if (!res.ok) throw new Error(`Figma API error (${res.status}): ${await res.text()}`);
    return res.json();
  }
}

function toFingerprint(doc: FigmaNodeDoc): Fingerprint {
  return {
    name: doc.name,
    description: doc.description ?? "",
    cornerRadius: doc.cornerRadius ?? null,
    fills: collectFills(doc, []),
    variantProps: doc.componentPropertyDefinitions
      ? Object.keys(doc.componentPropertyDefinitions)
      : [],
    textStyles: collectTextStyles(doc, []),
  };
}

export async function fetchFingerprint(fileKey: string, nodeId: string): Promise<Fingerprint> {
  const data = await figmaApi(`/files/${fileKey}/nodes?ids=${nodeId}`);
  const entry = data.nodes?.[nodeId];
  if (!entry?.document) throw new Error(`Node ${nodeId} not found in file ${fileKey}`);
  return toFingerprint(entry.document as FigmaNodeDoc);
}

/** Fetches several nodes of one file in a single request. */
async function fetchFingerprints(
  fileKey: string,
  nodeIds: string[],
): Promise<Map<string, Fingerprint | Error>> {
  const out = new Map<string, Fingerprint | Error>();
  try {
    const data = await figmaApi(`/files/${fileKey}/nodes?ids=${nodeIds.join(",")}`);
    for (const id of nodeIds) {
      const entry = data.nodes?.[id];
      out.set(
        id,
        entry?.document ? toFingerprint(entry.document as FigmaNodeDoc) : new Error(`Node ${id} not found in file ${fileKey}`),
      );
    }
  } catch (err) {
    for (const id of nodeIds) out.set(id, err as Error);
  }
  return out;
}

export interface DriftEntry {
  id: string; // watch item id + timestamp
  watchId: string;
  label: string;
  figmaUrl: string;
  detectedAt: string;
  before: Fingerprint | null;
  after: Fingerprint;
  summary: string;
  reviewed: boolean;
}

const STORE_DIR = path.join(process.cwd(), "storage", "figma-watch");
const SNAPSHOT_FILE = "snapshot.json";
const DRIFT_LOG_FILE = "drift-log.json";
const STATUS_FILE = "status.json";

export interface CheckStatus {
  lastCheckedAt: string;
  checked: number;
  failedCount: number;
  newDriftCount: number;
}
const BLOB_PREFIX = "figma-watch/";

/**
 * Snapshots and the drift log persist in Vercel Blob when BLOB_READ_WRITE_TOKEN
 * is set (required on the deployed site, whose filesystem does not persist
 * between requests) and fall back to local files otherwise.
 */
const useBlob = () => Boolean(process.env.BLOB_READ_WRITE_TOKEN);

async function readJson<T>(file: string, fallback: T): Promise<T> {
  if (useBlob()) {
    const { blobs } = await list({ prefix: BLOB_PREFIX + file, limit: 1 });
    const hit = blobs.find((b) => b.pathname === BLOB_PREFIX + file);
    if (!hit) return fallback;
    const res = await fetch(hit.url + "?t=" + Date.now(), { cache: "no-store" });
    return res.ok ? ((await res.json()) as T) : fallback;
  }
  try {
    return JSON.parse(await fs.readFile(path.join(STORE_DIR, file), "utf-8")) as T;
  } catch {
    return fallback;
  }
}

async function writeJson(file: string, data: unknown) {
  const body = JSON.stringify(data, null, 2);
  if (useBlob()) {
    await put(BLOB_PREFIX + file, body, {
      access: "public",
      addRandomSuffix: false,
      allowOverwrite: true,
      contentType: "application/json",
      cacheControlMaxAge: 60,
    });
    return;
  }
  await fs.mkdir(STORE_DIR, { recursive: true });
  await fs.writeFile(path.join(STORE_DIR, file), body, "utf-8");
}

async function readSnapshot(): Promise<Record<string, Fingerprint>> {
  return readJson<Record<string, Fingerprint>>(SNAPSHOT_FILE, {});
}

async function writeSnapshot(snap: Record<string, Fingerprint>) {
  await writeJson(SNAPSHOT_FILE, snap);
}

export async function readStatus(): Promise<CheckStatus | null> {
  return readJson<CheckStatus | null>(STATUS_FILE, null);
}

export async function readDriftLog(): Promise<DriftEntry[]> {
  return readJson<DriftEntry[]>(DRIFT_LOG_FILE, []);
}

async function appendDrift(entry: DriftEntry) {
  const log = await readDriftLog();
  log.unshift(entry);
  await writeJson(DRIFT_LOG_FILE, log);
}

export async function markReviewed(driftId: string): Promise<boolean> {
  const log = await readDriftLog();
  const entry = log.find((e) => e.id === driftId);
  if (!entry) return false;
  entry.reviewed = true;
  await writeJson(DRIFT_LOG_FILE, log);
  return true;
}

function summarize(before: Fingerprint | null, after: Fingerprint): string {
  if (!before) return "First time this node has been checked — baseline recorded.";
  const parts: string[] = [];
  if (before.name !== after.name) parts.push(`renamed "${before.name}" → "${after.name}"`);
  if (before.description !== after.description) parts.push("description changed");
  if (before.cornerRadius !== after.cornerRadius) {
    parts.push(`corner radius ${before.cornerRadius} → ${after.cornerRadius}`);
  }
  if (JSON.stringify(before.variantProps) !== JSON.stringify(after.variantProps)) {
    parts.push("variant properties changed");
  }
  const beforeFills = new Map(before.fills.map((f) => [f.id, f.hex]));
  const afterFills = new Map(after.fills.map((f) => [f.id, f.hex]));
  for (const [id, hex] of afterFills) {
    const prev = beforeFills.get(id);
    if (prev && prev !== hex) parts.push(`fill on node ${id}: ${prev} → ${hex}`);
  }
  if (afterFills.size !== beforeFills.size) parts.push("number of fill layers changed");

  const beforeText = new Map(before.textStyles.map((t) => [t.id, t]));
  const afterText = new Map(after.textStyles.map((t) => [t.id, t]));
  for (const [id, t] of afterText) {
    const prev = beforeText.get(id);
    if (!prev) continue;
    if (prev.font !== t.font || prev.size !== t.size || prev.lineHeight !== t.lineHeight) {
      parts.push(
        `text "${t.name}": ${prev.font} ${prev.size}px/${prev.lineHeight}px → ${t.font} ${t.size}px/${t.lineHeight}px`
      );
    }
  }
  if (afterText.size !== beforeText.size) parts.push("number of text nodes changed");

  return parts.length ? parts.join("; ") : "No trackable change.";
}

/** Runs the check for every watched item, or just those in `onlyFileKey` if given. */
export interface CheckResult {
  newDrift: DriftEntry[];
  checked: number;
  baselined: number;
  failed: { id: string; label: string; fileKey: string; nodeId: string; error: string }[];
}

export async function checkForDrift(onlyFileKey?: string): Promise<DriftEntry[]> {
  return (await checkForDriftDetailed(onlyFileKey)).newDrift;
}

/** Runs the check and also reports what was baselined and which nodes could not be fetched. */
export async function checkForDriftDetailed(onlyFileKey?: string): Promise<CheckResult> {
  const snapshot = await readSnapshot();
  const items = onlyFileKey ? WATCH_LIST.filter((w) => w.fileKey === onlyFileKey) : WATCH_LIST;
  const newDrift: DriftEntry[] = [];
  const failed: CheckResult["failed"] = [];
  let checked = 0;
  let baselined = 0;

  const byFile = new Map<string, WatchItem[]>();
  for (const item of items) byFile.set(item.fileKey, [...(byFile.get(item.fileKey) ?? []), item]);

  const CHUNK = 12;
  for (const [fileKey, fileItems] of byFile) {
    for (let i = 0; i < fileItems.length; i += CHUNK) {
      const chunk = fileItems.slice(i, i + CHUNK);
      const results = await fetchFingerprints(fileKey, chunk.map((c) => c.nodeId));

      for (const item of chunk) {
        const result = results.get(item.nodeId);
        // A node that cannot be fetched keeps its previous baseline; it is never overwritten.
        if (!result || result instanceof Error) {
          failed.push({ id: item.id, label: item.label, fileKey: item.fileKey, nodeId: item.nodeId, error: result?.message ?? "empty response" });
          continue;
        }
        checked++;
        const before = snapshot[item.id] ?? null;
        if (!before) baselined++;
        const summary = summarize(before, result);

        if (before && summary !== "No trackable change.") {
          const entry: DriftEntry = {
            id: `${item.id}-${Date.now()}`,
            watchId: item.id,
            label: item.label,
            figmaUrl: item.figmaUrl,
            detectedAt: new Date().toISOString(),
            before,
            after: result,
            summary,
            reviewed: false,
          };
          newDrift.push(entry);
          await appendDrift(entry);
        }
        snapshot[item.id] = result;
      }
    }
    // Save after each file so a long run keeps its progress.
    await writeSnapshot(snapshot);
  }

  await writeJson(STATUS_FILE, {
    lastCheckedAt: new Date().toISOString(),
    checked,
    failedCount: failed.length,
    newDriftCount: newDrift.length,
  } satisfies CheckStatus);

  return { newDrift, checked, baselined, failed };
}
