/**
 * Single source of truth for token values used outside CSS (swatches, docs
 * tables, JS-driven previews). Keep in sync with src/app/globals.css.
 */

export const colorTokens = [
  { name: "ink", value: "#121212", css: "text-ink", usage: "Primary body text" },
  { name: "ink-muted", value: "rgba(18,18,18,0.75)", css: "text-ink-muted", usage: "Secondary text, nav links" },
  { name: "black", value: "#000000", css: "bg-black", usage: "Primary CTA buttons" },
  { name: "white", value: "#ffffff", css: "bg-white", usage: "Surfaces, CTA text" },
  { name: "primary", value: "#B15A63", css: "bg-primary", usage: "Brand mauve — links, accents, and active states across the UI" },
  { name: "primary-dark", value: "#311B1E", css: "bg-primary-dark", usage: "Deep plum — headings on light backgrounds, hover states" },
  { name: "brand-pink", value: "#F9D2D2", css: "bg-brand-pink", usage: "Logo mark accent only (the split \"O\") — not a general UI color" },
  { name: "truffle", value: "#82736C", css: "bg-truffle", usage: "Accent color — a warm neutral counterpoint for supporting UI moments outside the primary palette" },
  { name: "charcoal", value: "#3F3D3E", css: "bg-charcoal", usage: "Footer and dark section backgrounds" },
  { name: "burnt-umber", value: "#5B3630", css: "bg-burnt-umber", usage: "Final Sale badge" },
  { name: "mauve", value: "#BB7A7E", css: "bg-mauve", usage: "Sale badge — pink variant" },
  { name: "lagoon", value: "#7B8675", css: "bg-lagoon", usage: "Sale badge — green variant" },
  { name: "cream-50", value: "#FEFBF6", css: "bg-cream-50", usage: "Page background" },
  { name: "cream-100", value: "#FAF7F3", css: "bg-cream-100", usage: "Section background" },
  { name: "cream-200", value: "#F1ECE5", css: "bg-cream-200", usage: "Card / panel background" },
  { name: "neutral-100", value: "#F6F6F6", css: "bg-neutral-100", usage: "Subtle surface" },
  { name: "neutral-200", value: "#F0F0F0", css: "bg-neutral-200", usage: "Disabled surface" },
  { name: "neutral-300", value: "#E3E3E3", css: "border-neutral-300", usage: "Borders, dividers" },
  { name: "neutral-400", value: "#CCCCCC", css: "border-neutral-400", usage: "Stronger borders" },
  { name: "neutral-700", value: "#777777", css: "text-neutral-700", usage: "Material tags on product pages, such as \"Genuine Leather\"" },
  { name: "neutral-900", value: "#4A4A4A", css: "text-neutral-900", usage: "Heading and body text in the PDP \"Why We Love It\" module" },
  { name: "storm", value: "#3F4B59", css: "text-storm", usage: "Grade tags on product pages, such as \"Contract Grade\" or \"Performance Fabric\"" },
  { name: "sale", value: "#FF4500", css: "bg-sale", usage: "Sale badges, urgency" },
  { name: "success", value: "#1FC16B", css: "bg-success", usage: "In-stock indicators and confirmation states" },
] as const;

export const fontTokens = [
  {
    name: "Display",
    variable: "font-display",
    stack: "\"GT Ultra Fine\", serif",
    usage: "Headings and display type — Regular weight only",
  },
  {
    name: "Sans / UI",
    variable: "font-sans",
    stack: "Montserrat, sans-serif",
    usage: "Body copy, labels, navigation, buttons and forms",
  },
] as const;

export const radiusTokens = [
  { name: "none", value: "0px", css: "rounded-none", usage: "Cards, inputs, panels" },
  { name: "sm", value: "4px", css: "rounded-sm", usage: "Badges, tags" },
  { name: "md", value: "8px", css: "rounded-md", usage: "Modals, dropdowns" },
  { name: "pill", value: "999px", css: "rounded-pill", usage: "Primary/secondary buttons" },
] as const;

/**
 * Outer page gutter, per breakpoint — anchored at the site's two real values
 * (20px mobile, 100px desktop). `refWidth` is the concrete pixel width used
 * to scale the visual ruler on the Spacing page (375 stands in for the "< 640"
 * Mobile row, since that's the real Mobile canvas width used everywhere else
 * in this system); `width` stays a display string for the table.
 */
export const breakpointMargins = [
  { breakpoint: "Mobile", width: "< 640px", refWidth: 375, margin: 20, css: "px-page-margin-mobile" },
  { breakpoint: "sm", width: "640px", refWidth: 640, margin: 32, css: "px-page-margin-sm" },
  { breakpoint: "md", width: "768px", refWidth: 768, margin: 48, css: "px-page-margin-md" },
  { breakpoint: "lg", width: "1024px", refWidth: 1024, margin: 64, css: "px-page-margin-lg" },
  { breakpoint: "xl", width: "1280px", refWidth: 1280, margin: 80, css: "px-page-margin-xl" },
  { breakpoint: "2xl / Desktop", width: "1440px+", refWidth: 1440, margin: 100, css: "px-page-margin-desktop" },
] as const;

/**
 * The 12/8/4-column responsive grid from Figma's "Global Grid" Export Sheet
 * (fileKey DTjIdCKhnDUVvJhEfpn10v, node 55:341) — the formal structure page
 * sections are composed against, distinct from the page-margin scale above
 * (which only covers the outer gutter, not column count or gutter width).
 */
export const columnGrids = [
  {
    breakpoint: "Desktop",
    width: 1440,
    columns: 12,
    gutter: 24,
    margin: 100,
    contentArea: "1240px",
    note: "Breathing room on large screens while keeping content comfortably readable.",
  },
  {
    breakpoint: "Tablet",
    width: 768,
    columns: 8,
    gutter: 20,
    margin: 32,
    contentArea: "~704px",
    note: "Slightly tighter margins and gutters, but enough for clean multi-column layouts.",
  },
  {
    breakpoint: "Mobile",
    width: 375,
    columns: 4,
    gutter: 16,
    margin: 20,
    contentArea: "~335px",
    note: "Simple, compact grid with plenty of whitespace for readability.",
  },
] as const;

/**
 * The two real, coexisting layout modes found on the live site, confirmed
 * against real sections (not proposed in the abstract): full-bleed hero/promo
 * sections use the responsive page-margin scale above; product-row/carousel
 * sections use a flat, non-responsive inset instead, so the row can bleed
 * close to the edge and hint that it scrolls.
 */
export const layoutModes = [
  {
    name: "Section margin",
    css: "px-space-page",
    margin: "100px Desktop, 32px Tablet, 20px Mobile",
    usedFor: "Full-bleed hero and promo sections — confirmed live on Email Sign Up",
    example: "Hero banners, Email Sign Up, Global Promo Banner",
  },
  {
    name: "Grid margin",
    css: "px-grid-margin",
    margin: "20px, flat at every breakpoint",
    usedFor: "Product-row and carousel sections, so the next card peeks off-screen as a scroll affordance — confirmed live on Category Cards, New Arrivals, and In Stock",
    example: "Category Cards, New Arrivals, In Stock, other horizontally-scrollable rows",
  },
] as const;

/**
 * Named, role-based spacing tokens, grouped by relationship — the closer two
 * things are related, the less space sits between them: Inline (icon + its
 * own label) < Stack (a heading and the copy beneath it) < Layout (gap
 * between cards in a grid) < Section (gap between whole page sections).
 * `kind` selects which preview shape a token renders as on the Spacing page
 * ("inline" — icon + label pair, "stack" — vertical gap between two blocks,
 * "row" — horizontal gap between tiles, "padding" — space inside a bordered
 * box), and `category` groups the table by that relationship rather than by
 * component. `value` is a representative px number for the preview and value
 * column; `range` overrides it with the true fluid min–max when the token
 * scales with viewport instead of holding one fixed number.
 */
export const spacingTokens = [
  { name: "inline-gap-sm", value: 8, css: "gap-inline-gap-sm", usage: "Icon and its own label — a search icon and its input, a nav pill's icon and text", kind: "inline", category: "Inline" },
  { name: "stack-gap-sm", value: 8, css: "gap-stack-gap-sm", usage: "Tight stack spacing — a value and its caption", kind: "stack", category: "Stack" },
  { name: "stack-gap-md", value: 16, css: "gap-stack-gap-md", usage: "Standard stack spacing — a heading and the body copy beneath it", kind: "stack", category: "Stack" },
  { name: "stack-gap-lg", value: 24, css: "gap-stack-gap-lg", usage: "Loose stack spacing — a heading, body copy, and a CTA together", kind: "stack", category: "Stack" },
  { name: "grid-gutter-sm", value: 10, css: "gap-grid-gutter-sm", usage: "Tight grid gutter — dense card grids", kind: "row", category: "Layout" },
  { name: "grid-gutter-md", value: 16, css: "gap-grid-gutter-md", usage: "Standard grid gutter — most card and tile grids", kind: "row", category: "Layout" },
  { name: "grid-gutter-lg", value: 24, css: "gap-grid-gutter-lg", usage: "Wide grid gutter — spacious or featured layouts", kind: "row", category: "Layout" },
  { name: "card-padding-sm", value: 16, css: "p-card-padding-sm", usage: "Compact card padding — dense list items, small badges", kind: "padding", category: "Inset" },
  { name: "card-padding-md", value: 24, css: "p-card-padding-md", usage: "Standard card padding — product cards, panels", kind: "padding", category: "Inset" },
  { name: "card-padding-lg", value: 32, css: "p-card-padding-lg", usage: "Spacious card padding — hero cards, promo banners", kind: "padding", category: "Inset" },
  { name: "section-gap-tight", value: 48, range: "32–48px, fluid", css: "gap-section-gap-tight", usage: "Closely related stacked sections — e.g. modules inside one PDP details block", kind: "stack", category: "Section" },
  { name: "section-gap-standard", value: 80, range: "48–80px, fluid", css: "gap-section-gap-standard", usage: "Most stacked page sections — the default rhythm for a homepage or landing page", kind: "stack", category: "Section" },
  { name: "section-gap-loose", value: 128, range: "64–128px, fluid", css: "gap-section-gap-loose", usage: "A hero-to-content transition, or a break between unrelated sections", kind: "stack", category: "Section" },
] as const;

/** Max-width constraints, distinct from the gap/padding scale above. */
export const widthTokens = [
  { name: "content", value: 640, css: "max-w-content", usage: "Reading-width constraint for long-form text blocks", kind: "width", category: "Sizing" },
] as const;
