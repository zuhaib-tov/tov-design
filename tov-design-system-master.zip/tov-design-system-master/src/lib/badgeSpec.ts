import type { BadgeSize, BadgeVariant } from "@/components/ui/Badge";

/**
 * Badge measurements from the OG Figma file's Buttons, Badges page (Tags frame,
 * node 65:2081): "TOV badge designs. Mobile and 2 desktop sizes". Written the way
 * they are coded, in pixels. Height is padding + line height + padding.
 */
export interface BadgeSizeSpec {
  key: BadgeSize;
  name: string;
  screen: "Desktop" | "Mobile";
  font: number;
  line: number;
  padY: number;
  /** Left and right padding. */
  padX: number;
  height: number;
  flame: number;
  flameGap: number;
}

export const BADGE_SIZES: BadgeSizeSpec[] = [
  { key: "md", name: "Medium", screen: "Desktop", font: 10, line: 15, padY: 6, padX: 10, height: 27, flame: 11, flameGap: 2 },
  { key: "sm", name: "Small", screen: "Mobile", font: 8, line: 11, padY: 4, padX: 7, height: 19, flame: 10, flameGap: 2 },
];

export interface BadgeTypeSpec {
  name: string;
  label: string;
  variant: BadgeVariant;
  fill: string;
  text: string;
}

export const BADGE_TYPES: BadgeTypeSpec[] = [
  { name: "New Arrival", label: "New Arrival", variant: "new-arrival", fill: "#F9D2D2", text: "#3F3D3E" },
  { name: "New Arrival · Sale", label: "New Arrival · Sale", variant: "new-arrival-sale", fill: "#3F3D3E", text: "#FFFFFF" },
  { name: "Best Seller", label: "Best Seller", variant: "best-seller", fill: "#3F3D3E", text: "#FFFFFF" },
  { name: "Best Seller · Sale", label: "Best Seller · Sale", variant: "best-seller-sale", fill: "#3F3D3E", text: "#FFFFFF" },
  { name: "Final Sale", label: "Final Sale", variant: "final-sale", fill: "#5B3630", text: "#FFFFFF" },
  { name: "Sale (mauve)", label: "Sale", variant: "sale-mauve", fill: "#BB7A7E", text: "#FFFFFF" },
  { name: "Sale (lagoon)", label: "Sale", variant: "sale-lagoon", fill: "#7B8675", text: "#FFFFFF" },
  { name: "Hot List", label: "Hot List", variant: "hot-list", fill: "#F9D2D2", text: "#3F3D3E" },
  { name: "Limited Edition", label: "Limited Edition", variant: "limited-edition", fill: "#E4D7BA to #CCB583", text: "#3F3D3E" },
];

/** A badge size written as plain CSS, for use outside the component library. */
export function badgeCss(s: BadgeSizeSpec): string {
  return `.badge-${s.key} {
  display: inline-flex;
  align-items: center;
  padding: ${s.padY}px ${s.padX}px;   /* top/bottom, left/right */
  border-radius: 999px;
  font: 700 ${s.font}px/${s.line}px Montserrat, sans-serif;
  letter-spacing: 0.045em;
  text-transform: uppercase;
  white-space: nowrap;
}  /* height: ${s.height}px */`;
}
