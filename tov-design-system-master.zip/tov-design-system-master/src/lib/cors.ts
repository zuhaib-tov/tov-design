/**
 * The Figma plugin (figma-plugin/) calls these routes as a genuinely
 * cross-origin request from Figma's plugin sandbox — without these
 * headers the browser blocks it outright and the plugin sees a bare
 * "Failed to fetch", with no further detail to debug from. These routes
 * have no auth today (see asset-store.ts), so a permissive origin costs
 * nothing real; tighten this to the plugin's actual origin if that ever
 * changes.
 */
export const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-vercel-protection-bypass",
  // This data changes every time someone clicks "Push to Figma" on the
  // site, and the plugin polls it on demand ("Check again") expecting to
  // see that change immediately — any caching layer serving a stale
  // response here defeats the whole point.
  "Cache-Control": "no-store",
};
