/**
 * Precise upload -> Figma node mappings for Amazon component pages that
 * support the "Update images in Figma" uploader. Each slot's nodeId targets
 * the exact node that renders the photo, so a push replaces the real image
 * instead of landing in a staging area.
 *
 * Category Hero (A+ Content, fileKey P6ISgCbxCzraEqRtTr0j3P, node 23:688,
 * "🟠 Feb - 2026" page): 22 furniture categories, each with a Desktop
 * (1464x600) and Mobile (600x450) variant. Every category already carries a
 * real, finished photo, so uploading here is always a replace, never a
 * first-time fill-in. The fill lives one level below each category's own
 * symbol, on a child frame named "Frame 1260" — the category symbol itself
 * is a container and setting fills on it is a no-op.
 *
 * Comfort & Construction (same file, node 23:792, same page): a very
 * different shape from Category Hero — 36 individual instances (18 under
 * "Module 4 Comfort", 18 under "Module 4 Construction") of one shared
 * component ("Comfort and Construction modules"), each already showing a
 * real photo. Categories repeat across instances (multiple "Accent Chairs"
 * photos, "Sectionals" x3, etc.) rather than one slot per category — this
 * is a visual-variety grid, not a 1:1 category mapping. Every instance's
 * own `fills` array stacks 2-3 IMAGE paints, but only the top one renders.
 */

import type { MaterialsCategory } from "@/components/ui/AmazonMaterialsModule";

export interface FigmaSlot {
  /** Shown in the assignment dropdown, e.g. "Living Room". */
  name: string;
  /** Every node this one uploaded image fills — e.g. a category's Desktop + Mobile variant. */
  nodeIds: string[];
  /** True if any of these nodes already has a real image fill — replacing it needs care (see the uploader's own copy). */
  hasExistingImage: boolean;
}

// desktopId/mobileId are the real photo fill node ("Frame 1260"), one
// level under each category's symbol — not the symbol's own id. Setting
// fills on the symbol itself is a no-op, since it's a container and not
// what renders the photo. The Figma plugin (figma-plugin/) uses exactly
// what's here rather than re-deriving the id at push time.
const CATEGORY_HERO_CATEGORIES: { category: string; desktopId: string; mobileId: string }[] = [
  { category: "Living Room", desktopId: "2012:1556", mobileId: "2012:1566" },
  { category: "Accent Chairs", desktopId: "2012:1580", mobileId: "2012:1590" },
  { category: "Sofas & Loveseats", desktopId: "2012:1604", mobileId: "2012:1614" },
  { category: "Sectionals", desktopId: "2012:1733", mobileId: "2012:1743" },
  { category: "Occasional Tables", desktopId: "2012:1757", mobileId: "2012:1767" },
  { category: "Benches & Ottomans", desktopId: "2012:1789", mobileId: "2012:1799" },
  { category: "Dining Room Tables", desktopId: "2012:1853", mobileId: "2012:1863" },
  { category: "Dining Room Chairs", desktopId: "2012:1877", mobileId: "2012:1887" },
  { category: "Bar & Counter Stools", desktopId: "2012:1901", mobileId: "2012:1911" },
  { category: "Buffets & Cabinets", desktopId: "2012:1973", mobileId: "2012:1983" },
  { category: "Beds", desktopId: "2012:1997", mobileId: "2012:2007" },
  { category: "Nightstands", desktopId: "2012:2021", mobileId: "2012:2031" },
  { category: "Vanities", desktopId: "2012:2093", mobileId: "2012:2103" },
  { category: "Chests & Dressers", desktopId: "2012:2117", mobileId: "2012:2127" },
  { category: "Desks", desktopId: "2012:2141", mobileId: "2012:2151" },
  { category: "Office Chairs", desktopId: "2012:2213", mobileId: "2012:2223" },
  { category: "Outdoor Dining Tables", desktopId: "2012:2237", mobileId: "2012:2247" },
  { category: "Outdoor Dining Seating", desktopId: "2012:2261", mobileId: "2012:2271" },
  { category: "Outdoor Lounge Seating", desktopId: "2012:2333", mobileId: "2012:2343" },
  { category: "Outdoor Accent Tables", desktopId: "2012:2357", mobileId: "2012:2367" },
  { category: "Decor", desktopId: "2012:2381", mobileId: "2012:2391" },
  { category: "Lighting", desktopId: "2012:2405", mobileId: "2012:2415" },
];

export const A_PLUS_CONTENT_FIGMA_FILE_KEY = "P6ISgCbxCzraEqRtTr0j3P";

export const CATEGORY_HERO_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const CATEGORY_HERO_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=23-688";

// One image per category — it fills both the Desktop and Mobile variant of
// that category's component, not two separate slots.
export const CATEGORY_HERO_SLOTS: FigmaSlot[] = CATEGORY_HERO_CATEGORIES.map((c) => ({
  name: c.category,
  nodeIds: [c.desktopId, c.mobileId],
  hasExistingImage: true,
}));

export const COMFORT_CONSTRUCTION_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const COMFORT_CONSTRUCTION_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=23-793";

// Names cleaned up from the real instance layer names (stripped the
// redundant "Module 4 " prefix).
export const COMFORT_CONSTRUCTION_SLOTS: FigmaSlot[] = [
  { name: "Comfort — Accent Chairs 1", nodeIds: ["18:908"], hasExistingImage: true },
  { name: "Comfort — Dining Room Tables 1", nodeIds: ["29:1016"], hasExistingImage: true },
  { name: "Comfort — Bar & Counter Stools 1", nodeIds: ["18:1178"], hasExistingImage: true },
  { name: "Comfort — Sectionals 1", nodeIds: ["18:521"], hasExistingImage: true },
  { name: "Comfort — Buffets & Cabinets 1", nodeIds: ["35:602"], hasExistingImage: true },
  { name: "Comfort — Beds 2", nodeIds: ["36:877"], hasExistingImage: true },
  { name: "Comfort — Beds 1", nodeIds: ["38:1065"], hasExistingImage: true },
  { name: "Comfort — Vanities 1", nodeIds: ["43:822"], hasExistingImage: true },
  { name: "Comfort — Outdoor Dining Tables 1", nodeIds: ["44:963"], hasExistingImage: true },
  { name: "Comfort — Sectionals 2", nodeIds: ["48:1072"], hasExistingImage: true },
  { name: "Comfort — Outdoor Lounge Seating 1", nodeIds: ["50:1160"], hasExistingImage: true },
  { name: "Comfort — Sectionals 3", nodeIds: ["50:1339"], hasExistingImage: true },
  { name: "Comfort — Decor 1", nodeIds: ["51:1382"], hasExistingImage: true },
  { name: "Comfort — Lighting 1", nodeIds: ["50:1337"], hasExistingImage: true },
  { name: "Comfort — Desks 1", nodeIds: ["43:889"], hasExistingImage: true },
  { name: "Comfort — Accent Chairs 2", nodeIds: ["43:936"], hasExistingImage: true },
  { name: "Comfort — Nightstands 1", nodeIds: ["40:872"], hasExistingImage: true },
  { name: "Comfort — Chests & Dressers 1", nodeIds: ["43:818"], hasExistingImage: true },
  { name: "Construction — Accent Chairs 1", nodeIds: ["18:909"], hasExistingImage: true },
  { name: "Construction — Dining Room Tables 1", nodeIds: ["29:1018"], hasExistingImage: true },
  { name: "Construction — Accent Chairs 2", nodeIds: ["33:600"], hasExistingImage: true },
  { name: "Construction — Occasional Tables 2", nodeIds: ["36:879"], hasExistingImage: true },
  { name: "Construction — Beds 1", nodeIds: ["38:1067"], hasExistingImage: true },
  { name: "Construction — Vanities 1", nodeIds: ["43:824"], hasExistingImage: true },
  { name: "Construction — Outdoor Dining Tables 1", nodeIds: ["44:965"], hasExistingImage: true },
  { name: "Construction — Outdoor Lounge Seating 1", nodeIds: ["50:1341"], hasExistingImage: true },
  { name: "Construction — Occasional Tables 1", nodeIds: ["50:1450"], hasExistingImage: true },
  { name: "Construction — Decor 1", nodeIds: ["51:1384"], hasExistingImage: true },
  { name: "Construction — Sofas & Loveseats 2", nodeIds: ["48:1074"], hasExistingImage: true },
  { name: "Construction — Bar & Counter Stools 1", nodeIds: ["48:1092"], hasExistingImage: true },
  { name: "Construction — Desks 1", nodeIds: ["43:891"], hasExistingImage: true },
  { name: "Construction — Benches & Ottomans 1", nodeIds: ["43:938"], hasExistingImage: true },
  { name: "Construction — Nightstands 1", nodeIds: ["40:874"], hasExistingImage: true },
  { name: "Construction — Chests & Dressers 1", nodeIds: ["43:820"], hasExistingImage: true },
  { name: "Construction — Sofas & Loveseats 1", nodeIds: ["18:522"], hasExistingImage: true },
  { name: "Construction — Dining Room Tables 2", nodeIds: ["18:1179"], hasExistingImage: true },
];

/**
 * Brand Story (A+ Content, same file, node 3:4, "Brand Story" section): a
 * full-bleed hero used to open a product's A+ page. Two sibling frames —
 * "Background IMG" (3:9, 6 symbols) and "Logos" (7:237, 2 symbols) — both
 * still in legacy `Property 1=` naming, never migrated to the
 * Version=/Viewport=/Status= convention.
 *
 * "Background IMG" is 3 real "looks" (a color scheme + copy combination),
 * each a Desktop/Mobile pair — not 6 unrelated variants. The top-level
 * symbol ids are not always the fill-bearing node, same "one level down"
 * pattern as Category Hero's "Frame 1260":
 *   - **"Tagline" (dark leopard panel + "TOV / Always en Vogue / Never
 *     overpriced" lockup)**: Desktop `4:85` → real fill on child `4:88`
 *     (868x625). Mobile `5:116` → real fill on grandchild `5:119` (466x369,
 *     2 stacked IMAGE fills, only the top one visible). Desktop and Mobile
 *     share the identical photo.
 *   - **"Don't Be Boring — Dark"** (same dark panel, bold "DON'T BE
 *     BORING." copy instead of the tagline lockup): Desktop `7:113` → real
 *     fill on child `7:130` (868x625, same shared photo). Mobile `7:272`
 *     has a broken image reference in the source file: its own `fills`
 *     lists the same `imageHash` as the two Mobile nodes below, but it
 *     renders as Figma's blank checkerboard. The uploader treats this as
 *     needing a first real fill, not a replace, even though the raw fill
 *     data isn't technically empty.
 *   - **"Don't Be Boring — Light"** (cream panel, same bold copy): Desktop
 *     `4:151` → real fill on child `4:167` (961x625, same shared photo
 *     again). Mobile `3:10` → fill lives directly on the symbol itself, no
 *     child needed (a distinct, narrower crop/`imageHash` from the Desktop
 *     photo, shared with the two mobile nodes above).
 * One upload per look fills both its Desktop and Mobile node — like
 * Category Hero, unlike Amazon Store below — because Desktop and Mobile
 * genuinely share the same photography here.
 *
 * "Logos" (7:237) is deliberately **not** in `BRAND_STORY_SLOTS` below —
 * see the comment on `BRAND_STORY_SLOTS` itself for why.
 *
 * Naming: `7:272` and `5:116` are both literally named "Property
 * 1=Variant6" but are genuinely different content (the broken Mobile
 * "Don't Be Boring" placeholder vs. the real Mobile Tagline photo), not
 * duplicates. A rename to the Version=/Viewport=/Status= convention has
 * not been executed on this file. Every id below is stable regardless of
 * name.
 */

const BRAND_STORY_LOOKS: { look: string; desktopId: string; mobileId: string; hasExistingImage: boolean }[] = [
  { look: "Tagline — dark", desktopId: "4:88", mobileId: "5:119", hasExistingImage: true },
  { look: "Don't Be Boring — dark", desktopId: "7:130", mobileId: "7:272", hasExistingImage: true },
  { look: "Don't Be Boring — light", desktopId: "4:167", mobileId: "3:10", hasExistingImage: true },
];

export const BRAND_STORY_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const BRAND_STORY_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=3-4";

// One image per look — it fills both the Desktop and Mobile node of that
// look, not two separate slots (see the comment above for why this matches
// Category Hero's pattern rather than Amazon Store's per-viewport one).
export const BRAND_STORY_SLOTS: FigmaSlot[] = BRAND_STORY_LOOKS.map((l) => ({
  name: l.look,
  nodeIds: [l.desktopId, l.mobileId],
  hasExistingImage: l.hasExistingImage,
}));

/**
 * Video Thumbnail Module (same file, node 23:918, "Module 3 - 2 Colum Text
 * + Video" section): 16 furniture categories, each with exactly ONE "Video
 * Tumbnail" instance (800x600, Figma's own typo in "Tumbnail" — not carried
 * into any name below). The canonical symbol (node 15:235, section 15:176)
 * is structurally simple compared to Materials/Hero Module: no variants,
 * just a single flat photo fill.
 *
 * Only 3 of these 16 instances — Accent Chairs, Living Room, Dining Room —
 * are a plain, unmodified photo with nothing else on top, matching the
 * canonical symbol exactly. The other 13 all carry an extra trailing SOLID
 * black fill at 20% opacity on top of whatever else is there — a dimming
 * scrim that isn't part of the canonical symbol (15:235 has no such fill)
 * and isn't consistent across instances.
 *
 * 7 of the 16 have every real content fill hidden and show only that
 * 20%-black scrim — i.e. no real photo/video at all, just a flat
 * translucent gray box. "16 real instances" does not mean "16 populated
 * photos" — hasExistingImage below is false for these.
 *
 * 4 of the 16 (Beds, Nightstands, Sectionals, Outdoor) have their real
 * content as a VIDEO paint, not an IMAGE paint — genuine embedded video,
 * not a static photo. This uploader only replaces fills with a static
 * image, so using it on these 4 would replace real video content with a
 * photo — they're marked hasExistingImage: true same as the image ones,
 * but need extra care given the different media type.
 *
 * No play-button icon, pill label, or any vector/overlay layer exists
 * anywhere — canonical symbol or any of the 16 instances — so this module
 * is built as a plain image with no invented affordance.
 */
export const VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const VIDEO_THUMBNAIL_MODULE_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=23-918";

export const VIDEO_THUMBNAIL_MODULE_SLOTS: FigmaSlot[] = [
  // Plain photo, no scrim — matches the canonical symbol exactly.
  { name: "Video Thumbnail — Accent Chairs", nodeIds: ["18:900"], hasExistingImage: true },
  { name: "Video Thumbnail — Living Room", nodeIds: ["18:513"], hasExistingImage: true },
  { name: "Video Thumbnail — Dining Room", nodeIds: ["29:1014"], hasExistingImage: true },
  // Real photo, but with the 20%-black scrim on top (dimmed).
  { name: "Video Thumbnail — Buffets & Cabinets", nodeIds: ["36:1043"], hasExistingImage: true },
  { name: "Video Thumbnail — Decor", nodeIds: ["50:1155"], hasExistingImage: true },
  // Real embedded VIDEO paint (not a static image) + the scrim on top.
  { name: "Video Thumbnail — Beds", nodeIds: ["38:1063"], hasExistingImage: true },
  { name: "Video Thumbnail — Sectionals", nodeIds: ["48:1070"], hasExistingImage: true },
  { name: "Video Thumbnail — Outdoor", nodeIds: ["44:953"], hasExistingImage: true },
  // Real embedded VIDEO paint, no scrim.
  { name: "Video Thumbnail — Nightstands", nodeIds: ["40:870"], hasExistingImage: true },
  // No real content at all — every fill hidden except the 20%-black scrim,
  // so these render as a flat gray box today. First-time fill-in, not a
  // replace.
  { name: "Video Thumbnail — Bar & Counter Stools", nodeIds: ["36:808"], hasExistingImage: false },
  { name: "Video Thumbnail — Benches", nodeIds: ["36:875"], hasExistingImage: false },
  { name: "Video Thumbnail — Chests & Dressers", nodeIds: ["40:842"], hasExistingImage: false },
  { name: "Video Thumbnail — Vanities", nodeIds: ["43:843"], hasExistingImage: false },
  { name: "Video Thumbnail — Desks", nodeIds: ["43:887"], hasExistingImage: false },
  { name: "Video Thumbnail — Office Chairs", nodeIds: ["43:934"], hasExistingImage: false },
  { name: "Video Thumbnail — Lighting", nodeIds: ["50:1158"], hasExistingImage: false },
];

/**
 * Amazon Store (fileKey I95mnwwaoq0CvJOGop9tfn, "TOV25 - B2C - Amazon
 * store"). Every slot already carries a real, finished photo, same as
 * Comfort & Construction and Category Hero.
 *
 * Desktop and Mobile are kept as SEPARATE slots here (unlike Category
 * Hero, where one upload fills both). A direct check found this file
 * doesn't share images between viewports consistently — hero/wide banners
 * do share the same photo across Desktop and Mobile, but individual grid
 * tiles (e.g. Category Page's "Accent Chairs") often use a different crop
 * or photo per viewport. Merging them would risk silently showing the
 * wrong photo on one viewport, so every Desktop/Mobile pair gets its own
 * slot — redundant upload if they happen to be the same photo, but never
 * wrong.
 */

export const AMAZON_STORE_FIGMA_FILE_KEY = "I95mnwwaoq0CvJOGop9tfn";
const AMAZON_STORE_FIGMA_FILE_URL_BASE =
  "https://www.figma.com/design/I95mnwwaoq0CvJOGop9tfn/TOV25---B2C---Amazon-store---206";

// Storefront: the Banner Images section (3 alternate hero variants + the
// embedded "Best sellers" banner, node 16:364), the Category Tiles (node
// 16:366), and the 3-Tile Grid (node 34:1359). Header (16:400) and Content
// Block (16:365) have zero image fills — Header is just a logo lockup,
// Content Block is pure text ("Always En Vogue, Never Overpriced." + a
// paragraph) — so neither gets upload slots.
export const STOREFRONT_FIGMA_FILE_URL = `${AMAZON_STORE_FIGMA_FILE_URL_BASE}?node-id=16-363`;

// Split into 3 section-scoped exports (was one flat STOREFRONT_SLOTS) so
// each section's FigmaSlotUploader on the doc page only lists its own real
// nodes — every node id and slot name below is unchanged from the original
// flat list, this is a reorganization, not a re-derivation.

// "Banner images" (16:364) — 3 alternate Hero variants. Every Desktop node
// is a leaf frame (no child text layers) — 1920x777 (rendered PNG measures
// 1928x785, a few px of stroke/effect bleed, same ~2.47:1 ratio). Every
// Mobile node sits one level under a same-size 1500x1110 wrapper ("Frame
// 405"), also a plain leaf fill with no crop.
export const STOREFRONT_HERO_SLOTS: FigmaSlot[] = [
  { name: "Hero 1 — Desktop", nodeIds: ["34:1264"], hasExistingImage: true },
  { name: "Hero 1 — Mobile", nodeIds: ["34:1316"], hasExistingImage: true },
  { name: "Hero 2 — Desktop", nodeIds: ["138:44"], hasExistingImage: true },
  { name: "Hero 2 — Mobile", nodeIds: ["138:51"], hasExistingImage: true },
  { name: "Hero 3 — Desktop", nodeIds: ["138:70"], hasExistingImage: true },
  { name: "Hero 3 — Mobile", nodeIds: ["138:77"], hasExistingImage: true },
];

// "Category images" (16:366) — 4 tiles. Each image node (e.g. 34:1242)
// sits alongside its own real caption text siblings under a shared tile
// parent (e.g. 34:1241 → 34:1242 "Frame 10" + 34:1243 "Frame 1235" →
// 34:1244 title text + 34:1245 "Shop now" text):
//   34:1242 → "Home office", 34:1248 → "Outdoor", 34:1254 → "Lighting",
//   34:1260 → "Decor". See AmazonCategoryTile.tsx for the real typography
// (48px GT Ultra Fine title / 36px Gotham Book underlined CTA / #3f3d3e,
// matching this app's existing --color-charcoal).
export const STOREFRONT_CATEGORY_TILE_SLOTS: FigmaSlot[] = [
  { name: "Category Tile — Home Office", nodeIds: ["34:1242"], hasExistingImage: true },
  { name: "Category Tile — Outdoor", nodeIds: ["34:1248"], hasExistingImage: true },
  { name: "Category Tile — Lighting", nodeIds: ["34:1254"], hasExistingImage: true },
  { name: "Category Tile — Decor", nodeIds: ["34:1260"], hasExistingImage: true },
];

// "3 tile grid section" (34:1359) — Bedroom / Nightstand / Living Room
// promo tiles. Same flat-image shape as Hero (leaf frames, no child text —
// e.g. 34:1307 "Bedroom -D").
//
// Not all 6 nodes share one aspect ratio. Bedroom (34:1307 Desktop /
// 34:1300 Mobile) and Living Room (76:193 Desktop / 76:211 Mobile) are all
// 1500x750 (2:1) — but Nightstand Desktop (76:186) is 1500x1500, a full
// square. Nightstand's own Mobile node (76:204) is back to 1500x750 — so
// even within the Nightstand pair, Desktop and Mobile don't share a crop.
// Do not assume 2:1 for all six slots; AmazonStorefrontBanner takes an
// explicit per-node aspectRatio for exactly this reason.
export const STOREFRONT_THREE_TILE_GRID_SLOTS: FigmaSlot[] = [
  { name: "3-Tile Grid — Bedroom — Desktop", nodeIds: ["34:1307"], hasExistingImage: true },
  { name: "3-Tile Grid — Bedroom — Mobile", nodeIds: ["34:1300"], hasExistingImage: true },
  { name: "3-Tile Grid — Nightstand — Desktop", nodeIds: ["76:186"], hasExistingImage: true },
  { name: "3-Tile Grid — Nightstand — Mobile", nodeIds: ["76:204"], hasExistingImage: true },
  { name: "3-Tile Grid — Living Room — Desktop", nodeIds: ["76:193"], hasExistingImage: true },
  { name: "3-Tile Grid — Living Room — Mobile", nodeIds: ["76:211"], hasExistingImage: true },
];

// Best Sellers: embedded inside Storefront's Banner Images section in
// Figma (not a separate top-level frame there), but broken out as its own
// page here per how the site is actually organized.
export const BEST_SELLERS_FIGMA_FILE_URL = `${AMAZON_STORE_FIGMA_FILE_URL_BASE}?node-id=34-1229`;
export const BEST_SELLERS_SLOTS: FigmaSlot[] = [
  { name: "Best Sellers — Desktop", nodeIds: ["34:1229"], hasExistingImage: true },
  { name: "Best Sellers — Mobile", nodeIds: ["34:1325"], hasExistingImage: true },
];

// Category Page (node 77:611): 7 rooms (Living Room, Dining Room, Decor,
// Outdoor, Home Office, Lighting, Bedroom), each with a hero + subcategory
// tiles, separately for Desktop and Mobile. Lighting Desktop's first tile
// (118:478) was verified to be a text/CTA element ("Shop by category"),
// not a photo — excluded below, not an oversight.
const CATEGORY_PAGE_ITEMS: { room: string; viewport: "Desktop" | "Mobile"; item: string; nodeId: string }[] = [
  // Desktop
  { room: "Living Room", viewport: "Desktop", item: "Hero", nodeId: "77:939" },
  { room: "Living Room", viewport: "Desktop", item: "Accent Chairs", nodeId: "77:946" },
  { room: "Living Room", viewport: "Desktop", item: "Sofas & Loveseats", nodeId: "77:956" },
  { room: "Living Room", viewport: "Desktop", item: "Sectionals", nodeId: "77:973" },
  { room: "Living Room", viewport: "Desktop", item: "Benches & Ottomans", nodeId: "77:979" },
  { room: "Dining Room", viewport: "Desktop", item: "Hero", nodeId: "77:991" },
  { room: "Dining Room", viewport: "Desktop", item: "Dining Room Chairs", nodeId: "77:1046" },
  { room: "Dining Room", viewport: "Desktop", item: "Dining Room Tables", nodeId: "77:1052" },
  { room: "Dining Room", viewport: "Desktop", item: "Buffets & Cabinets", nodeId: "77:1058" },
  { room: "Dining Room", viewport: "Desktop", item: "Bar & Counter Stools", nodeId: "77:1064" },
  { room: "Decor", viewport: "Desktop", item: "Hero", nodeId: "78:1221" },
  { room: "Decor", viewport: "Desktop", item: "Mirrors", nodeId: "78:1225" },
  { room: "Decor", viewport: "Desktop", item: "Pillows & Throws", nodeId: "78:1231" },
  { room: "Decor", viewport: "Desktop", item: "Tabletop & Bookends", nodeId: "78:1237" },
  { room: "Decor", viewport: "Desktop", item: "Rugs", nodeId: "78:1280" },
  { room: "Outdoor", viewport: "Desktop", item: "Hero", nodeId: "87:145" },
  { room: "Outdoor", viewport: "Desktop", item: "Outdoor Dining Tables", nodeId: "87:149" },
  { room: "Outdoor", viewport: "Desktop", item: "Outdoor Dining Seating", nodeId: "87:155" },
  { room: "Outdoor", viewport: "Desktop", item: "Outdoor Lounge Seating", nodeId: "87:161" },
  { room: "Outdoor", viewport: "Desktop", item: "Outdoor Accent Tables", nodeId: "87:167" },
  { room: "Home Office", viewport: "Desktop", item: "Hero", nodeId: "78:1123" },
  { room: "Home Office", viewport: "Desktop", item: "Desks", nodeId: "78:1127" },
  { room: "Home Office", viewport: "Desktop", item: "Office Chairs", nodeId: "78:1133" },
  { room: "Lighting", viewport: "Desktop", item: "Hero", nodeId: "78:1259" },
  { room: "Lighting", viewport: "Desktop", item: "Tile 2", nodeId: "118:486" },
  { room: "Lighting", viewport: "Desktop", item: "Tile 3", nodeId: "118:492" },
  { room: "Lighting", viewport: "Desktop", item: "Tile 4", nodeId: "118:495" },
  { room: "Bedroom", viewport: "Desktop", item: "Hero", nodeId: "78:1080" },
  { room: "Bedroom", viewport: "Desktop", item: "Beds", nodeId: "78:1084" },
  { room: "Bedroom", viewport: "Desktop", item: "Nightstands", nodeId: "78:1090" },
  { room: "Bedroom", viewport: "Desktop", item: "Chests & Dressers", nodeId: "78:1096" },
  { room: "Bedroom", viewport: "Desktop", item: "Vanities", nodeId: "78:1102" },
  // Mobile
  { room: "Bedroom", viewport: "Mobile", item: "Hero", nodeId: "80:133" },
  { room: "Bedroom", viewport: "Mobile", item: "Beds", nodeId: "80:109" },
  { room: "Bedroom", viewport: "Mobile", item: "Nightstands", nodeId: "80:115" },
  { room: "Bedroom", viewport: "Mobile", item: "Chests & Dressers", nodeId: "80:121" },
  { room: "Bedroom", viewport: "Mobile", item: "Vanities", nodeId: "80:127" },
  { room: "Dining Room", viewport: "Mobile", item: "Hero", nodeId: "80:171" },
  { room: "Dining Room", viewport: "Mobile", item: "Dining Room Chairs", nodeId: "80:147" },
  { room: "Dining Room", viewport: "Mobile", item: "Dining Room Tables", nodeId: "80:153" },
  { room: "Dining Room", viewport: "Mobile", item: "Buffets & Cabinets", nodeId: "80:159" },
  { room: "Dining Room", viewport: "Mobile", item: "Bar & Counter Stools", nodeId: "80:165" },
  { room: "Living Room", viewport: "Mobile", item: "Hero", nodeId: "82:247" },
  { room: "Living Room", viewport: "Mobile", item: "Accent Chairs", nodeId: "82:223" },
  { room: "Living Room", viewport: "Mobile", item: "Sofas & Loveseats", nodeId: "82:229" },
  { room: "Living Room", viewport: "Mobile", item: "Sectionals", nodeId: "82:235" },
  { room: "Living Room", viewport: "Mobile", item: "Benches & Ottomans", nodeId: "82:241" },
  { room: "Decor", viewport: "Mobile", item: "Hero", nodeId: "78:1520" },
  { room: "Decor", viewport: "Mobile", item: "Mirrors", nodeId: "78:1392" },
  { room: "Decor", viewport: "Mobile", item: "Pillows & Throws", nodeId: "78:1398" },
  { room: "Decor", viewport: "Mobile", item: "Tabletop & Bookends", nodeId: "78:1404" },
  { room: "Decor", viewport: "Mobile", item: "Rugs", nodeId: "78:1410" },
  { room: "Outdoor", viewport: "Mobile", item: "Hero", nodeId: "94:179" },
  { room: "Outdoor", viewport: "Mobile", item: "Outdoor Dining Tables", nodeId: "94:155" },
  { room: "Outdoor", viewport: "Mobile", item: "Outdoor Dining Seating", nodeId: "94:161" },
  { room: "Outdoor", viewport: "Mobile", item: "Outdoor Lounge Seating", nodeId: "94:167" },
  { room: "Outdoor", viewport: "Mobile", item: "Outdoor Accent Tables", nodeId: "94:173" },
  { room: "Home Office", viewport: "Mobile", item: "Hero", nodeId: "78:1550" },
  { room: "Home Office", viewport: "Mobile", item: "Desks", nodeId: "78:1526" },
  { room: "Home Office", viewport: "Mobile", item: "Office Chairs", nodeId: "78:1532" },
  { room: "Lighting", viewport: "Mobile", item: "Hero", nodeId: "78:1434" },
];

export const CATEGORY_PAGE_FIGMA_FILE_URL = `${AMAZON_STORE_FIGMA_FILE_URL_BASE}?node-id=77-611`;
export const CATEGORY_PAGE_SLOTS: FigmaSlot[] = CATEGORY_PAGE_ITEMS.map((i) => ({
  name: `${i.room} — ${i.viewport} — ${i.item}`,
  nodeIds: [i.nodeId],
  hasExistingImage: true,
}));

// Subcategory components (node 89:183): a flat list of ~29 individual
// subcategory image tiles, each a single Desktop frame — no separate
// Mobile variant was found for this component set.
const SUBCATEGORY_COMPONENTS_ITEMS: { name: string; nodeId: string }[] = [
  { name: "Accent Chairs", nodeId: "101:194" },
  { name: "Sofas & Loveseats", nodeId: "103:218" },
  { name: "Sectionals", nodeId: "103:228" },
  { name: "Benches & Ottomans", nodeId: "103:234" },
  { name: "Occasional Tables", nodeId: "103:240" },
  { name: "Dining Chairs", nodeId: "103:245" },
  { name: "Dining Tables", nodeId: "103:252" },
  { name: "Bar & Counter Stools", nodeId: "103:258" },
  { name: "Buffets & Cabinets", nodeId: "103:264" },
  { name: "Beds", nodeId: "103:270" },
  { name: "Nightstands", nodeId: "103:276" },
  { name: "Chest & Dressers", nodeId: "103:282" },
  { name: "Vanities", nodeId: "103:288" },
  { name: "Desks", nodeId: "103:294" },
  { name: "Office Chair", nodeId: "103:300" },
  { name: "Outdoor Dining Tables", nodeId: "103:306" },
  { name: "Outdoor Dining Seating", nodeId: "103:312" },
  { name: "Outdoor Lounge Seating", nodeId: "103:318" },
  { name: "Outdoor Accent Tables", nodeId: "104:327" },
  { name: "Mirrors", nodeId: "104:333" },
  { name: "Pillows & Throws", nodeId: "104:339" },
  { name: "Vases", nodeId: "104:345" },
  { name: "Tabletop & Bookends", nodeId: "105:351" },
  { name: "Rugs", nodeId: "105:357" },
  { name: "Pet Beds", nodeId: "105:363" },
  { name: "Table Lamps", nodeId: "105:369" },
  { name: "Floor Lamps", nodeId: "105:375" },
  { name: "Ceiling Lamps", nodeId: "105:381" },
  { name: "Cabinets & Storage", nodeId: "152:502" },
];

export const SUBCATEGORY_COMPONENTS_FIGMA_FILE_URL = `${AMAZON_STORE_FIGMA_FILE_URL_BASE}?node-id=89-183`;
export const SUBCATEGORY_COMPONENTS_SLOTS: FigmaSlot[] = SUBCATEGORY_COMPONENTS_ITEMS.map((i) => ({
  name: i.name,
  nodeIds: [i.nodeId],
  hasExistingImage: true,
}));

/**
 * Materials Module (A+ Content, same file, Components page frame
 * "Materials" node 9:265): 4 symbols, still legacy `Property 1=...` named.
 * Labels don't reliably match the real component — cross-referenced against
 * the populated instance library instead ("Module 2 - 4 Colum Images", node
 * 18:893, 4 named sub-sections with real photos):
 *   - `Property 1=Design` (9:266) matches by name (17 real instances under
 *     "Module 2 Design", node 23:689).
 *   - `Property 1=Material` (9:272) matches by name (7 real instances
 *     under "Module 2 Material", node 23:690).
 *   - `Property 1=Variant3` (9:307) is really **Durable** (12 real
 *     instances under "Module 2 Durable", node 23:704).
 *   - `Property 1=Variant4` (9:313) is really **Craftsmanship** (18 real
 *     instances under "Module 2 Craftsmanship", node 23:776).
 *
 * Naming: unlike Category Hero/Comfort & Construction, these 54 instances'
 * own Figma layer names are just an ordinal ("Module 2 Design - Materials
 * 1", "...2", etc.) — they don't encode a real furniture category the way
 * Comfort & Construction's layer names did ("Comfort — Accent Chairs 1").
 * Content varies (real product photography, e.g. 18:896 is an accent
 * chair), but there's no better identifier to label it with beyond the
 * ordinal. Slot names below are ordinal per group (`"Design 1"..."Design
 * 17"`, etc.), stripping the redundant "Module 2 " / "- Materials"
 * wrapping, same spirit as Comfort & Construction's own prefix-stripping.
 */

const MATERIALS_MODULE_GROUPS: { category: MaterialsCategory; nodeIds: string[] }[] = [
  {
    category: "Design",
    nodeIds: [
      "18:896", "43:940", "50:1350", "50:1374", "50:1390", "33:574", "36:849", "40:844",
      "35:727", "35:734", "35:741", "48:1076", "50:1235", "18:1032", "31:1021", "50:1452", "32:537",
    ],
  },
  {
    category: "Material",
    nodeIds: ["18:897", "31:1028", "50:1468", "18:1167", "48:994", "50:1198", "50:1398"],
  },
  {
    category: "Durable",
    nodeIds: [
      "18:898", "33:582", "40:852", "18:1168", "23:957", "43:948",
      "36:857", "38:1045", "32:520", "50:1067", "50:1243", "50:1434",
    ],
  },
  {
    category: "Craftsmanship",
    nodeIds: [
      "18:899", "11:468", "18:1169", "23:949", "28:1005", "32:529", "36:866", "38:1054", "40:861",
      "48:1084", "50:1251", "43:834", "43:957", "50:1366", "50:1382", "50:1442", "50:1460", "44:955",
    ],
  },
];

export const MATERIALS_MODULE_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const MATERIALS_MODULE_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=18-893";

// One image per instance — each of the 54 already carries a real, finished
// photo, so every slot is a replace, never a first-time fill-in.
export const MATERIALS_MODULE_SLOTS: FigmaSlot[] = MATERIALS_MODULE_GROUPS.flatMap((g) =>
  g.nodeIds.map((nodeId, i) => ({
    name: `${g.category} ${i + 1}`,
    nodeIds: [nodeId],
    hasExistingImage: true,
  }))
);

/**
 * Sustainability Module (same A+ Content file, "Module 7 Sustainability"
 * section, node 23:933 → "Thumbnails" 23:934 → instance "Sustainability
 * Module" 18:520, 800x600). Deliberately not a `FigmaSlot` entry and not
 * wired to `FigmaSlotUploader` — this is a single evergreen lifestyle photo
 * (a generic styled vignette, not tied to any product or category), reused
 * as-is rather than replaced per-category like every other module above.
 * The same underlying component is reused for the "Storage" and
 * "Collections" modules elsewhere in the file.
 *
 * The real requirement here is a guaranteed-exact 800x600 download, not an
 * upload slot. A node's own image *fill* is often a larger original photo
 * cropped/scaled to its frame (`scaleMode: FILL/FIT/CROP/TILE`), so
 * exporting "the original fill asset" could silently return something
 * other than 800x600. Instead this uses `renderFigmaFrame` (see
 * src/lib/figma.ts) — Figma's own image-render endpoint at scale 1, which
 * composites the node exactly as shown and returns a PNG sized to the
 * node's own layout box. The API route built around it
 * (src/app/api/amazon/sustainability-module) re-verifies the decoded PNG's
 * real dimensions against this expected size on every request and refuses
 * to serve a mismatch, rather than trusting the spec size below blindly.
 */
export const SUSTAINABILITY_MODULE_FIGMA_FILE_KEY = A_PLUS_CONTENT_FIGMA_FILE_KEY;
export const SUSTAINABILITY_MODULE_NODE_ID = "18:520";
export const SUSTAINABILITY_MODULE_FIGMA_FILE_URL =
  "https://www.figma.com/design/P6ISgCbxCzraEqRtTr0j3P/TOV26---Amazon---Premium-A--content---476?node-id=23-933";
export const SUSTAINABILITY_MODULE_EXPECTED_SIZE = { width: 800, height: 600 };
