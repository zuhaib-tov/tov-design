export type NavItem = { label: string; href: string; icon: string };
export type NavSection = { title: string; items: NavItem[] };
export type Property = {
  key: string;
  /** Shown as the top line of the sidebar switcher, e.g. "TOV Design System". */
  label: string;
  /** Shown bold in the switcher button, e.g. "B2C" or "Amazon". */
  sublabel: string;
  /** Sidebar switcher badge circle fill — a CSS color, verified per-property against Figma. */
  badgeColor: string;
  /** Sidebar panel background — a CSS color, verified per-property against Figma. */
  panelBg: string;
  homeHref: string;
  sections: NavSection[];
};

const B2C_SECTIONS: NavSection[] = [
  {
    title: "Get started",
    items: [{ label: "Overview", href: "/", icon: "Home" }],
  },
  {
    title: "Foundations",
    items: [
      { label: "Brand", href: "/foundations/brand", icon: "Tag" },
      { label: "Color", href: "/foundations/color", icon: "Palette" },
      { label: "Typography", href: "/foundations/typography", icon: "Type" },
      { label: "Spacing & Radius", href: "/foundations/spacing", icon: "Ruler" },
      { label: "Layout", href: "/foundations/layout", icon: "LayoutGrid" },
      { label: "Iconography", href: "/foundations/iconography", icon: "Sparkles" },
    ],
  },
  {
    title: "Components",
    items: [
      { label: "Main Navigation", href: "/components/navigation", icon: "Navigation" },
      { label: "Button", href: "/components/button", icon: "RectangleHorizontal" },
      { label: "Badge", href: "/components/badge", icon: "BadgeCheck" },
      { label: "Input & Select", href: "/components/form-fields", icon: "TextCursorInput" },
      { label: "Rating", href: "/components/rating", icon: "Star" },
      { label: "Tabs", href: "/components/tabs", icon: "PanelTop" },
    ],
  },
  {
    title: "Pages",
    items: [
      { label: "Homepage & Marketing", href: "/pages/homepage", icon: "Megaphone" },
      { label: "Collection (PLP)", href: "/pages/collection", icon: "LayoutGrid" },
      { label: "PDP", href: "/pages/product", icon: "Package" },
      { label: "Cart & Checkout", href: "/pages/cart-checkout", icon: "ShoppingCart" },
      { label: "Account", href: "/pages/account", icon: "User" },
    ],
  },
  {
    title: "Editorial Pages",
    items: [
      { label: "New Arrivals", href: "/pages/editorial/new-arrivals", icon: "Sparkle" },
      { label: "Collection", href: "/pages/editorial/collection", icon: "Folder" },
      { label: "TOV Edits", href: "/pages/editorial/tov-edits", icon: "Newspaper" },
    ],
  },
  {
    title: "Marketing",
    items: [{ label: "Email", href: "/pages/marketing/email", icon: "Mail" }],
  },
];

const B2B_SECTIONS: NavSection[] = [
  {
    title: "Get started",
    items: [{ label: "Overview", href: "/b2b", icon: "Home" }],
  },
  {
    title: "Foundations",
    items: [
      { label: "Color", href: "/b2b/foundations/color", icon: "Palette" },
      { label: "Typography", href: "/b2b/foundations/typography", icon: "Type" },
      { label: "Spacing & Radius", href: "/b2b/foundations/spacing", icon: "Ruler" },
      { label: "Layout", href: "/b2b/foundations/layout", icon: "LayoutGrid" },
    ],
  },
  {
    title: "Components",
    items: [
      { label: "Button", href: "/b2b/components/button", icon: "RectangleHorizontal" },
      { label: "Tag", href: "/b2b/components/tag", icon: "Tag" },
      { label: "Reviews", href: "/b2b/components/reviews", icon: "Star" },
      { label: "Icon", href: "/b2b/components/icon", icon: "Sparkles" },
      { label: "Banners", href: "/b2b/components/banners", icon: "Megaphone" },
      { label: "Navigation", href: "/b2b/components/navigation", icon: "Navigation" },
      { label: "Product Card", href: "/b2b/components/product-card", icon: "Package" },
      { label: "Category Tile", href: "/b2b/components/category-tile", icon: "Grid3x3" },
      { label: "Feature Card", href: "/b2b/components/feature-card", icon: "Layers" },
      { label: "Carousel", href: "/b2b/components/carousel", icon: "Columns3" },
      { label: "Benefits & Programs", href: "/b2b/components/benefits-programs", icon: "Handshake" },
      { label: "Why TOV", href: "/b2b/components/why-tov", icon: "Info" },
    ],
  },
  {
    title: "Dashboard",
    items: [
      { label: "Elements", href: "/b2b/components/dashboard/elements", icon: "TextCursorInput" },
      { label: "Menu Panel", href: "/b2b/components/dashboard/menu-panel", icon: "PanelLeft" },
      { label: "Cards & Tiles", href: "/b2b/components/dashboard/cards-tiles", icon: "Layers" },
      { label: "Order Row", href: "/b2b/components/dashboard/order-row", icon: "ShoppingCart" },
      { label: "Contact Row", href: "/b2b/components/dashboard/contact-row", icon: "Mail" },
      { label: "Project Line Item", href: "/b2b/components/dashboard/project-line-item", icon: "ListChecks" },
      { label: "Tables", href: "/b2b/components/dashboard/tables", icon: "Columns3" },
      { label: "Page Header", href: "/b2b/components/dashboard/page-header", icon: "Type" },
      { label: "Dashboard Overview", href: "/b2b/components/dashboard/overview", icon: "Sparkle" },
      { label: "Track Orders Card", href: "/b2b/components/dashboard/track-orders-card", icon: "Package" },
      { label: "Saved Projects Strip", href: "/b2b/components/dashboard/saved-projects-strip", icon: "FolderOpen" },
      { label: "Form Card", href: "/b2b/components/dashboard/form-card", icon: "FileText" },
      { label: "Account Rep & Agent", href: "/b2b/components/dashboard/account-reps", icon: "UserCheck" },
    ],
  },
  {
    title: "Pages",
    items: [
      { label: "Homepage", href: "/b2b/pages/homepage", icon: "Megaphone" },
      { label: "Dashboard", href: "/b2b/pages/dashboard", icon: "LayoutGrid" },
    ],
  },
];

const AMAZON_SECTIONS: NavSection[] = [
  {
    title: "Get started",
    items: [{ label: "Overview", href: "/amazon", icon: "Home" }],
  },
  {
    title: "A+ Content",
    items: [
      { label: "Brand Story", href: "/amazon/a-plus-content/brand-story", icon: "BookOpen" },
      { label: "Category Hero", href: "/amazon/a-plus-content/category-hero", icon: "Image" },
      { label: "Materials Module", href: "/amazon/a-plus-content/materials-module", icon: "Layers" },
      { label: "Video Thumbnail Module", href: "/amazon/a-plus-content/video-thumbnail-module", icon: "Video" },
      { label: "Comfort & Construction", href: "/amazon/a-plus-content/comfort-construction", icon: "Hammer" },
      { label: "Sustainability Module", href: "/amazon/a-plus-content/sustainability-module", icon: "Leaf" },
      { label: "Collections Module", href: "/amazon/a-plus-content/collections-module", icon: "LayoutGrid" },
    ],
  },
  {
    title: "Amazon Store",
    items: [
      { label: "Storefront", href: "/amazon/store/storefront", icon: "PanelTop" },
      { label: "Best Seller Page", href: "/amazon/store/best-sellers", icon: "Star" },
      { label: "Category Pages", href: "/amazon/store/category-pages", icon: "Grid3x3" },
      { label: "Sub Category Components", href: "/amazon/store/subcategory-components", icon: "Image" },
      { label: "About Us", href: "/amazon/store/about-us", icon: "Info" },
    ],
  },
  // These are a first-pass menu from surveying the two source Figma files
  // (P6ISgCbxCzraEqRtTr0j3P for A+ Content, I95mnwwaoq0CvJOGop9tfn for the
  // Store) — real section/module names found in the files, not guessed.
  // Shay's component renaming pass in Figma is still in progress, so
  // treat these labels as a draft: cheap to rename here once naming
  // settles, unlike redoing a full component mapping.
];

/** Shared across every property — not product design-system content, just app tooling. */
const SHARED_SECTIONS: NavSection[] = [
  {
    title: "Imagery",
    items: [{ label: "Asset Library", href: "/assets", icon: "Images" }],
  },
  {
    title: "Developer Tools",
    items: [{ label: "Figma Image Export", href: "/tools/figma-image-export", icon: "Download" }],
  },
];

export const PROPERTIES: Property[] = [
  {
    key: "b2c",
    label: "TOV Design System",
    sublabel: "B2C",
    // Matches --color-primary exactly (#b15a63) — verified against the real
    // Figma fill, not a coincidence: this IS the site's primary mauve.
    badgeColor: "var(--color-primary)",
    panelBg: "var(--color-sidebar)",
    homeHref: "/",
    sections: [...B2C_SECTIONS, ...SHARED_SECTIONS],
  },
  {
    key: "amazon",
    label: "TOV Design System",
    sublabel: "Amazon",
    // Real fills from the Figma source (TOV27 - General Design System,
    // node 2:39, and its dark panel ancestor 2:20) — neither has an
    // existing token in this codebase yet, both B2C-specific colors.
    badgeColor: "#9ebac8",
    panelBg: "#2c2c2c",
    homeHref: "/amazon",
    sections: [...AMAZON_SECTIONS, ...SHARED_SECTIONS],
  },
  {
    key: "b2b",
    label: "TOV Design System",
    sublabel: "B2B",
    // Real token values from the file's own Foundations page (var(--tov-color-text-primary),
    // the same charcoal already in this app as --color-charcoal) — distinct from B2C's mauve
    // and Amazon's light blue so the switcher stays readable at a glance.
    badgeColor: "#3f3d3e",
    panelBg: "#262625",
    homeHref: "/b2b",
    sections: [...B2B_SECTIONS, ...SHARED_SECTIONS],
  },
];

/** Picks the active property from the current pathname (defaults to B2C, the root property). */
export function propertyForPathname(pathname: string): Property {
  const match = PROPERTIES.find((p) => p.key !== "b2c" && pathname.startsWith(`/${p.key}`));
  return match ?? PROPERTIES[0];
}
