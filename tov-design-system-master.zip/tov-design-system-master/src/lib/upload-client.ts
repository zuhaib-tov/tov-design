import { upload } from "@vercel/blob/client";
import type { AssetRecord } from "@/lib/asset-store";

/**
 * Confirms a just-uploaded blob is actually reachable before we record it.
 * Real incident: a handful of uploads (this tool's actual production
 * traffic) ended up with a recorded asset pointing at a URL that 404'd —
 * the client's own upload() call had already resolved successfully, so
 * whatever went wrong happened after that, out of our control to prevent
 * outright. What IS controllable is not staying quiet about it: without
 * this check, the dead link only surfaces much later, as a confusing
 * failure when someone tries to push it to Figma, with no way to tell
 * which upload caused it. A couple of retries with backoff absorbs the
 * normal brief propagation lag; if it's still unreachable after that, the
 * upload is reported as failed right here, immediately, so the person
 * uploading can just retry it themselves on the spot.
 */
async function verifyBlobReachable(url: string): Promise<boolean> {
  const delaysMs = [500, 1500, 3000];
  for (const delay of delaysMs) {
    await new Promise((r) => setTimeout(r, delay));
    try {
      const res = await fetch(url, { method: "HEAD", cache: "no-store" });
      if (res.ok) return true;
    } catch {
      // network hiccup — fall through and retry
    }
  }
  return false;
}

/**
 * Uploads files directly from the browser to Blob storage, then records
 * each one in the library's index. This bypasses the Next.js server route
 * entirely for the file bytes — a plain FormData POST hits Vercel's ~4.5MB
 * serverless function body limit after just a couple of real photos, which
 * is why uploads used to hang after the first two.
 *
 * Uploads sequentially (not in parallel) so a failure partway through is
 * easy to attribute to a specific file, and reports which files succeeded
 * so the caller can still show/keep those even if a later file fails.
 */
export async function uploadFilesToLibrary(
  files: FileList | File[],
  meta: {
    folder: string;
    tags?: string[];
    category?: "general" | "marketing";
    campaign?: string;
    pageType?: string;
  }
): Promise<{ uploaded: AssetRecord[]; errors: { fileName: string; message: string }[] }> {
  const uploaded: AssetRecord[] = [];
  const errors: { fileName: string; message: string }[] = [];

  for (const file of Array.from(files)) {
    try {
      const id = crypto.randomUUID();
      const ext = file.name.includes(".") ? file.name.split(".").pop() : "";
      const pathname = `assets/files/${id}${ext ? `.${ext}` : ""}`;
      const mimeType = file.type || "application/octet-stream";

      const blob = await upload(pathname, file, {
        access: "public",
        handleUploadUrl: "/api/assets/upload-token",
        contentType: mimeType,
      });

      const reachable = await verifyBlobReachable(blob.url);
      if (!reachable) {
        throw new Error("Upload didn't complete properly — please try this file again");
      }

      const res = await fetch("/api/assets/record", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          url: blob.url,
          filename: pathname,
          originalName: file.name,
          mimeType,
          size: file.size,
          folder: meta.folder,
          tags: meta.tags ?? [],
          category: meta.category,
          campaign: meta.campaign,
          pageType: meta.pageType,
        }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Failed to save (${res.status})`);
      }

      const data = await res.json();
      uploaded.push(data.asset);
    } catch (err) {
      errors.push({ fileName: file.name, message: (err as Error).message });
    }
  }

  return { uploaded, errors };
}
