import { put, del, list } from "@vercel/blob";
import crypto from "crypto";

/**
 * Vercel Blob-backed asset store for the imagery library.
 *
 * Vercel's deployed functions run on a read-only filesystem (aside from
 * /tmp, which isn't shared across invocations), so uploads can't live on
 * local disk in production — they need to go to real object storage. Every
 * route in app/api/assets/ only talks to the functions exported here.
 */

export interface AssetRecord {
  id: string;
  /** Blob store pathname for the file. */
  filename: string;
  /** Public URL for the file in Blob storage. */
  url: string;
  originalName: string;
  mimeType: string;
  size: number;
  tags: string[];
  folder: string;
  /** "marketing" uploads are organized by campaign + page type; "general" is a flat folder. */
  category: "general" | "marketing";
  campaign?: string;
  pageType?: string;
  /** Set once someone has requested this asset be placed into the Figma file. */
  figmaPushRequestedAt?: string;
  /** Set once the asset has actually been placed into Figma (via the Plugin API, run on request). */
  figmaPushedAt?: string;
  /**
   * Precise push target, set when a page's "Update images in Figma"
   * uploader is used to assign an exact slot (see src/lib/amazon/figma-slots.ts)
   * — a tighter alternative to the campaign-folder staging flow above,
   * for updating an already-mapped component's specific image slot.
   */
  figmaTargetFileKey?: string;
  /** Every node this asset fills — a slot can span more than one (e.g. a category's Desktop + Mobile variant). */
  figmaTargetNodeIds?: string[];
  figmaTargetLabel?: string;
  source:
    | { type: "upload" }
    | { type: "figma"; fileKey: string; fileName?: string; nodeId: string };
  createdAt: string;
}

// Each asset is its own blob (assets/records/<id>.json) rather than one
// shared array. An earlier version kept a single "index" blob holding every
// record, which meant ANY two writes close together in time — even to two
// completely unrelated assets — could race: both read the array, both wrote
// their own full copy back, and whichever write landed second silently
// erased the other's change. That wasn't theoretical; it happened
// repeatedly in real use (a push-completion marker getting reverted by an
// unrelated slot assignment written moments later). Per-asset blobs don't
// eliminate Vercel Blob's own propagation lag (a write can still take a
// moment to show up in reads), but they make that lag a per-record
// annoyance instead of a shared-array collision that can silently lose
// someone else's unrelated change.
const RECORDS_PREFIX = "assets/records/";
const BLOB_BASE_URL = "https://rqkq06lfhaxlqext.public.blob.vercel-storage.com/";

function recordPathname(id: string) {
  return `${RECORDS_PREFIX}${id}.json`;
}

/**
 * Vercel Blob reads aren't just laggy after a write (the propagation lag
 * documented elsewhere here) — they're genuinely inconsistent read to
 * read, full stop. Confirmed directly: a HEAD request 404'd on an asset,
 * and the very next GET, moments later, returned the complete, correct
 * file. Several uploads this session were written off as permanently
 * broken and told to be re-uploaded on exactly this evidence — a single
 * failed read — which in hindsight most likely weren't broken at all,
 * just unlucky about which read hit which edge replica. A short retry
 * with backoff costs nothing on the (common) success path and turns most
 * of these false negatives into non-events.
 */
async function fetchWithRetry(url: string, attempts = 3): Promise<Response> {
  let lastRes: Response | undefined;
  for (let i = 0; i < attempts; i++) {
    if (i > 0) await new Promise((r) => setTimeout(r, 300 * 2 ** (i - 1)));
    const res = await fetch(url, { cache: "no-store" });
    if (res.ok) return res;
    lastRes = res;
  }
  return lastRes!;
}

async function readRecord(id: string): Promise<AssetRecord | undefined> {
  const res = await fetchWithRetry(BLOB_BASE_URL + recordPathname(id));
  if (res.ok) return (await res.json()) as AssetRecord;
  if (res.status === 404) return undefined;

  const { blobs } = await list({ prefix: recordPathname(id), limit: 1 });
  const blob = blobs.find((b) => b.pathname === recordPathname(id));
  if (!blob) return undefined;
  const fallbackRes = await fetchWithRetry(blob.url);
  if (!fallbackRes.ok) return undefined;
  return (await fallbackRes.json()) as AssetRecord;
}

async function writeRecord(record: AssetRecord) {
  await put(recordPathname(record.id), JSON.stringify(record, null, 2), {
    access: "public",
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: "application/json",
  });
}

export async function listAssets(): Promise<AssetRecord[]> {
  const { blobs } = await list({ prefix: RECORDS_PREFIX, limit: 1000 });
  const records = await Promise.all(
    blobs.map(async (b) => {
      const res = await fetchWithRetry(b.url);
      if (!res.ok) return undefined;
      return (await res.json()) as AssetRecord;
    })
  );
  return records
    .filter((r): r is AssetRecord => !!r)
    // Older records predate the general/marketing split — default them to "general".
    .map((r) => ({ ...r, category: r.category ?? "general" }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getAsset(id: string): Promise<AssetRecord | undefined> {
  return readRecord(id);
}

export async function getAssetBuffer(record: AssetRecord): Promise<Buffer> {
  const res = await fetchWithRetry(record.url);
  if (!res.ok) throw new Error(`Failed to fetch asset from storage (${res.status})`);
  return Buffer.from(await res.arrayBuffer());
}

/** Uploads file bytes server-side (used for the Figma-sync import, which renders images server-side). */
export async function saveAsset(input: {
  buffer: Buffer;
  originalName: string;
  mimeType: string;
  tags: string[];
  folder: string;
  category?: AssetRecord["category"];
  campaign?: string;
  pageType?: string;
  source: AssetRecord["source"];
}): Promise<AssetRecord> {
  const id = crypto.randomUUID();
  const ext = input.originalName.includes(".") ? input.originalName.split(".").pop() : "";
  const pathname = `assets/files/${id}${ext ? `.${ext}` : ""}`;

  const blob = await put(pathname, input.buffer, {
    access: "public",
    addRandomSuffix: false,
    contentType: input.mimeType,
  });

  return recordAsset({
    id,
    filename: pathname,
    url: blob.url,
    originalName: input.originalName,
    mimeType: input.mimeType,
    size: input.buffer.length,
    tags: input.tags,
    folder: input.folder,
    category: input.category,
    campaign: input.campaign,
    pageType: input.pageType,
    source: input.source,
  });
}

/**
 * Records an asset that was already uploaded directly to Blob storage from
 * the browser (see @vercel/blob/client's upload() + /api/assets/upload-token
 * — this is how the Asset Library actually uploads user files, bypassing the
 * ~4.5MB request body limit on Vercel serverless functions that a plain
 * FormData POST to a server route would hit for real photos).
 */
export async function recordAsset(input: {
  id: string;
  filename: string;
  url: string;
  originalName: string;
  mimeType: string;
  size: number;
  tags: string[];
  folder: string;
  category?: AssetRecord["category"];
  campaign?: string;
  pageType?: string;
  source: AssetRecord["source"];
}): Promise<AssetRecord> {
  const record: AssetRecord = {
    id: input.id,
    filename: input.filename,
    url: input.url,
    originalName: input.originalName,
    mimeType: input.mimeType,
    size: input.size,
    tags: input.tags,
    folder: input.folder || "Uncategorized",
    category: input.category ?? "general",
    campaign: input.campaign,
    pageType: input.pageType,
    source: input.source,
    createdAt: new Date().toISOString(),
  };

  await writeRecord(record);
  return record;
}

type AssetPatch = Partial<
  Pick<
    AssetRecord,
    | "figmaPushRequestedAt"
    | "figmaPushedAt"
    | "figmaTargetFileKey"
    | "figmaTargetNodeIds"
    | "figmaTargetLabel"
  >
>;

/**
 * Each id's record is its own blob, so patching several ids just means
 * patching each one's own record independently — no shared array, no risk
 * of one id's write erasing an unrelated id's write.
 */
export async function updateAssets(ids: string[], patch: AssetPatch): Promise<AssetRecord[]> {
  const results = await Promise.all(
    ids.map(async (id) => {
      const current = await readRecord(id);
      if (!current) return undefined;
      const merged = { ...current, ...patch };
      await writeRecord(merged);
      return merged;
    })
  );
  return results.filter((r): r is AssetRecord => !!r);
}

/**
 * Same idea as updateAssets, but self-healing against this record's own
 * propagation lag: if the read can't find it yet (very possible seconds
 * after its own upload, or if this is the record's first write), falls
 * back to the caller's own copy instead of failing outright — the caller
 * only has that copy because their own earlier upload/list call already
 * succeeded, so it's trustworthy. `patch` always wins over both. Fixed a
 * real bug where assigning a Figma slot right after uploading could 404.
 */
export async function upsertAssetPatch(
  fallback: AssetRecord,
  patch: AssetPatch
): Promise<AssetRecord> {
  const current = await readRecord(fallback.id);
  const merged: AssetRecord = { ...(current ?? {}), ...fallback, ...patch };
  await writeRecord(merged);
  return merged;
}

export async function deleteAsset(id: string): Promise<boolean> {
  const record = await readRecord(id);
  if (!record) return false;

  await del(record.url);
  await del(BLOB_BASE_URL + recordPathname(id));
  return true;
}
