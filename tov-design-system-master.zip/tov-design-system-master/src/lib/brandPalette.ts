/**
 * TOV's full named brand palette — the source palette every functional UI
 * token in src/lib/tokens.ts maps onto (e.g. --color-primary = Rouge,
 * --color-charcoal = Not black).
 */

export interface PaletteColor {
  name: string;
  value: string;
  mapsTo?: string; // a functional token in tokens.ts, if this color is already in use
}

export interface PaletteGroup {
  title: string;
  description: string;
  colors: PaletteColor[];
}

export const BRAND_PALETTE: PaletteGroup[] = [
  {
    title: "Primary",
    description:
      "Most prominent in the UI — used for key interactive elements to guide user actions and anchor the brand's visual identity.",
    colors: [
      { name: "Cream", value: "#FEFBF6", mapsTo: "cream-50" },
      { name: "Soft taupe", value: "#F1ECE5", mapsTo: "cream-200" },
      { name: "Stone", value: "#CFC3C3" },
      { name: "Terracotta", value: "#C4A092" },
      { name: "Truffle", value: "#82736C", mapsTo: "truffle" },
    ],
  },
  {
    title: "Secondary",
    description:
      "Complements primary colors in secondary actions and UI accents — enhances visual interest without overshadowing primary colors.",
    colors: [
      { name: "Mauve", value: "#BB7A7E" },
      { name: "Ritual", value: "#9EBAC8" },
      { name: "Mint", value: "#B5CCC2" },
      { name: "Lagoon", value: "#7B8675" },
      { name: "Forest", value: "#485B59" },
      { name: "Lavendar", value: "#A39AAD" },
      { name: "Pebble", value: "#99979C" },
      { name: "Golden", value: "#805E39" },
      { name: "Sunshine", value: "#CCB583" },
    ],
  },
  {
    title: "Tertiary",
    description:
      "An extended range for nuanced design expression — depth, mood, and variety beyond the core primary/secondary pair.",
    colors: [
      { name: "Rouge", value: "#B15A63", mapsTo: "primary" },
      { name: "Bold lip", value: "#713A40" },
      { name: "Rosewood", value: "#8A5955" },
      { name: "Rose", value: "#AB8A81" },
      { name: "Chocolate", value: "#645248" },
      { name: "Not black", value: "#3F3D3E", mapsTo: "charcoal" },
      { name: "Muse", value: "#867A86" },
      { name: "Impression", value: "#6A596B" },
      { name: "Essence", value: "#DADCDB" },
      { name: "Teal", value: "#1D3037" },
      { name: "Earth", value: "#5B5E4B" },
      { name: "Storm", value: "#3F4B59" },
      { name: "River", value: "#5F7F8E" },
      { name: "Burnt umber", value: "#5B3630" },
      { name: "Caramel", value: "#9E8567" },
      { name: "Fog", value: "#DBCEC6" },
    ],
  },
  {
    title: "Neutral",
    description:
      "Text, backgrounds, and form elements — the core of the color system, from light to dark.",
    colors: [
      { name: "Neutral/100", value: "#FFFFFF" },
      { name: "Neutral/200", value: "#E8E8E8" },
      { name: "Neutral/300", value: "#D2D2D2" },
      { name: "Neutral/400", value: "#BBBBBB" },
      { name: "Neutral/500", value: "#A4A4A4" },
      { name: "Neutral/600", value: "#8E8E8E" },
      { name: "Neutral/700", value: "#777777" },
      { name: "Neutral/800", value: "#606060" },
      { name: "Neutral/900", value: "#4A4A4A" },
      { name: "Neutral/1000", value: "#333333" },
    ],
  },
  {
    title: "Status (Red / Green / Yellow)",
    description:
      "Alert, error, success, and warning ramps — each with 4 steps (100 lightest → 200 boldest).",
    colors: [
      { name: "Red/100", value: "#FB3748" },
      { name: "Red/150", value: "#F0858D" },
      { name: "Red/175", value: "#E31E2D" },
      { name: "Red/200", value: "#D00416" },
      { name: "Green/100", value: "#84EBB4" },
      { name: "Green/150", value: "#6FDEA3" },
      { name: "Green/175", value: "#2BBC6F" },
      { name: "Green/200", value: "#1FC16B" },
      { name: "Yellow/100", value: "#F2E092" },
      { name: "Yellow/150", value: "#FFDB43" },
      { name: "Yellow/175", value: "#E5C126" },
      { name: "Yellow/200", value: "#DFB400" },
    ],
  },
];
