/**
 * Upcoming campaign list for Marketing Uploads, pulled from the page titles
 * in the "TOV26 - Homepage - Imagery" Figma file
 * (RrOSKZ0YfSCDlzMLGu49SH), starting at "Fall Flash Sale - 10/05" and
 * continuing through every campaign scheduled after it, in date order.
 * `figmaPageId` is that same file's page (canvas) id, for pushing uploaded
 * images into the right page.
 */
export const MARKETING_FIGMA_FILE_KEY = "RrOSKZ0YfSCDlzMLGu49SH";

export const MARKETING_CAMPAIGNS = [
  { name: "Fall Flash Sale - 10/05", figmaPageId: "6447:7253" },
  { name: "Fall Banner Pt 5 - 10/13", figmaPageId: "6454:7262" },
  { name: "Winter Banner Pt 1 - 10/28", figmaPageId: "6454:7263" },
  { name: "BFCM Phase 1 - 11/09", figmaPageId: "6454:7254" },
  { name: "BFCM Phase 2 - 11/25", figmaPageId: "6454:7255" },
  { name: "Winter Banner Pt 2 - 12/02", figmaPageId: "6454:7264" },
  { name: "Winter Event - TBD", figmaPageId: "6454:7256" },
  { name: "Winter Banner Pt 2 - 12/17", figmaPageId: "6454:7265" },
  { name: "New Years - 12/26", figmaPageId: "6454:7257" },
] as const;

export const MARKETING_CAMPAIGN_NAMES = MARKETING_CAMPAIGNS.map((c) => c.name);

export function campaignFigmaPageId(name: string): string | undefined {
  return MARKETING_CAMPAIGNS.find((c) => c.name === name)?.figmaPageId;
}

export const MARKETING_PAGE_TYPES = ["Homepage", "New Arrivals", "Edits"] as const;

export type MarketingPageType = (typeof MARKETING_PAGE_TYPES)[number];

export function marketingFolder(campaign: string, pageType: string): string {
  return `Marketing/${campaign}/${pageType}`;
}
