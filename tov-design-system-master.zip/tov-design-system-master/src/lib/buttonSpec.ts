/**
 * Button measurements and state colors, written as they are coded. The Button
 * component, the Button page and the dev handoff all read from here.
 *
 * Every size has a fixed height, and the label is centered in it, so vertical
 * padding is the same on every button of a size. The only padding that changes
 * is horizontal: it is the space either side of the label, never less than the
 * minimum below, and it grows when the button is wider than its label.
 */

export interface ButtonSize {
  key: "lg" | "md" | "sm";
  name: string;
  /** Fixed height in px, border included. */
  height: number;
  /** Minimum horizontal padding on each side of the label. */
  padX: number;
  /** Font size and line height in px. Weight is Bold, text is uppercase. */
  font: number;
  line: number;
  /** Gap between an icon and the label. */
  gap: number;
  use: string;
}

export const BUTTON_BORDER = 1;
/** +4.5% of the font size, set on every button label. */
export const BUTTON_TRACKING = "0.045em";

export const BUTTON_SIZES: ButtonSize[] = [
  { key: "lg", name: "Large", height: 54, padX: 24, font: 14, line: 16, gap: 10, use: "Primary call to action on a page or in a module: Add to cart, Shop now, Checkout." },
  { key: "md", name: "Medium", height: 42, padX: 24, font: 14, line: 16, gap: 8, use: "In-flow actions in compact layouts, such as Back and Next on a Mobile form step." },
  { key: "sm", name: "Small", height: 33, padX: 16, font: 12, line: 14, gap: 6, use: "Compact actions inside a product card or a list row: Quick add, Edit." },
];

export interface ButtonScreen {
  key: "desktop" | "tablet" | "mobile";
  label: string;
  from: string;
  /** Page margin from the spacing scale, px. */
  margin: number;
  /** The size a Primary button uses by default on this screen. */
  primary: "lg" | "md";
  /** When the other size is used instead. */
  primaryNote: string;
  large: string;
  medium: string;
  small: string;
}

/** What changes between screens. The three sizes keep their height and side padding; the width and the size chosen change. */
export const BUTTON_SCREENS: ButtonScreen[] = [
  {
    key: "desktop",
    label: "Desktop",
    from: "1024px and up",
    margin: 100,
    primary: "lg",
    primaryNote: "Large is the default for every call to action. Use Small only inside a card or a list row.",
    large: "54px tall, 24px minimum side padding. Hugs the label, or takes a column width such as 274, 346 or 552.",
    medium: "42px tall, 24px side padding. Hugs the label.",
    small: "33px tall, 16px side padding. Hugs the label.",
  },
  {
    key: "tablet",
    label: "Tablet",
    from: "768px to 1023px",
    margin: 32,
    primary: "lg",
    primaryNote: "Same as Desktop: Large is the default. Use Small only inside a card or a list row.",
    large: "54px tall, 24px minimum side padding. Hugs the label, or fills a card or column.",
    medium: "42px tall, 24px side padding. Hugs the label.",
    small: "33px tall, 16px side padding. Hugs the label.",
  },
  {
    key: "mobile",
    label: "Mobile",
    from: "under 768px",
    margin: 20,
    primary: "md",
    primaryNote: "Medium is the default. Use Large only when the button is the one action on the screen and fills the full width.",
    large: "54px tall, same padding. Fills the container: 335px wide on a 375px screen (375 minus 20px margin on each side).",
    medium: "42px tall, same padding. Back and Next sit side by side, each half of the row (about 138px each in a 295px row with a 20px gap).",
    small: "33px tall, same padding. Hugs the label.",
  },
];

export interface ButtonUseCase {
  scenario: string;
  style: string;
  size: string;
  desktop: string;
  mobile: string;
}

export const BUTTON_USE_CASES: ButtonUseCase[] = [
  { scenario: "Add to cart on a product page", style: "Primary", size: "Large", desktop: "Fills the details panel beside the 54px wishlist circle, 5px gap.", mobile: "The fixed bar at the bottom of the screen. See the PDP page." },
  { scenario: "Hero or banner call to action (Shop now, Join now)", style: "Primary, or Inverse on photography", size: "Large", desktop: "Large, hugs the label.", mobile: "Medium, hugs the label." },
  { scenario: "Cart actions (Checkout, View cart)", style: "Primary and Tertiary", size: "Large", desktop: "Fills the cart column. Primary above Tertiary, 10px apart.", mobile: "Fills the screen width." },
  { scenario: "Back and Next on a form step", style: "Primary for Next, a text link for Back", size: "Large on Desktop, Medium on Mobile", desktop: "Large, 54px.", mobile: "Medium, 42px, side by side." },
  { scenario: "Final submit (Submit claim, Back to summary)", style: "Primary", size: "Large, 16px label", desktop: "473px wide.", mobile: "Fills the screen width, 335px." },
  { scenario: "Quick add on a product card", style: "Tertiary", size: "Small", desktop: "Hugs the label, centered in the card.", mobile: "Hugs the label, centered in the card." },
  { scenario: "Edit on an account row", style: "Tertiary, or Primary when it is the one action", size: "Small", desktop: "Hugs the label, aligned right.", mobile: "Hugs the label, aligned right." },
  { scenario: "A third action next to a primary (Learn more)", style: "Tertiary", size: "Large or Medium to match the primary", desktop: "Large, same size as the primary beside it.", mobile: "Medium, same size as the primary, stacked under it." },
];

export interface StateColors {
  bg: string;
  text: string;
  border: string;
}

export interface ButtonVariantSpec {
  key: "primary" | "secondary" | "tertiary" | "inverse";
  name: string;
  surface: "light" | "dark";
  use: string;
  default: StateColors;
  /** Hover and pressed share one set of colors. */
  hover: StateColors;
  /** Focus ring color (2px, 2px offset). */
  focus: string;
}

export const BUTTON_VARIANTS: ButtonVariantSpec[] = [
  {
    key: "primary",
    name: "Primary",
    surface: "light",
    use: "The one main action in a view. Use at most one per screen area.",
    default: { bg: "#3F3D3E", text: "#FFFFFF", border: "#3F3D3E" },
    hover: { bg: "#FEFBF6", text: "#3F3D3E", border: "#3F3D3E" },
    focus: "#3F3D3E",
  },
  {
    key: "secondary",
    name: "Secondary",
    surface: "light",
    use: "A supporting action next to a primary, or a main action on a cream or white section.",
    default: { bg: "#F9D2D2", text: "#3F3D3E", border: "transparent" },
    hover: { bg: "#3F3D3E", text: "#FFFFFF", border: "transparent" },
    focus: "#3F3D3E",
  },
  {
    key: "tertiary",
    name: "Tertiary",
    surface: "light",
    use: "Low-emphasis outline for a third action: Learn more, View cart.",
    default: { bg: "#FEFBF6", text: "#3F3D3E", border: "#3F3D3E" },
    hover: { bg: "#3F3D3E", text: "#FFFFFF", border: "#3F3D3E" },
    focus: "#3F3D3E",
  },
  {
    key: "inverse",
    name: "Inverse",
    surface: "dark",
    use: "The outline button on photography and dark sections: white border and label.",
    default: { bg: "transparent", text: "#FFFFFF", border: "#FFFFFF" },
    hover: { bg: "#FFFFFF", text: "#3F3D3E", border: "#FFFFFF" },
    focus: "#FFFFFF",
  },
];

export const DISABLED_OPACITY = 0.5;

export interface TextLinkSize {
  key: "lg" | "md" | "sm";
  name: string;
  font: number;
  line: number;
}

export const TEXT_LINK_SIZES: TextLinkSize[] = [
  { key: "lg", name: "Large", font: 16, line: 18 },
  { key: "md", name: "Medium", font: 14, line: 16 },
  { key: "sm", name: "Small", font: 12, line: 14 },
];
