/**
 * TOV B2C type specification. One heading family (GT Ultra Fine) and one
 * text family (Montserrat), four groups of styles, and a single tracking rule:
 * letter-spacing is 0 on all text except button text and all-caps text, which
 * use TRACKING_CAPS.
 */

export type Weight = "Light" | "Regular" | "Medium" | "SemiBold" | "Bold";

export const WEIGHT_VALUE: Record<Weight, number> = {
  Light: 300,
  Regular: 400,
  Medium: 500,
  SemiBold: 600,
  Bold: 700,
};

/** The only letter-spacing in the system: all-caps text and button text. */
export const TRACKING_CAPS = "0.045em";

export interface TypeStyle {
  name: string;
  fontFamily: "GT Ultra Fine" | "Montserrat";
  weight: Weight;
  size: number;
  lineHeight: number;
  uppercase?: boolean;
  capitalize?: boolean;
  underline?: boolean;
  usage: string;
}

/** Screen sizes a heading is specified for. Mobile is the base; Tablet and Desktop apply from these widths up. */
export const BREAKPOINTS = { tablet: 768, desktop: 1024 } as const;

export interface ResponsiveSize {
  size: number;
  lineHeight: number;
}

export interface HeadingStyle extends TypeStyle {
  /** Desktop (from 1024px) is the style's own size and line-height. */
  tablet: ResponsiveSize;
  mobile: ResponsiveSize;
}

/**
 * Every heading has a Desktop, Tablet and Mobile size. Desktop is the Figma
 * style. Mobile runs at roughly 0.6 of Desktop for display sizes, easing to 0.9
 * for the smallest heading, and Tablet sits at the midpoint. Each level is
 * smaller than the one above on every screen, and no heading drops below 20px
 * on Mobile so it stays clearly larger than 16px body copy.
 */
export const HEADINGS: HeadingStyle[] = [
  { name: "H1", fontFamily: "GT Ultra Fine", weight: "Regular", size: 68, lineHeight: 70, tablet: { size: 52, lineHeight: 56 }, mobile: { size: 40, lineHeight: 44 }, usage: "Promotional display — landing-page and campaign openers." },
  { name: "H2", fontFamily: "GT Ultra Fine", weight: "Regular", size: 60, lineHeight: 68, tablet: { size: 46, lineHeight: 50 }, mobile: { size: 36, lineHeight: 40 }, usage: "Promotional display — large campaign statements." },
  { name: "H3", fontFamily: "GT Ultra Fine", weight: "Regular", size: 56, lineHeight: 62, tablet: { size: 42, lineHeight: 46 }, mobile: { size: 32, lineHeight: 36 }, usage: "Promotional display — banner and hero headlines." },
  { name: "H4", fontFamily: "GT Ultra Fine", weight: "Regular", size: 46, lineHeight: 50, tablet: { size: 36, lineHeight: 40 }, mobile: { size: 28, lineHeight: 32 }, usage: "Page title (collection pages) and primary homepage section headings." },
  { name: "H5", fontFamily: "GT Ultra Fine", weight: "Regular", size: 38, lineHeight: 42, tablet: { size: 30, lineHeight: 34 }, mobile: { size: 24, lineHeight: 28 }, usage: "Product title and major section headings." },
  { name: "H6", fontFamily: "GT Ultra Fine", weight: "Regular", size: 26, lineHeight: 30, tablet: { size: 24, lineHeight: 28 }, mobile: { size: 22, lineHeight: 25 }, usage: "Module titles — Pair it With, You May Also Like, Best Sellers." },
  { name: "H7", fontFamily: "GT Ultra Fine", weight: "Regular", size: 22, lineHeight: 25, tablet: { size: 22, lineHeight: 25 }, mobile: { size: 20, lineHeight: 24 }, usage: "Minor headings." },
];

/** Montserrat body copy: every size carries a 1.5 line-height. */
export const BODY: TypeStyle[] = [
  { name: "B1", fontFamily: "Montserrat", weight: "Regular", size: 18, lineHeight: 27, usage: "Introductory and lede paragraphs." },
  { name: "B2", fontFamily: "Montserrat", weight: "Regular", size: 16, lineHeight: 24, usage: "Default body copy and product descriptions." },
  { name: "B3", fontFamily: "Montserrat", weight: "Regular", size: 14, lineHeight: 21, usage: "Secondary copy — specs, lists, captions, form text." },
  { name: "B4", fontFamily: "Montserrat", weight: "Regular", size: 12, lineHeight: 18, usage: "Fine print — footer, legal, shipping notes." },
  { name: "B5", fontFamily: "Montserrat", weight: "Regular", size: 10, lineHeight: 15, usage: "Smallest supporting text — micro-captions." },
];

/** Montserrat all-caps labels and button text. These, and only these, carry TRACKING_CAPS. */
export const LABELS: TypeStyle[] = [
  { name: "Label/L", fontFamily: "Montserrat", weight: "SemiBold", size: 20, lineHeight: 24, uppercase: true, usage: "Category and collection card titles." },
  { name: "Label/M", fontFamily: "Montserrat", weight: "Bold", size: 14, lineHeight: 16, uppercase: true, usage: "Buttons and calls to action — Shop Now, Join Now. Same as Button/Large." },
  { name: "Label/S", fontFamily: "Montserrat", weight: "Bold", size: 12, lineHeight: 14, uppercase: true, usage: "Small buttons, promo bars and eyebrows — Add to Cart, Quick View. Same as Button/Small." },
  { name: "Badge/Medium", fontFamily: "Montserrat", weight: "Bold", size: 10, lineHeight: 15, uppercase: true, usage: "Badge text on desktop — New Arrival, Sale, Final Sale (27px tall badge)." },
  { name: "Badge/Small", fontFamily: "Montserrat", weight: "Bold", size: 8, lineHeight: 11, uppercase: true, usage: "Badge text on mobile (19px tall badge)." },
];

/** Montserrat interface text in sentence or title case. No tracking. */
export const UI_TEXT: TypeStyle[] = [
  { name: "Nav/Link", fontFamily: "Montserrat", weight: "Medium", size: 13, lineHeight: 14, capitalize: true, usage: "Primary navigation links; the active link uses Bold." },
  { name: "Product/Name", fontFamily: "Montserrat", weight: "Medium", size: 12, lineHeight: 18, capitalize: true, usage: "Product names on cards and grids." },
  { name: "Price/L", fontFamily: "Montserrat", weight: "Bold", size: 18, lineHeight: 21, usage: "Price on the product page." },
  { name: "Price/S", fontFamily: "Montserrat", weight: "Bold", size: 13, lineHeight: 16, usage: "Price on cards and grids; the struck-through regular price uses Regular." },
];

/** Underlined text links. CTA is bold caps with TRACKING_CAPS; Inline is regular with no tracking. */
export const TEXT_LINKS: TypeStyle[] = [
  { name: "Text link/CTA/Large", fontFamily: "Montserrat", weight: "Bold", size: 16, lineHeight: 18, uppercase: true, underline: true, usage: "Call to action, Large — class tov-link tov-link--cta tov-link--lg." },
  { name: "Text link/CTA/Medium", fontFamily: "Montserrat", weight: "Bold", size: 14, lineHeight: 16, uppercase: true, underline: true, usage: "Call to action, Medium (default) — class tov-link tov-link--cta." },
  { name: "Text link/CTA/Small", fontFamily: "Montserrat", weight: "Bold", size: 12, lineHeight: 14, uppercase: true, underline: true, usage: "Call to action, Small — class tov-link tov-link--cta tov-link--sm." },
  { name: "Text link/Inline/Large", fontFamily: "Montserrat", weight: "Regular", size: 16, lineHeight: 18, underline: true, usage: "Link inside a sentence, Large — class tov-link tov-link--inline tov-link--lg." },
  { name: "Text link/Inline/Medium", fontFamily: "Montserrat", weight: "Regular", size: 14, lineHeight: 16, underline: true, usage: "Link inside a sentence, Medium (default) — class tov-link tov-link--inline." },
  { name: "Text link/Inline/Small", fontFamily: "Montserrat", weight: "Regular", size: 12, lineHeight: 14, underline: true, usage: "Link inside a sentence, Small — class tov-link tov-link--inline tov-link--sm." },
];

/**
 * The CSS class for a text style, written the way a developer adds it:
 * H1 to H7 are responsive (Desktop, Tablet and Mobile in one class), Body is
 * type-b1 to type-b5, and the text links use the tov-link classes.
 */
export function typeClass(name: string): string {
  let m = name.match(/^H(\d)$/);
  if (m) return `type-h${m[1]}`;
  m = name.match(/^B(\d)$/);
  if (m) return `type-b${m[1]}`;
  const fixed: Record<string, string> = {
    "Label/L": "type-label-l",
    "Label/M": "type-label-m",
    "Label/S": "type-label-s",
    "Badge/Medium": "type-badge-md",
    "Badge/Small": "type-badge-sm",
    "Nav/Link": "type-nav-link",
    "Product/Name": "type-product-name",
    "Price/L": "type-price-l",
    "Price/S": "type-price-s",
  };
  if (fixed[name]) return fixed[name];
  m = name.match(/^Text link\/(CTA|Inline)\/(Large|Medium|Small)$/);
  if (m) return `tov-link tov-link--${m[1].toLowerCase()}${m[2] === "Large" ? " tov-link--lg" : m[2] === "Small" ? " tov-link--sm" : ""}`;
  return "";
}

export const WEIGHT_USAGE: { weight: Weight; usage: string }[] = [
  { weight: "Light", usage: "Long bullet lists and extended descriptions." },
  { weight: "Regular", usage: "Default for all body copy and GT Ultra Fine headings." },
  { weight: "Medium", usage: "Navigation, product names and badges." },
  { weight: "SemiBold", usage: "Category card titles." },
  { weight: "Bold", usage: "Buttons, prices, labels and inline emphasis." },
];
