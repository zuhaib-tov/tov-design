import type { ChangeLogEntry } from "../changelog";

const OG_URL = "https://www.figma.com/design/DTjIdCKhnDUVvJhEfpn10v";
const BASELINE = "Mapped from Figma; tracking baseline recorded.";
const DATE = "2026-10-08";

function email(component: string, nodeId: string): ChangeLogEntry {
  return {
    page: "marketing-email",
    component,
    status: "draft",
    summary: BASELINE,
    date: DATE,
    figmaUrl: `${OG_URL}?node-id=${nodeId.replace(":", "-")}`,
  };
}

export const OG_ADDITIONS_CHANGELOG: ChangeLogEntry[] = [
  {
    page: "layout",
    component: "Grid Export Sheet (12/8/4 column grid)",
    status: "new",
    summary: BASELINE,
    date: DATE,
    figmaUrl: `${OG_URL}?node-id=55-341`,
  },
  {
    page: "iconography",
    component: "Ecommerce icons",
    status: "new",
    summary: BASELINE,
    date: DATE,
    figmaUrl: `${OG_URL}?node-id=230-3249`,
  },
  email("Hero", "1753:460"),
  email("Category Cards", "1754:458"),
  email("Image Grid", "1754:473"),
  email("Product Cards", "1755:498"),
  email("Banner", "1756:468"),
  email("Content Block", "1757:476"),
  email("Announcement Bar", "1760:619"),
  email("Text Block", "1760:650"),
  email("Sign-off", "1760:665"),
  email("Cart Reminder", "1761:677"),
  email("Incentive", "1761:696"),
  email("Styled By You", "1761:713"),
  {
    page: "homepage",
    component: "Page layout (Desktop)",
    status: "new",
    summary: BASELINE,
    date: "2026-10-21",
    figmaUrl: `${OG_URL}?node-id=1686-1375`,
  },
  {
    page: "homepage",
    component: "Page layout (Mobile)",
    status: "new",
    summary: BASELINE,
    date: "2026-10-21",
    figmaUrl: `${OG_URL}?node-id=1686-1493`,
  },
];
