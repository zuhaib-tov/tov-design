import type { ChangeLogEntry } from "../changelog";

const DATE = "2026-10-08";
const SUMMARY = "Mapped from Figma; tracking baseline recorded.";

export const PDP_EDITORIAL_CHANGELOG: ChangeLogEntry[] = [
  {
    page: "new-arrivals",
    component: "New Arrivals page (Desktop + Mobile frames)",
    status: "draft",
    summary: SUMMARY,
    date: DATE,
    figmaUrl: "https://www.figma.com/design/tefhO0Dx4CNYT09diRqfB2?node-id=8005-9839",
  },
  {
    page: "editorial-collection",
    component: "Collections Landing page (Desktop + Mobile frames)",
    status: "draft",
    summary: SUMMARY,
    date: DATE,
    figmaUrl: "https://www.figma.com/design/oO2Li1XutYUUAgUUs4f3lJ?node-id=6084-479",
  },
  {
    page: "editorial-collection",
    component: "Collection Individual Page (Desktop + Mobile frames)",
    status: "draft",
    summary: SUMMARY,
    date: DATE,
    figmaUrl: "https://www.figma.com/design/9xYNBPcAsKBOCCGP5X6wJ9?node-id=2159-2815",
  },
  {
    page: "tov-edits",
    component: "TOV Edits Directory page (Desktop + Mobile frames)",
    status: "draft",
    summary: SUMMARY,
    date: DATE,
    figmaUrl: "https://www.figma.com/design/PXf8n9b6WW5X5ZkYqiykJH?node-id=8015-1447",
  },
  {
    page: "tov-edits",
    component: "TOV Edits individual Edit page (Desktop + Mobile frames)",
    status: "draft",
    summary: SUMMARY,
    date: DATE,
    figmaUrl: "https://www.figma.com/design/PXf8n9b6WW5X5ZkYqiykJH?node-id=8023-4971",
  },
];
