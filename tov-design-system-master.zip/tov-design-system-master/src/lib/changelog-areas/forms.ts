import type { ChangeLogEntry } from "../changelog";

const CLAIMS_URL = "https://www.figma.com/design/fAR8Q5JFFhzwMVslVENoHr";
const BASELINE = "Mapped from Figma; tracking baseline recorded.";
const DATE = "2026-10-19";

function entry(component: string, nodeId: string): ChangeLogEntry {
  return {
    page: "form-fields",
    component,
    status: "new",
    summary: BASELINE,
    date: DATE,
    figmaUrl: `${CLAIMS_URL}?node-id=${nodeId.replace(":", "-")}`,
  };
}

export const FORMS_CHANGELOG: ChangeLogEntry[] = [
  entry("Input field (label, placeholder, filled box)", "3827:7452"),
  entry("Textarea with helper text", "3381:3144"),
  entry("Checkbox with label", "3381:4961"),
  entry("Checkbox group", "3381:4970"),
  entry("Option card, default", "3381:3017"),
  entry("Option card, selected", "3381:3024"),
  entry("Product option card", "3381:3010"),
  entry("File upload zone", "3381:3465"),
  entry("Progress bar", "3381:4977"),
  entry("Summary row", "3381:4220"),
  entry("Form step card", "3381:4942"),
  {
    page: "form-fields",
    component: "Viewport measurements",
    status: "updated",
    summary: "Measured the claims form at Mobile (375px) and Desktop (1440px). Fields are 295 x 54px on Mobile and 460 x 54px on Desktop; the card is 335px and 500px; the file upload is 103px and 263px tall; the review row is 59px and 79px; intro text is 16/19 and 18/24. Option, product, upload, review and card components take a viewport prop, and the page shows each at its real size. Rendered heights now equal the Figma heights (borders sit inside the size).",
    date: "2026-10-22",
    figmaUrl: `${CLAIMS_URL}?node-id=1-5`,
  },
];
