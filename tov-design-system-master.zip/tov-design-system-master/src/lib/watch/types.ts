export interface WatchItem {
  id: string;
  label: string;
  fileKey: string;
  nodeId: string;
  figmaUrl: string;
}
