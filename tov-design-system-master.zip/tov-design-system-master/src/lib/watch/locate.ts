import { CHANGELOG } from "../changelog";
import { WATCH_LIST } from "../figma-watch";
import { PAGE_MAP } from "./page-map";

export interface WatchLocation {
  route: string;
  title: string;
}

function parseNode(url?: string): { file: string; node: string } | null {
  const m = url?.match(/design\/([A-Za-z0-9]+)[^?]*\?[^#]*node-id=([0-9]+)-([0-9]+)/);
  return m ? { file: m[1], node: `${m[2]}:${m[3]}` } : null;
}


/**
 * Fallback for watched pieces whose Figma node differs from the node recorded in their change-tracking entry:
 * the first matching id prefix names the page that shows them.
 */
const FALLBACK: [prefix: string, page: WatchLocation][] = [
  ["pdp-", { route: "/pages/product", title: "PDP" }],
  ["editorial-new-arrivals", { route: "/pages/editorial/new-arrivals", title: "New Arrivals" }],
  ["editorial-collection", { route: "/pages/editorial/collection", title: "Collection" }],
  ["editorial-tov-edits", { route: "/pages/editorial/tov-edits", title: "TOV Edits" }],
  ["og-homepage-", { route: "/pages/homepage", title: "Homepage & Marketing" }],
  ["homepage-", { route: "/pages/homepage", title: "Homepage & Marketing" }],
  ["nav-", { route: "/components/navigation", title: "Main Navigation" }],
  ["og-nav", { route: "/components/navigation", title: "Main Navigation" }],
  ["og-icons-", { route: "/foundations/iconography", title: "Iconography" }],
  ["og-core-brand-palette", { route: "/foundations/color", title: "Color" }],
  ["brand-color-palette", { route: "/foundations/color", title: "Color" }],
  ["og-core-type-scale", { route: "/foundations/typography", title: "Typography" }],
  ["type-scale", { route: "/foundations/typography", title: "Typography" }],
  ["og-core-buttons", { route: "/components/button", title: "Button" }],
  ["button-frame", { route: "/components/button", title: "Button" }],
  ["og-core-badges", { route: "/components/badge", title: "Badge" }],
  ["badge-tags", { route: "/components/badge", title: "Badge" }],
  ["logo-", { route: "/foundations/brand", title: "Brand" }],
  ["tagline-", { route: "/foundations/brand", title: "Brand" }],
  ["account-", { route: "/pages/account", title: "Account" }],
  ["og-account", { route: "/pages/account", title: "Account" }],
  ["og-plp-", { route: "/pages/collection", title: "Collection (PLP)" }],
  ["og-reviews", { route: "/pages/collection", title: "Collection (PLP)" }],
  ["og-email", { route: "/pages/marketing/email", title: "Email" }],
  ["og-marketing", { route: "/pages/marketing/email", title: "Email" }],
  ["og-grid", { route: "/foundations/layout", title: "Layout" }],
  ["b2b-dashboard-stat-pill", { route: "/b2b/components/dashboard/cards-tiles", title: "Cards & Tiles" }],
];

/** Design-system pages that show a watched Figma piece, found through the change-tracking entries that reference its node. */
export function locateWatch(watchId: string): WatchLocation[] {
  const item = WATCH_LIST.find((w) => w.id === watchId);
  if (!item) return [];
  const found = new Map<string, WatchLocation>();
  for (const entry of CHANGELOG) {
    const ref = parseNode(entry.figmaUrl);
    if (!ref || ref.file !== item.fileKey || ref.node !== item.nodeId) continue;
    const page = PAGE_MAP[entry.page];
    if (page) found.set(page.route, page);
  }
  if (found.size === 0) {
    const hit = FALLBACK.find(([prefix]) => watchId.startsWith(prefix));
    if (hit) found.set(hit[1].route, hit[1]);
  }
  return [...found.values()];
}
