import type { WatchItem } from "./types";

const CLAIMS = "fAR8Q5JFFhzwMVslVENoHr"; // TOV26 - B2C - Claims form - 2864

function item(id: string, label: string, nodeId: string): WatchItem {
  return {
    id,
    label,
    fileKey: CLAIMS,
    nodeId,
    figmaUrl: `https://www.figma.com/design/${CLAIMS}?node-id=${nodeId.replace(":", "-")}`,
  };
}

/** Claims form nodes mapped to the Input & Select page. Every nodeId was read from the live Figma file. */
export const FORMS_WATCH: WatchItem[] = [
  item("forms-input-field", "Forms — Input field", "3827:7452"),
  item("forms-textarea", "Forms — Textarea with helper text", "3381:3144"),
  item("forms-checkbox", "Forms — Checkbox with label", "3381:4961"),
  item("forms-checkbox-group", "Forms — Checkbox group", "3381:4970"),
  item("forms-option-card-default", "Forms — Option card (default)", "3381:3017"),
  item("forms-option-card-selected", "Forms — Option card (selected)", "3381:3024"),
  item("forms-product-option-card", "Forms — Product option card", "3381:3010"),
  item("forms-file-upload", "Forms — File upload zone", "3381:3465"),
  item("forms-progress-bar", "Forms — Progress bar", "3381:4977"),
  item("forms-summary-row", "Forms — Summary row", "3381:4220"),
  item("forms-step-card", "Forms — Form step card", "3381:4942"),
];
