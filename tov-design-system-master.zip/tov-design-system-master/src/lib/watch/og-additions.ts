import type { WatchItem } from "./types";

const OG = "DTjIdCKhnDUVvJhEfpn10v"; // TOV - B2C - Design system (OG file)
const CORE = "5aVhd2ZmqVDG61uN3Ruas5"; // TOV Design System - Core
const PLP = "jDOs1dFChECKIYdAyPUkav"; // TOV26 - PLP Designs System

function item(id: string, label: string, fileKey: string, nodeId: string): WatchItem {
  return {
    id,
    label,
    fileKey,
    nodeId,
    figmaUrl: `https://www.figma.com/design/${fileKey}?node-id=${nodeId.replace(":", "-")}`,
  };
}

/**
 * Mapped OG / Core / PLP nodes not covered by the base WATCH_LIST in
 * figma-watch.ts. Every nodeId was checked against the live Figma file.
 */
export const OG_ADDITIONS_WATCH: WatchItem[] = [
  // Foundations
  item("og-grid-export-sheet", "Foundations — Grid Export Sheet (12/8/4 column grid)", OG, "55:341"),
  item("og-icons-ecommerce", "Iconography — Ecommerce icons", OG, "230:3249"),
  item("og-icons-info", "Iconography — Info icons", OG, "141:5604"),
  item("og-icons-general", "Iconography — General UI icons", OG, "230:2602"),
  item("og-icons-arrows", "Iconography — Arrows icons", OG, "230:2694"),

  // Core file mirrors of the OG foundations and atoms
  item("og-core-brand-palette", "Core — Brand Palette", CORE, "23:59"),
  item("og-core-type-scale", "Core — Type Scale", CORE, "25:14"),
  item("og-core-buttons", "Core — Buttons", CORE, "27:3"),
  item("og-core-badges", "Core — Badges", CORE, "27:28"),

  // Homepage components beyond the sets already in WATCH_LIST
  item("og-homepage-categories-accent-chairs", "Homepage — Categories (Accent Chairs)", OG, "1063:1679"),
  item("og-homepage-categories-outdoor", "Homepage — Categories (Outdoor)", OG, "1063:1692"),
  item("og-homepage-categories-storage", "Homepage — Categories (Storage)", OG, "1063:1706"),
  item("og-homepage-categories-mobile", "Homepage — Mobile Categories", OG, "1063:1776"),
  item("og-homepage-new-arrivals-product-row", "Homepage — New Arrivals Product Row", OG, "1063:2050"),
  item("og-homepage-new-arrivals-mobile", "Homepage — New Arrivals (Mobile)", OG, "1063:2098"),
  item("og-homepage-collections-chair", "Homepage — Collections sub-card (Chair)", OG, "1063:2506"),
  item("og-homepage-collections-storage", "Homepage — Collections sub-card (Storage)", OG, "1067:1455"),
  item("og-homepage-collections-nightstand", "Homepage — Collections sub-card (Nightstand)", OG, "1067:1466"),
  item("og-homepage-collections-side-table", "Homepage — Collections sub-card (Side Table)", OG, "1067:1477"),

  // Navigation & Footer canvas
  item("og-nav-email-sign-up", "Navigation — Email Sign Up", OG, "1688:3636"),
  item("og-nav-mobile-navigation", "Navigation — Mobile Navigation (drill-down states)", OG, "1688:3862"),
  item("og-nav-search-type-a", "Navigation — Search Type A", OG, "1696:1360"),
  item("og-nav-search-type-b", "Navigation — Search Type B", OG, "1696:1829"),
  item("og-nav-search-type-c", "Navigation — Search Type C", OG, "1696:2014"),
  item("og-nav-search-type-d", "Navigation — Search Type D", OG, "1696:2290"),
  item("og-nav-search-type-e", "Navigation — Search Type E", OG, "1696:2539"),
  item("og-nav-search-returning-users", "Navigation — Search Returning Users", OG, "1696:2824"),
  item("og-nav-search-no-results", "Navigation — Search No Results", OG, "1696:2932"),

  // Collection (PLP)
  item("og-plp-product-card", "Collection — Product Card", PLP, "17:4689"),
  item("og-plp-product-row", "Collection — Product Row", PLP, "1:556"),
  item("og-plp-root-category-hero", "Collection — Root Category Hero", PLP, "8:1265"),
  item("og-plp-reviews", "Collection — Reviews", OG, "152:3788"),

  // Account page layouts not already watched
  item("og-account-page-orders-empty-desktop", "Account — Orders Empty page (Desktop)", OG, "1778:1168"),
  item("og-account-page-orders-mobile", "Account — Orders page (Mobile)", OG, "1778:1462"),
  item("og-account-page-orders-empty-mobile", "Account — Orders Empty page (Mobile)", OG, "1778:1655"),
  item("og-account-page-profile-mobile", "Account — Profile page (Mobile)", OG, "1778:1751"),

  // Marketing email components
  item("og-email-hero", "Email — Hero", OG, "1753:460"),
  item("og-email-category-cards", "Email — Category Cards", OG, "1754:458"),
  item("og-email-image-grid", "Email — Image Grid", OG, "1754:473"),
  item("og-email-product-cards", "Email — Product Cards", OG, "1755:498"),
  item("og-email-banner", "Email — Banner", OG, "1756:468"),
  item("og-email-content-block", "Email — Content Block", OG, "1757:476"),
  item("og-email-announcement-bar", "Email — Announcement Bar", OG, "1760:619"),
  item("og-email-text-block", "Email — Text Block", OG, "1760:650"),
  item("og-email-sign-off", "Email — Sign-off", OG, "1760:665"),
  item("og-email-cart-reminder", "Email — Cart Reminder", OG, "1761:677"),
  item("og-email-incentive", "Email — Incentive", OG, "1761:696"),
  item("og-email-styled-by-you", "Email — Styled By You", OG, "1761:713"),

  // Homepage page layouts (Mock-up frames)
  item("og-homepage-layout-desktop", "Homepage — Page layout (Desktop)", OG, "1686:1375"),
  item("og-homepage-layout-mobile", "Homepage — Page layout (Mobile)", OG, "1686:1493"),
];
