import type { WatchItem } from "./types";

/**
 * PDP + Editorial page watch entries. Every nodeId here was verified to
 * exist in its Figma file. PDP entries point at each component set (or the
 * standalone component) so all of its variants are fingerprinted; Editorial
 * entries point at the page-level Desktop/Mobile frames.
 */

const PDP_FILE = "ySZYmjbO2Wck8u1JGAtI5J";
const NEW_ARRIVALS_FILE = "tefhO0Dx4CNYT09diRqfB2";
const COLLECTIONS_LP_FILE = "oO2Li1XutYUUAgUUs4f3lJ";
const COLLECTION_PAGE_FILE = "9xYNBPcAsKBOCCGP5X6wJ9";
const TOV_EDITS_FILE = "PXf8n9b6WW5X5ZkYqiykJH";

function watch(id: string, label: string, fileKey: string, nodeId: string): WatchItem {
  return {
    id,
    label,
    fileKey,
    nodeId,
    figmaUrl: `https://www.figma.com/design/${fileKey}?node-id=${nodeId.replace(":", "-")}`,
  };
}

export const PDP_EDITORIAL_WATCH: WatchItem[] = [
  // PDP — Details Panel
  watch("pdp-price", "PDP — Price", PDP_FILE, "7:20"),
  watch("pdp-product-name", "PDP — Product Name", PDP_FILE, "1:97"),
  watch("pdp-fabric-selection", "PDP — Fabric Selection", PDP_FILE, "11:559"),
  watch("pdp-quantity", "PDP — Quantity", PDP_FILE, "11:622"),
  watch("pdp-atc-stack", "PDP — ATC Stack", PDP_FILE, "13:144"),
  watch("pdp-sticky-atc", "PDP — Sticky ATC", PDP_FILE, "13:194"),
  watch("pdp-why-we-love-it", "PDP — Why We Love It", PDP_FILE, "61:4027"),
  watch("pdp-shipping-alert", "PDP — Shipping Alert", PDP_FILE, "115:4116"),
  watch("pdp-value-props", "PDP — Value Props", PDP_FILE, "15:5089"),
  watch("pdp-variant-selection", "PDP — Variant Selection", PDP_FILE, "197:990"),
  watch("pdp-club-tov", "PDP — Club TOV", PDP_FILE, "813:8189"),
  watch("pdp-gallery-desktop", "PDP — Gallery (Desktop)", PDP_FILE, "15:348"),
  watch("pdp-gallery-mobile", "PDP — Gallery (Mobile)", PDP_FILE, "15:349"),
  watch("pdp-bread-crumbs", "PDP — Bread Crumbs", PDP_FILE, "582:11812"),
  watch("pdp-bnpl", "PDP — BNPL", PDP_FILE, "838:8555"),
  watch("pdp-product-info-accordion", "PDP — Product Info Accordion", PDP_FILE, "13:366"),

  // Editorial — New Arrivals
  watch("editorial-new-arrivals-desktop", "Editorial — New Arrivals page (Desktop)", NEW_ARRIVALS_FILE, "8005:9839"),
  watch("editorial-new-arrivals-mobile", "Editorial — New Arrivals page (Mobile)", NEW_ARRIVALS_FILE, "8005:9838"),

  // Editorial — Collections Landing
  watch("editorial-collections-landing-desktop", "Editorial — Collections Landing page (Desktop)", COLLECTIONS_LP_FILE, "6084:479"),
  watch("editorial-collections-landing-mobile", "Editorial — Collections Landing page (Mobile)", COLLECTIONS_LP_FILE, "6052:1385"),

  // Editorial — Collection individual page
  watch("editorial-collection-page-desktop", "Editorial — Collection individual page (Desktop)", COLLECTION_PAGE_FILE, "2159:2815"),
  watch("editorial-collection-page-mobile", "Editorial — Collection individual page (Mobile)", COLLECTION_PAGE_FILE, "2159:3150"),

  // Editorial — TOV Edits
  watch("editorial-tov-edits-directory-desktop", "Editorial — TOV Edits Directory page (Desktop)", TOV_EDITS_FILE, "8015:1447"),
  watch("editorial-tov-edits-directory-mobile", "Editorial — TOV Edits Directory page (Mobile)", TOV_EDITS_FILE, "8015:1765"),
  watch("editorial-tov-edits-edit-page-desktop", "Editorial — TOV Edits individual Edit page (Desktop)", TOV_EDITS_FILE, "8023:4971"),
  watch("editorial-tov-edits-edit-page-mobile", "Editorial — TOV Edits individual Edit page (Mobile)", TOV_EDITS_FILE, "8023:5028"),
];
