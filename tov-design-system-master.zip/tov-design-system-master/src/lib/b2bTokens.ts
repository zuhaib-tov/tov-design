/**
 * Token data for the TOV B2B property's Foundations pages. Parallel to
 * src/lib/tokens.ts (which covers B2C) but kept separate — B2B's palette,
 * type ramp, and spacing/layout scale are distinct from B2C's and should
 * evolve independently.
 *
 * Source: Figma file "TOV26 - B2B - Design system" (CGe5J4j6AI5uus5G2f8iqh),
 * page "🎨 Foundations" (1:2), frame "Foundations" (26:12).
 */

// ---------------------------------------------------------------------------
// Color
// ---------------------------------------------------------------------------

/** Raw brand values. Semantic tokens below alias these — components should
 * always bind to a semantic token, never a primitive, directly. */
export const colorPrimitives = [
  { name: "charcoal/900", hex: "#3F3D3E", css: "--tov-primitive-charcoal-900" },
  { name: "ink/800", hex: "#333333", css: "--tov-primitive-ink-800" },
  { name: "black", hex: "#000000", css: "--tov-primitive-black" },
  { name: "white", hex: "#FFFFFF", css: "--tov-primitive-white" },
  { name: "gray/600", hex: "#606060", css: "--tov-primitive-gray-600" },
  { name: "gray/500", hex: "#8E8E8E", css: "--tov-primitive-gray-500" },
  { name: "gray/300", hex: "#CDCDCD", css: "--tov-primitive-gray-300" },
  { name: "gray/200", hex: "#E8E8E8", css: "--tov-primitive-gray-200" },
  { name: "gray/100", hex: "#F2F2F2", css: "--tov-primitive-gray-100" },
  { name: "cream/50", hex: "#FAF9F5", css: "--tov-primitive-cream-50" },
  { name: "cream/100", hex: "#F1ECE5", css: "--tov-primitive-cream-100" },
  { name: "cream/200", hex: "#DBCEC6", css: "--tov-primitive-cream-200" },
  { name: "rose/500", hex: "#B15A63", css: "--tov-primitive-rose-500" },
  { name: "rose/100", hex: "#F9D2D2", css: "--tov-primitive-rose-100" },
  { name: "gold/400", hex: "#CCB583", css: "--tov-primitive-gold-400" },
] as const;

export interface SemanticColorToken {
  name: string;
  hex: string;
  mapsTo: string;
  css: string;
  usage: string;
}

/** Surface/background roles. */
export const semanticBg: SemanticColorToken[] = [
  { name: "bg/page", hex: "#FFFFFF", mapsTo: "white", css: "--tov-color-bg-page", usage: "Default page background across every B2B surface." },
  { name: "bg/subtle", hex: "#FAF9F5", mapsTo: "cream/50", css: "--tov-color-bg-subtle", usage: "Subtle section background for light visual separation without a hard border." },
  { name: "bg/warm", hex: "#F1ECE5", mapsTo: "cream/100", css: "--tov-color-bg-warm", usage: "Warm section background for feature and editorial modules." },
  { name: "bg/inverse", hex: "#3F3D3E", mapsTo: "charcoal/900", css: "--tov-color-bg-inverse", usage: "Dark section background — footer and inverse-theme modules." },
  { name: "bg/brand", hex: "#B15A63", mapsTo: "rose/500", css: "--tov-color-bg-brand", usage: "Brand-filled surfaces — primary CTAs, highlighted program tiles." },
  { name: "bg/brand-subtle", hex: "#F9D2D2", mapsTo: "rose/100", css: "--tov-color-bg-brand-subtle", usage: "Soft brand tint for badges and low-emphasis highlights." },
  { name: "bg/muted", hex: "#F2F2F2", mapsTo: "gray/100", css: "--tov-color-bg-muted", usage: "Muted surface for disabled or secondary panels." },
  { name: "bg/placeholder", hex: "#CDCDCD", mapsTo: "gray/300", css: "--tov-color-bg-placeholder", usage: "Image and media placeholder fill before content loads." },
  { name: "bg/overlay", hex: "#000000", mapsTo: "black", css: "--tov-color-bg-overlay", usage: "Modal and lightbox scrim." },
];

/** Text roles. */
export const semanticText: SemanticColorToken[] = [
  { name: "text/primary", hex: "#3F3D3E", mapsTo: "charcoal/900", css: "--tov-color-text-primary", usage: "Primary body copy and default heading color." },
  { name: "text/secondary", hex: "#333333", mapsTo: "ink/800", css: "--tov-color-text-secondary", usage: "Secondary text and supporting copy." },
  { name: "text/muted", hex: "#8E8E8E", mapsTo: "gray/500", css: "--tov-color-text-muted", usage: "Muted text — captions, timestamps, helper copy." },
  { name: "text/subtle", hex: "#606060", mapsTo: "gray/600", css: "--tov-color-text-subtle", usage: "Subtle text, one step lighter than secondary." },
  { name: "text/inverse", hex: "#FFFFFF", mapsTo: "white", css: "--tov-color-text-inverse", usage: "Text on dark or brand-filled backgrounds." },
  { name: "text/brand", hex: "#B15A63", mapsTo: "rose/500", css: "--tov-color-text-brand", usage: "Brand-colored text — links and active navigation states." },
  { name: "text/disabled", hex: "#E8E8E8", mapsTo: "gray/200", css: "--tov-color-text-disabled", usage: "Disabled text and placeholder text in form fields." },
];

/** Border roles. */
export const semanticBorder: SemanticColorToken[] = [
  { name: "border/default", hex: "#F1ECE5", mapsTo: "cream/100", css: "--tov-color-border-default", usage: "Default hairline border for cards and panels." },
  { name: "border/subtle", hex: "#E8E8E8", mapsTo: "gray/200", css: "--tov-color-border-subtle", usage: "Subtle divider between list items and sections." },
  { name: "border/strong", hex: "#3F3D3E", mapsTo: "charcoal/900", css: "--tov-color-border-strong", usage: "High-contrast border for focus and emphasis states." },
  { name: "border/inverse", hex: "#FFFFFF", mapsTo: "white", css: "--tov-color-border-inverse", usage: "Border on dark backgrounds." },
  { name: "border/brand", hex: "#B15A63", mapsTo: "rose/500", css: "--tov-color-border-brand", usage: "Brand-colored border — active tabs and selected states." },
];

/** Icon roles. */
export const semanticIcon: SemanticColorToken[] = [
  { name: "icon/rating", hex: "#CCB583", mapsTo: "gold/400", css: "--tov-color-icon-rating", usage: "Star-rating icon fill." },
  { name: "icon/primary", hex: "#3F3D3E", mapsTo: "charcoal/900", css: "--tov-color-icon-primary", usage: "Default icon color." },
  { name: "icon/inverse", hex: "#FFFFFF", mapsTo: "white", css: "--tov-color-icon-inverse", usage: "Icon color on dark or brand-filled backgrounds." },
];

// ---------------------------------------------------------------------------
// Typography
// ---------------------------------------------------------------------------

export const fontFamilies = [
  {
    name: "GT Ultra Fine Trial",
    stack: '"GT Ultra Fine Trial", serif',
    usage: "Display and heading moments — hero statements, section titles, program names.",
  },
  {
    name: "Montserrat",
    stack: "Montserrat, sans-serif",
    usage: "Body copy, labels, navigation, and UI text.",
  },
] as const;

export interface TypeStep {
  name: string;
  family: "GT Ultra Fine Trial" | "Montserrat";
  weight: "Light" | "Regular" | "Medium" | "SemiBold" | "Bold";
  size: number;
  /** "auto" means the style carries no fixed line-height override. */
  lineHeight: number | "auto";
  letterSpacing?: number;
  uppercase?: boolean;
  usage: string;
}

export const typeRamp: TypeStep[] = [
  { name: "Display/XL", family: "GT Ultra Fine Trial", weight: "Regular", size: 68, lineHeight: 70, usage: "The largest hero statement — landing-page openers." },
  { name: "Display/L", family: "GT Ultra Fine Trial", weight: "Regular", size: 56, lineHeight: 62, usage: "Large hero and section-opening statements." },
  { name: "Heading/H1", family: "GT Ultra Fine Trial", weight: "Regular", size: 46, lineHeight: 50, usage: "Page-level heading — one per page." },
  { name: "Heading/H2", family: "GT Ultra Fine Trial", weight: "Regular", size: 38, lineHeight: 42, usage: "Major section heading." },
  { name: "Heading/H3", family: "GT Ultra Fine Trial", weight: "Regular", size: 26, lineHeight: 30, usage: "Subsection heading, card and module titles." },
  { name: "Heading/H4", family: "GT Ultra Fine Trial", weight: "Regular", size: 22, lineHeight: 25, usage: "Minor heading within a module." },
  { name: "Heading/H5", family: "GT Ultra Fine Trial", weight: "Regular", size: 18, lineHeight: 27, usage: "Small heading — list and card headers." },
  { name: "Heading/H6", family: "GT Ultra Fine Trial", weight: "Regular", size: 16, lineHeight: 24, usage: "Smallest heading tier, used sparingly." },
  { name: "Body/L Light", family: "Montserrat", weight: "Light", size: 18, lineHeight: 24, usage: "Large intro paragraphs and lede copy." },
  { name: "Body/L Regular", family: "Montserrat", weight: "Regular", size: 18, lineHeight: 24, usage: "Large body copy where more emphasis is needed than Light." },
  { name: "Body/M Regular", family: "Montserrat", weight: "Regular", size: 16, lineHeight: 19, usage: "Default body copy." },
  { name: "Body/M Light", family: "Montserrat", weight: "Light", size: 16, lineHeight: 24, usage: "Default body copy, lighter weight for longer passages." },
  { name: "Body/M Bold", family: "Montserrat", weight: "Bold", size: 16, lineHeight: 21, usage: "Emphasized inline text within body copy." },
  { name: "Body/S Regular", family: "Montserrat", weight: "Regular", size: 14, lineHeight: 16, usage: "Secondary body copy — captions, form helper text." },
  { name: "Body/S Light", family: "Montserrat", weight: "Light", size: 14, lineHeight: 20, usage: "Secondary body copy, lighter weight." },
  { name: "Body/S Bold", family: "Montserrat", weight: "Bold", size: 14, lineHeight: 16, usage: "Emphasized secondary copy." },
  { name: "Body/XS Regular", family: "Montserrat", weight: "Regular", size: 12, lineHeight: 14, usage: "Fine print — legal copy, timestamps." },
  { name: "Label/L", family: "Montserrat", weight: "Bold", size: 18, lineHeight: 24, uppercase: true, usage: "Large uppercase label — program and category headers." },
  { name: "Label/M Bold", family: "Montserrat", weight: "Bold", size: 14, lineHeight: 24, uppercase: true, usage: "Standard uppercase label, bold weight." },
  { name: "Label/M SemiBold", family: "Montserrat", weight: "SemiBold", size: 14, lineHeight: 19, uppercase: true, usage: "Standard uppercase label, semibold weight." },
  { name: "Label/S", family: "Montserrat", weight: "SemiBold", size: 12, lineHeight: "auto", letterSpacing: 2, uppercase: true, usage: "Small uppercase label with wide tracking — badges, tags." },
  { name: "Label/XS", family: "Montserrat", weight: "SemiBold", size: 11, lineHeight: 16, letterSpacing: 2, uppercase: true, usage: "Smallest uppercase label — metadata tags." },
  { name: "Eyebrow", family: "Montserrat", weight: "SemiBold", size: 16, lineHeight: 16, letterSpacing: 2, uppercase: true, usage: "Eyebrow text above a heading, e.g. \"Why TOV\"." },
  { name: "Nav/Link", family: "Montserrat", weight: "Medium", size: 13, lineHeight: 13, usage: "Primary navigation links." },
  { name: "Button/Default", family: "Montserrat", weight: "Medium", size: 16, lineHeight: 14, letterSpacing: 0, usage: "Button label text." },
  { name: "Stat/Number", family: "Montserrat", weight: "Bold", size: 24, lineHeight: 21, usage: "Large stat figures, e.g. \"10+ years\"." },
];

// ---------------------------------------------------------------------------
// Spacing & Radius
// ---------------------------------------------------------------------------

export const spacingTokens = [
  { name: "spacing/2xs", value: 4, css: "--tov-spacing-2xs", usage: "Tightest spacing — icon to its own label." },
  { name: "spacing/xs", value: 8, css: "--tov-spacing-xs", usage: "Tight stack spacing — a value and its caption." },
  { name: "spacing/sm", value: 12, css: "--tov-spacing-sm", usage: "Compact padding inside dense controls." },
  { name: "spacing/md", value: 16, css: "--tov-spacing-md", usage: "Standard stack spacing — a heading and the copy beneath it." },
  { name: "spacing/lg", value: 24, css: "--tov-spacing-lg", usage: "Standard card and panel padding." },
  { name: "spacing/xl", value: 32, css: "--tov-spacing-xl", usage: "Spacious card padding, gap between related modules." },
  { name: "spacing/2xl", value: 40, css: "--tov-spacing-2xl", usage: "Minimum vertical gap between stacked page sections." },
  { name: "spacing/3xl", value: 48, css: "--tov-spacing-3xl", usage: "Standard gap between stacked page sections." },
  { name: "spacing/4xl", value: 64, css: "--tov-spacing-4xl", usage: "Wide gap between unrelated sections." },
  { name: "spacing/5xl", value: 80, css: "--tov-spacing-5xl", usage: "Maximum vertical rhythm — hero-to-content breaks." },
] as const;

export const radiusTokens = [
  { name: "radius/sm", value: "4px", usage: "Badges, tags, small controls." },
  { name: "radius/md", value: "8px", usage: "Buttons, inputs, standard cards." },
  { name: "radius/lg", value: "16px", usage: "Larger cards and panels." },
  { name: "radius/xl", value: "36px", usage: "Feature cards and prominent containers." },
  { name: "radius/full", value: "999px", usage: "Pills and circular controls." },
] as const;

// ---------------------------------------------------------------------------
// Layout & Breakpoints
// ---------------------------------------------------------------------------

export interface BreakpointSpec {
  breakpoint: string;
  width: number;
  margin: number;
  gutter: number;
  columns: number;
  contentArea: string;
}

/** Page margins, gutters and column counts for each breakpoint. */
export const breakpointMargins: BreakpointSpec[] = [
  { breakpoint: "Desktop", width: 1440, margin: 75, gutter: 20, columns: 12, contentArea: "1290px" },
  { breakpoint: "Tablet", width: 768, margin: 40, gutter: 16, columns: 8, contentArea: "688px" },
  { breakpoint: "Mobile", width: 390, margin: 20, gutter: 10, columns: 4, contentArea: "350px" },
];

/** Vertical rhythm between stacked sections, plus one documented exception. */
export const sectionRhythm = [
  {
    name: "Standard section padding",
    desktop: "40–80px",
    mobile: "20–40px",
    usage: "Default vertical padding between stacked page sections.",
  },
  {
    name: "Trade Programs inset",
    desktop: "100px side margin, 1240px content",
    mobile: undefined,
    usage: "A wider desktop inset used specifically by the Trade Programs module, in place of the standard 75px margin.",
  },
] as const;
