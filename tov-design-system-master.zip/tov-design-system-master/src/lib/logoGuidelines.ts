/**
 * TOV logo construction, clear space and colorway data — the source for the
 * Brand page's logo guidelines and for the downloadable SVG and PNG files.
 * The wordmark is drawn on a 1000-unit grid; the exported artwork is the
 * tight crop 200 412 586 176.
 */

export const LOGO_VIEWBOX = { x: 200, y: 412, w: 586, h: 176 } as const;

const T = "200,447 256,447 256,585 288,585 288,447 344,447 344,415 200,415 200,447";
const O_RING =
  "M 475,412 C 424.19,412 383,451.4 383,500 C 383,548.6 424.19,588 475,588 C 525.81,588 567,548.6 567,500 C 567,451.4 525.81,412 475,412 Z M 475,444 C 441.86,444 415,469.07 415,500 C 415,530.93 441.86,556 475,556 C 508.14,556 535,530.93 535,500 C 535,469.07 508.14,444 475,444 Z";
const O_HALF =
  "M 475,412 C 525.81,412 567,451.4 567,500 C 567,548.6 525.81,588 475,588 L 475,556 C 508.14,556 535,530.93 535,500 C 535,469.07 508.14,444 475,444 L 475,412 Z";
const V = "696,546 641,415 606,415 680,585 712,585 786,415 751,415 696,546";

export const LOGO_SHAPES = { t: T, oRing: O_RING, oHalf: O_HALF, v: V } as const;

export interface LogoColorway {
  key: "primary" | "black" | "white" | "pink";
  name: string;
  /** Color of the T, the right half of the O and the V. */
  ink: string;
  /** Color of the O ring. */
  accent: string;
  /** Surface the preview sits on. */
  surface: string;
  file: string;
  usage: string;
}

export const LOGO_COLORWAYS: LogoColorway[] = [
  {
    key: "primary",
    name: "Primary",
    ink: "#000000",
    accent: "#F9D2D2",
    surface: "#FEFBF6",
    file: "tov-logo-primary",
    usage: "Black #000000 with the pink O. Default on cream and white.",
  },
  {
    key: "black",
    name: "Black",
    ink: "#000000",
    accent: "#000000",
    surface: "#F1ECE5",
    file: "tov-logo-black",
    usage: "Solid #000000. Single-color print, invoices, stamps, embroidery.",
  },
  {
    key: "white",
    name: "White",
    ink: "#FEFBF6",
    accent: "#FEFBF6",
    surface: "#3F3D3E",
    file: "tov-logo-white",
    usage: "Cream #FEFBF6. For dark surfaces and photography overlays.",
  },
  {
    key: "pink",
    name: "Pink",
    ink: "#F9D2D2",
    accent: "#F9D2D2",
    surface: "#3F3D3E",
    file: "tov-logo-pink",
    usage: "TOV Pink #F9D2D2. Campaign and packaging use on Not Black only.",
  },
];

/** The standalone SVG file for one colorway. Single-color variants drop the split O. */
export function logoSvg(c: LogoColorway): string {
  const flat = c.ink === c.accent;
  const { x, y, w, h } = LOGO_VIEWBOX;
  const shapes = [
    `  <polygon points="${T}" fill="${c.ink}"/>`,
    `  <path fill-rule="evenodd" d="${O_RING}" fill="${c.accent}"/>`,
    flat ? null : `  <path d="${O_HALF}" fill="${c.ink}"/>`,
    `  <polygon points="${V}" fill="${c.ink}"/>`,
  ].filter(Boolean);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x} ${y} ${w} ${h}" width="${w}" height="${h}">\n  <title>TOV</title>\n${shapes.join("\n")}\n</svg>\n`;
}

export const CONSTRUCTION_FACTS: { value: string; label: string; note: string }[] = [
  { value: "32", label: "Stroke weight", note: "Identical across the T stem, the O ring and both V diagonals." },
  { value: "92 / 60", label: "O radii", note: "A true circle, centered at 475, 500. Two arcs, no traced segments." },
  { value: "39", label: "Letter gap", note: "Equal sidebearing between T–O and O–V. Total mark: 586 × 176." },
];

export const LOGO_DONTS: string[] = [
  "Recolor the O to anything other than TOV Pink, cream, or black as shown in the colorways.",
  "Stretch, rotate, outline, or add a drop shadow to the wordmark.",
  "Place the full primary logo on a busy photograph — use the cream or black single-color variant instead.",
  "Re-space the letters or lock the mark to a tagline without brand-team sign-off.",
];

/** PNG exports are transparent and this many pixels wide. */
export const LOGO_PNG_WIDTH = 2048;
