/**
 * TOV spacing classes. One scale, listed from largest to smallest, with a value
 * for each screen size. Mobile is the base; Tablet applies from 768px and
 * Desktop from 1024px (the same breakpoints as the heading styles). The
 * steps from xl up scale with the screen; xs and below hold one value on every
 * screen, because small gaps inside a component do not need to grow.
 *
 * Classes are Tailwind utilities generated from the `--spacing-space-*`
 * theme keys in globals.css: `p-space-md`, `gap-space-sm`, `mt-space-3xl`,
 * `py-space-2xl`, and so on. The values live in `--space-*` variables that
 * switch at the breakpoints, so a class never needs a responsive prefix.
 */
export interface SpaceStep {
  /** Class suffix: p-space-{name}, gap-space-{name}, mt-space-{name}. */
  name: string;
  desktop: number;
  tablet: number;
  mobile: number;
  usage: string;
}

export const SPACE_STEPS: SpaceStep[] = [
  { name: "5xl", desktop: 128, tablet: 96, mobile: 64, usage: "Hero to content, and the break between unrelated page sections." },
  { name: "4xl", desktop: 96, tablet: 80, mobile: 56, usage: "Large breaks between page sections." },
  { name: "3xl", desktop: 80, tablet: 64, mobile: 48, usage: "Default rhythm between stacked page sections." },
  { name: "2xl", desktop: 64, tablet: 56, mobile: 40, usage: "Related page sections, such as modules inside one product details block." },
  { name: "xl", desktop: 48, tablet: 40, mobile: 32, usage: "Spacious padding for hero cards and promo banners; space between a section heading and its content." },
  { name: "lg", desktop: 40, tablet: 32, mobile: 28, usage: "Generous card padding; gap between featured layout blocks." },
  { name: "md", desktop: 32, tablet: 28, mobile: 24, usage: "Standard card and panel padding; wide gaps in feature layouts." },
  { name: "sm", desktop: 24, tablet: 20, mobile: 16, usage: "Column gutter of the page grid; compact card padding; gap between a heading, its copy and a call to action." },
  { name: "xs", desktop: 16, tablet: 16, mobile: 16, usage: "Standard gap between a heading and the copy beneath it; gutter between cards in a row." },
  { name: "2xs", desktop: 8, tablet: 8, mobile: 8, usage: "Tight stacks, such as a value and its caption; an icon and its label." },
  { name: "3xs", desktop: 4, tablet: 4, mobile: 4, usage: "Hairline gaps inside a single control." },
];

/**
 * Page margin: the outer inset of every full-width section, written as the
 * class px-space-page. It matches the margins of the column grid (100px
 * Desktop, 32px Tablet, 20px Mobile).
 */
export const PAGE_MARGIN = { name: "page", desktop: 100, tablet: 32, mobile: 20 } as const;
