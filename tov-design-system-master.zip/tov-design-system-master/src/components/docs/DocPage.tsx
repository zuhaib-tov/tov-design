import { ReactNode } from "react";

export function DocPage({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="max-w-4xl px-8 py-10">
      <h1 className="font-display text-4xl text-primary-dark mb-2">{title}</h1>
      {description && (
        <p className="text-ink-muted max-w-2xl mb-10">{description}</p>
      )}
      <div className="flex flex-col gap-12">{children}</div>
    </div>
  );
}

export function DocSection({
  title,
  children,
}: {
  title: ReactNode;
  children: ReactNode;
}) {
  return (
    <section>
      <h2 className="font-display text-xl text-ink mb-4 flex items-center gap-2">
        {title}
      </h2>
      {children}
    </section>
  );
}
