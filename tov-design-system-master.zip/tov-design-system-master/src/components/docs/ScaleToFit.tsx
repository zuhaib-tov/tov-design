"use client";

import { ReactNode, useEffect, useRef, useState } from "react";

/**
 * Shrinks full-bleed Desktop components (nav rows, footers, etc. — genuinely
 * 1440px wide in Figma, no scroll in the real design) down to fit the
 * Preview box's available width, instead of leaving them to horizontally
 * scroll. Natural size is measured via scrollWidth/Height, which CSS
 * transforms don't affect, so this is safe to re-measure on every resize.
 */
export function ScaleToFit({ children }: { children: ReactNode }) {
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [natural, setNatural] = useState<{ w: number; h: number } | null>(null);

  useEffect(() => {
    const outer = outerRef.current;
    const inner = innerRef.current;
    const parent = outer?.parentElement;
    if (!outer || !inner || !parent) return;

    // Measure against the parent (the Preview box's flex row), not `outer`
    // itself — once `outer` gets an explicit scaled width/height below, its
    // own size becomes a downstream result, and observing it would feed
    // back into the calculation instead of tracking real available space.
    const measure = () => {
      const naturalWidth = inner.scrollWidth;
      const naturalHeight = inner.scrollHeight;
      // clientWidth includes the parent's padding (Preview's p-8), which
      // isn't space the child can actually use.
      const ps = getComputedStyle(parent);
      const availableWidth =
        parent.clientWidth - parseFloat(ps.paddingLeft) - parseFloat(ps.paddingRight);
      const nextScale = naturalWidth > availableWidth ? availableWidth / naturalWidth : 1;
      setScale(nextScale);
      setNatural({ w: naturalWidth, h: naturalHeight });
    };

    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(parent);
    ro.observe(inner);
    return () => ro.disconnect();
  }, []);

  return (
    <div
      ref={outerRef}
      className="max-w-full"
      style={natural ? { width: natural.w * scale, height: natural.h * scale } : undefined}
    >
      <div
        ref={innerRef}
        style={{
          transform: scale !== 1 ? `scale(${scale})` : undefined,
          transformOrigin: "top left",
          width: natural && scale !== 1 ? natural.w : undefined,
        }}
      >
        {children}
      </div>
    </div>
  );
}
