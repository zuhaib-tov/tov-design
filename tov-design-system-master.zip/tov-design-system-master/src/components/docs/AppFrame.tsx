"use client";

import { ReactNode } from "react";
import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/docs/Sidebar";

/** Docs chrome (sidebar + main) for every page except the sign-in gate, which renders full-screen. */
export function AppFrame({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  if (pathname === "/gate") return <>{children}</>;
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 min-w-0 bg-white">{children}</main>
    </div>
  );
}
