"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  Home,
  Tag,
  Palette,
  Type,
  Ruler,
  Sparkles,
  Sparkle,
  RectangleHorizontal,
  BadgeCheck,
  TextCursorInput,
  Image,
  DollarSign,
  Star,
  PanelTop,
  ChevronDown,
  AppWindow,
  ChevronRight,
  Megaphone,
  LayoutGrid,
  Package,
  ShoppingCart,
  User,
  FolderOpen,
  Folder,
  Newspaper,
  FileText,
  Images,
  Navigation,
  Download,
  BookOpen,
  Layers,
  Video,
  Hammer,
  Leaf,
  Grid3x3,
  Columns3,
  Info,
  Check,
  Mail,
  Heart,
  BarChart3,
  ListOrdered,
  Briefcase,
  Handshake,
  Quote,
  GalleryHorizontal,
  ListChecks,
  Hash,
  Search,
  Zap,
  Percent,
  IdCard,
  CircleHelp,
  Lightbulb,
  Filter,
  PanelLeft,
  LineChart,
  Target,
  UserCheck,
  Headset,
  Plus,
  type LucideIcon,
} from "lucide-react";
import { PROPERTIES, propertyForPathname } from "@/lib/nav";
import { Logo } from "@/components/ui/Logo";

const ICONS: Record<string, LucideIcon> = {
  Home,
  Tag,
  Palette,
  Type,
  Ruler,
  Sparkles,
  Sparkle,
  RectangleHorizontal,
  BadgeCheck,
  TextCursorInput,
  Image,
  DollarSign,
  Star,
  PanelTop,
  ChevronDown,
  AppWindow,
  ChevronRight,
  Megaphone,
  LayoutGrid,
  Package,
  ShoppingCart,
  User,
  FolderOpen,
  Folder,
  Newspaper,
  FileText,
  Images,
  Navigation,
  Download,
  BookOpen,
  Layers,
  Video,
  Hammer,
  Leaf,
  Grid3x3,
  Columns3,
  Info,
  Mail,
  Heart,
  BarChart3,
  ListOrdered,
  Briefcase,
  Handshake,
  Quote,
  GalleryHorizontal,
  ListChecks,
  Hash,
  Search,
  Zap,
  Percent,
  IdCard,
  CircleHelp,
  Lightbulb,
  Filter,
  PanelLeft,
  LineChart,
  Target,
  UserCheck,
  Headset,
  Plus,
};

export function Sidebar() {
  const pathname = usePathname();
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const property = propertyForPathname(pathname);

  return (
    <aside
      className="w-64 shrink-0 h-screen sticky top-0 overflow-y-auto"
      style={{ backgroundColor: property.panelBg }}
    >
      <div className="px-5 py-6 relative">
        <button
          type="button"
          onClick={() => setSwitcherOpen((v) => !v)}
          className="flex items-center gap-1.5 w-full text-left"
        >
          <span
            className="flex items-center justify-center w-[34px] h-[34px] rounded-full shrink-0"
            style={{ backgroundColor: property.badgeColor }}
          >
            <Logo className="h-[7px] text-white" accentColor="currentColor" />
          </span>
          <span className="flex-1 min-w-0 text-white text-[12px] leading-tight truncate" title={`${property.sublabel} Design System`}>
            <span className="font-bold">{property.sublabel}</span>{" "}
            <span className="font-normal text-white/90">Design System</span>
          </span>
          <ChevronDown size={16} className="text-white/70 shrink-0" />
        </button>

        {switcherOpen && (
          <div className="absolute left-5 right-5 top-[calc(100%-4px)] z-20 rounded-app-md bg-[#1e1e1e] shadow-lg overflow-hidden py-1.5 border border-white/10">
            {PROPERTIES.map((p) => {
              const isActive = p.key === property.key;
              return (
                <Link
                  key={p.key}
                  href={p.homeHref}
                  onClick={() => setSwitcherOpen(false)}
                  className="flex items-center gap-2.5 mx-1.5 px-2 py-2 rounded-app-sm hover:bg-white/10 transition-colors"
                  title={`${p.sublabel} Design System`}
                >
                  <span className="w-3.5 shrink-0 flex items-center justify-center">
                    {isActive && <Check size={14} strokeWidth={2.5} className="text-white" />}
                  </span>
                  <span
                    className="flex items-center justify-center w-[20px] h-[20px] rounded-full shrink-0"
                    style={{ backgroundColor: p.badgeColor }}
                  >
                    <Logo className="h-[4px] text-white" accentColor="currentColor" />
                  </span>
                  <span className="flex-1 min-w-0 text-sm text-white truncate">
                    {p.sublabel} Design System
                  </span>
                </Link>
              );
            })}
          </div>
        )}
      </div>
      <nav className="px-3 py-2">
        {property.sections.map((section) => (
          <div key={section.title} className="mb-5">
            <div className="px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wide-ui text-white/40">
              {section.title}
            </div>
            <ul className="flex flex-col gap-0.5">
              {section.items.map((item) => {
                const active = pathname === item.href;
                const Icon = ICONS[item.icon];
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={`flex items-center gap-2.5 rounded-full px-3 py-2 text-sm transition-colors ${
                        active
                          ? "text-white font-bold"
                          : "text-white/70 font-medium hover:bg-white/10 hover:text-white"
                      }`}
                      style={active ? { backgroundColor: property.badgeColor } : undefined}
                    >
                      {Icon && <Icon size={16} strokeWidth={1.75} className="shrink-0" />}
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
