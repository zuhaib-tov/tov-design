"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";

interface DriftEntry {
  id: string;
  watchId: string;
  label: string;
  figmaUrl: string;
  detectedAt: string;
  summary: string;
  reviewed: boolean;
  pages?: { route: string; title: string }[];
}

interface CheckResult {
  checked: number;
  baselined: number;
  updates: DriftEntry[];
  finishedAt: string;
}

interface CheckStatus {
  lastCheckedAt: string;
  checked: number;
  failedCount: number;
  newDriftCount: number;
}

function PageLinks({ pages }: { pages?: { route: string; title: string }[] }) {
  if (!pages || pages.length === 0) return null;
  return (
    <div className="text-xs text-ink-muted mt-1">
      Lives on:{" "}
      {pages.map((p, i) => (
        <span key={p.route}>
          {i > 0 && ", "}
          <Link href={p.route} className="text-primary-dark hover:underline">
            {p.title}
          </Link>
        </span>
      ))}
    </div>
  );
}

function CheckResultPanel({ result }: { result: CheckResult }) {
  const byPage = new Map<string, { title: string; route: string | null; items: DriftEntry[] }>();
  for (const u of result.updates) {
    const targets = u.pages && u.pages.length > 0 ? u.pages : [{ route: "", title: "Not linked to a page yet" }];
    for (const p of targets) {
      const g = byPage.get(p.route || p.title) ?? { title: p.title, route: p.route || null, items: [] };
      g.items.push(u);
      byPage.set(p.route || p.title, g);
    }
  }
  const pageCount = [...byPage.values()].filter((g) => g.route).length;
  const stat = (value: number, label: string, tone = "text-ink") => (
    <div className="flex-1 rounded-app-md bg-cream-100 px-4 py-3">
      <div className={`font-display text-2xl ${tone}`}>{value}</div>
      <div className="text-xs text-ink-muted">{label}</div>
    </div>
  );

  return (
    <div className="mb-4 rounded-app-md border border-neutral-200 p-4">
      <div className="mb-3 text-xs text-ink-muted">
        Check finished {new Date(result.finishedAt).toLocaleTimeString()}
        {result.baselined > 0 && ` · ${result.baselined} newly baselined`}
      </div>
      <div className="flex gap-3">
        {stat(result.checked, "pieces checked")}
        {stat(result.updates.length, result.updates.length === 1 ? "update found" : "updates found", result.updates.length ? "text-sale" : "text-ink")}
        {stat(pageCount, pageCount === 1 ? "page affected" : "pages affected")}
      </div>

      {result.updates.length === 0 ? (
        <p className="mt-3 text-sm text-ink-muted">Everything matches the last recorded Figma state.</p>
      ) : (
        <div className="mt-4 flex flex-col gap-3">
          {[...byPage.values()].map((g) => (
            <div key={g.route ?? g.title}>
              <div className="text-sm font-semibold text-ink">
                {g.route ? (
                  <Link href={g.route} className="text-primary-dark hover:underline">
                    {g.title}
                  </Link>
                ) : (
                  g.title
                )}{" "}
                <span className="font-normal text-ink-muted">
                  ({g.items.length} {g.items.length === 1 ? "update" : "updates"})
                </span>
              </div>
              <ul className="mt-1 flex flex-col gap-1">
                {g.items.map((u) => (
                  <li key={u.id} className="text-xs text-ink-muted">
                    <span className="font-semibold text-ink">{u.label}</span> — {u.summary}{" "}
                    <a href={u.figmaUrl} target="_blank" rel="noreferrer" className="text-primary-dark hover:underline">
                      View in Figma
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function FigmaSyncStatus() {
  const [log, setLog] = useState<DriftEntry[]>([]);
  const [status, setStatus] = useState<CheckStatus | null>(null);
  const [watchCount, setWatchCount] = useState(0);
  const [fileCount, setFileCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CheckResult | null>(null);

  const refresh = async () => {
    const res = await fetch("/api/figma-watch/check");
    const data = await res.json();
    setLog(data.log ?? []);
    setStatus(data.status ?? null);
    setWatchCount(data.watchCount ?? 0);
    setFileCount(data.fileCount ?? 0);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  const checkNow = async () => {
    setChecking(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/figma-watch/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const data = await res.json();
      await refresh();
      if (!res.ok) throw new Error(data.error);
      setResult({
        checked: data.checked,
        baselined: data.baselined,
        updates: data.newDrift ?? [],
        finishedAt: new Date().toISOString(),
      });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setChecking(false);
    }
  };

  const dismiss = async (driftId: string) => {
    await fetch("/api/figma-watch/check", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ driftId }),
    });
    refresh();
  };

  const unreviewed = log.filter((e) => !e.reviewed);
  const reviewed = log.filter((e) => e.reviewed).slice(0, 5);

  return (
    <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-lg text-ink flex items-center gap-2">
          Figma sync status
          {unreviewed.length > 0 && <Badge variant="sale">{unreviewed.length} unreviewed</Badge>}
        </h2>
        <Button size="sm" variant="secondary" onClick={checkNow} disabled={checking}>
          {checking ? "Checking…" : "Check now"}
        </Button>
      </div>

      {!loading && (
        <p className="text-sm text-ink-muted mb-3">
          Watching <span className="font-semibold text-ink">{watchCount}</span> mapped pieces across{" "}
          <span className="font-semibold text-ink">{fileCount}</span> Figma files.{" "}
          {status ? (
            <>
              Last checked{" "}
              <span className="font-semibold text-ink">{new Date(status.lastCheckedAt).toLocaleString()}</span> —{" "}
              {status.newDriftCount} {status.newDriftCount === 1 ? "change" : "changes"} detected. Checked
              automatically every day.
            </>
          ) : (
            <>Not checked yet. Checked automatically every day once scheduled checks are enabled.</>
          )}
        </p>
      )}

      {status && status.failedCount > 0 && !error && (
        <p className="text-xs text-sale mb-3">
          {status.failedCount} watched {status.failedCount === 1 ? "piece" : "pieces"} could not be checked on the last run.
        </p>
      )}

      {error && (
        <p className="text-xs text-sale mb-3">
          {error}
          {/FIGMA_TOKEN|Token|403/.test(error) && (
            <>
              {" "}— check <code className="font-mono bg-cream-100 px-1">FIGMA_TOKEN</code> in your environment variables.
            </>
          )}
        </p>
      )}

      {result && <CheckResultPanel result={result} />}

      {loading ? (
        <p className="text-sm text-ink-muted">Loading…</p>
      ) : unreviewed.length === 0 ? (
        <p className="text-sm text-ink-muted">No unreviewed changes in Figma.</p>
      ) : (
        <ul className="flex flex-col gap-3">
          {unreviewed.map((e) => (
            <li key={e.id} className="rounded-app-md border border-neutral-200 p-3 text-sm flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold text-ink">{e.label}</div>
                <div className="text-ink-muted">{e.summary}</div>
                <PageLinks pages={e.pages} />
                <div className="text-xs text-ink-muted mt-1">
                  {new Date(e.detectedAt).toLocaleString()} ·{" "}
                  <a href={e.figmaUrl} target="_blank" rel="noreferrer" className="text-primary-dark hover:underline">
                    View in Figma
                  </a>
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => dismiss(e.id)}>
                Mark reviewed
              </Button>
            </li>
          ))}
        </ul>
      )}

      {reviewed.length > 0 && (
        <div className="mt-4 border-t border-neutral-200 pt-3">
          <h3 className="text-xs font-semibold uppercase tracking-wide-ui text-ink-muted mb-2">Recently reviewed</h3>
          <ul className="flex flex-col gap-2">
            {reviewed.map((e) => (
              <li key={e.id} className="text-xs text-ink-muted">
                <span className="font-semibold text-ink">{e.label}</span> — {e.summary}{" "}
                <span>
                  ({new Date(e.detectedAt).toLocaleDateString()},{" "}
                  <a href={e.figmaUrl} target="_blank" rel="noreferrer" className="text-primary-dark hover:underline">
                    Figma
                  </a>
                  )
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
