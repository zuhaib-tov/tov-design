"use client";

import { Children, ReactNode, useState } from "react";
import { ScaleToFit } from "./ScaleToFit";

/** Live example + collapsible source, the Material-docs pattern. */
export function Preview({
  children,
  code,
  align = "center",
}: {
  children: ReactNode;
  code: string;
  align?: "center" | "start";
}) {
  const [showCode, setShowCode] = useState(false);

  return (
    <div className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white">
      <div
        className={`flex flex-wrap gap-4 p-8 bg-cream-100 ${
          align === "center" ? "items-center justify-center" : "items-start"
        }`}
      >
        {Children.map(children, (child) => (
          <ScaleToFit>{child}</ScaleToFit>
        ))}
      </div>
      <div className="border-t border-neutral-200">
        <button
          onClick={() => setShowCode((v) => !v)}
          className="w-full text-left px-4 py-2 text-xs font-semibold uppercase tracking-wide-ui text-ink-muted hover:bg-neutral-100"
        >
          {showCode ? "Hide code" : "Show code"}
        </button>
        {showCode && (
          <pre className="overflow-x-auto bg-charcoal text-neutral-100 text-sm p-4">
            <code>{code.trim()}</code>
          </pre>
        )}
      </div>
    </div>
  );
}

export function PropsTable({
  rows,
}: {
  rows: { name: string; type: string; default?: string; description: string }[];
}) {
  return (
    <div className="overflow-x-auto rounded-app-md border border-neutral-200 shadow-sm">
      <table className="w-full text-sm">
        <thead className="bg-cream-200 text-left">
          <tr>
            <th className="px-3 py-2 font-semibold">Prop</th>
            <th className="px-3 py-2 font-semibold">Type</th>
            <th className="px-3 py-2 font-semibold">Default</th>
            <th className="px-3 py-2 font-semibold">Description</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.name} className="border-t border-neutral-200">
              <td className="px-3 py-2 font-mono text-xs whitespace-nowrap">{r.name}</td>
              <td className="px-3 py-2 font-mono text-xs text-primary-dark whitespace-nowrap">{r.type}</td>
              <td className="px-3 py-2 font-mono text-xs text-ink-muted whitespace-nowrap">{r.default ?? "—"}</td>
              <td className="px-3 py-2 text-ink-muted">{r.description}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
