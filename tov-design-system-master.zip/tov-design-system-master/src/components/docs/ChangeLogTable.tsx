"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { entriesForPage, type ChangeStatus } from "@/lib/changelog";
import { Badge } from "@/components/ui/Badge";

const STATUS_LABEL: Record<ChangeStatus, string> = {
  new: "New",
  updated: "Updated",
  stable: "Stable",
  draft: "Draft",
};

const STATUS_VARIANT: Record<ChangeStatus, "new" | "success" | "neutral" | "sale"> = {
  new: "new",
  updated: "new",
  stable: "success",
  draft: "sale",
};

/** Per-page change-tracking table, sourced from src/lib/changelog.ts. Newest first; each row's full summary expands in place. */
export function ChangeLogTable({ page }: { page: string }) {
  const entries = entriesForPage(page); // sorted newest-first
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  const toggle = (i: number) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  return (
    <section>
      <h2 className="font-display text-xl text-ink mb-4">Change tracking</h2>
      {entries.length === 0 ? (
        <p className="text-sm text-ink-muted rounded-app-md border border-neutral-200 shadow-sm bg-white p-4">
          No changes logged for this page yet.
        </p>
      ) : (
        <div className="rounded-app-md border border-neutral-200 shadow-sm bg-white overflow-hidden overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-cream-100 text-left">
              <tr>
                <th className="w-8 px-3 py-2" aria-hidden />
                <th className="px-3 py-2 font-semibold whitespace-nowrap">Date</th>
                <th className="px-3 py-2 font-semibold whitespace-nowrap">Component</th>
                <th className="px-3 py-2 font-semibold whitespace-nowrap">Status</th>
                <th className="px-3 py-2 font-semibold">Summary</th>
                <th className="px-3 py-2 font-semibold text-right whitespace-nowrap">Figma</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e, i) => {
                const isOpen = expanded.has(i);
                return (
                  <tr
                    key={i}
                    onClick={() => toggle(i)}
                    className="border-t border-neutral-200 align-top cursor-pointer hover:bg-cream-100/60"
                  >
                    <td className="px-3 py-2.5">
                      <ChevronDown
                        size={14}
                        className={`text-ink-muted transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs text-ink-muted whitespace-nowrap">
                      {e.date}
                    </td>
                    <td className="px-3 py-2.5 font-semibold whitespace-nowrap">{e.component}</td>
                    <td className="px-3 py-2.5">
                      <Badge variant={STATUS_VARIANT[e.status]} size="sm">
                        {STATUS_LABEL[e.status]}
                      </Badge>
                    </td>
                    <td className={`px-3 py-2.5 text-ink-muted max-w-md ${isOpen ? "" : "line-clamp-1"}`}>
                      {e.summary}
                    </td>
                    <td
                      className="px-3 py-2.5 text-right whitespace-nowrap"
                      onClick={(ev) => ev.stopPropagation()}
                    >
                      {e.figmaUrl ? (
                        <a
                          href={e.figmaUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-primary-dark hover:underline text-xs font-semibold"
                        >
                          View
                        </a>
                      ) : (
                        <span className="text-ink-muted text-xs">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
