import Link from "next/link";
import { Badge } from "@/components/ui/Badge";

export function PageSystemStub({
  title,
  description,
  planned,
}: {
  title: string;
  description: string;
  planned: string[];
}) {
  return (
    <div className="max-w-4xl px-8 py-10">
      <div className="flex items-center gap-3 mb-2">
        <h1 className="font-display text-4xl text-primary-dark">{title}</h1>
        <Badge variant="neutral">Not started</Badge>
      </div>
      <p className="text-ink-muted max-w-2xl mb-10">{description}</p>

      <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6">
        <h2 className="font-display text-lg text-ink mb-3">Planned page-level components</h2>
        <ul className="flex flex-col gap-2">
          {planned.map((item) => (
            <li key={item} className="text-sm text-ink-muted flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-6 rounded-app-lg bg-cream-100 p-5 text-sm text-ink-muted">
        These are compositions of the atoms already under{" "}
        <Link href="/" className="text-primary-dark hover:underline">Components</Link> —
        e.g. a Product Gallery combines Badge, Rating, and Price. Nothing on this
        page is built yet — this is a placeholder for the structure. See{" "}
        <code className="font-mono bg-white rounded-app-sm px-1 py-0.5">FIGMA_SYSTEMS.md</code> for
        this system&apos;s Figma file and sync status once one exists.
      </div>
    </div>
  );
}
