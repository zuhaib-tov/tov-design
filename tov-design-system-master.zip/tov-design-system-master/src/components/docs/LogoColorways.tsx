"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { saveBlob, svgToPng } from "@/lib/download";
import {
  LOGO_COLORWAYS,
  LOGO_PNG_WIDTH,
  LOGO_SHAPES,
  LOGO_VIEWBOX,
  logoSvg,
  type LogoColorway,
} from "@/lib/logoGuidelines";

function svgBlob(c: LogoColorway) {
  return new Blob([logoSvg(c)], { type: "image/svg+xml" });
}

function pngBlob(c: LogoColorway): Promise<Blob> {
  const w = LOGO_PNG_WIDTH;
  return svgToPng(logoSvg(c), w, Math.round((w * LOGO_VIEWBOX.h) / LOGO_VIEWBOX.w));
}

/** SVG and PNG download buttons for one colorway, for use beside a logo shown elsewhere on the page. */
export function LogoColorwayDownload({ colorway }: { colorway: LogoColorway["key"] }) {
  const c = LOGO_COLORWAYS.find((x) => x.key === colorway);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (!c) return null;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2">
        <Button size="sm" variant="primary" onClick={() => saveBlob(svgBlob(c), `${c.file}.svg`)}>
          SVG
        </Button>
        <Button
          size="sm"
          variant="tertiary"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            setError(null);
            try {
              saveBlob(await pngBlob(c), `${c.file}.png`);
            } catch (err) {
              setError((err as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          PNG
        </Button>
      </div>
      {error && <p className="text-xs text-sale">{error}</p>}
    </div>
  );
}

/** Every colorway as SVG and PNG, for the all-assets ZIP. */
export async function colorwayFiles(): Promise<{ name: string; data: string | Blob }[]> {
  const files: { name: string; data: string | Blob }[] = [];
  for (const c of LOGO_COLORWAYS) {
    files.push({ name: `${c.file}.svg`, data: logoSvg(c) });
    files.push({ name: `${c.file}.png`, data: await pngBlob(c) });
  }
  return files;
}

function Preview({ c }: { c: LogoColorway }) {
  const flat = c.ink === c.accent;
  const { x, y, w, h } = LOGO_VIEWBOX;
  return (
    <svg viewBox={`${x} ${y} ${w} ${h}`} className="h-auto w-[140px]" role="img" aria-label={`${c.name} TOV logo`}>
      <polygon points={LOGO_SHAPES.t} fill={c.ink} />
      <path fillRule="evenodd" d={LOGO_SHAPES.oRing} fill={c.accent} />
      {!flat && <path d={LOGO_SHAPES.oHalf} fill={c.ink} />}
      <polygon points={LOGO_SHAPES.v} fill={c.ink} />
    </svg>
  );
}

/** The four approved colorways with SVG and PNG downloads, and one ZIP of all eight files. */
export function LogoColorways() {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async (id: string, job: () => Promise<void>) => {
    setBusy(id);
    setError(null);
    try {
      await job();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const downloadAll = () =>
    run("all", async () => {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      for (const c of LOGO_COLORWAYS) {
        zip.file(`${c.file}.svg`, logoSvg(c));
        zip.file(`${c.file}.png`, await pngBlob(c));
      }
      saveBlob(await zip.generateAsync({ type: "blob" }), "tov-logo-assets.zip");
    });

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {LOGO_COLORWAYS.map((c) => (
          <div key={c.key} className="flex flex-col overflow-hidden rounded-app-lg border border-neutral-200 bg-white shadow-sm">
            <div className="flex min-h-[96px] items-center justify-center px-6 py-6" style={{ background: c.surface }}>
              <Preview c={c} />
            </div>
            <div className="flex flex-col gap-2 border-t border-neutral-200 p-4">
              <div className="text-base font-bold text-ink">{c.name}</div>
              <p className="text-[13px] leading-[1.5] text-ink-muted">{c.usage}</p>
              <div className="flex gap-2 pt-1">
                <Button
                  size="sm"
                  variant="primary"
                  className="flex-1"
                  onClick={() => saveBlob(svgBlob(c), `${c.file}.svg`)}
                >
                  SVG
                </Button>
                <Button
                  size="sm"
                  variant="tertiary"
                  className="flex-1"
                  disabled={busy !== null}
                  onClick={() => run(`${c.key}-png`, async () => saveBlob(await pngBlob(c), `${c.file}.png`))}
                >
                  PNG
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-4 border-t border-neutral-200 pt-4">
        <p className="max-w-md text-[13px] leading-[1.5] text-ink-muted">
          PNG exports are transparent and {LOGO_PNG_WIDTH}px wide. Need another size or a square-canvas master? Ask
          the brand team.
        </p>
        <Button variant="primary" onClick={downloadAll} disabled={busy !== null}>
          {busy === "all" ? "Preparing…" : "Download all eight"}
        </Button>
      </div>
      {error && <p className="text-xs text-sale">{error}</p>}
    </div>
  );
}
