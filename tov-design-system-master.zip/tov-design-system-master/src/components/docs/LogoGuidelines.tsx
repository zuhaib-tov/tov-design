import { CONSTRUCTION_FACTS, LOGO_DONTS, LOGO_SHAPES, LOGO_VIEWBOX } from "@/lib/logoGuidelines";

const TRUFFLE = "var(--color-truffle)";
const ALERT = "#A40713";
const FONT = "var(--font-sans), Montserrat, sans-serif";

/** The four wordmark shapes in their on-grid coordinates. */
function Shapes({ ink = "#000000", accent = "#F9D2D2" }: { ink?: string; accent?: string }) {
  return (
    <>
      <polygon points={LOGO_SHAPES.t} fill={ink} />
      <path fillRule="evenodd" d={LOGO_SHAPES.oRing} fill={accent} />
      <path d={LOGO_SHAPES.oHalf} fill={ink} />
      <polygon points={LOGO_SHAPES.v} fill={ink} />
    </>
  );
}

function Mark({ width, label }: { width: number; label: string }) {
  const { x, y, w, h } = LOGO_VIEWBOX;
  return (
    <div className="flex flex-col items-start gap-2">
      <svg viewBox={`${x} ${y} ${w} ${h}`} style={{ width }} className="h-auto" role="img" aria-label="TOV logo">
        <Shapes />
      </svg>
      <p className="text-xs text-ink-muted">{label}</p>
    </div>
  );
}

/** The wordmark on its grid, with cap height, baseline, overshoot and letter widths marked. */
export function LogoConstruction() {
  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
        <svg viewBox="150 370 686 270" className="block h-auto w-full" role="img" aria-label="TOV logo on its construction grid">
          <g stroke="#F9D2D2" strokeWidth="1.2" fill="none">
            <line x1="160" y1="415" x2="826" y2="415" />
            <line x1="160" y1="585" x2="826" y2="585" />
            <line x1="160" y1="500" x2="826" y2="500" strokeDasharray="6 6" />
            <line x1="160" y1="412" x2="826" y2="412" strokeDasharray="3 5" />
            <line x1="160" y1="588" x2="826" y2="588" strokeDasharray="3 5" />
            <line x1="200" y1="380" x2="200" y2="620" />
            <line x1="344" y1="380" x2="344" y2="620" />
            <line x1="383" y1="380" x2="383" y2="620" />
            <line x1="567" y1="380" x2="567" y2="620" />
            <line x1="606" y1="380" x2="606" y2="620" />
            <line x1="786" y1="380" x2="786" y2="620" />
            <circle cx="475" cy="500" r="92" />
            <circle cx="475" cy="500" r="60" />
            <line x1="475" y1="380" x2="475" y2="620" strokeDasharray="6 6" />
          </g>
          <Shapes />
          <g fill={TRUFFLE} fontFamily={FONT} fontSize="13">
            <text x="160" y="408">CAP 415</text>
            <text x="160" y="602">BASE 585</text>
            <text x="600" y="404" textAnchor="end">OVERSHOOT +3</text>
            <text x="272" y="640" textAnchor="middle">144</text>
            <text x="475" y="640" textAnchor="middle">184</text>
            <text x="696" y="640" textAnchor="middle">180</text>
          </g>
          <g stroke={TRUFFLE} strokeWidth="1">
            <line x1="200" y1="625" x2="344" y2="625" />
            <line x1="383" y1="625" x2="567" y2="625" />
            <line x1="606" y1="625" x2="786" y2="625" />
          </g>
        </svg>
      </div>

      <div className="grid grid-cols-1 gap-px overflow-hidden rounded-app-lg border border-neutral-200 bg-neutral-200 sm:grid-cols-3">
        {CONSTRUCTION_FACTS.map((f) => (
          <div key={f.label} className="flex flex-col gap-1 bg-cream-50 p-4">
            <div className="text-3xl font-bold leading-none text-charcoal">{f.value}</div>
            <div className="text-xs font-bold uppercase tracking-wide-ui text-ink-muted">{f.label}</div>
            <p className="text-[13px] leading-[1.5] text-ink-muted">{f.note}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Clear-space diagram, minimum sizes and the list of misuses. */
export function LogoClearSpace() {
  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm">
        <svg viewBox="0 0 938 528" className="block h-auto w-full" role="img" aria-label="Clear space around the TOV logo equals the height of the O">
          <rect x="0.5" y="0.5" width="937" height="527" fill="#F1ECE5" />
          <rect x="176.5" y="176.5" width="586" height="175" fill="none" stroke={TRUFFLE} strokeWidth="1" strokeDasharray="6 6" />
          <g transform="translate(-23.5,-235.5)">
            <Shapes />
          </g>
          <g stroke={ALERT} strokeWidth="1">
            <line x1="88" y1="176" x2="88" y2="352" />
            <line x1="80" y1="176" x2="96" y2="176" />
            <line x1="80" y1="352" x2="96" y2="352" />
          </g>
          <text x="104" y="270" fill={ALERT} fontFamily={FONT} fontSize="15" fontWeight="700">X</text>
          <text x="20" y="30" fill={TRUFFLE} fontFamily={FONT} fontSize="14">X = height of the O</text>
        </svg>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="flex flex-col gap-4">
          <h3 className="text-xs font-bold uppercase tracking-wide-ui text-ink-muted">Minimum sizes</h3>
          <div className="flex items-end gap-7 border-y border-neutral-200 py-5">
            <Mark width={107} label="Digital — 32px tall" />
            <Mark width={48} label="Print — 0.5in wide" />
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <h3 className="text-xs font-bold uppercase tracking-wide-ui text-ink-muted">Do not</h3>
          <ul className="flex flex-col gap-2.5 text-sm leading-[1.5] text-ink-muted">
            {LOGO_DONTS.map((d) => (
              <li key={d} className="grid grid-cols-[16px_1fr] gap-2.5">
                <span aria-hidden="true" style={{ color: ALERT }}>×</span>
                <span>{d}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
