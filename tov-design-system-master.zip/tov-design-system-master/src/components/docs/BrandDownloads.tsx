"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { BRAND_ASSETS, BRAND_PNG_SCALE, brandAsset, type BrandAsset } from "@/lib/brandAssets";
import { fetchText, saveBlob, svgToPng } from "@/lib/download";
import { colorwayFiles } from "@/components/docs/LogoColorways";

async function assetPng(a: BrandAsset): Promise<Blob> {
  const svg = await fetchText(a.src);
  return svgToPng(svg, a.width * BRAND_PNG_SCALE, a.height * BRAND_PNG_SCALE);
}

/** SVG and PNG download buttons for one brand file from /public/brand. */
export function BrandAssetDownload({ asset }: { asset: BrandAsset["key"] }) {
  const a = brandAsset(asset);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async (id: string, job: () => Promise<void>) => {
    setBusy(id);
    setError(null);
    try {
      await job();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2">
        <Button
          size="sm"
          variant="primary"
          disabled={busy !== null}
          onClick={() =>
            run("svg", async () => saveBlob(new Blob([await fetchText(a.src)], { type: "image/svg+xml" }), `${a.file}.svg`))
          }
        >
          SVG
        </Button>
        <Button
          size="sm"
          variant="tertiary"
          disabled={busy !== null}
          onClick={() => run("png", async () => saveBlob(await assetPng(a), `${a.file}.png`))}
        >
          PNG
        </Button>
      </div>
      {error && <p className="text-xs text-sale">{error}</p>}
    </div>
  );
}

/** One ZIP with every logo colorway, the logo mark and both taglines, each as SVG and PNG. */
export function DownloadAllBrandAssets() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const download = async () => {
    setBusy(true);
    setError(null);
    try {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      const logos = zip.folder("logo");
      for (const f of await colorwayFiles()) logos?.file(f.name, f.data);
      for (const a of BRAND_ASSETS) {
        const folder = zip.folder(a.key === "mark" ? "logo-mark" : "tagline");
        folder?.file(`${a.file}.svg`, await fetchText(a.src));
        folder?.file(`${a.file}.png`, await assetPng(a));
      }
      saveBlob(await zip.generateAsync({ type: "blob" }), "tov-brand-assets.zip");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 rounded-app-lg border border-neutral-200 bg-white p-5 shadow-sm sm:flex-row sm:items-center sm:justify-between">
      <div className="max-w-xl">
        <div className="text-base font-bold text-ink">All brand assets</div>
        <p className="text-[13px] leading-[1.5] text-ink-muted">
          One ZIP with the four logo colorways, the logo mark and both taglines, each as an SVG and a transparent PNG
          (14 files, in logo, logo-mark and tagline folders).
        </p>
        {error && <p className="mt-1 text-xs text-sale">{error}</p>}
      </div>
      <Button variant="primary" onClick={download} disabled={busy} className="shrink-0">
        {busy ? "Preparing…" : "Download all"}
      </Button>
    </div>
  );
}
