"use client";

import { useMemo, useState } from "react";
import { DocSection } from "@/components/docs/DocPage";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

export interface IconSection {
  title: string;
  updated?: boolean;
  files: string[];
}

function label(file: string) {
  return file.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function fetchSvg(file: string) {
  const res = await fetch(`/icons/${file}.svg`);
  if (!res.ok) throw new Error(`Could not load ${file}.svg`);
  return res.text();
}

export function IconLibrary({ sections }: { sections: IconSection[] }) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const all = useMemo(() => sections.flatMap((s) => s.files), [sections]);
  const count = selected.size;

  const toggle = (file: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(file)) next.delete(file);
      else next.add(file);
      return next;
    });

  const setMany = (files: string[], on: boolean) =>
    setSelected((prev) => {
      const next = new Set(prev);
      for (const f of files) {
        if (on) next.add(f);
        else next.delete(f);
      }
      return next;
    });

  const download = async () => {
    if (count === 0) return;
    setBusy(true);
    setError(null);
    try {
      const files = all.filter((f) => selected.has(f));
      if (files.length === 1) {
        const svg = await fetchSvg(files[0]);
        saveBlob(new Blob([svg], { type: "image/svg+xml" }), `${files[0]}.svg`);
      } else {
        const { default: JSZip } = await import("jszip");
        const zip = new JSZip();
        const contents = await Promise.all(files.map(fetchSvg));
        files.forEach((f, i) => zip.file(`${f}.svg`, contents[i]));
        const blob = await zip.generateAsync({ type: "blob" });
        saveBlob(blob, `tov-icons-${files.length}.zip`);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="sticky top-0 z-10 -mt-4 flex flex-wrap items-center gap-3 rounded-app-lg border border-neutral-200 bg-white/95 px-4 py-3 shadow-sm backdrop-blur">
        <p className="mr-auto text-sm text-ink">
          {count === 0 ? (
            <span className="text-ink-muted">Select the icons you want to download.</span>
          ) : (
            <>
              <span className="font-semibold">{count}</span> {count === 1 ? "icon" : "icons"} selected
            </>
          )}
        </p>
        <Button size="sm" variant="ghost" onClick={() => setMany(all, count !== all.length)}>
          {count === all.length ? "Clear all" : `Select all ${all.length}`}
        </Button>
        {count > 0 && count !== all.length && (
          <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
            Clear
          </Button>
        )}
        <Button size="sm" variant="primary" onClick={download} disabled={count === 0 || busy}>
          {busy ? "Preparing…" : count <= 1 ? "Download SVG" : `Download ${count} as ZIP`}
        </Button>
        {error && <p className="w-full text-xs text-sale">{error}</p>}
      </div>

      {sections.map((section) => {
        const sectionCount = section.files.filter((f) => selected.has(f)).length;
        const allOn = sectionCount === section.files.length;
        return (
          <DocSection
            key={section.title}
            title={
              <>
                {section.title}
                {section.updated && <Badge variant="new">Updated</Badge>}
                <button
                  type="button"
                  onClick={() => setMany(section.files, !allOn)}
                  className="ml-auto font-sans text-xs font-medium text-primary-dark hover:underline"
                >
                  {allOn ? "Clear section" : "Select section"}
                </button>
              </>
            }
          >
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 md:grid-cols-6">
              {section.files.map((file) => {
                const on = selected.has(file);
                return (
                  <button
                    key={file}
                    type="button"
                    aria-pressed={on}
                    aria-label={`${label(file)}${on ? ", selected" : ""}`}
                    onClick={() => toggle(file)}
                    className={`relative flex flex-col items-center gap-2 rounded-app-md border bg-white p-4 text-center shadow-sm transition-colors ${
                      on ? "border-primary ring-1 ring-primary" : "border-neutral-200 hover:border-neutral-400"
                    }`}
                  >
                    <span
                      aria-hidden="true"
                      className={`absolute left-2 top-2 flex h-4 w-4 items-center justify-center rounded-sm border text-[10px] leading-none ${
                        on ? "border-primary bg-primary text-white" : "border-neutral-300 bg-white text-transparent"
                      }`}
                    >
                      ✓
                    </span>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={`/icons/${file}.svg`} alt="" className="h-6 w-6" />
                    <span className="font-mono text-[11px] text-ink-muted">{file}</span>
                  </button>
                );
              })}
            </div>
          </DocSection>
        );
      })}
    </>
  );
}
