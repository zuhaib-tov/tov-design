"use client";

import { useRef, useState } from "react";
import { Button } from "@/components/ui/Button";
import {
  MARKETING_CAMPAIGN_NAMES,
  MARKETING_PAGE_TYPES,
  marketingFolder,
} from "@/lib/marketing-campaigns";
import type { AssetRecord } from "@/lib/asset-store";
import { uploadFilesToLibrary } from "@/lib/upload-client";

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function isSpreadsheet(mimeType: string, name: string) {
  return (
    mimeType.includes("spreadsheet") ||
    mimeType === "text/csv" ||
    /\.(csv|xlsx?|numbers)$/i.test(name)
  );
}

const ACCEPT = "image/*,video/*,.csv,.xls,.xlsx,.numbers";

export function MarketingUploads({
  assets,
  upsertAssets,
  removeAssetsLocally,
}: {
  assets: AssetRecord[];
  upsertAssets: (updated: AssetRecord[]) => void;
  removeAssetsLocally: (ids: string[]) => void;
}) {
  const [campaign, setCampaign] = useState<string | null>(null);
  const [pageType, setPageType] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const marketingAssets = assets.filter((a) => a.category === "marketing");
  const countFor = (c: string, p?: string) =>
    marketingAssets.filter((a) => a.campaign === c && (!p || a.pageType === p)).length;

  const uploadFiles = async (files: FileList | File[]) => {
    if (!campaign || !pageType) return;
    setUploading(true);
    setUploadError(null);
    try {
      const { uploaded, errors } = await uploadFilesToLibrary(files, {
        folder: marketingFolder(campaign, pageType),
        category: "marketing",
        campaign,
        pageType,
      });
      if (uploaded.length) upsertAssets(uploaded);
      if (errors.length) {
        setUploadError(errors.map((e) => `${e.fileName}: ${e.message}`).join("; "));
      }
    } catch (err) {
      setUploadError((err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const removeAsset = async (id: string) => {
    const res = await fetch(`/api/assets/${id}`, { method: "DELETE" });
    if (res.ok) removeAssetsLocally([id]);
  };

  const [requesting, setRequesting] = useState(false);
  const requestFigmaPush = async () => {
    if (!campaign || !pageType) return;
    setRequesting(true);
    const res = await fetch("/api/assets/figma-push", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "request", campaign, pageType }),
    });
    const data = await res.json();
    if (res.ok) upsertAssets(data.assets ?? []);
    setRequesting(false);
  };

  const currentAssets = marketingAssets.filter(
    (a) => a.campaign === campaign && a.pageType === pageType
  );
  const pushableCount = currentAssets.filter(
    (a) => a.mimeType.startsWith("image/") && !a.figmaPushedAt
  ).length;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide-ui text-ink-muted">
        <button
          onClick={() => {
            setCampaign(null);
            setPageType(null);
          }}
          className={campaign ? "hover:text-primary-dark" : "text-primary-dark"}
        >
          Marketing Uploads
        </button>
        {campaign && (
          <>
            <span>/</span>
            <button
              onClick={() => setPageType(null)}
              className={pageType ? "hover:text-primary-dark" : "text-primary-dark"}
            >
              {campaign}
            </button>
          </>
        )}
        {pageType && (
          <>
            <span>/</span>
            <span className="text-primary-dark">{pageType}</span>
          </>
        )}
      </div>

      {!campaign && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {MARKETING_CAMPAIGN_NAMES.map((c) => (
            <button
              key={c}
              onClick={() => setCampaign(c)}
              className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-5 text-left hover:border-primary transition-colors"
            >
              <p className="font-display text-base text-primary-dark">{c}</p>
              <p className="text-xs text-ink-muted mt-1">
                {countFor(c)} {countFor(c) === 1 ? "asset" : "assets"}
              </p>
            </button>
          ))}
        </div>
      )}

      {campaign && !pageType && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {MARKETING_PAGE_TYPES.map((p) => (
            <button
              key={p}
              onClick={() => setPageType(p)}
              className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 text-left hover:border-primary transition-colors"
            >
              <p className="font-display text-lg text-primary-dark">{p}</p>
              <p className="text-xs text-ink-muted mt-1">
                {countFor(campaign, p)} {countFor(campaign, p) === 1 ? "asset" : "assets"}
              </p>
            </button>
          ))}
        </div>
      )}

      {campaign && pageType && (
        <div className="flex flex-col gap-6">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`rounded-app-lg border-2 border-dashed p-8 text-center text-sm text-ink-muted cursor-pointer ${
              dragOver ? "border-primary bg-cream-100" : "border-neutral-200 bg-white"
            }`}
          >
            Drag & drop images, videos, or spreadsheets — or click to choose files
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={ACCEPT}
              className="hidden"
              onChange={(e) => e.target.files && uploadFiles(e.target.files)}
            />
            {uploading && <p className="text-xs mt-2">Uploading…</p>}
            {uploadError && <p className="text-xs mt-2 text-sale">{uploadError}</p>}
          </div>

          {currentAssets.length === 0 ? (
            <p className="text-sm text-ink-muted rounded-app-lg border border-neutral-200 shadow-sm bg-white p-8 text-center">
              No assets yet in {campaign} / {pageType}.
            </p>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={requestFigmaPush}
                  disabled={pushableCount === 0 || requesting}
                >
                  Request push to Figma {pushableCount > 0 ? `(${pushableCount})` : ""}
                </Button>
                <p className="text-xs text-ink-muted">
                  Figma has no write API — this flags images for Claude to place into the{" "}
                  {campaign} page next time it's asked.
                </p>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {currentAssets.map((asset) => (
                <div
                  key={asset.id}
                  className="rounded-app-lg overflow-hidden border border-neutral-200 shadow-sm bg-white relative"
                >
                  {(asset.figmaPushedAt || asset.figmaPushRequestedAt) && (
                    <span className="absolute top-2 right-2 z-10 rounded-pill bg-white/90 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide-ui text-ink-muted">
                      {asset.figmaPushedAt ? "In Figma" : "Requested"}
                    </span>
                  )}
                  <div className="aspect-square bg-cream-200 flex items-center justify-center">
                    {asset.mimeType.startsWith("image/") ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={`/api/assets/${asset.id}`}
                        alt={asset.originalName}
                        className="w-full h-full object-cover"
                      />
                    ) : asset.mimeType.startsWith("video/") ? (
                      <video
                        src={`/api/assets/${asset.id}`}
                        className="w-full h-full object-cover"
                        muted
                      />
                    ) : (
                      <span className="text-xs font-semibold uppercase tracking-wide-ui text-ink-muted px-2 text-center">
                        {isSpreadsheet(asset.mimeType, asset.originalName) ? "Spreadsheet" : "File"}
                      </span>
                    )}
                  </div>
                  <div className="p-2">
                    <p className="text-xs truncate" title={asset.originalName}>
                      {asset.originalName}
                    </p>
                    <p className="text-[11px] text-ink-muted">{formatBytes(asset.size)}</p>
                    <div className="flex items-center justify-between mt-2">
                      <a
                        href={`/api/assets/${asset.id}?download=1`}
                        className="text-[11px] font-semibold uppercase tracking-wide-ui text-primary-dark hover:text-primary"
                      >
                        Download
                      </a>
                      <button
                        onClick={() => removeAsset(asset.id)}
                        className="text-[11px] text-ink-muted hover:text-sale"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              </div>
            </>
          )}

          <Button variant="ghost" size="sm" onClick={() => setPageType(null)} className="self-start">
            ← Back to {campaign}
          </Button>
        </div>
      )}
    </div>
  );
}
