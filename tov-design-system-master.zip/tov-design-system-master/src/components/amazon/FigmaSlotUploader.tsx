"use client";

import { useEffect, useRef, useState } from "react";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import type { AssetRecord } from "@/lib/asset-store";
import { uploadFilesToLibrary } from "@/lib/upload-client";
import type { FigmaSlot } from "@/lib/amazon/figma-slots";

/**
 * "Update images in Figma" — embedded on an Amazon component's doc page.
 * Upload replacement images, assign each one to an exact Figma node from a
 * fixed slot list (no freeform naming, no ambiguity about where it lands),
 * then Claude places it directly into that node next time it's asked —
 * Figma has no write REST API, so an assisted session still has to do the
 * actual placement (see the Figma Image Export tool's own note on this).
 *
 * Slots with hasExistingImage: true get a visible warning in the dropdown
 * and the status row, since replacing a real image is different from
 * filling an empty one — see the per-page slot list for which is which.
 */
export function FigmaSlotUploader({
  folder,
  figmaFileKey,
  figmaFileUrl,
  slots,
}: {
  folder: string;
  figmaFileKey: string;
  figmaFileUrl: string;
  slots: FigmaSlot[];
}) {
  const [assets, setAssets] = useState<AssetRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [brokenIds, setBrokenIds] = useState<Set<string>>(new Set());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = async () => {
    setLoading(true);
    const res = await fetch("/api/assets");
    const data = await res.json();
    setAssets((data.assets ?? []).filter((a: AssetRecord) => a.folder === folder));
    setLoading(false);
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const uploadFiles = async (files: FileList | File[]) => {
    setUploading(true);
    setUploadError(null);
    try {
      const { uploaded, errors } = await uploadFilesToLibrary(files, { folder });
      if (uploaded.length) setAssets((prev) => [...uploaded, ...prev]);
      if (errors.length) setUploadError(errors.map((e) => `${e.fileName}: ${e.message}`).join("; "));
    } catch (err) {
      setUploadError((err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const assignSlot = async (asset: AssetRecord, slotName: string) => {
    const slot = slots.find((s) => s.name === slotName);
    const res = await fetch("/api/assets/figma-slot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        asset,
        figmaTargetFileKey: slot ? figmaFileKey : undefined,
        figmaTargetNodeIds: slot?.nodeIds,
        figmaTargetLabel: slot?.name,
      }),
    });
    const data = await res.json();
    if (res.ok && data.asset) {
      setAssets((prev) => prev.map((a) => (a.id === asset.id ? data.asset : a)));
    }
  };

  const requestPush = async (asset: AssetRecord) => {
    const res = await fetch("/api/assets/figma-push-request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ asset }),
    });
    const data = await res.json();
    if (res.ok && data.asset) {
      setAssets((prev) => prev.map((a) => (a.id === asset.id ? data.asset : a)));
    }
  };

  const removeAsset = async (id: string) => {
    await fetch(`/api/assets/${id}`, { method: "DELETE" });
    setAssets((prev) => prev.filter((a) => a.id !== id));
  };

  const assignedNodeOwners = new Map<string, string>();
  assets.forEach((a) => (a.figmaTargetNodeIds ?? []).forEach((nodeId) => assignedNodeOwners.set(nodeId, a.id)));

  return (
    <div className="rounded-app-lg border border-neutral-200 shadow-sm bg-white p-6 flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-lg text-ink">Update images in Figma</h2>
        <a
          href={figmaFileUrl}
          target="_blank"
          rel="noreferrer"
          className="text-xs font-semibold uppercase tracking-wide-ui text-primary-dark hover:text-primary whitespace-nowrap"
        >
          Open in Figma
        </a>
      </div>
      <p className="text-xs text-ink-muted">
        Upload your new images, assign each one to the exact slot it belongs to, then hit{" "}
        <strong>Push to Figma</strong>. Figma has no write API, so pushing only queues the
        request — it lands in the file once someone runs the{" "}
        <strong>TOV — Push Images</strong> plugin inside Figma (see{" "}
        <code className="font-mono bg-cream-100 rounded-app-sm px-1 py-0.5">figma-plugin/</code>{" "}
        in the repo), or next time an assisted Claude session is working with you.
      </p>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
        }}
        onClick={() => fileInputRef.current?.click()}
        className={`rounded-app-md border-2 border-dashed p-6 text-center text-sm cursor-pointer ${
          dragOver ? "border-primary bg-cream-100" : "border-neutral-200 bg-cream-50"
        }`}
      >
        Drag & drop images, or click to choose files
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={(e) => e.target.files && uploadFiles(e.target.files)}
        />
        {uploading && <p className="text-xs mt-2">Uploading…</p>}
      </div>
      {uploadError && <p className="text-xs text-sale">{uploadError}</p>}

      {!loading && assets.length === 0 && (
        <p className="text-xs text-ink-muted text-center py-2">No images uploaded here yet.</p>
      )}

      {assets.length > 0 && (
        <div className="flex flex-col gap-3">
          {assets.map((asset) => {
            const assignedSlot = slots.find((s) => s.name === asset.figmaTargetLabel);
            return (
              <div
                key={asset.id}
                className="flex items-center gap-3 border border-neutral-200 rounded-app-md p-3"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`/api/assets/${asset.id}`}
                  alt=""
                  onError={() => setBrokenIds((prev) => new Set(prev).add(asset.id))}
                  className="w-16 h-16 object-cover rounded-app-sm shrink-0 bg-cream-200"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs truncate text-ink-muted mb-1" title={asset.originalName}>
                    {asset.originalName}
                  </p>
                  {brokenIds.has(asset.id) && (
                    <p className="text-[11px] text-sale mb-1">
                      This upload didn&apos;t save correctly — delete it and upload the file again.
                    </p>
                  )}
                  <select
                    value={asset.figmaTargetLabel ?? ""}
                    onChange={(e) => assignSlot(asset, e.target.value)}
                    className="w-full border border-black text-sm px-2 py-1.5 bg-white"
                  >
                    <option value="">Choose a slot…</option>
                    {slots.map((s) => {
                      const takenByOther = s.nodeIds.some((nodeId) => {
                        const owner = assignedNodeOwners.get(nodeId);
                        return !!owner && owner !== asset.id;
                      });
                      return (
                        <option key={s.name} value={s.name} disabled={takenByOther}>
                          {s.name}
                          {s.hasExistingImage ? " (has an image already)" : ""}
                          {takenByOther ? " — already assigned" : ""}
                        </option>
                      );
                    })}
                  </select>
                  {assignedSlot?.hasExistingImage && (
                    <p className="text-[11px] text-ink-muted mt-1">
                      This slot already has an image — pushing replaces it directly. Archive it in
                      Figma yourself first if you want to keep the current one.
                    </p>
                  )}
                </div>
                <div className="shrink-0">
                  {brokenIds.has(asset.id) ? (
                    <Badge variant="sale">Broken — Re-upload</Badge>
                  ) : asset.figmaPushedAt ? (
                    <Badge variant="success">In Figma</Badge>
                  ) : asset.figmaPushRequestedAt ? (
                    <Badge variant="new">Requested</Badge>
                  ) : asset.figmaTargetNodeIds?.length ? (
                    <Button size="sm" onClick={() => requestPush(asset)}>
                      Push to Figma
                    </Button>
                  ) : (
                    <Badge variant="neutral">Unassigned</Badge>
                  )}
                </div>
                <button
                  onClick={() => removeAsset(asset.id)}
                  className="text-[11px] text-ink-muted hover:text-sale shrink-0"
                >
                  Delete
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
