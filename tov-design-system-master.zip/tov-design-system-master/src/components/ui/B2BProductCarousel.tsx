"use client";

import { useRef } from "react";
import { ChevronRight } from "lucide-react";
import { B2BFeatureCard } from "./B2BFeatureCard";
import { B2BProductCard } from "./B2BProductCard";

export interface B2BCarouselProduct {
  tag?: string;
  eyebrow?: string;
  /** `strong` sets the eyebrow as a bold grade label instead of a muted uppercase note. */
  eyebrowStyle?: "muted" | "strong";
  name: string;
  price?: string;
  image?: string;
  nameSize?: "lg" | "base";
}

export interface B2BProductCarouselProps {
  variant?: "new-arrivals" | "best-sellers";
  viewport?: "desktop" | "mobile";
  products: B2BCarouselProduct[];
  /** Photograph behind the feature card. */
  featureImage?: string;
  /** Extra classes for the next-arrow button, e.g. to inset it from the right edge. */
  arrowClassName?: string;
  className?: string;
}

const VARIANT_COPY = {
  "new-arrivals": { eyebrow: "In stock", showStatusDot: true, title: "New Arrivals", link: "See All New" },
  "best-sellers": { eyebrow: "The best performance", showStatusDot: false, title: "Best Sellers", link: "See All Best Sellers" },
} as const;

/**
 * Merchandising section combining a feature card, product previews and a
 * carousel affordance (Figma "Product Carousel", node 14:191 — New
 * Arrivals/Best Sellers, Desktop/Mobile, all Status=Live). New Arrivals and
 * Best Sellers each have desktop and mobile variants.
 *
 * Desktop: a feature card and the product row share one horizontally
 * scrolling track, with the carousel arrow anchored to the right edge.
 * Mobile: the feature card sits full-width above its own horizontally
 * scrolling product row.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:625.
 */
export function B2BProductCarousel({
  variant = "new-arrivals",
  viewport = "desktop",
  products,
  featureImage,
  arrowClassName = "",
  className = "",
}: B2BProductCarouselProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const copy = VARIANT_COPY[variant];
  const isMobile = viewport === "mobile";

  const scrollNext = () => {
    trackRef.current?.scrollBy({ left: 335, behavior: "smooth" });
  };

  if (isMobile) {
    return (
      <div className={`flex w-full max-w-[390px] flex-col ${className}`}>
        <div className="p-5">
          <B2BFeatureCard
            eyebrow={copy.eyebrow}
            title={copy.title}
            linkLabel={copy.link}
            showStatusDot={copy.showStatusDot}
            viewport="mobile"
            image={featureImage}
          />
        </div>
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-5 pl-5">
          {products.map((p, i) => (
            <div key={i} className="shrink-0">
              <B2BProductCard tag={p.tag} name={p.name} eyebrow={p.eyebrow} price={p.price} image={p.image} viewport="mobile" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-full pb-5 pl-[75px] ${className}`}>
      <div ref={trackRef} className="no-scrollbar flex scroll-smooth gap-2.5 overflow-x-auto">
        <div className="w-[469px] shrink-0">
          <B2BFeatureCard
            eyebrow={copy.eyebrow}
            title={copy.title}
            linkLabel={copy.link}
            showStatusDot={copy.showStatusDot}
            viewport="desktop"
            image={featureImage}
          />
        </div>
        {products.map((p, i) => (
          <div key={i} className="shrink-0">
            <B2BProductCard
              tag={p.tag}
              name={p.name}
              eyebrow={p.eyebrow}
              eyebrowStyle={p.eyebrowStyle}
              price={p.price}
              image={p.image}
              nameSize={p.nameSize}
              viewport="desktop"
            />
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={scrollNext}
        aria-label="Next products"
        className={`absolute right-6 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-md bg-white/[0.44] ${arrowClassName}`}
      >
        <ChevronRight className="h-4 w-4 text-primary" />
      </button>
    </div>
  );
}
