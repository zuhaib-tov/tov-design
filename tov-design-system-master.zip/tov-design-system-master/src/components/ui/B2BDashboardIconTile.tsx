import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Icon Tile — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 39:124. 48px tinted rounded
 * square (12px radius) holding a 24px line icon. Four tints, each shipping with
 * its default glyph: Rose (#fdf1f2 / folder download), Sage (#eaf4f0 /
 * document), Sand (#faf3e7 / home), Blue (#eef2fc / arrow right).
 */
export type IconTileTint = "rose" | "sage" | "sand" | "blue";

export interface B2BDashboardIconTileProps {
  tint?: IconTileTint;
  /** Replaces the tint's default glyph. Use a 24px icon with currentColor strokes. */
  icon?: ReactNode;
  className?: string;
}

const tints: Record<IconTileTint, { bg: string; fg: string }> = {
  rose: { bg: "bg-[#fdf1f2]", fg: "text-[#b15a63]" },
  sage: { bg: "bg-[#eaf4f0]", fg: "text-[#82736c]" },
  sand: { bg: "bg-[#faf3e7]", fg: "text-[#9e8567]" },
  blue: { bg: "bg-[#eef2fc]", fg: "text-[#4766e1]" },
};

const stroke = {
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

function DefaultIcon({ tint }: { tint: IconTileTint }) {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden className="shrink-0">
      {tint === "rose" && (
        <path
          {...stroke}
          d="M20.777 13.5L20.8667 11.3944C20.9394 9.68897 19.5764 8.26667 17.8695 8.26667H14.648C13.4233 8.26667 12.3926 7.34971 12.25 6.13333C12.1075 4.91696 11.0768 4 9.8521 4H6.09525C4.40167 4 3.04381 5.40096 3.09671 7.09371L3.40921 17.0937C3.45982 18.7133 4.78737 20 6.40775 20H12.0001M17 15V20.5M15 18.5L17 20.5L19 18.5"
        />
      )}
      {tint === "sage" && (
        <path
          {...stroke}
          d="M14 3.49998V5C14 6.65686 15.3431 8 17 8H18.5M8 17H16M8 13H14M8 8.5H12M16 21H8C6.34315 21 5 19.6569 5 18V6C5 4.34315 6.34315 3 8 3H12.7574C13.553 3 14.3161 3.31607 14.8787 3.87868L18.1213 7.12132C18.6839 7.68393 19 8.44699 19 9.24264V18C19 19.6569 17.6569 21 16 21Z"
        />
      )}
      {tint === "sand" && (
        <path
          {...stroke}
          d="M9 21V15C9 14.4696 9.21072 13.9609 9.58578 13.5858C9.96086 13.2107 10.4696 13 11 13H13C13.5304 13 14.0391 13.2107 14.4142 13.5858C14.7893 13.9609 15 14.4696 15 15V21M4.99999 12H3L12 3L21 12H19.0001V19.0001C19.0001 19.5305 18.7893 20.0391 18.4142 20.4142C18.0392 20.7892 17.5305 21 16.9999 21H7C6.46956 21 5.96087 20.7892 5.58579 20.4142C5.21072 20.0391 4.99999 19.5305 4.99999 19.0001V12Z"
        />
      )}
      {tint === "blue" && (
        <path {...stroke} d="M4.99988 12.0002H18.9999M14.9999 16.0002L18.9999 12.0002L14.9999 8.00025" />
      )}
    </svg>
  );
}

export function B2BDashboardIconTile({ tint = "rose", icon, className = "" }: B2BDashboardIconTileProps) {
  const t = tints[tint];
  return (
    <span className={`inline-flex size-12 items-center justify-center rounded-[12px] ${t.bg} ${t.fg} ${className}`}>
      {icon ?? <DefaultIcon tint={tint} />}
    </span>
  );
}
