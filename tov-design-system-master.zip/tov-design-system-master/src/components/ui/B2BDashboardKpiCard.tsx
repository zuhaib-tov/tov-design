import { ArrowUpRight } from "lucide-react";

/**
 * TOV B2B Dashboard / KPI Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:22 → Version=Default (41:21),
 * 192px wide. Overview metric: label, value and an arrow link into the
 * detail view. White fill, 0.5px #e0e0e0 border, 16px radius, 12px padding.
 */
export interface B2BDashboardKpiCardProps {
  /** Metric label, e.g. "Active Orders". */
  label: string;
  /** Headline figure, e.g. "12". */
  value: string;
  className?: string;
}

export function B2BDashboardKpiCard({ label, value, className = "" }: B2BDashboardKpiCardProps) {
  return (
    <div
      className={`flex w-[192px] flex-col items-start gap-[10px] rounded-app-md border-[0.5px] border-[#e0e0e0] bg-white p-3 ${className}`}
    >
      <p className="font-sans text-[15px] font-bold leading-[14px] text-charcoal">{label}</p>
      <div className="flex items-end gap-3">
        <p className="font-sans text-2xl font-bold text-neutral-700">{value}</p>
        <span className="inline-flex size-[22px] items-center justify-center rounded-full bg-charcoal text-white">
          <ArrowUpRight size={13} strokeWidth={2.5} />
        </span>
      </div>
    </div>
  );
}
