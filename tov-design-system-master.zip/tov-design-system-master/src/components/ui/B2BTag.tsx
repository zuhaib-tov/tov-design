import { ReactNode } from "react";

/**
 * TOV B2B product tag — Figma Core/Tag component set (node 4:32). A single
 * Default appearance, scaled between Desktop and Mobile rather than
 * restyled: Desktop is 13px text in an 8px-radius pill, Mobile scales every
 * value down (~61%) to an 8.19px / 5px-radius pill. The file labels the
 * Desktop variant "New Arrival" and the Mobile variant "New Arrivals" —
 * both are the real supplied copy, not a typo to reconcile here.
 */
type Size = "desktop" | "mobile";

const sizeClasses: Record<Size, string> = {
  desktop: "text-[13px] rounded-[8px] px-[13px] py-[7px]",
  mobile: "text-[8px] rounded-[5px] px-[8px] py-[4px]",
};

export function B2BTag({
  size = "desktop",
  children,
}: {
  size?: Size;
  children: ReactNode;
}) {
  return (
    <span
      className={`inline-flex items-center justify-center whitespace-nowrap bg-charcoal/88 font-medium text-white ${sizeClasses[size]}`}
    >
      {children}
    </span>
  );
}
