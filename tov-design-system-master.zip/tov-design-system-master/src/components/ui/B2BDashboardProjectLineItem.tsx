import { Heart, Minus, Plus, Trash2, Plus as PlusSmall } from "lucide-react";

/**
 * TOV B2B Dashboard / Project Line Item — Figma "TOV26 - B2B - Design
 * system" (fileKey CGe5J4j6AI5uus5G2f8iqh), node 43:93 → Version=Default
 * (43:92), 342px wide. Product row inside a saved project: image with a
 * Wishlist Button, name + price, a Quantity Stepper, a Soft "Add to cart"
 * button and a remove icon. The image slot's own fill is charcoal
 * (#3f3d3e) — there's no photo baked into the symbol itself.
 */
export interface B2BDashboardProjectLineItemProps {
  productName: string;
  price: string;
  quantity?: number;
  className?: string;
}

export function B2BDashboardProjectLineItem({
  productName,
  price,
  quantity = 1,
  className = "",
}: B2BDashboardProjectLineItemProps) {
  return (
    <div className={`flex w-[342px] max-w-full flex-col items-start justify-center gap-5 ${className}`}>
      <div className="relative flex h-[379px] w-full items-end justify-end rounded-app-md bg-charcoal px-[15px] py-3">
        <span className="absolute right-3 top-3 inline-flex size-[42px] items-center justify-center text-white">
          <Heart size={22} strokeWidth={1.5} />
        </span>
      </div>
      <div className="flex w-full flex-col gap-1 text-[#333]">
        <p className="font-sans text-lg font-normal leading-[27px]">{productName}</p>
        <p className="font-sans text-lg font-bold leading-[21px]">{price}</p>
      </div>
      <div className="flex w-full items-center gap-2.5">
        <div className="flex h-10 w-[111px] items-center justify-center gap-2 rounded-pill bg-charcoal px-2.5 py-1 text-white">
          <button type="button" aria-label="Decrease quantity" className="inline-flex size-6 items-center justify-center">
            <Minus size={14} />
          </button>
          <p className="flex-1 text-center font-sans text-[10px] font-bold">{quantity}</p>
          <button type="button" aria-label="Increase quantity" className="inline-flex size-6 items-center justify-center">
            <Plus size={14} />
          </button>
        </div>
        <button
          type="button"
          className="inline-flex h-[39px] flex-1 items-center justify-center gap-1.5 rounded-pill bg-cream-200 px-4 py-2 font-sans text-[11px] font-semibold uppercase tracking-wide-ui text-charcoal"
        >
          <PlusSmall size={12} />
          Add to cart
        </button>
        <button type="button" aria-label="Remove from project" className="inline-flex size-6 items-center justify-center text-charcoal">
          <Trash2 size={20} strokeWidth={1.5} />
        </button>
      </div>
    </div>
  );
}
