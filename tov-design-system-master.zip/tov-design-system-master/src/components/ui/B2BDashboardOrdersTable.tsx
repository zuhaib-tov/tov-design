import { B2BDashboardStatusBadge, DashboardStatus } from "./B2BDashboardStatusBadge";

/**
 * TOV B2B Dashboard / Orders Table — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:685, Dashboard page, Organisms
 * section. A bordered 1066px data table: a cream Table Header row (SO
 * Order, PO Number, Order Date, Status, Est Ship, Act Ship, Tracking,
 * Carrier, Method, Total, Items, Shipping) over Table Row instances built
 * from the Dashboard/Status Badge atom. The source file reuses the same
 * placeholder order across every row, varying only the status — a
 * Cancelled row replaces its shipping-related cells with dashes.
 */
const COLUMNS = [
  "SO Order",
  "PO Number",
  "Order Date",
  "Status",
  "Est Ship",
  "Act Ship",
  "Tracking",
  "Carrier",
  "Method",
  "Total",
  "Items",
  "Shipping",
];

const ROW_STATUSES: DashboardStatus[] = [
  "shipped",
  "processing",
  "delivered",
  "cancelled",
  "shipped",
  "processing",
  "shipped",
  "processing",
];

export function B2BDashboardOrdersTable({ className = "" }: { className?: string }) {
  return (
    <div className={`flex w-[1066px] flex-col items-start overflow-x-auto rounded-[12px] border border-[#e0e0e0] bg-white font-sans ${className}`}>
      <div className="flex w-max min-w-full gap-[13px] border-b border-[#e0e0e0] bg-cream-100 px-4 py-[14px] text-[11px] font-bold text-charcoal">
        {COLUMNS.map((col, i) => (
          <span
            key={col}
            className={`w-[98px] shrink-0 uppercase tracking-wide-ui ${i >= COLUMNS.length - 2 ? "text-right" : ""} ${
              i === COLUMNS.length - 1 ? "w-[77px]" : ""
            }`}
          >
            {col}
          </span>
        ))}
      </div>
      {ROW_STATUSES.map((status, i) => {
        const cancelled = status === "cancelled";
        return (
          <div
            key={i}
            className="flex w-max min-w-full items-center gap-[13px] border-b border-[#e0e0e0] bg-white px-4 py-[14px] text-[13px] text-charcoal"
          >
            <span className="w-[98px] shrink-0 font-medium">SO-2024-0847</span>
            <span className="w-[98px] shrink-0 font-medium text-[#8e8e8e]">PO-78234</span>
            <span className="w-[98px] shrink-0 font-medium">Jul 15, 2024</span>
            <span className="w-[98px] shrink-0">
              <B2BDashboardStatusBadge status={status} />
            </span>
            <span className="w-[98px] shrink-0 font-medium">{cancelled ? "-" : "Jul 18, 2024"}</span>
            <span className="w-[98px] shrink-0 font-medium">{cancelled ? "-" : "Jul 19, 2024"}</span>
            <span className={`w-[98px] shrink-0 text-xs font-medium ${cancelled ? "" : "text-primary underline"}`}>
              {cancelled ? "-" : "1Z999AA10012345"}
            </span>
            <span className="w-[98px] shrink-0 font-medium">{cancelled ? "-" : "UPS"}</span>
            <span className="w-[98px] shrink-0 font-medium">{cancelled ? "-" : "Ground"}</span>
            <span className="w-[98px] shrink-0 font-medium">$4,250.00</span>
            <span className="w-[98px] shrink-0 text-right font-medium">$3,850.00</span>
            <span className="w-[77px] shrink-0 text-right font-medium text-[#8e8e8e]">$400.00</span>
          </div>
        );
      })}
    </div>
  );
}
