import { B2BButton } from "./B2BButton";
import { B2BStep } from "./B2BStep";

/**
 * TOV B2B — How It Works. A centered onboarding section: an eyebrow and
 * heading above three numbered Steps and a single membership CTA, on the
 * cream band that separates it from the white merchandising sections around it.
 */
export interface B2BHowItWorksStep {
  number: string;
  title: string;
  description: string;
}

export interface B2BHowItWorksProps {
  eyebrow?: string;
  title?: string;
  steps?: B2BHowItWorksStep[];
  ctaLabel?: string;
  className?: string;
}

const DEFAULT_STEPS: B2BHowItWorksStep[] = [
  {
    number: "01",
    title: "Apply in minutes",
    description: "Tell us about your business. No resale certificate and no minimum buy-in required to get started.",
  },
  {
    number: "02",
    title: "Get approved fast",
    description: "Most trade accounts are approved within one business day, with a concierge to help you set up.",
  },
  {
    number: "03",
    title: "Start saving 20%",
    description: "Your discount applies automatically, plus free shipping over $299 and tax-exempt options.",
  },
];

export function B2BHowItWorks({
  eyebrow = "How it works",
  title = "Up and running in three easy steps",
  steps = DEFAULT_STEPS,
  ctaLabel = "Join today",
  className = "",
}: B2BHowItWorksProps) {
  return (
    <section className={`flex w-[1440px] flex-col items-center gap-10 bg-cream-100 px-[75px] py-20 ${className}`}>
      <div className="flex flex-col items-center gap-2.5 text-center">
        <p className="text-base font-semibold uppercase leading-4 tracking-wide-ui text-charcoal">{eyebrow}</p>
        <h2 className="font-display text-[38px] leading-[42px] text-charcoal">{title}</h2>
      </div>
      <div className="flex w-[1170px] items-start gap-3.5">
        {steps.map((step) => (
          <B2BStep key={step.number} {...step} className="flex-1" />
        ))}
      </div>
      <B2BButton variant="primary" className="border border-white">
        {ctaLabel}
      </B2BButton>
    </section>
  );
}
