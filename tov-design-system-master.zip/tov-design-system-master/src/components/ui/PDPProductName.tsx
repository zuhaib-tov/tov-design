/**
 * The PDP "Product Name" component from the PDP Design System file
 * (fileKey ySZYmjbO2Wck8u1JGAtI5J). 5 Live versions collapse to two
 * independent flags: an optional grade tag and an optional material tag.
 */
export interface PDPProductNameProps {
  name: string;
  grade?: "Contract Grade" | "Performance Fabric";
  genuineLeather?: boolean;
  /** Mobile size (22px) instead of Desktop (38px). */
  compact?: boolean;
}

export function PDPProductName({ name, grade, genuineLeather, compact = false }: PDPProductNameProps) {
  const hasTags = grade || genuineLeather;

  return (
    <div className="flex flex-col gap-1">
      {hasTags && (
        <div className="flex items-center gap-2 text-xs font-bold">
          {grade && <span className="text-storm">{grade}</span>}
          {grade && genuineLeather && <span className="w-1 h-1 rounded-full bg-neutral-400" />}
          {genuineLeather && <span className="text-neutral-700">Genuine Leather</span>}
        </div>
      )}
      <h1 className={`font-display text-ink ${compact ? "text-[22px] leading-[25px]" : "text-[38px] leading-[42px]"}`}>{name}</h1>
    </div>
  );
}
