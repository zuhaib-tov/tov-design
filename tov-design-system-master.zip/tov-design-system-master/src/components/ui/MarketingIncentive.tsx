/**
 * Marketing email "Incentive" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1761:696) — Draft. Code box border is dashed charcoal (real
 * strokeDashPattern [6,4] in Figma, not a plain solid line) — not bound
 * to a variable even though the color matches --color-charcoal. Card
 * background (#fefbf6 / --color-cream-50) is a different cream than
 * Sign-off/Styled By You's --color-cream-200 — not interchangeable.
 */
export interface MarketingIncentiveProps {
  headline?: string;
  body?: string;
  code?: string;
  buttonLabel?: string;
  finePrint?: string;
}

export function MarketingIncentiveDesktop({
  headline = "A little something to help you decide",
  body = "Take 10% off your order with this code at checkout.",
  code = "COMEBACK10",
  buttonLabel = "Complete my order",
  finePrint = "Code expires in 48 hours. Excludes final sale items.",
}: MarketingIncentiveProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="rounded-[36px] bg-cream-50 px-10 py-9 flex flex-col items-center gap-4 text-center">
        <h2 className="text-charcoal font-bold text-[20px] leading-[1.25]">{headline}</h2>
        <p className="text-charcoal text-[16px] leading-[1.5]">{body}</p>
        <div className="rounded-[12px] border border-dashed border-charcoal bg-white px-8 py-3.5">
          <p className="text-charcoal font-bold uppercase text-[22px] tracking-wide-ui">{code}</p>
        </div>
        <button className="rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
          {buttonLabel}
        </button>
        <p className="text-[#8a8788] text-[12px] leading-[1.5]">{finePrint}</p>
      </div>
    </div>
  );
}

export function MarketingIncentiveMobile({
  headline = "A little something to help you decide",
  body = "Take 10% off your order with this code at checkout.",
  code = "COMEBACK10",
  buttonLabel = "Complete my order",
  finePrint = "Code expires in 48 hours. Excludes final sale items.",
}: MarketingIncentiveProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="rounded-[24px] bg-cream-50 px-5 py-7 flex flex-col items-center gap-3 text-center">
        <h2 className="text-charcoal font-bold text-[18px] leading-[1.25]">{headline}</h2>
        <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
        <div className="rounded-[12px] border border-dashed border-charcoal bg-white px-5 py-3">
          <p className="text-charcoal font-bold uppercase text-[18px] tracking-wide-ui">{code}</p>
        </div>
        <button className="rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
          {buttonLabel}
        </button>
        <p className="text-[#8a8788] text-[12px] leading-[1.5]">{finePrint}</p>
      </div>
    </div>
  );
}
