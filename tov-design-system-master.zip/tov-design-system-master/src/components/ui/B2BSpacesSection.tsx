import { B2BSpaceCard } from "./B2BSpaceCard";

/**
 * TOV B2B — Spaces Section. The "Get inspired" band: an eyebrow, a headline
 * with a look book link aligned to its baseline, and a row of four Space
 * Cards that fill the page margins evenly.
 */
export interface B2BSpacesSectionSpace {
  title: string;
  image?: string;
  linkLabel?: string;
}

export interface B2BSpacesSectionProps {
  eyebrow?: string;
  title?: string;
  linkLabel?: string;
  spaces: B2BSpacesSectionSpace[];
  className?: string;
}

export function B2BSpacesSection({
  eyebrow = "Get inspired",
  title = "See TOV styled in real spaces.",
  linkLabel = "See the full look book",
  spaces,
  className = "",
}: B2BSpacesSectionProps) {
  return (
    <section className={`flex w-[1440px] flex-col gap-5 bg-white px-[75px] py-10 ${className}`}>
      <div className="flex flex-col gap-2.5">
        <p className="text-base font-semibold uppercase leading-4 tracking-wide-ui text-charcoal">{eyebrow}</p>
        <div className="flex items-end gap-2.5">
          <h2 className="font-display text-[46px] leading-[50px] text-charcoal">{title}</h2>
          <a href="#" className="flex-1 text-right text-sm font-bold uppercase tracking-wide-ui leading-6 text-charcoal underline">
            {linkLabel}
          </a>
        </div>
      </div>
      <div className="flex gap-2.5">
        {spaces.map((space) => (
          <div key={space.title} className="min-w-0 flex-1">
            <B2BSpaceCard title={space.title} linkLabel={space.linkLabel} image={space.image} className="w-full" />
          </div>
        ))}
      </div>
    </section>
  );
}
