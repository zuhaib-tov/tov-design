import { Badge, BadgeVariant } from "./Badge";

/**
 * PLP product card with real content (fileKey jDOs1dFChECKIYdAyPUkav,
 * "💠Components" page, Product Display section, frame "Version 5 — Gift icon +
 * text, no background", node 98:526). Six card types come from the same
 * parts: a 302 x 379 photo with a 16px radius on #F0F0F0, up to two badges at
 * the top left, an outline heart at the top right, then the meta block 20px
 * below the photo.
 *
 * Meta block, top to bottom, with a 4px gap between the delivery line and the
 * name group and a 5px gap before the price:
 * - Delivery line (optional): 14px gift icon, 4px gap, 10/12 SemiBold #713A40.
 * - Callouts (optional, any mix): "New color" and "New size" are 12/16 Medium
 *   uppercase (#3F4B59 and #777777, joined by a "+"); "Performance Fabric" is
 *   12/16 ExtraBold #3F4B59 in sentence case.
 * - Name: 18/27 Regular #333333, wraps to as many lines as it needs.
 * - Price: 18/21 Bold #333333. A range reads "$449 – $649". On sale the price
 *   is #A0585E Bold followed by the original price struck through in
 *   #767676 Regular, 8px apart.
 */
export interface PLPListingBadge {
  variant: BadgeVariant;
  label: string;
}

export interface PLPListingCardProps {
  image: string;
  name: string;
  /** Current price or range, for example "$679" or "$1,199 – $1,399". */
  price: string;
  /** Original price. When set, the price is drawn as a sale price. */
  wasPrice?: string;
  badges?: PLPListingBadge[];
  newColor?: boolean;
  newSize?: boolean;
  performanceFabric?: boolean;
  /** Delivery line with the gift icon, for example "Get it by Dec. 4th". */
  delivery?: string;
}

function Heart() {
  return (
    <span className="absolute right-5 top-4 flex h-7 w-7 items-center justify-center" aria-label="Add to wishlist" role="img">
      <svg width="25" height="22" viewBox="0 0 28 25" fill="none" aria-hidden="true">
        <path
          d="M13.0399 23.6006C13.1846 23.6819 13.348 23.7238 13.5139 23.7222C13.6798 23.7238 13.8432 23.6819 13.9878 23.6006C16.2236 22.2936 18.3206 20.7626 20.2465 19.0312C24.4878 15.2152 26.6389 11.3993 26.6389 7.68054C26.6389 6.15015 26.1573 4.65855 25.2625 3.41703C24.3677 2.17552 23.1049 1.24702 21.653 0.763069C20.2012 0.279117 18.6339 0.264244 17.1731 0.720557C15.799 1.14977 14.5848 1.97541 13.6813 3.09086C13.5956 3.19662 13.4322 3.19662 13.3465 3.09086C12.443 1.97541 11.2287 1.14977 9.8547 0.720557C8.39392 0.264244 6.8266 0.279117 5.37475 0.763069C3.92289 1.24702 2.66011 2.17552 1.76527 3.41703C0.870437 4.65855 0.388916 6.15015 0.388916 7.68054C0.388916 16.4184 12.5174 23.309 13.0399 23.6006Z"
          stroke="#3F3D3E"
          strokeWidth="1.5"
        />
      </svg>
    </span>
  );
}

export function PLPListingCard({
  image,
  name,
  price,
  wasPrice,
  badges = [],
  newColor,
  newSize,
  performanceFabric,
  delivery,
}: PLPListingCardProps) {
  const hasCallouts = newColor || newSize || performanceFabric;
  return (
    <div className="flex w-[302px] shrink-0 flex-col gap-5 font-sans">
      <div className="relative h-[379px] w-full overflow-hidden rounded-2xl bg-[#f0f0f0]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={image} alt="" className="h-full w-full object-cover" />
        {badges.length > 0 && (
          <div className="absolute left-3 top-3 flex gap-1.5">
            {badges.map((b) => (
              <Badge key={b.label} variant={b.variant} size="md">
                {b.label}
              </Badge>
            ))}
          </div>
        )}
        <Heart />
      </div>
      <div className="flex flex-col gap-[5px]">
        <div className="flex flex-col gap-1">
          {delivery && (
            <div className="flex h-3.5 items-center gap-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/gift-small.svg" alt="" width={14} height={14} className="h-3.5 w-3.5" />
              <span className="text-[10px] font-semibold leading-3 text-bold-lip">{delivery}</span>
            </div>
          )}
          <div className="flex flex-col gap-0.5">
            {hasCallouts && (
              <div className="flex flex-col gap-0.5">
                {(newColor || newSize) && (
                  <p className="text-xs font-medium uppercase leading-4">
                    {newColor && <span className="text-[#3f4b59]">New color</span>}
                    {newColor && newSize && <span className="text-[#777777]"> + </span>}
                    {newSize && <span className="text-[#777777]">New size</span>}
                  </p>
                )}
                {performanceFabric && <p className="text-xs font-extrabold leading-4 text-[#3f4b59]">Performance Fabric</p>}
              </div>
            )}
            <p className="text-lg leading-[27px] text-[#333333]">{name}</p>
          </div>
        </div>
        <p className="flex items-baseline gap-2 text-lg leading-[21px]">
          <span className={`font-bold ${wasPrice ? "text-[#a0585e]" : "text-[#333333]"}`}>{price}</span>
          {wasPrice && <span className="text-[#767676] line-through">{wasPrice}</span>}
        </p>
      </div>
    </div>
  );
}
