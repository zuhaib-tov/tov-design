/**
 * Amazon A+ Content "Comfort and Construction modules" component (fileKey
 * P6ISgCbxCzraEqRtTr0j3P, "TOV26 - Amazon - Premium A+ content - 476"),
 * canonical symbol node 16:193 (inside section 16:189) — 650x350. A plain
 * photo card. No overlay, no pill label, no icon, no text of any kind —
 * unlike Category Hero, there is nothing here to compose beyond the image
 * itself.
 *
 * The real, populated instance library lives in section "Module 4 - 2
 * Colum Images" (node 23:792) — the exact same node
 * `COMFORT_CONSTRUCTION_SLOTS` (src/lib/amazon/figma-slots.ts) was built
 * from, 34 real instances across "Module 4 Comfort" and "Module 4
 * Construction". Each instance is the same card design; "Comfort" vs
 * "Construction" is a section/category label in the source file, not a
 * visual variant, so this is intentionally a single component rather
 * than separate Comfort/Construction components.
 *
 * Aspect ratio 650:350 (~1.857:1) is taken directly from the canonical
 * node's own dimensions.
 *
 * Corner radius: `cornerRadius` is 0 on all four corners of the canonical
 * node (16:193), genuinely square. Also 0 on a live populated instance
 * (18:908, "Module 4 Comfort - Accent Chairs 1", the same instance
 * referenced in COMFORT_CONSTRUCTION_SLOTS), which has no children and a
 * 3-entry fill stack (1 hidden, 2 visible-but-stacked so only the topmost
 * actually renders) — matching this component's own "messy fill stack"
 * note, with no overlay/pill/icon/text at the instance level either.
 */
export function AmazonComfortConstructionCard({ className = "" }: { className?: string }) {
  return <div className={`bg-image-placeholder w-[650px] max-w-full aspect-[650/350] ${className}`} />;
}
