/**
 * The PDP "Shipping Alert" component (fileKey ySZYmjbO2Wck8u1JGAtI5J,
 * node 115:4116) — all 6 Live variants, labeled here by what they actually
 * say rather than Figma's own internal names, which are misleading: "PO"
 * includes a restock estimate, "PO-EST" does not — the opposite of what
 * the names suggest.
 *
 * Each variant has a horizontal gradient background (white → color at ~49%
 * → white) plus a small color dot before the text. In-Stock variants carry
 * the gradient/root fill directly on the component; Preorder/Low Stock
 * variants carry it one frame in ("Frame 1263") — same visual result.
 */
export type PDPShippingAlertStatus =
  | "in-stock"
  | "in-stock-eta"
  | "preorder"
  | "preorder-eta"
  | "low-stock"
  | "low-stock-ai";

export const PDP_SHIPPING_ALERT_CONTENT: Record<
  PDPShippingAlertStatus,
  { label: string; text: string; color: "success" | "mauve" }
> = {
  "in-stock": { label: "In Stock", text: "In stock. Ready to ship.", color: "success" },
  "in-stock-eta": {
    label: "In Stock — Ships in 1-3 Days",
    text: "In stock. Ships out in 1-3 days.",
    color: "success",
  },
  preorder: {
    label: "Preorder",
    text: "This item is popular! Preorder Today.",
    color: "mauve",
  },
  "preorder-eta": {
    label: "Preorder — With Restock Estimate",
    text: "This item is popular! Preorder Today. Estimated restock [Date].",
    color: "mauve",
  },
  "low-stock": {
    label: "Low Stock — With Restock Estimate",
    text: "Hurry only [Number] left. Estimated restock [Date].",
    color: "mauve",
  },
  "low-stock-ai": {
    label: "Low Stock — AI Inventory Estimate",
    text: "Hurry, only [Number] left! Additional Inventory Expected [Date].",
    color: "mauve",
  },
};

const GRADIENT_STOP: Record<"success" | "mauve", string> = {
  success: "#A2F3C8",
  mauve: "#F9D2D2",
};

export function PDPShippingAlert({ status }: { status: PDPShippingAlertStatus }) {
  const { text, color } = PDP_SHIPPING_ALERT_CONTENT[status];
  return (
    <div
      className="inline-flex items-center gap-1 rounded-[4px] px-[9px] py-[7px] font-sans"
      style={{ background: `linear-gradient(to right, white, ${GRADIENT_STOP[color]} 49%, white)` }}
    >
      <span className={`w-2 h-2 rounded-[4px] shrink-0 ${color === "success" ? "bg-success" : "bg-mauve"}`} />
      <p className={`text-[10px] leading-[15px] ${color === "success" ? "text-success" : "text-mauve"}`}>{text}</p>
    </div>
  );
}
