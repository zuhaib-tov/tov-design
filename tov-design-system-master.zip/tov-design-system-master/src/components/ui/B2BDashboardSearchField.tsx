import { InputHTMLAttributes } from "react";

/**
 * TOV B2B Dashboard / Search Field — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:681. Search input for
 * filter bars: 280px wide, white fill, 1px #e0e0e0 border, 8px radius,
 * 16px / 10px padding, 16px charcoal magnifier, 14px Medium #8e8e8e placeholder.
 */
export interface B2BDashboardSearchFieldProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  containerClassName?: string;
}

export function B2BDashboardSearchField({
  placeholder = "Search orders...",
  containerClassName = "",
  className = "",
  ...props
}: B2BDashboardSearchFieldProps) {
  return (
    <label
      className={`flex w-[280px] items-center gap-2 rounded-md border border-[#e0e0e0] bg-white px-4 py-[10px] focus-within:border-primary ${containerClassName}`}
    >
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden className="shrink-0">
        <g stroke="#3F3D3E" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 14L10 10" />
          <circle cx="6.66667" cy="6.66667" r="4.66667" />
        </g>
      </svg>
      <input
        type="search"
        placeholder={placeholder}
        className={`min-w-px flex-1 bg-transparent font-sans text-sm font-medium text-charcoal outline-none placeholder:text-[#8e8e8e] ${className}`}
        {...props}
      />
    </label>
  );
}
