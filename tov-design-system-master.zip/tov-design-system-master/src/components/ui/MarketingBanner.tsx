/**
 * Marketing email "Banner" (fileKey DTjIdCKhnDUVvJhEfpn10v, node 1756:468)
 * — Draft. "Image Overlay" stacks two scrims (frame-level 23% black plus a
 * separate contrast-overlay rectangle at 20% black, ~38% combined) — this
 * is intentional layering, not a duplicate to collapse. "Split"'s
 * product-image half is unrounded (cornerRadius 0), unlike every other
 * image region in this file.
 */
export interface MarketingBannerOverlayProps {
  headline?: string;
  buttonLabel?: string;
}

export interface MarketingBannerSplitProps {
  headline?: string;
  body?: string;
  buttonLabel?: string;
}

export function MarketingBannerOverlayDesktop({
  headline = "Up to 30% off dining",
  buttonLabel = "Shop the sale",
}: MarketingBannerOverlayProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="bg-image-placeholder relative h-[323px] rounded-[36px] overflow-hidden flex flex-col items-center justify-center gap-3.5 px-10">
        <div className="absolute inset-0 bg-black/23" />
        <div className="absolute inset-0 bg-black/20" />
        <h2 className="relative text-white font-bold text-[26px] leading-[30px] text-center">
          {headline}
        </h2>
        <button className="relative rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
          {buttonLabel}
        </button>
      </div>
    </div>
  );
}

export function MarketingBannerOverlayMobile({
  headline = "Up to 30% off dining",
  buttonLabel = "Shop the sale",
}: MarketingBannerOverlayProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="bg-image-placeholder relative h-[208px] rounded-[24px] overflow-hidden flex flex-col items-center justify-center gap-2.5 px-5">
        <div className="absolute inset-0 bg-black/23" />
        <div className="absolute inset-0 bg-black/20" />
        <h2 className="relative text-white font-bold text-[20px] leading-[1.15] text-center">
          {headline}
        </h2>
        <button className="relative rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
          {buttonLabel}
        </button>
      </div>
    </div>
  );
}

export function MarketingBannerSplitDesktop({
  headline = "Meet the Riviera chair",
  body = "Hand-woven rattan and a striped seat that brings the coast home.",
  buttonLabel = "Shop now",
}: MarketingBannerSplitProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="flex h-[258px] rounded-[36px] overflow-hidden bg-cream-200">
        <div className="w-[275px] flex flex-col justify-center gap-3 p-8">
          <h2 className="text-charcoal font-bold text-[22px] leading-[25px]">{headline}</h2>
          <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
          <button className="self-start rounded-pill bg-charcoal text-white font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
            {buttonLabel}
          </button>
        </div>
        <div className="bg-image-placeholder w-[275px]" />
      </div>
    </div>
  );
}

export function MarketingBannerSplitMobile({
  headline = "Meet the Riviera chair",
  body = "Hand-woven rattan and a striped seat that brings the coast home.",
  buttonLabel = "Shop now",
}: MarketingBannerSplitProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="flex flex-col rounded-[24px] overflow-hidden bg-cream-200">
        <div className="bg-image-placeholder h-[240px]" />
        <div className="flex flex-col items-center text-center gap-3 px-6 pt-7 pb-7">
          <h2 className="text-charcoal font-bold text-[20px] leading-[1.15]">{headline}</h2>
          <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
          <button className="rounded-pill bg-charcoal text-white font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
            {buttonLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
