/**
 * The PDP swatch variant selector (fileKey ySZYmjbO2Wck8u1JGAtI5J, node
 * 11:559, the "Swatch" version: "Viewport=All" maps to Mobile,
 * "Viewport=Desktop" maps to Desktop). It is one selector with three
 * labels — Fabric, Color and Finish. Only the "View Fabric Details" link
 * differs by viewport (Mobile only).
 *
 * Swatches are 50px targets holding a 46px chip with a 0.5px #cecece border
 * and an 8px radius, spaced 2.7px apart. Unselected chips are flat; the
 * selected chip carries a 1px charcoal ring (10px radius) and the soft
 * 1.5/1.5/12 shadow. The free-swatch link belongs to Fabric only.
 */
export type PDPSwatchLabel = "Fabric" | "Color" | "Finish";

export interface PDPFabricOption {
  color: string;
  selected?: boolean;
}

export interface PDPFabricSelectionProps {
  /** Which attribute is being selected. Drives the label and the placeholder name. */
  label?: PDPSwatchLabel;
  /** Name of the selected option; defaults to "<label> Name". */
  fabricName?: string;
  swatches: PDPFabricOption[];
  /** Shows the "View Fabric Details" link below the swatches (Mobile, Fabric only). */
  showViewDetails?: boolean;
}

export function PDPFabricSelection({
  label = "Fabric",
  fabricName,
  swatches,
  showViewDetails = false,
}: PDPFabricSelectionProps) {
  const name = fabricName ?? `${label} Name`;
  return (
    <div className="flex w-[446px] max-w-full flex-col gap-[15px] font-sans">
      <div className="flex items-center justify-between">
        <p className="text-sm leading-4 text-ink">
          {label}: <span className="font-bold">{name}</span>
        </p>
        {label === "Fabric" && (
          <a href="#" className="text-sm leading-4 text-mauve underline">
            Free fabric swatch
          </a>
        )}
      </div>

      <div className="flex items-center gap-[2.7px]">
        {swatches.map((s, i) => (
          <div
            key={i}
            className={`flex h-[50px] w-[50px] shrink-0 items-center justify-center rounded-[10px] ${
              s.selected ? "border border-charcoal" : "border border-transparent"
            }`}
          >
            <div
              className="h-[46px] w-[46px] rounded-lg border-[0.5px] border-[#cecece]"
              style={{
                backgroundColor: s.color,
                boxShadow: s.selected ? "1.5px 1.5px 12px rgba(63,61,62,0.14)" : "none",
              }}
            />
          </div>
        ))}
      </div>

      {showViewDetails && label === "Fabric" && (
        <a href="#" className="text-sm leading-4 text-ink underline">
          View Fabric Details
        </a>
      )}
    </div>
  );
}
