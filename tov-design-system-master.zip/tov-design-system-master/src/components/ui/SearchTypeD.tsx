/**
 * Search — Type D ("Compound search: product + attribute") — fileKey
 * DTjIdCKhnDUVvJhEfpn10v, node 1696:2290. 2 real variants: Desktop
 * (1696:2030) and Mobile (1696:2123). Same structural pattern as Type A
 * (results header + product grid + promo banner) but for the query
 * "Swivel Chair" — routed as a plain product-category search per Figma's
 * own designer note (no left panel, same as Type A).
 *
 * Flagged, not corrected: Mobile card 2 is titled "Gertrude Yellow Gingham
 * Linen Skirted Ottoman" — a leftover/stale copy from Type A's card, not a
 * swivel chair. Kept exactly as Figma has it rather than silently
 * relabeling it. Desktop again shows $1,499 vs. Mobile's $479 for the same
 * products, same discrepancy as every other Search type.
 */
import { SearchTopBar, MobileSearchTopBar, ResultsHeader, ResultsHeaderMobile, DesktopProductCard, MobileProductCard, PromoBanner, SeeAllProductsButton, type SearchProduct } from "./SearchShared";

const DESKTOP_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/chair-skyla-swivel.jpg", title: "Skyla Swivel Accent Chair", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#E2E1DE", "#979797"] },
  { image: "/images/search/chair-kennedy-velvet-swivel.jpg", title: "Kennedy Velvet Swivel Accent Chair", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#0E1D36", "#585858", "#0D0D0D", "#22372A", "#E6E6E6"] },
  { image: "/images/search/chair-fickle-cream-boucle.jpg", title: "Fickle Cream Boucle Swivel Chair", price: "$1,499", materialTag: "Performance Fabric", swatches: [null] },
];

const MOBILE_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/chair-skyla-swivel-sq.jpg", title: "Skyla Swivel Accent Chair", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/chair-typeD-card2-sq.jpg", title: "Gertrude Yellow Gingham Linen Skirted Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/chair-fickle-cream-boucle-sq.jpg", title: "Fickle Cream Boucle Swivel Chair", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/chair-austin-upcycled-swivel.jpg", title: "Austin Upcycled Swivel Accent Chair", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/chair-judy-boucle-swivel.jpg", title: "Judy Boucle Swivel Accent Chair", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/chair-rory-boucle-swivel.jpg", title: "Rory Boucle Swivel Accent Chair", price: "$479", materialTag: "Performance Fabric" },
];

export function SearchTypeDDesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Swivel Chair" />
      <ResultsHeader query="Swivel Chair" />
      <div className="grid grid-cols-3 gap-grid-gutter-lg px-10 pb-10">
        {DESKTOP_PRODUCTS.map((p) => (
          <DesktopProductCard key={p.title} product={p} />
        ))}
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeDMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <ResultsHeaderMobile query="Swivel Chair" />
      <div className="grid grid-cols-2 gap-grid-gutter-md px-5 pb-6">
        {MOBILE_PRODUCTS.map((p, i) => (
          <MobileProductCard key={`${p.title}-${i}`} product={p} />
        ))}
      </div>
      <div className="px-5 pb-6">
        <SeeAllProductsButton />
      </div>
    </div>
  );
}
