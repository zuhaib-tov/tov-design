import { Logo } from "./Logo";

/**
 * Mobile Navigation drill-down states (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1688:3862) — the hamburger-menu expansion + per-category drill-down
 * screens, distinct from the collapsed top bar already built in MainNav.tsx.
 * 6 real symbols:
 * - `Version=Default` (`1688:3863`) — the collapsed bar. Its only 2 text
 *   nodes (announcement copy + search placeholder) are identical to
 *   `MainNavMobile` in MainNav.tsx, so it's not duplicated here.
 * - `Version=Main Menu` (`1688:3897`) — the expanded top-level category list.
 * - `Version=Furniture/Lighting/Outdoor/Decor & Tabletop` (`1692:353/354/355/356`)
 *   — one drill-down per category, each an always-expanded accordion of
 *   subcategory groups (no collapse interactivity built — Figma's own
 *   frame shows every group open, same "map what's shown" precedent as
 *   MegaMenu.tsx).
 *
 * Every category link row in Main Menu uses a right-pointing chevron
 * (`chevron-thin-right.svg`); each drill-down's back row and accordion
 * group headers reuse the same underlying chevron shape rotated left/up
 * (`chevron-thin-left.svg` / `chevron-thin-up.svg`) — distinct assets from
 * `chevron-left.svg`/`chevron-right.svg` (rounded vertex, `#363538`),
 * since this shape has a sharp vertex and is colored `#777777`.
 *
 * Menu contents follow tovfurniture.com's mobile drawer: the same nine
 * top-level links and eight utility links as the desktop nav, Game Tables
 * under Living Room → TABLES, Home Office before Entryway, and an Outdoor
 * group inside Furniture.
 */

interface MobileNavGroup {
  heading: string;
  subGroups?: { label: string; items: string[] }[];
  items?: string[];
  viewAllLabel: string;
}

interface MobileNavCategory {
  name: string;
  groups: MobileNavGroup[];
}

const MAIN_MENU_LINKS = [
  "New", "Furniture", "Rugs", "Lighting", "Decor & Tabletop",
  "Throw Pillows", "Outdoor", "Wall Art & Mirrors", "Sale",
];

const FOOTER_LINKS = [
  "Best Sellers", "Get Inspired!", "Collections", "TOV Edits",
  "Collaborations", "Showrooms", "Design Box", "Trade Program",
];

const CATEGORIES: Record<string, MobileNavCategory> = {
  furniture: {
    name: "Furniture",
    groups: [
      {
        heading: "Living Room",
        subGroups: [
          { label: "SEATING", items: ["Sofas", "Sectionals", "Loveseats & Settees", "Accent Chairs", "Benches & Ottomans"] },
          { label: "TABLES", items: ["Coffee & Cocktail Tables", "Game Tables", "Side Tables", "Console Tables", "Entertainment Centers", "Sideboards & Buffets", "Bar Carts"] },
        ],
        viewAllLabel: "View All Living Room",
      },
      { heading: "Bedroom", items: ["Beds", "Nightstands", "Chests & Dressers", "Benches & Ottomans", "Vanities", "TV Consoles", "Mattresses"], viewAllLabel: "View All Bedroom" },
      { heading: "Dining Room", items: ["Dining Tables", "Dining Chairs", "Bar & Counter Stools", "Sideboards & Buffets", "Bar Carts"], viewAllLabel: "View All Dining Room" },
      { heading: "Home Office", items: ["Desks", "Office Chairs", "Book Shelves"], viewAllLabel: "View All Home Office" },
      { heading: "Entryway", items: ["Console Tables", "Benches & Ottomans"], viewAllLabel: "View All Entryway" },
      { heading: "Outdoor", items: ["Outdoor Dining", "Outdoor Lounge", "Outdoor Accents"], viewAllLabel: "View All Outdoor" },
    ],
  },
  lighting: {
    name: "Lighting",
    groups: [
      { heading: "Lamps", items: ["Table Lamps", "Floor Lamps"], viewAllLabel: "View All Lamps" },
      { heading: "Ceiling Lights", items: ["Pendants", "Chandeliers"], viewAllLabel: "View All Ceiling Lights" },
    ],
  },
  outdoor: {
    name: "Outdoor",
    groups: [
      { heading: "Outdoor Dining", items: ["Dining Tables", "Dining Seating"], viewAllLabel: "View All Outdoor Dining" },
      { heading: "Outdoor Lounge", items: ["Sofas", "Sectionals", "Accent Chairs", "Coffee Tables", "Chaise Lounges", "Benches & Ottomans"], viewAllLabel: "View All Outdoor Lounge" },
      { heading: "Outdoor Accents", items: ["Accent Tables", "Console Tables"], viewAllLabel: "View All Outdoor Accents" },
    ],
  },
  decorTabletop: {
    name: "Decor & Tabletop",
    groups: [
      { heading: "Decorative Objects", items: ["Vases & Planters", "Judaica", "Candles & Candle Holders", "Home Accents", "Bowls & Catchalls", "Pet Beds"], viewAllLabel: "View All Decorative Objects" },
      { heading: "Entertaining", items: ["Placemats, Table Linens & Napkins", "Dinkware", "Cutlery & Serveware"], viewAllLabel: "View All Entertaining" },
    ],
  },
};

function TopBar() {
  return (
    <>
      <div className="bg-charcoal flex items-center justify-center px-5 py-2.5">
        <p className="text-xs text-white">Free shipping on orders $299+</p>
      </div>
      <div className="flex items-center justify-between px-5 py-2.5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/menu.svg" alt="Menu" className="w-6 h-[18px]" />
        <Logo className="h-4 text-charcoal" />
        <div className="flex items-center gap-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/heart.svg" alt="Wishlist" className="w-6 h-6" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/bag-alt-light.svg" alt="Cart" className="w-6 h-6" />
        </div>
      </div>
      <div className="px-5 pb-2.5">
        <div className="flex items-center gap-inline-gap-sm rounded-pill bg-neutral-100 border border-neutral-200 px-5 py-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/search.svg" alt="" className="w-[14px] h-[14px]" />
          <p className="text-[10px] text-ink-muted">Search for accent chairs...</p>
        </div>
      </div>
    </>
  );
}

function FooterLinksAndSocial() {
  return (
    <div className="bg-white px-5 py-[7px] flex flex-col gap-[5px]">
      {FOOTER_LINKS.map((label) => (
        <a key={label} href="#" className="text-xs uppercase tracking-wide-ui text-[#8E8E8E] py-1.5">{label}</a>
      ))}
      <a href="#" className="text-xs font-bold uppercase tracking-wide-ui text-[#8E8E8E] py-1.5">Login/Sign up</a>
      <div className="bg-charcoal rounded-[10px] flex items-center justify-center gap-4 py-[7px] mt-2">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/instagram.svg" alt="Instagram" className="w-[18px] h-[18px]" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/youtube.svg" alt="YouTube" className="w-[15px] h-3" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/pinterest.svg" alt="Pinterest" className="w-[15px] h-[15px]" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/tiktok.svg" alt="TikTok" className="w-[18px] h-[18px]" />
      </div>
    </div>
  );
}

/** Main Menu — the expanded hamburger menu: top-level category list + footer links/social. */
export function MobileNavMainMenu() {
  return (
    <div className="w-[375px] font-sans bg-white">
      <TopBar />
      <div className="flex flex-col">
        {MAIN_MENU_LINKS.map((label) => (
          <a key={label} href="#" className="flex items-center justify-between px-[30px] py-3 border-b border-neutral-200 text-[13px] leading-[14px] font-medium text-ink">
            {label}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/chevron-thin-right.svg" alt="" className="w-4 h-4" />
          </a>
        ))}
      </div>
      <FooterLinksAndSocial />
    </div>
  );
}

function CategoryDrillDown({ category }: { category: MobileNavCategory }) {
  return (
    <div className="w-[375px] font-sans bg-white">
      <TopBar />
      <div className="flex items-center gap-2 bg-[#E8E8E8] px-[30px] py-4">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/chevron-thin-left.svg" alt="" className="w-3 h-3" />
        <p className="text-xs font-bold text-ink">{category.name}</p>
      </div>
      <div className="flex flex-col">
        {category.groups.map((group) => (
          <div key={group.heading} className="border-b border-neutral-200">
            <div className="flex items-center justify-between px-[30px] py-3">
              <p className="text-xs font-semibold text-ink">{group.heading}</p>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/chevron-thin-up.svg" alt="" className="w-4 h-4" />
            </div>
            {group.subGroups
              ? group.subGroups.map((sg) => (
                  <div key={sg.label}>
                    <p className="px-[30px] pb-1 text-[10px] font-semibold tracking-wide-ui text-[#8C8C8C]">{sg.label}</p>
                    {sg.items.map((item) => (
                      <a key={`${sg.label}-${item}`} href="#" className="flex items-center px-[30px] h-[34px] text-xs font-medium text-ink">{item}</a>
                    ))}
                  </div>
                ))
              : group.items!.map((item) => (
                  <a key={item} href="#" className="flex items-center px-[30px] h-[34px] text-xs font-medium text-ink">{item}</a>
                ))}
            <a href="#" className="flex items-center px-[30px] h-[34px] text-[10px] font-semibold tracking-wide-ui text-[#777777]">{group.viewAllLabel.toUpperCase()}</a>
          </div>
        ))}
      </div>
      <FooterLinksAndSocial />
    </div>
  );
}

export function MobileNavFurniture() {
  return <CategoryDrillDown category={CATEGORIES.furniture} />;
}
export function MobileNavLighting() {
  return <CategoryDrillDown category={CATEGORIES.lighting} />;
}
export function MobileNavOutdoor() {
  return <CategoryDrillDown category={CATEGORIES.outdoor} />;
}
export function MobileNavDecorTabletop() {
  return <CategoryDrillDown category={CATEGORIES.decorTabletop} />;
}
