/**
 * TOV B2B — Step. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 4:65 ("Step" symbol frame), Default/Desktop
 * (4:59, 381x101, centered, no card background) and Default/Mobile (4:64, 350x138,
 * left-aligned inside a cream card) variants.
 *
 * Numbered onboarding instruction with a title and supporting description.
 * Repeat for a clear sequence and keep step numbers in order.
 */
export interface B2BStepProps {
  /** Two-digit step number, e.g. "01". */
  number: string;
  title: string;
  description: string;
  /** Renders the Mobile variant (left-aligned, cream card) instead of Desktop. */
  compact?: boolean;
  className?: string;
}

export function B2BStep({ number, title, description, compact = false, className = "" }: B2BStepProps) {
  if (compact) {
    return (
      <div className={`bg-cream-100 rounded-xl flex flex-col gap-2.5 p-4 w-[350px] ${className}`}>
        <p className="font-sans font-bold text-2xl text-charcoal">{number}</p>
        <p className="font-display text-[22px] text-primary">{title}</p>
        <p className="text-sm text-charcoal">{description}</p>
      </div>
    );
  }

  return (
    <div className={`rounded-2xl flex flex-col items-center text-center gap-2.5 w-[381px] ${className}`}>
      <div className="flex flex-col items-center gap-2.5">
        <p className="font-sans text-2xl leading-6 text-charcoal">{number}</p>
        <p className="font-display text-[22px] leading-[25px] text-primary">{title}</p>
      </div>
      <p className="text-sm leading-4 text-charcoal">{description}</p>
    </div>
  );
}
