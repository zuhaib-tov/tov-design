import { ButtonHTMLAttributes, forwardRef } from "react";

/**
 * Pill button from the "📛 Buttons, Badges" OG Figma page (node 1611:4711).
 * Measurements and state colors are written out in src/lib/buttonSpec.ts and
 * shown on the Button page.
 *
 * Each size has a fixed height with the label centered, so vertical padding is
 * the same on every button. Only horizontal padding changes: a minimum of 24px
 * (Large, Medium) or 16px (Small) on each side, more when the button is wider
 * than its label. Every size uses Bold, uppercase text with +4.5%
 * letter-spacing and a 999px radius.
 *
 * States: hover and pressed share one set of colors, focus-visible draws a 2px
 * ring offset by 2px, disabled is 50% opacity. `data-state` forces a state so
 * the docs can show hover, pressed and focus without a pointer.
 */
type Variant = "primary" | "secondary" | "tertiary" | "inverse" | "ghost";
type Size = "sm" | "md" | "lg";

const base =
  "inline-flex items-center justify-center whitespace-nowrap rounded-pill border font-bold uppercase tracking-wide-ui transition-colors outline-none disabled:opacity-50 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-offset-2 data-[state=focus]:outline-2 data-[state=focus]:outline-offset-2";

const variants: Record<Variant, string> = {
  primary:
    "bg-charcoal text-white border-charcoal hover:bg-cream-50 hover:text-charcoal active:bg-cream-50 active:text-charcoal data-[state=hover]:bg-cream-50 data-[state=hover]:text-charcoal data-[state=pressed]:bg-cream-50 data-[state=pressed]:text-charcoal focus-visible:outline-charcoal data-[state=focus]:outline-charcoal",
  secondary:
    "bg-brand-pink text-charcoal border-transparent hover:bg-charcoal hover:text-white active:bg-charcoal active:text-white data-[state=hover]:bg-charcoal data-[state=hover]:text-white data-[state=pressed]:bg-charcoal data-[state=pressed]:text-white focus-visible:outline-charcoal data-[state=focus]:outline-charcoal",
  tertiary:
    "bg-cream-50 text-charcoal border-charcoal hover:bg-charcoal hover:text-white active:bg-charcoal active:text-white data-[state=hover]:bg-charcoal data-[state=hover]:text-white data-[state=pressed]:bg-charcoal data-[state=pressed]:text-white focus-visible:outline-charcoal data-[state=focus]:outline-charcoal",
  inverse:
    "bg-transparent text-white border-white hover:bg-white hover:text-charcoal active:bg-white active:text-charcoal data-[state=hover]:bg-white data-[state=hover]:text-charcoal data-[state=pressed]:bg-white data-[state=pressed]:text-charcoal focus-visible:outline-white data-[state=focus]:outline-white",
  // Not part of the real Figma button system — app-chrome-only, for
  // low-emphasis actions inside this docs site's own UI (e.g. "dismiss").
  ghost:
    "bg-transparent text-primary-dark border-transparent hover:text-primary normal-case font-medium tracking-normal",
};

// Fixed heights, border included: lg 54, md 42, sm 33. Minimum horizontal
// padding: lg 24, md 24, sm 16.
const sizes: Record<Size, string> = {
  lg: "h-[54px] gap-2.5 px-6 text-sm leading-4",
  md: "h-[42px] gap-2 px-6 text-sm leading-4",
  sm: "h-[33px] gap-1.5 px-4 text-xs leading-[14px]",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  /** Forces a visual state. Used by the docs to show states without a pointer. */
  state?: "hover" | "pressed" | "focus";
}

/**
 * Class names a developer adds to a button outside the component library:
 * `tov-btn`, one style and one size, for example
 * `tov-btn tov-btn--primary tov-btn--lg`. States are selectors (`:hover`,
 * `:active`, `:focus-visible`, `:disabled`), not classes.
 */
export function buttonClasses({ variant = "primary", size = "md" }: Pick<ButtonProps, "variant" | "size"> = {}) {
  return `tov-btn tov-btn--${variant} tov-btn--${size}`;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", size = "md", state, className = "", ...props }, ref) => {
    return (
      <button
        ref={ref}
        data-state={state}
        className={`${buttonClasses({ variant, size })} ${base} ${variants[variant]} ${sizes[size]} ${className}`}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
