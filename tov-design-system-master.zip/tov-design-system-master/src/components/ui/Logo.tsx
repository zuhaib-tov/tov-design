/**
 * TOV logo mark — a simplified geometric lockup built from solid vector
 * shapes, no font dependency.
 *
 * The split-"O" accent color is `#F9D2D2` — see `--color-brand-pink` in
 * globals.css.
 */
export function Logo({
  className = "h-8",
  accentColor = "var(--color-brand-pink)",
}: {
  className?: string;
  accentColor?: string;
}) {
  return (
    <svg viewBox="60 350 840 280" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <g transform="translate(500 500) scale(1.35) translate(-500 -500)">
        <polygon
          points="200,447 256,447 256,585 288,585 288,447 344,447 344,415 200,415"
          fill="currentColor"
        />
        <path
          fillRule="evenodd"
          d="M 475,412 C 424.19,412 383,451.4 383,500 C 383,548.6 424.19,588 475,588 C 525.81,588 567,548.6 567,500 C 567,451.4 525.81,412 475,412 Z M 475,444 C 441.86,444 415,469.07 415,500 C 415,530.93 441.86,556 475,556 C 508.14,556 535,530.93 535,500 C 535,469.07 508.14,444 475,444 Z"
          fill={accentColor}
        />
        <path
          d="M 475,412 C 525.81,412 567,451.4 567,500 C 567,548.6 525.81,588 475,588 L 475,556 C 508.14,556 535,530.93 535,500 C 535,469.07 508.14,444 475,444 L 475,412 Z"
          fill="currentColor"
        />
        <polygon
          points="696,546 641,415 606,415 680,585 712,585 786,415 751,415"
          fill="currentColor"
        />
      </g>
    </svg>
  );
}
