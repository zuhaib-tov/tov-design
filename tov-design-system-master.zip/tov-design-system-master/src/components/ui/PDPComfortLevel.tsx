/**
 * The PDP "Comfort level" scale, matched to the live product pages (the Figma
 * Product Info Accordion only carries the text line "Comfort level: Plush").
 *
 * Shown in the Details tab of products with seat cushioning, such as accent
 * chairs and sofas. Tables, beds, dressers and other pieces without a cushion
 * do not get it. The four steps run Plush, Soft, Medium, Firm; the active step
 * fills one quarter of a 16px track and darkens its dot and label.
 *
 * It fills its container: 423px wide in the desktop Details panel and 311px on
 * a 375px phone. The row has no outer margin; the tab content sets the 24px
 * space above and below.
 */
export const COMFORT_LEVELS = ["Plush", "Soft", "Medium", "Firm"] as const;
export type ComfortLevel = (typeof COMFORT_LEVELS)[number];

export function PDPComfortLevel({ level }: { level: ComfortLevel }) {
  const index = COMFORT_LEVELS.indexOf(level);
  return (
    <div className="flex w-full flex-col gap-2 font-sans">
      <h3 className="text-sm font-bold leading-[14px] text-charcoal">Comfort level: {level}</h3>
      <div className="flex flex-col gap-[15px]">
        <div className="px-[15px]">
          <div className="relative h-4 rounded-[20px] bg-[#e8e8e8]/[0.58]" role="img" aria-label={`Comfort level ${level}, step ${index + 1} of ${COMFORT_LEVELS.length}`}>
            <span
              className="absolute left-0 top-0 h-4 w-1/4 rounded-[20px] bg-charcoal"
              style={{ transform: `translateX(${index * 100}%)` }}
            />
          </div>
        </div>
        <div className="grid grid-cols-4 px-[15px]">
          {COMFORT_LEVELS.map((l) => {
            const active = l === level;
            return (
              <div key={l} className="flex flex-col items-center gap-2">
                <span className="flex h-[14px] items-center">
                  <span className={`block h-[7px] w-[7px] rounded-full ${active ? "bg-charcoal" : "bg-[#d9d9d9]"}`} />
                </span>
                <span className={`text-sm leading-[14px] ${active ? "text-charcoal" : "text-[#a4a4a4]"}`}>{l}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
