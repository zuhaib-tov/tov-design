/**
 * TOV B2B — Email Sign Up. The subscription band shown at the foot of the
 * page when no sign-up pop-up is active: a heading and supporting line on
 * the left, with a pill email field and a white Submit pill on the right.
 */
export interface B2BEmailSignUpProps {
  title?: string;
  description?: string;
  placeholder?: string;
  submitLabel?: string;
  className?: string;
}

export function B2BEmailSignUp({
  title = "Not Ready to Open an Account?",
  description = "Subscribe to stay in the know and up to date on latest trends.",
  placeholder = "Email Address",
  submitLabel = "Submit",
  className = "",
}: B2BEmailSignUpProps) {
  return (
    <div className={`w-[1440px] border-t-[0.5px] border-white bg-charcoal px-[100px] py-5 ${className}`}>
      <div className="flex h-[120px] items-center gap-5">
        <div className="flex flex-1 flex-col gap-[5px] text-white">
          <h2 className="font-display text-[38px] leading-[42px]">{title}</h2>
          <p className="text-lg leading-6">{description}</p>
        </div>
        <form className="flex items-center gap-5" action="#">
          <input
            type="email"
            placeholder={placeholder}
            aria-label={placeholder}
            className="h-14 w-[351px] rounded-pill border border-white bg-transparent px-6 py-2.5 text-[15px] font-medium text-neutral-400 placeholder-[#a4a4a4] outline-none"
          />
          <button
            type="submit"
            className="rounded-pill bg-white px-[54px] py-5 text-sm font-bold uppercase tracking-wide-ui text-charcoal"
          >
            {submitLabel}
          </button>
        </form>
      </div>
    </div>
  );
}
