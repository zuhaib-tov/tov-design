/**
 * The PDP "Variant Selection" component (fileKey ySZYmjbO2Wck8u1JGAtI5J,
 * node 197:990) — all 4 variants included (all Draft; no Live version
 * exists yet). One reusable label + pill-option-row pattern, demonstrated
 * in the source with two example option sets (Size, Fill Type), each shown
 * unselected and selected.
 */
export interface PDPVariantSelectionProps {
  label: string;
  options: string[];
  selected?: string;
}

export function PDPVariantSelection({ label, options, selected }: PDPVariantSelectionProps) {
  return (
    <div className="flex flex-col gap-2 font-sans">
      <span className="text-sm leading-[21px] text-ink">
        {label} {selected && <span className="font-bold">{selected}</span>}
      </span>
      <div className="flex items-center gap-2 flex-wrap">
        {options.map((opt) => {
          const isSelected = opt === selected;
          return (
            <button
              key={opt}
              type="button"
              className={`rounded-pill px-5 py-2.5 text-sm border ${
                isSelected
                  ? "bg-charcoal/[0.07] border-charcoal text-ink"
                  : "bg-[#e8e8e8] border-[#e8e8e8] text-ink"
              }`}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}
