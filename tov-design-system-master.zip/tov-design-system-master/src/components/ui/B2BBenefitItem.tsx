import { LucideIcon } from "lucide-react";

/**
 * TOV B2B — Benefit Item. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 4:80 ("Benefit Item" symbol frame),
 * Default/Desktop (4:72, 280 wide) and Default/Mobile (4:79, 350 wide) variants.
 *
 * Single icon-led program benefit with a heading and short explanation. Reuse
 * as a building block within the Benefits Bar. Renders in white — intended for
 * a brand-colored (mauve) background, not a bare page.
 */
export interface B2BBenefitItemProps {
  icon: LucideIcon;
  title: string;
  description: string;
  className?: string;
}

export function B2BBenefitItem({ icon: Icon, title, description, className = "" }: B2BBenefitItemProps) {
  return (
    <div className={`flex flex-col items-center text-center gap-2.5 w-full min-w-0 ${className}`}>
      <Icon className="text-white" size={24} strokeWidth={1.5} />
      <div className="flex flex-col gap-1">
        <p className="font-display text-[22px] leading-tight text-white">{title}</p>
        <p className="text-sm font-light text-white">{description}</p>
      </div>
    </div>
  );
}
