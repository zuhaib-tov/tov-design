/**
 * The Homepage "Mobile Categories" component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1063:1776) — a vertical stack of 4 full-width category cards (335x190,
 * 5px apart), not a grid. The categories differ from the 4 separate Desktop
 * card sets: the displayed text is "Living room / Home office / Outdoor /
 * Bedroom", whatever the layer names inside the Figma component say.
 */
import { HomepageCategoryCard } from "./HomepageCategoryCard";

const MOBILE_CATEGORIES = ["Living room", "Home office", "Outdoor", "Bedroom"];

export function HomepageMobileCategories() {
  return (
    <div className="flex flex-col gap-[5px] w-full max-w-sm">
      {MOBILE_CATEGORIES.map((label) => (
        <HomepageCategoryCard key={label} label={label} size="sm" />
      ))}
    </div>
  );
}
