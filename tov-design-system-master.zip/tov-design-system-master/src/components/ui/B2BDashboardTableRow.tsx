import { B2BDashboardStatusBadge, DashboardStatus } from "./B2BDashboardStatusBadge";

/**
 * TOV B2B Dashboard / Table Row — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 44:110, 4 variants: Shipped
 * (44:61), Processing (44:77), Delivered (44:93), Cancelled (44:109).
 * Orders-table body row, pairs with Table Header. Uses a Status Badge
 * instance for the Status cell. Cancelled rows show dashes across every
 * shipping-related column (Est/Act Ship, Tracking, Carrier, Method) while
 * Total/Items/Shipping values stay populated.
 */
export interface B2BDashboardTableRowProps {
  status?: DashboardStatus;
  soOrder?: string;
  poNumber?: string;
  orderDate?: string;
  estShip?: string;
  actShip?: string;
  tracking?: string;
  carrier?: string;
  method?: string;
  total?: string;
  items?: string;
  shipping?: string;
  className?: string;
}

export function B2BDashboardTableRow({
  status = "shipped",
  soOrder = "SO-2024-0847",
  poNumber = "PO-78234",
  orderDate = "Jul 15, 2024",
  estShip = "Jul 18, 2024",
  actShip = "Jul 19, 2024",
  tracking = "1Z999AA10012345",
  carrier = "UPS",
  method = "Ground",
  total = "$4,250.00",
  items = "$3,850.00",
  shipping = "$400.00",
  className = "",
}: B2BDashboardTableRowProps) {
  const cancelled = status === "cancelled";
  const dash = "-";
  return (
    <div
      className={`flex w-full items-center gap-[13px] border-b border-[#e0e0e0] bg-white px-4 py-3.5 font-sans text-[13px] font-medium ${className}`}
    >
      <p className="w-[98px] shrink-0 text-charcoal">{soOrder}</p>
      <p className="w-[98px] shrink-0 text-[#8e8e8e]">{poNumber}</p>
      <p className="w-[98px] shrink-0 text-charcoal">{orderDate}</p>
      <div className="flex w-[98px] shrink-0 items-start">
        <B2BDashboardStatusBadge status={status} />
      </div>
      <p className="w-[98px] shrink-0 text-charcoal">{cancelled ? dash : estShip}</p>
      <p className="w-[98px] shrink-0 text-charcoal">{cancelled ? dash : actShip}</p>
      <p
        className={`w-[98px] shrink-0 text-xs ${
          cancelled ? "text-charcoal" : "text-primary underline underline-offset-2"
        }`}
      >
        {cancelled ? dash : tracking}
      </p>
      <p className="w-[98px] shrink-0 text-charcoal">{cancelled ? dash : carrier}</p>
      <p className="w-[98px] shrink-0 text-charcoal">{cancelled ? dash : method}</p>
      <p className="w-[98px] shrink-0 text-charcoal">{total}</p>
      <p className="w-[98px] shrink-0 text-right text-charcoal">{items}</p>
      <p className="w-[68px] shrink-0 text-right text-[#8e8e8e]">{shipping}</p>
    </div>
  );
}
