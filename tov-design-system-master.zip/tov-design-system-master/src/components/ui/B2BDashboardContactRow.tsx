import { Phone } from "lucide-react";
import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Contact Row — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:92 → Version=Default (41:91),
 * 515px wide. Icon tile + uppercase label + value, for phone/email/hours
 * contact lines. Icon tile is 40px, cream (#faf7f2) fill, 8px radius.
 */
export interface B2BDashboardContactRowProps {
  icon?: ReactNode;
  label?: string;
  value?: string;
  className?: string;
}

export function B2BDashboardContactRow({
  icon,
  label = "Direct Phone",
  value = "(800) 555-8392",
  className = "",
}: B2BDashboardContactRowProps) {
  return (
    <div className={`flex w-[515px] max-w-full items-center gap-4 ${className}`}>
      <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-md bg-cream-100 text-primary">
        {icon ?? <Phone size={18} strokeWidth={1.75} />}
      </span>
      <div className="flex min-w-0 flex-1 flex-col gap-0.5 whitespace-nowrap">
        <p className="font-sans text-[11px] font-bold uppercase tracking-wide-ui text-[#8e8e8e]">{label}</p>
        <p className="font-sans text-[15px] font-semibold text-charcoal">{value}</p>
      </div>
    </div>
  );
}
