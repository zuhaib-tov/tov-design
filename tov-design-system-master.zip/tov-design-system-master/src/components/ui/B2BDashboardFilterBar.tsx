import { ChevronDown, Search, Upload } from "lucide-react";

/**
 * TOV B2B Dashboard / Filter Bar — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 44:133 → Version=Orders (44:132),
 * full-width (1066px). A Search Field, two Select filters, a "Reset
 * Filters" link and a Secondary "Export" button — sits above a data table.
 * The Search Field, Select and Button here are built inline (the Dashboard
 * Atoms tier owns their canonical versions).
 */
export interface B2BDashboardFilterBarProps {
  searchPlaceholder?: string;
  dateRangeValue?: string;
  statusValue?: string;
  dateRangeLabel?: string;
  statusLabel?: string;
  actionLabel?: string;
  className?: string;
}

export function B2BDashboardFilterBar({
  searchPlaceholder = "Search orders...",
  dateRangeValue = "All Time",
  statusValue = "All Statuses",
  dateRangeLabel = "Date Range:",
  statusLabel = "Status:",
  actionLabel = "Export",
  className = "",
}: B2BDashboardFilterBarProps) {
  return (
    <div className={`flex w-full flex-wrap items-center justify-between gap-3 ${className}`}>
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex w-[280px] max-w-full items-center gap-2 rounded-md border border-[#e0e0e0] bg-white px-4 py-2.5">
          <Search size={16} className="shrink-0 text-[#8e8e8e]" />
          <p className="font-sans text-sm font-medium text-[#8e8e8e]">{searchPlaceholder}</p>
        </div>
        <div className="flex items-center gap-3 rounded-md border border-[#e0e0e0] bg-white px-4 py-2.5">
          <p className="whitespace-nowrap font-sans text-sm font-medium text-[#8e8e8e]">{dateRangeLabel}</p>
          <p className="whitespace-nowrap font-sans text-sm font-medium text-charcoal">{dateRangeValue}</p>
          <ChevronDown size={16} className="text-[#8e8e8e]" />
        </div>
        <div className="flex items-center gap-3 rounded-md border border-[#e0e0e0] bg-white px-4 py-2.5">
          <p className="whitespace-nowrap font-sans text-sm font-medium text-[#8e8e8e]">{statusLabel}</p>
          <p className="whitespace-nowrap font-sans text-sm font-medium text-charcoal">{statusValue}</p>
          <ChevronDown size={16} className="text-[#8e8e8e]" />
        </div>
        <p className="cursor-pointer whitespace-nowrap font-sans text-sm font-medium text-[#8e8e8e] underline">
          Reset Filters
        </p>
      </div>
      <button
        type="button"
        className="flex items-center gap-2 rounded-md border border-[#e0e0e0] bg-white px-[18px] py-2.5 font-sans text-sm font-medium tracking-wide-ui text-charcoal"
      >
        <Upload size={16} />
        {actionLabel}
      </button>
    </div>
  );
}
