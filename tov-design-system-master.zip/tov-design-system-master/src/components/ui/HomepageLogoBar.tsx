/**
 * The Homepage "Logo Bar" component (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1060:1704) — a Live set of four variants: two looks × two viewports
 * ("Logo Bar" / "Logo Bar 2", Desktop / Mobile). A cream (#F1ECE5) pill of
 * press logos, each 15px tall at 50% opacity, set in a row with a 120px gap on
 * Desktop and 22px on Mobile. Desktop base keeps a 100px side margin and is 56px
 * tall with a 10px radius; Desktop 2 is full-bleed with square corners. Mobile
 * base is full-bleed and 35px tall; Mobile 2 has a 20px side margin and rounded
 * corners.
 *
 * In Figma the row is an infinite-scroll marquee. It is drawn here as the
 * resting frame: the same sequence at the same offset inside the clipped pill,
 * without the animation.
 */
const LOGOS = [
  { name: "Vogue", file: "logo-01", w: 55.5 },
  { name: "Architectural Digest", file: "logo-02", w: 19.9 },
  { name: "Forbes", file: "logo-03", w: 56.6 },
  { name: "HGTV", file: "logo-04", w: 29.1 },
  { name: "Cosmopolitan", file: "logo-05", w: 31.9 },
  { name: "Maxim", file: "logo-06", w: 71.4 },
  { name: "The Hollywood Reporter", file: "logo-07", w: 63.8 },
  { name: "The Wall Street Journal", file: "logo-08", w: 31.8 },
  { name: "WWD", file: "logo-09", w: 50.8 },
  { name: "Esquire", file: "logo-10", w: 56.6 },
  { name: "Miami", file: "logo-11", w: 63.8 },
];

/** Left offset of the logo row inside the pill, from the Figma frames. */
const OFFSET = {
  desktop: { inset: -225, full: -125 },
  mobile: { inset: -677, full: -657 },
} as const;

export interface HomepageLogoBarProps {
  viewport?: "desktop" | "mobile";
  /** Side margin around the pill. Defaults to inset on Desktop and full-bleed on Mobile. */
  inset?: boolean;
}

export function HomepageLogoBar({ viewport = "desktop", inset }: HomepageLogoBarProps) {
  const isDesktop = viewport === "desktop";
  const hasInset = inset ?? isDesktop;
  const gap = isDesktop ? 120 : 22;
  const left = OFFSET[viewport][hasInset ? "inset" : "full"];
  const wrap = isDesktop
    ? hasInset
      ? "px-page-margin-desktop pt-5"
      : "pt-5"
    : hasInset
      ? "px-page-margin-mobile"
      : "";
  const pill = isDesktop ? "h-14" : "h-[35px]";
  const radius = hasInset ? "rounded-[10px]" : "";

  return (
    <div className={`bg-white ${isDesktop ? "w-[1440px]" : "w-[375px]"} ${wrap}`}>
      <div className={`relative overflow-hidden bg-cream-200 ${pill} ${radius}`}>
        <div className="absolute top-1/2 flex -translate-y-1/2 items-center" style={{ left, gap }}>
          {[...LOGOS, ...LOGOS].map((l, i) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={i}
              src={`/images/homepage/logos/${l.file}.svg`}
              alt={l.name}
              width={l.w}
              height={15}
              className="h-[15px] shrink-0"
              style={{ width: l.w }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
