import { LucideIcon, PackageOpen, FileMinus, Percent, Truck, ClipboardList, TrendingDown, UserCheck } from "lucide-react";

/**
 * TOV B2B — Program Card. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 8:143 ("Program Card" symbol frame) — 4 variants:
 * Trade Program/Desktop (8:105), Wholesale/Desktop (8:142), Trade Program/Mobile
 * (19:327), Wholesale/Mobile (19:328).
 *
 * Detailed program offer for Trade Program or Wholesale, including audience,
 * benefits and requirements. Both program versions have desktop and mobile
 * variants; keep eligibility and pricing copy approved.
 *
 * Desktop renders as a bordered, transparent-background panel; Mobile renders
 * as a cream card with no border — matching the real file exactly.
 */
export interface B2BProgramPerk {
  icon: LucideIcon;
  title: string;
  description: string;
}

export interface B2BProgramCardProps {
  title: string;
  description: string;
  /** Small filled pill next to the title, e.g. "Tier II" — Wholesale only. */
  tierBadge?: string;
  /** Uppercase label at the right of the title row, e.g. "PREMIUM" — Wholesale only. */
  tierLabel?: string;
  perks: B2BProgramPerk[];
  /** Renders the Mobile variant (cream card, no border) instead of Desktop. */
  compact?: boolean;
  className?: string;
}

export const TRADE_PROGRAM_PERKS: B2BProgramPerk[] = [
  {
    icon: PackageOpen,
    title: "No Minimum Buy-Ins",
    description: "Order one piece or a hundred — there is no minimum to unlock custom trade rates.",
  },
  {
    icon: FileMinus,
    title: "No Certificate Required",
    description:
      "Get started fast — a resale certificate is not required to join the Trade Program. Tax-exempt options available.",
  },
  {
    icon: Percent,
    title: "Automatic Savings",
    description: "A standing 20% off full-price items, applied automatically at checkout.",
  },
  {
    icon: Truck,
    title: "Fast Free Shipping",
    description: "In-stock pieces ship in 1 to 3 days on trackable freight networks. Free on orders over $299.",
  },
];

export const WHOLESALE_PERKS: B2BProgramPerk[] = [
  {
    icon: ClipboardList,
    title: "Requirements",
    description: "Valid resale certificate, minimum opening and annual commitment.",
  },
  {
    icon: TrendingDown,
    title: "Unlock Additional Savings",
    description: "Tiered pricing rewards larger orders with additional savings.",
  },
  {
    icon: UserCheck,
    title: "Concierge Style Service",
    description: "A dedicated account manager for all your needs.",
  },
  {
    icon: Truck,
    title: "Flat Rate Shipping Program",
    description: "Simplified shipping for large-scale projects with predictable costs.",
  },
];

export function B2BProgramCard({
  title,
  description,
  tierBadge,
  tierLabel,
  perks,
  compact = false,
  className = "",
}: B2BProgramCardProps) {
  return (
    <div
      className={`rounded-2xl flex flex-col gap-6 ${
        compact ? "bg-cream-100 p-5 w-[350px]" : "border border-neutral-200 p-8 w-[600px]"
      } ${className}`}
    >
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <p className={`font-display text-charcoal ${compact ? "text-2xl" : "text-[38px] leading-[42px]"}`}>{title}</p>
            {tierBadge && (
              <span className="bg-primary text-white text-sm rounded px-2 py-0.5">{tierBadge}</span>
            )}
          </div>
          {tierLabel && (
            <span className="text-sm text-primary uppercase tracking-wide-ui">{tierLabel}</span>
          )}
        </div>
        <p className={`text-sm text-[#8e8e8e] ${compact ? "" : "min-h-8 leading-4"}`}>{description}</p>
      </div>

      <div className="border-t border-neutral-200" />

      <div className="flex flex-col gap-5">
        {perks.map((perk) => (
          <div key={perk.title} className="flex items-start gap-4">
            <perk.icon className="text-charcoal shrink-0 mt-0.5" size={24} strokeWidth={1.5} />
            <div className="flex flex-col gap-1">
              <p className={`font-display text-[22px] text-primary ${compact ? "" : "leading-[25px]"}`}>{perk.title}</p>
              <p className={`text-sm text-charcoal ${compact ? "" : "leading-4"}`}>{perk.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
