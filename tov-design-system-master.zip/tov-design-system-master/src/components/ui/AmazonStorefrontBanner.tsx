/**
 * Amazon Store — Storefront "flat, pre-composited" banner (fileKey
 * I95mnwwaoq0CvJOGop9tfn, "TOV25 - B2C - Amazon store", "Amazon store
 * images" section 16:363). Covers two of the section's three sub-sections:
 *
 *  - "Banner images" (16:364) — the 3 alternate Hero variants. Hero Desktop
 *    nodes (e.g. 34:1264 "Hero - Desktop") are leaf frames — no child text
 *    layers — 1920x777 (rendered PNG measures 1928x785, a few px of
 *    stroke/effect bleed, same ~2.47:1 ratio). Hero Mobile (e.g. 34:1316)
 *    sits one level under a same-size 1500x1110 wrapper/"Frame 405", also a
 *    plain leaf fill, no crop — the photo fills the full wrapper, ~1.35:1.
 *  - "3 tile grid section" (34:1359) — Bedroom / Nightstand / Living Room
 *    promo tiles. Same shape: leaf frames, no child text (e.g. 34:1307
 *    "Bedroom -D").
 *
 * Both sub-sections share the same real trait: the headline, subhead, and
 * "SHOP NOW" pill are baked directly into the photo — there is no separate
 * Figma text layer to compose here, unlike Category Tiles (see
 * AmazonCategoryTile.tsx). So this component is intentionally just a
 * full-bleed image with no text props.
 *
 * Dimension note (see figma-slots.ts's comment on
 * STOREFRONT_THREE_TILE_GRID_SLOTS for the full writeup): the three 3-Tile
 * Grid promo tiles do not all share one aspect ratio. Bedroom and Living
 * Room's Desktop + Mobile nodes are all 1500x750 (2:1), but Nightstand's
 * Desktop node (76:186) is 1500x1500 — a full square. Nightstand's own
 * Mobile node (76:204) is back to 1500x750, so even within the "Nightstand"
 * pair the two viewports don't share a crop. Callers must pass the real
 * aspectRatio per node — never assume 2:1 for all six 3-Tile Grid slots.
 */
export interface AmazonStorefrontBannerProps {
  /** width / height, e.g. 1920 / 777 for Hero Desktop, or 1 for Nightstand Desktop's square crop. Always pass the real per-node ratio — see the caveat above. */
  aspectRatio: number;
  /** Caps the rendered width so a Preview reads near its real on-page size instead of filling the column. */
  maxWidth?: number;
  imageSrc?: string;
  imageAlt?: string;
  className?: string;
}

export function AmazonStorefrontBanner({
  aspectRatio,
  maxWidth = 640,
  imageSrc,
  imageAlt,
  className = "",
}: AmazonStorefrontBannerProps) {
  return (
    <div
      className={`bg-image-placeholder w-full overflow-hidden ${className}`}
      style={{ maxWidth, aspectRatio }}
      role={!imageSrc ? "img" : undefined}
      aria-label={!imageSrc ? imageAlt ?? "Storefront banner placeholder" : undefined}
    >
      {imageSrc && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={imageSrc} alt={imageAlt ?? ""} className="w-full h-full object-cover" />
      )}
    </div>
  );
}
