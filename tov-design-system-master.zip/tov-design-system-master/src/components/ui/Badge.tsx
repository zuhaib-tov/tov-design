import { ReactNode } from "react";

/**
 * The 9 real named variants below match the OG Figma "📛 Buttons, Badges"
 * page (node 1611:4711) exactly — colors bound-variable-resolved (8/9) or
 * gradient-stop-resolved (Limited Edition). The 4 legacy variants (new,
 * sale, success, neutral) are app-chrome-only: they predate this sync and
 * are kept for this docs site's own indicators (the "Updated" badge on
 * foundations pages, sync-status counts, etc.) — not a real TOV product
 * badge, so they don't need to track Figma.
 */
export type BadgeVariant =
  | "new"
  | "sale"
  | "success"
  | "neutral"
  | "new-arrival"
  | "new-arrival-sale"
  | "best-seller"
  | "best-seller-sale"
  | "final-sale"
  | "sale-mauve"
  | "sale-lagoon"
  | "hot-list"
  | "limited-edition";

export type BadgeSize = "sm" | "md";

const variants: Record<BadgeVariant, string> = {
  // app-chrome only
  new: "bg-primary text-white",
  sale: "bg-sale text-white",
  success: "bg-success text-white",
  neutral: "bg-neutral-200 text-ink",

  // real TOV product badges
  "new-arrival": "bg-brand-pink text-charcoal",
  "new-arrival-sale": "bg-charcoal text-white",
  "best-seller": "bg-charcoal text-white",
  "best-seller-sale": "bg-charcoal text-white",
  "final-sale": "bg-burnt-umber text-white",
  "sale-mauve": "bg-mauve text-white",
  "sale-lagoon": "bg-lagoon text-white",
  "hot-list": "bg-brand-pink text-charcoal",
  "limited-edition": "bg-gradient-to-r from-[#E4D7BA] to-[#CCB583] text-charcoal",
};

/**
 * Two sizes: Medium for Desktop, 27px tall (10px text, 6px / 10px padding), and
 * Small for Mobile, 19px tall (8px text, 4px / 7px). The line heights are set so
 * the rendered heights equal the Figma heights. Figma also draws a 45px Large
 * badge; it is not used on the live site and is not part of the system.
 */
const sizes: Record<BadgeSize, string> = {
  md: "text-[10px] leading-[15px] px-2.5 py-1.5",
  sm: "text-[8px] leading-[11px] px-[7px] py-1",
};

/** Hot List carries a flame: 11px on Medium and 10px on Small, with a 2px gap. */
const FLAME: Record<BadgeSize, { px: number; gap: string }> = {
  md: { px: 11, gap: "gap-0.5" },
  sm: { px: 10, gap: "gap-0.5" },
};

export function Badge({
  children,
  variant = "neutral",
  size = "md",
  icon,
}: {
  children: ReactNode;
  variant?: BadgeVariant;
  size?: BadgeSize;
  icon?: ReactNode;
}) {
  const flame = variant === "hot-list" && icon === undefined ? FLAME[size] : null;
  return (
    <span
      className={`inline-flex items-center ${flame ? flame.gap : "gap-1"} rounded-pill font-bold uppercase tracking-wide-ui whitespace-nowrap ${variants[variant]} ${sizes[size]}`}
    >
      {flame ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src="/icons/fire.svg" alt="" width={flame.px} height={flame.px} style={{ width: flame.px, height: flame.px }} />
      ) : (
        icon
      )}
      {children}
    </span>
  );
}
