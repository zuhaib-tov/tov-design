import { Button } from "./Button";

/**
 * Search — No Results — fileKey DTjIdCKhnDUVvJhEfpn10v, node 1696:2932.
 * 2 real variants: Desktop (1696:2838) and Mobile (1696:2885). Centered
 * message (display-font heading + body copy + a "Go to results" button,
 * real sentence-case text uppercased via CSS) for the same "SKU
 * TOV-OC69425" query used by Type C — reuses the same promo banner on
 * Desktop; Mobile ends right after the button, no promo banner shown.
 */
import { SearchTopBar, MobileSearchTopBar, PromoBanner } from "./SearchShared";

function NoResultsMessage() {
  return (
    <div className="flex flex-col items-center text-center gap-stack-gap-md max-w-lg mx-auto">
      <h2 className="font-display text-3xl text-ink">View all results</h2>
      <p className="text-sm leading-[21px] text-ink-muted">
        Quick suggestions came up empty for &ldquo;SKU TOV-OC69425&rdquo;. View our full search that includes close and similar matches.
      </p>
      <Button size="lg">Go to results</Button>
    </div>
  );
}

export function SearchTypeNoResultsDesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="SKU TOV-OC69425" />
      <p className="text-xs text-ink px-10 pt-6 pb-4">
        <span className="text-ink-muted">No results for</span> &lsquo;SKU TOV-OC69425&rsquo;
      </p>
      <div className="px-10 py-16">
        <NoResultsMessage />
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeNoResultsMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <p className="text-xs text-ink px-5 pt-6 pb-4">
        <span className="text-ink-muted">No results for</span> &lsquo;SKU TOV-OC69425&rsquo;
      </p>
      <div className="px-5 py-8">
        <NoResultsMessage />
      </div>
    </div>
  );
}
