/**
 * TOV B2B Dashboard / Saved Projects Strip — Figma "TOV26 - B2B - Design
 * system" (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:550, Dashboard page,
 * Organisms section. A 1000px Overview-page strip: a header (project
 * count + "View all") over three Dashboard/Project Feature Card instances
 * — an image-led card with a dark gradient overlay, a "Created [date]"
 * stamp, the project name + item count, and a "View Project" link.
 */
const PROJECTS = [
  { createdOn: "Created Jun 30" },
  { createdOn: "Created May 06" },
  { createdOn: "Created May 01" },
];

export function B2BDashboardSavedProjectsStrip({
  projectCount = 12,
  className = "",
}: {
  projectCount?: number;
  className?: string;
}) {
  return (
    <div className={`flex w-[1000px] flex-col items-start gap-5 rounded-[16px] border border-[#eee] bg-white p-5 font-sans ${className}`}>
      <div className="flex w-full items-center gap-5">
        <span className="text-[15px] font-bold text-charcoal">Saved projects</span>
        <span className="text-[15px] text-charcoal">{projectCount} Projects</span>
        <div className="flex-1" />
        <span className="text-sm font-bold text-charcoal underline">View all</span>
      </div>
      <div className="flex w-full items-start gap-[5px]">
        {PROJECTS.map((project) => (
          <div
            key={project.createdOn}
            className="relative flex h-[210px] flex-1 flex-col justify-end gap-[10px] overflow-hidden rounded-[10px] border-[0.5px] border-[#e0e0e0] p-3"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/b2b/dashboard/project-feature.png"
              alt=""
              className="absolute inset-0 size-full object-cover"
            />
            <div
              className="absolute inset-0"
              style={{ backgroundImage: "linear-gradient(8deg, rgba(0,0,0,0.62) 9%, rgba(255,255,255,0) 123%)" }}
            />
            <div className="relative flex flex-1 flex-col justify-end gap-[8px]">
              <span className="text-[10px] uppercase tracking-wide-ui text-white/70">{project.createdOn}</span>
            </div>
            <div className="relative flex flex-col gap-[25px] text-white">
              <div className="flex flex-col gap-1">
                <span className="text-xl font-bold">Project Name</span>
                <span className="text-[15px]">Qty: 12 Items</span>
              </div>
              <span className="text-sm font-bold underline">View Project</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
