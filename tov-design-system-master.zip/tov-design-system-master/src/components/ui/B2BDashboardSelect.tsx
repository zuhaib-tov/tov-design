import { SelectHTMLAttributes } from "react";

/**
 * TOV B2B Dashboard / Select — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:688. Labelled dropdown
 * filter (Label: Value + chevron): white fill, 1px #e0e0e0 border, 8px radius,
 * 16px / 10px padding, 12px gap, 14px Medium. Label is #8e8e8e, value is
 * charcoal, 16px chevron with a 1.25px charcoal stroke.
 */
export interface B2BDashboardSelectProps
  extends Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> {
  /** Muted label shown before the value, e.g. "Date Range:". */
  label: string;
  options: { value: string; label: string }[];
  containerClassName?: string;
}

export function B2BDashboardSelect({
  label,
  options,
  containerClassName = "",
  className = "",
  ...props
}: B2BDashboardSelectProps) {
  return (
    <label
      className={`inline-flex items-center gap-3 rounded-md border border-[#e0e0e0] bg-white px-4 py-[10px] font-sans text-sm font-medium focus-within:border-primary ${containerClassName}`}
    >
      <span className="whitespace-nowrap text-[#8e8e8e]">{label}</span>
      <select
        className={`cursor-pointer appearance-none bg-transparent font-medium text-charcoal outline-none ${className}`}
        {...props}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden className="pointer-events-none shrink-0">
        <path d="M4 6L8 10L12 6" stroke="#3F3D3E" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </label>
  );
}
