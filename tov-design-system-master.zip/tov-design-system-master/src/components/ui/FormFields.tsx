import { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes, forwardRef } from "react";

/**
 * Form elements from the Claims form file (fileKey fAR8Q5JFFhzwMVslVENoHr).
 * Fields are soft-filled and rounded: #F6F6F6 fill, 1px #E8E8E8 border, 16px
 * radius, 54px tall. The label sits above in 16px Regular, placeholder text is
 * #BBBBBB, and the accent for selected controls is Bold lip (#713A40).
 *
 * Figma draws the form at two sizes: Mobile (375px page, 335px card, 295px
 * fields) and Desktop (1440px page, 500px card, 460px fields). Field height,
 * radius, label and placeholder are identical on both; the pieces that change
 * take a `viewport` prop. Leave it off and they follow the screen, switching to
 * the Desktop values at 1024px.
 */

export type FormViewport = "mobile" | "desktop";

function byViewport(viewport: FormViewport | undefined, mobile: string, desktop: string, auto: string) {
  return viewport === "mobile" ? mobile : viewport === "desktop" ? desktop : auto;
}

const FIELD =
  "w-full rounded-[16px] border border-[#e8e8e8] bg-neutral-100 px-2.5 font-sans text-sm leading-4 text-charcoal outline-none transition-colors placeholder:text-[#bbbbbb] focus:border-bold-lip disabled:cursor-not-allowed disabled:opacity-50";

interface FieldWrapProps {
  label?: string;
  /** Appends the required marker to the label. */
  required?: boolean;
  error?: string;
  /** Short guidance under the field. Replaced by the error message when there is one. */
  helper?: string;
}

function FieldWrap({
  label,
  required,
  error,
  helper,
  children,
}: FieldWrapProps & { children: ReactNode }) {
  return (
    <label className="flex flex-col gap-2.5 font-sans">
      {label && (
        <span className="text-base leading-[19px] text-charcoal">
          {label}
          {required && "*"}
        </span>
      )}
      {children}
      {error ? (
        <span className="text-xs leading-[14px] text-sale">{error}</span>
      ) : helper ? (
        <span className="text-[10px] leading-3 text-[#bbbbbb]">{helper}</span>
      ) : null}
    </label>
  );
}

export interface InputProps
  extends InputHTMLAttributes<HTMLInputElement>,
    FieldWrapProps {}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, required, error, helper, className = "", ...props }, ref) => (
    <FieldWrap label={label} required={required} error={error} helper={helper}>
      <input
        ref={ref}
        required={required}
        aria-invalid={error ? true : undefined}
        className={`${FIELD} h-[54px] ${error ? "border-sale" : ""} ${className}`}
        {...props}
      />
    </FieldWrap>
  )
);
Input.displayName = "Input";

export interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement>,
    FieldWrapProps {}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, required, error, helper, className = "", ...props }, ref) => (
    <FieldWrap label={label} required={required} error={error} helper={helper}>
      <textarea
        ref={ref}
        required={required}
        aria-invalid={error ? true : undefined}
        className={`${FIELD} min-h-[118px] resize-y py-[18px] ${error ? "border-sale" : ""} ${className}`}
        {...props}
      />
    </FieldWrap>
  )
);
Textarea.displayName = "Textarea";

export interface SelectProps
  extends SelectHTMLAttributes<HTMLSelectElement>,
    FieldWrapProps {}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, required, error, helper, className = "", children, ...props }, ref) => (
    <FieldWrap label={label} required={required} error={error} helper={helper}>
      <select
        ref={ref}
        required={required}
        aria-invalid={error ? true : undefined}
        className={`${FIELD} h-[54px] cursor-pointer appearance-none bg-[url('/icons/chevron-down.svg')] bg-[length:16px] bg-[right_14px_center] bg-no-repeat pr-10 ${
          error ? "border-sale" : ""
        } ${className}`}
        {...props}
      >
        {children}
      </select>
    </FieldWrap>
  )
);
Select.displayName = "Select";

export type SearchFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, "type">;

/** Pill search field: 36px tall, search icon on the left, 12px text. */
export const SearchField = forwardRef<HTMLInputElement, SearchFieldProps>(
  ({ className = "", placeholder = "Search", ...props }, ref) => (
    <label className="flex h-9 w-full items-center gap-1 rounded-pill border border-[#e8e8e8] bg-neutral-100 pr-3 font-sans">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/search.svg" alt="" className="h-[18px] w-[18px]" />
      </span>
      <input
        ref={ref}
        type="search"
        placeholder={placeholder}
        className={`min-w-0 flex-1 bg-transparent text-xs leading-[14px] text-charcoal outline-none placeholder:text-charcoal ${className}`}
        {...props}
      />
    </label>
  )
);
SearchField.displayName = "SearchField";

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  label: string;
}

/** 18px square, 4px radius. Unchecked is #E8E8E8 with a #BBBBBB border; the label is 12px #A4A4A4. */
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, className = "", ...props }, ref) => (
    <label className="inline-flex cursor-pointer items-center gap-2 font-sans text-xs leading-[14px] text-[#a4a4a4]">
      <span className="relative inline-flex h-[18px] w-[18px] shrink-0">
        <input
          ref={ref}
          type="checkbox"
          className={`peer absolute inset-0 m-0 h-full w-full cursor-pointer appearance-none rounded-[4px] border border-[#bbbbbb] bg-[#e8e8e8] outline-none checked:border-bold-lip checked:bg-bold-lip focus-visible:ring-2 focus-visible:ring-bold-lip/40 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
          {...props}
        />
        <svg
          viewBox="0 0 12 12"
          className="pointer-events-none absolute inset-0 m-auto h-3 w-3 text-white opacity-0 peer-checked:opacity-100"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <path d="M2.5 6.2l2.4 2.4 4.6-5" />
        </svg>
      </span>
      {label}
    </label>
  )
);
Checkbox.displayName = "Checkbox";

export interface RadioCardProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "title"> {
  title: string;
  description?: string;
}

/**
 * Option card: 295px wide at the mobile step, 16px radius, a 27px radio and a
 * two-line label. Selected switches to the pale pink fill (#FEF4F4) with a
 * TOV Pink border and a filled Bold lip radio.
 */
export const RadioCard = forwardRef<HTMLInputElement, RadioCardProps>(
  ({ title, description, className = "", ...props }, ref) => (
    <label
      className={`flex cursor-pointer items-center gap-[15px] rounded-[16px] border border-[#e8e8e8] bg-neutral-100 px-[11px] py-[18px] font-sans transition-colors has-[:checked]:border-brand-pink has-[:checked]:bg-pink-50 has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-50 ${className}`}
    >
      <span className="relative inline-flex h-[27px] w-[27px] shrink-0">
        <input ref={ref} type="radio" className="peer sr-only" {...props} />
        <span className="absolute inset-0 rounded-full border-[0.73px] border-bold-lip bg-white transition-colors peer-checked:bg-bold-lip peer-focus-visible:ring-2 peer-focus-visible:ring-bold-lip/40" />
      </span>
      <span className="flex min-w-0 flex-col">
        <span className="text-lg leading-6 text-bold-lip">{title}</span>
        {description && <span className="text-sm leading-4 text-neutral-700">{description}</span>}
      </span>
    </label>
  )
);
RadioCard.displayName = "RadioCard";

export interface ProductOptionCardProps {
  sku: string;
  name: string;
  /** Image URL for the 83×70 thumbnail. Omit for the empty white tile. */
  image?: string;
  selected?: boolean;
  onClick?: () => void;
  /** The SKU line is 12px on Mobile and 14px on Desktop. */
  viewport?: FormViewport;
}

/** Product row for picking an item: 83×70 thumbnail, SKU label and product name. 90px tall. */
export function ProductOptionCard({ sku, name, image, selected = false, onClick, viewport }: ProductOptionCardProps) {
  const className = `flex w-full items-center gap-[15px] rounded-[16px] border p-[9px] text-left font-sans transition-colors ${
    selected ? "border-brand-pink bg-pink-50" : "border-[#e8e8e8] bg-neutral-100"
  }`;
  const content = (
    <>
      <span className="flex h-[70px] w-[83px] shrink-0 items-center justify-center overflow-hidden rounded-lg bg-white">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {image && <img src={image} alt="" className="h-full w-full object-contain" />}
      </span>
      <span className="flex min-w-0 flex-col">
        <span className={`${byViewport(viewport, "text-xs", "text-sm", "text-xs lg:text-sm")} uppercase leading-4 tracking-wide-ui text-neutral-700`}>SKU {sku}</span>
        <span className="text-sm leading-4 text-bold-lip">{name}</span>
      </span>
    </>
  );
  return onClick ? (
    <button type="button" onClick={onClick} aria-pressed={selected} className={className}>
      {content}
    </button>
  ) : (
    <div className={className}>{content}</div>
  );
}

export interface FileDropzoneProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  title?: string;
  /** Format and limit line under the title, for example "JPG or PNG · Up to 6 photos, 10MB max per file". */
  hint?: string;
  /** Mobile is 103px tall, Desktop 263px. */
  viewport?: FormViewport;
}

/** Dashed upload zone: Bold lip dashed border at 10% tint, cloud icon, 14px title and an 8.33px hint line. Borders sit inside the Figma sizes, so paddings here are 1px smaller than the Figma values. */
export const FileDropzone = forwardRef<HTMLInputElement, FileDropzoneProps>(
  ({ title = "Tap to browse and upload", hint, viewport, className = "", ...props }, ref) => (
    <label
      className={`flex ${byViewport(viewport, "min-h-[103px]", "min-h-[263px]", "min-h-[103px] lg:min-h-[263px]")} w-full cursor-pointer flex-col items-center justify-center gap-0 rounded-[16px] border border-dashed border-bold-lip bg-bold-lip/10 px-2.5 py-[18px] text-center font-sans ${className}`}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/icons/cloud-upload.svg" alt="" className="h-[39px] w-[39px]" />
      <span className="text-sm leading-4 text-bold-lip">{title}</span>
      {hint && <span className="text-[8.33px] leading-[10px] text-[#333333]">{hint}</span>}
      <input ref={ref} type="file" className="sr-only" {...props} />
    </label>
  )
);
FileDropzone.displayName = "FileDropzone";

/** Step progress: 7px tall pill, a 16% Bold lip track and a solid Bold lip fill. `value` is 0–1. */
export function ProgressBar({ value, label }: { value: number; label?: string }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(pct)}
      className="h-[7px] w-full overflow-hidden rounded-full bg-bold-lip/[0.16]"
    >
      <div className="h-full rounded-full bg-bold-lip" style={{ width: `${pct}%` }} />
    </div>
  );
}

/** Review row: a muted label over a bold value, with an edit action on the right. */
export function SummaryRow({
  label,
  value,
  onEdit,
  viewport,
}: {
  label: string;
  value: ReactNode;
  onEdit?: () => void;
  /** Mobile is 59px tall with 10px padding, Desktop 79px with 20px. */
  viewport?: FormViewport;
}) {
  return (
    <div
      className={`flex w-full items-center justify-between gap-4 rounded-[16px] border border-[#e8e8e8] bg-neutral-100 font-sans ${byViewport(viewport, "p-[9px]", "p-[19px]", "p-[9px] lg:p-[19px]")}`}
    >
      <div className="flex min-w-0 flex-col gap-1">
        <span className="text-sm leading-4 text-neutral-700">{label}</span>
        <span className="text-base font-bold leading-[19px] text-charcoal">{value}</span>
      </div>
      <button
        type="button"
        onClick={onEdit}
        aria-label={`Edit ${label.toLowerCase()}`}
        className="flex h-6 w-6 shrink-0 items-center justify-center"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/pencil-edit.svg" alt="" className="h-6 w-6" />
      </button>
    </div>
  );
}

/**
 * The card that holds one step of a form: 36px radius, 0.5px gradient border
 * from Bold lip to TOV Pink, soft shadow, 30px / 20px padding. A 39px icon and
 * a 38px GT Ultra Fine heading in Bold lip open the step. The card is 335px on
 * Mobile and 500px on Desktop, with the same padding and 29px gap on both.
 */
export function FormStepCard({
  icon,
  title,
  intro,
  children,
  viewport,
}: {
  icon?: string;
  title: string;
  intro?: string;
  children?: ReactNode;
  /** Mobile is a 335px card with a 16px intro; Desktop is 500px with an 18px intro. */
  viewport?: FormViewport;
}) {
  return (
    <div className={`w-full ${byViewport(viewport, "max-w-[335px]", "max-w-[500px]", "max-w-[335px] lg:max-w-[500px]")} rounded-[36px] bg-gradient-to-br from-bold-lip to-brand-pink p-[0.5px] shadow-[0_0_4px_rgba(0,0,0,0.25)]`}>
      <div className="flex flex-col items-center gap-[29px] rounded-[35.5px] bg-white px-[19.5px] py-[29.5px] font-sans">
        <div className="flex flex-col items-center gap-[9px] text-center">
          {icon && (
            <span
              aria-hidden="true"
              className="block h-[39px] w-[39px] bg-bold-lip"
              style={{
                maskImage: `url(/icons/${icon}.svg)`,
                WebkitMaskImage: `url(/icons/${icon}.svg)`,
                maskRepeat: "no-repeat",
                WebkitMaskRepeat: "no-repeat",
                maskPosition: "center",
                WebkitMaskPosition: "center",
                maskSize: "contain",
                WebkitMaskSize: "contain",
              }}
            />
          )}
          <h3 className="font-display text-[38px] leading-[42px] text-bold-lip">{title}</h3>
          {intro && (
            <p className={`${byViewport(viewport, "text-base leading-[19px]", "text-lg leading-6", "text-base leading-[19px] lg:text-lg lg:leading-6")} text-charcoal`}>
              {intro}
            </p>
          )}
        </div>
        {children && <div className="flex w-full flex-col gap-2.5">{children}</div>}
      </div>
    </div>
  );
}
