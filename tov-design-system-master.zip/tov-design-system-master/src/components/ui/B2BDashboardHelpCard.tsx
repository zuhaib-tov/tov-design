/**
 * TOV B2B Dashboard / Help Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:61 → Version=Default (41:60),
 * 270px wide. Support/account-manager callout: title + subtitle, a profile
 * row (Avatar + name/role) and a full-width Brand button. Cream (#f1ece5)
 * fill, white border, 12px radius, 16px padding/gap.
 *
 * The Avatar renders as a placeholder swatch here — the real photo asset is
 * supplied by the Dashboard/Avatar atom (sibling component).
 */
export interface B2BDashboardHelpCardProps {
  title?: string;
  subtitle?: string;
  name: string;
  role: string;
  buttonLabel: string;
  className?: string;
}

export function B2BDashboardHelpCard({
  title = "Need help?",
  subtitle = "Contact your account manager",
  name,
  role,
  buttonLabel,
  className = "",
}: B2BDashboardHelpCardProps) {
  return (
    <div
      className={`flex w-[270px] flex-col items-start gap-4 rounded-[12px] border border-white bg-cream-200 p-4 ${className}`}
    >
      <div className="flex w-full flex-col gap-1">
        <p className="font-sans text-[15px] font-bold text-charcoal">{title}</p>
        <p className="font-sans text-[11px] font-normal text-[#8e8e8e]">{subtitle}</p>
      </div>
      <div className="flex w-full items-center gap-2.5">
        <span className="bg-image-placeholder size-10 shrink-0 rounded-full" />
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <p className="font-sans text-[13px] font-semibold text-charcoal">{name}</p>
          <p className="font-sans text-[11px] font-normal text-[#8e8e8e]">{role}</p>
        </div>
      </div>
      <button
        type="button"
        className="w-full rounded-pill bg-primary px-6 py-3 font-sans text-xs font-bold tracking-wide-ui text-white"
      >
        {buttonLabel}
      </button>
    </div>
  );
}
