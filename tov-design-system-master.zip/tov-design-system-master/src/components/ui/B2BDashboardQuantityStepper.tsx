"use client";

import { useState } from "react";

/**
 * TOV B2B Dashboard / Quantity Stepper — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:675. Minus / value / plus
 * control for project line items: 111x40 pill, #e5e5e5 fill, 31px glyph
 * buttons (1.72px charcoal strokes) either side of a 10.33px Bold value.
 */
export interface B2BDashboardQuantityStepperProps {
  /** Controlled value. Omit to let the stepper manage its own state. */
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  onChange?: (value: number) => void;
  className?: string;
}

export function B2BDashboardQuantityStepper({
  value,
  defaultValue = 1,
  min = 1,
  max = 999,
  onChange,
  className = "",
}: B2BDashboardQuantityStepperProps) {
  const [inner, setInner] = useState(defaultValue);
  const current = value ?? inner;

  const set = (next: number) => {
    const clamped = Math.min(max, Math.max(min, next));
    if (value === undefined) setInner(clamped);
    onChange?.(clamped);
  };

  const buttonCls =
    "relative size-[31px] shrink-0 rounded-pill transition-opacity disabled:opacity-40 disabled:pointer-events-none hover:opacity-70";

  return (
    <div
      role="group"
      aria-label="Quantity"
      className={`inline-flex h-10 w-[111px] items-center justify-center gap-[9px] rounded-pill bg-[#e5e5e5] px-[10px] py-1 ${className}`}
    >
      <button
        type="button"
        aria-label="Decrease quantity"
        disabled={current <= min}
        onClick={() => set(current - 1)}
        className={buttonCls}
      >
        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" aria-hidden className="block">
          <path d="M20.6667 15.5H10.3334" stroke="#3F3D3E" strokeWidth="1.72222" strokeLinecap="round" />
        </svg>
      </button>
      <div
        aria-live="polite"
        className="min-w-px flex-1 text-center font-sans text-[10.33px] font-bold leading-[18.08px] text-charcoal"
      >
        {current}
      </div>
      <button
        type="button"
        aria-label="Increase quantity"
        disabled={current >= max}
        onClick={() => set(current + 1)}
        className={buttonCls}
      >
        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" aria-hidden className="block">
          <path d="M15.5 10.3333V20.6666" stroke="#3F3D3E" strokeWidth="1.72222" strokeLinecap="round" />
          <path d="M20.6667 15.5H10.3334" stroke="#3F3D3E" strokeWidth="1.72222" strokeLinecap="round" />
        </svg>
      </button>
    </div>
  );
}
