/**
 * TOV B2B Dashboard / Count Badge — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:659. Asset / file count
 * chip: #faf7f2 fill, 1px #e5ddd5 border, 10px x 4px padding, fully rounded,
 * 11px Montserrat Medium label in the brand color.
 */
export interface B2BDashboardCountBadgeProps {
  children: React.ReactNode;
  className?: string;
}

export function B2BDashboardCountBadge({ children, className = "" }: B2BDashboardCountBadgeProps) {
  return (
    <span
      className={`inline-flex items-start whitespace-nowrap rounded-pill border border-[#e5ddd5] bg-[#faf7f2] px-[10px] py-1 font-sans text-[11px] font-medium text-primary ${className}`}
    >
      {children}
    </span>
  );
}
