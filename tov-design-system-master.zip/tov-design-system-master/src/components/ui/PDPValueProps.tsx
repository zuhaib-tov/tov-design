import { PDPFittedImage, PDP_ICON_ART } from "./PDPFittedImage";

/**
 * The PDP "Value Props" component (fileKey ySZYmjbO2Wck8u1JGAtI5J,
 * node 813:8358, "Version=Value Props Updated, Viewport=All, Status=Live" —
 * universal). Each row is an icon + rich text with bold and/or underlined
 * ("Learn more.") segments.
 *
 * Container padding is 10px horizontal / 4px vertical; each row has 7px
 * top/bottom padding with a 6px icon-to-text gap. Every icon sits in the same
 * 25px container and fills the same share of it (measured from the artwork,
 * not the file canvas), so the four icons read as one size.
 */
export interface PDPValuePropSegment {
  text: string;
  bold?: boolean;
  underline?: boolean;
}

export interface PDPValuePropRow {
  icon: keyof typeof PDP_ICON_ART;
  segments: PDPValuePropSegment[];
}

/** Share of the 25px icon container that every icon's artwork fills. */
const ICON_FILL = 0.56;

export function PDPValueProps({ items }: { items: PDPValuePropRow[] }) {
  return (
    <div className="flex flex-col rounded-lg bg-[#f1f1f1] px-2.5 py-1 font-sans max-w-md">
      {items.map((item, i) => (
        <div
          key={i}
          className={`flex items-center gap-1.5 py-[7px] ${i > 0 ? "border-t border-neutral-300" : ""}`}
        >
          <PDPFittedImage src={`/icons/${item.icon}.svg`} box={[25, 25]} fill={ICON_FILL} {...PDP_ICON_ART[item.icon]} />
          <p className="text-xs leading-[18px] text-ink">
            {item.segments.map((s, j) => (
              <span key={j} className={`${s.bold ? "font-bold" : "font-normal"} ${s.underline ? "underline" : ""}`}>
                {s.text}
              </span>
            ))}
          </p>
        </div>
      ))}
    </div>
  );
}
