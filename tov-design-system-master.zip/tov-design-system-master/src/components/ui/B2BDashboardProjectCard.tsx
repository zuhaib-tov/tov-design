import { ChevronRight } from "lucide-react";

/**
 * TOV B2B Dashboard / Project Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 43:59 → Version=Default (43:58),
 * 345.33px wide. Saved-project grid card: photo thumbnail, name, item count
 * and a trailing chevron. White fill, cream (#f1ece5) border, 12px radius,
 * 12px padding/gap, soft drop shadow.
 */
export interface B2BDashboardProjectCardProps {
  title: string;
  itemCount: number;
  className?: string;
}

export function B2BDashboardProjectCard({ title, itemCount, className = "" }: B2BDashboardProjectCardProps) {
  return (
    <div
      className={`flex w-[345px] max-w-full flex-col items-start gap-3 rounded-[12px] border border-cream-200 bg-white p-3 shadow-[0px_4px_6px_rgba(0,0,0,0.04)] ${className}`}
    >
      <div className="bg-image-placeholder h-[220px] w-full rounded-md" />
      <div className="flex w-full flex-col gap-1">
        <p className="font-sans text-base font-bold text-charcoal">{title}</p>
        <p className="font-sans text-xs font-normal text-[#8e8e8e]">{itemCount} items saved</p>
      </div>
      <div className="flex w-full items-center justify-end">
        <ChevronRight size={16} className="text-[#8e8e8e]" />
      </div>
    </div>
  );
}
