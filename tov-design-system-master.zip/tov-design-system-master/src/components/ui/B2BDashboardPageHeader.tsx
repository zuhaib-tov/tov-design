/**
 * TOV B2B Dashboard / Page Header — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 44:172 → Version=With Action
 * (44:171), full-width (1066px). Serif page title (GT Ultra Fine, 22px) +
 * subtitle, with an optional right-aligned Brand Outline action button.
 */
export interface B2BDashboardPageHeaderProps {
  title: string;
  subtitle: string;
  actionLabel?: string;
  className?: string;
}

export function B2BDashboardPageHeader({
  title,
  subtitle,
  actionLabel,
  className = "",
}: B2BDashboardPageHeaderProps) {
  return (
    <div className={`flex w-full flex-wrap items-center justify-between gap-4 ${className}`}>
      <div className="flex flex-col gap-1">
        <p className="font-display text-[22px] leading-[25px] text-charcoal">{title}</p>
        <p className="font-sans text-[13px] font-normal text-[#8e8e8e]">{subtitle}</p>
      </div>
      {actionLabel && (
        <button
          type="button"
          className="whitespace-nowrap rounded-pill border-[1.5px] border-primary px-6 py-3 font-sans text-sm font-bold uppercase tracking-wide-ui text-primary"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
