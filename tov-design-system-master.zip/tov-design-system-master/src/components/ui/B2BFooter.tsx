/* eslint-disable @next/next/no-img-element */

/**
 * TOV B2B — Footer. A charcoal band with the TOV wordmark rendered as a
 * low-contrast watermark on the left, the Support links stacked on the right,
 * and a base row holding the social icons and the legal line.
 */
export interface B2BFooterProps {
  links?: string[];
  legal?: string;
  className?: string;
}

const SUPPORT_LINKS = [
  "Contact Us",
  "Returns, Refunds Claims",
  "Shipping and Delivery",
  "FAQs",
  "Product Care",
  "Find a Store",
  "Financing",
];

const LEGAL_TEXT =
  "© 2026 TOV Furniture. All right reserved  Privacy Policy | Terms and Conditions | Prop 65 | Do Not Sell or Share My Information";

const SOCIAL = [
  { name: "Instagram", src: "/images/b2b/homepage/icons/social-instagram.svg" },
  { name: "TikTok", src: "/images/b2b/homepage/icons/social-tiktok.svg" },
  { name: "YouTube", src: "/images/b2b/homepage/icons/social-youtube.svg" },
  { name: "Pinterest", src: "/images/b2b/homepage/icons/social-pinterest.svg" },
];

export function B2BFooter({ links = SUPPORT_LINKS, legal = LEGAL_TEXT, className = "" }: B2BFooterProps) {
  return (
    <footer className={`relative flex h-[325px] w-[1440px] flex-col justify-between bg-charcoal px-[100px] pb-[50px] pt-6 ${className}`}>
      <div className="flex items-start justify-between">
        <img src="/images/b2b/homepage/logos/tov-wordmark.svg" alt="TOV" width={439} height={131} className="mt-0.5 h-[131px] w-[439px]" />
        <div className="flex w-[750px] flex-col gap-2.5 text-white">
          <p className="text-base font-bold leading-[1.3]">Support</p>
          {links.map((label) => (
            <a key={label} href="#" className="text-sm leading-[1.3]">
              {label}
            </a>
          ))}
        </div>
      </div>
      <div className="flex items-center">
        <div className="flex w-[471px] items-end gap-4">
          {SOCIAL.map((s) => (
            <img key={s.name} src={s.src} alt={s.name} width={24} height={24} className="h-6 w-6" />
          ))}
        </div>
        <p className="flex-1 whitespace-pre-wrap text-right text-xs text-white">{legal}</p>
      </div>
    </footer>
  );
}
