import { TextLink } from "./TextLink";

/**
 * The Homepage "Collections" module (fileKey DTjIdCKhnDUVvJhEfpn10v) —
 * a full-bleed collection hero ("Collections Module 1", node 1063:2467,
 * Desktop and Mobile Live variants) followed by four product tiles (Chair
 * 1063:2506, Storage 1067:1455, Nightstand 1067:1466, Side Table 1067:1477)
 * and their Mobile product grid (1063:2537).
 *
 * Hero: a photo with a 20% black overlay and a left-aligned text stack
 * pinned to the bottom — heading (46px GT Ultra Fine, white), subheading
 * (22px Gotham Book, cream-50), and an underlined all-caps CTA link (14px
 * Gotham Bold, cream-50). The Mobile variant uses a 26px heading, a 16px
 * subheading, 20px side padding and adds a soft multiply gradient (black at
 * the bottom-left fading to white at the top-right, 20% strength) over the
 * overlay.
 *
 * Product tiles: a light-grey rounded tile (white with a 6% black overlay)
 * holding a product cut-out. The Live tiles carry no text. Desktop tiles are
 * 36px radius with the product contained (the Side Table photo fills the
 * tile); the Mobile grid is 2 x 2 with 16px radius, 5px gaps and 20px padding.
 */
const IMG = "/images/homepage/collections";

export function HomepageCollectionsHero({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`relative overflow-hidden w-full ${compact ? "aspect-[375/365]" : "aspect-[1440/567.82]"}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`${IMG}/amara-collection-hero.webp`} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/20" />
      {compact && (
        <div
          className="absolute inset-0 opacity-20 mix-blend-multiply"
          style={{ background: "linear-gradient(52.6deg, #000 7.6%, #fff 64.6%)" }}
        />
      )}
      <div className={`absolute bottom-8 flex flex-col gap-2.5 ${compact ? "left-5 right-5" : "left-[100px] right-[100px]"}`}>
        <div className="flex flex-col gap-px">
          <h3 className={`font-display text-white ${compact ? "text-[26px] leading-[30px]" : "text-[46px] leading-[50px]"}`}>
            Shop the Amara Collection
          </h3>
          <p className={`text-cream-50 ${compact ? "text-base leading-[17px]" : "text-[22px] leading-[33px]"}`}>
            The Amara dining chairs are sculptural yet supremely comfortable.
          </p>
        </div>
        <TextLink href="#" inverse className="self-start my-[8.5px]">
          Shop the collection
        </TextLink>
      </div>
    </div>
  );
}

const TILES = [
  { label: "Chair", src: `${IMG}/chair.webp`, fit: "object-contain" },
  { label: "Storage", src: `${IMG}/storage.webp`, fit: "object-contain" },
  { label: "Nightstand", src: `${IMG}/nightstand.webp`, fit: "object-contain" },
  { label: "Side Table", src: `${IMG}/side-table.webp`, fit: "object-cover" },
];

export function HomepageCollectionsSubCards({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={
        compact
          ? "grid grid-cols-2 gap-[5px] p-5 w-[375px] max-w-full bg-white"
          : "grid grid-cols-4 gap-grid-gutter-sm w-full"
      }
    >
      {TILES.map(({ label, src, fit }) => (
        <div
          key={label}
          className={`relative overflow-hidden bg-white ${
            compact ? "rounded-2xl aspect-[165/190]" : "rounded-[36px] aspect-[301.75/338]"
          }`}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={src} alt={label} className={`absolute inset-0 w-full h-full ${fit}`} />
          <div className="absolute inset-0 bg-black/[0.06]" />
        </div>
      ))}
    </div>
  );
}
