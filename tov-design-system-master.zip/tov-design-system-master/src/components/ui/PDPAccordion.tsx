"use client";

import { ReactNode, useState } from "react";

/**
 * The PDP "Product Info Accordion" component (fileKey ySZYmjbO2Wck8u1JGAtI5J,
 * node 13:366) — a 3-row accordion (Details, Dimensions, Care), single item
 * open at a time. All 6 Figma variants are Draft and Desktop-only (no Mobile
 * variant exists yet); each represents genuinely different, product-specific
 * content (a chair's Dimensions table looks nothing like a dresser's or a
 * bed's Details tab). See the doc page for all 6 as real content examples.
 *
 * Dimensions always shows exactly 2 measurement diagrams;
 * `PDPDimensionDiagrams` does not take a `count` prop.
 *
 * Each row is its own independently rounded and bordered card (cornerRadius
 * 8, 8px gap between them), not one continuous box with dividers. The toggle
 * icon is a plus sign that rotates -45° when open (becoming an "×"), not a
 * chevron — it reuses `quantity-plus.svg`, which already matches the
 * charcoal stroke color used throughout. Title text is 18px Bold
 * (`text-lg font-bold`).
 *
 * Every text color in this component — title, open-state border, dimension
 * group titles, dimension row label and value — is `text-charcoal`
 * (#3f3d3e), not `text-ink` (#121212); the two tokens are visually close
 * but distinct. The open row's border is charcoal (#3f3d3e); closed rows
 * use a light grey border. Dimension row label and value share the same
 * weight and color (14px Regular, charcoal) rather than a muted-label /
 * bold-value split. Dimension group titles are 16px Medium
 * (`text-base font-medium`). The dimension groups list sits 20px further
 * left-inset than the diagrams box above it.
 */
export interface PDPAccordionItem {
  label: string;
  content: ReactNode;
}

export function PDPAccordion({
  items,
  defaultOpenIndex = null,
}: {
  items: PDPAccordionItem[];
  defaultOpenIndex?: number | null;
}) {
  const [openIndex, setOpenIndex] = useState<number | null>(defaultOpenIndex);

  return (
    <div className="w-[446px] max-w-full flex flex-col gap-2 font-sans">
      {items.map((item, i) => {
        const isOpen = openIndex === i;
        return (
          <div
            key={item.label}
            className={`flex flex-col gap-4 rounded-lg border bg-white p-4 ${isOpen ? "border-charcoal" : "border-[#e8e8e8]"}`}
          >
            <button
              type="button"
              onClick={() => setOpenIndex(isOpen ? null : i)}
              className="flex w-full items-center justify-between gap-2 text-left"
            >
              <span className="text-lg font-bold leading-[21px] text-charcoal">{item.label}</span>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/icons/quantity-plus.svg"
                alt=""
                className={`h-[14.4px] w-[14.4px] shrink-0 transition-transform ${isOpen ? "-rotate-45" : ""}`}
              />
            </button>
            {isOpen && item.content}
          </div>
        );
      })}
    </div>
  );
}

export function PDPDimensionRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2.5 text-sm leading-4 text-charcoal">
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}

/** Wraps the dimension groups (+ the "How to measure" link) with the real
 * 20px left indent that frame ("Frame 1267") has relative to the diagrams
 * box above it, which stays flush. Real itemSpacing between groups is 16px. */
export function PDPDimensionGroupList({ children }: { children: ReactNode }) {
  return <div className="flex flex-col gap-4 px-5">{children}</div>;
}

export function PDPMeasureLink() {
  return (
    <a href="#" className="text-xs leading-4 text-charcoal underline">
      How to measure for delivery
    </a>
  );
}

export function PDPDimensionGroup({ title, rows }: { title: string; rows: { label: string; value: string }[] }) {
  return (
    <div className="flex flex-col gap-2">
      <p className="text-base font-medium leading-[15px] text-charcoal">{title}</p>
      <div className="flex flex-col gap-[5px]">
        {rows.map((r) => (
          <PDPDimensionRow key={r.label} label={r.label} value={r.value} />
        ))}
      </div>
    </div>
  );
}

export function PDPDimensionDiagrams() {
  return (
    <div className="flex gap-0 rounded-lg border-[0.5px] border-[#e8e8e8] bg-white overflow-hidden">
      {Array.from({ length: 2 }).map((_, i) => (
        <div
          key={i}
          className="flex-1 aspect-square flex items-center justify-center text-xs leading-[18px] text-ink-muted"
        >
          Diagram
        </div>
      ))}
    </div>
  );
}
