import { Button } from "./Button";
import { B2BButton } from "./B2BButton";

/**
 * TOV B2B — Hero. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 12:52 ("Hero" symbol frame), Professional
 * Program/Desktop (12:42, 1440x646) and Professional Program/Mobile (12:51,
 * 390x580) variants.
 *
 * Image-led Professional Program introduction with a headline and membership
 * CTA. Use near the top of the page; retain text contrast and choose the
 * correct viewport composition.
 *
 * The default composition anchors the copy to the bottom-left with a solid CTA.
 * The `centered` variant (homepage) vertically centers the copy over the photo
 * with a left-to-right scrim and an outlined CTA.
 */
export interface B2BHeroProps {
  eyebrow: string;
  headline: string;
  /** Desktop only — the real Mobile composition drops the body copy entirely. */
  body?: string;
  ctaLabel: string;
  compact?: boolean;
  /** Photograph rendered behind the copy. Falls back to the image placeholder. */
  image?: string;
  /** `centered` is the desktop homepage composition. Ignored on the compact (mobile) hero. */
  variant?: "default" | "centered";
  className?: string;
}

export function B2BHero({
  eyebrow,
  headline,
  body,
  ctaLabel,
  compact = false,
  image,
  variant = "default",
  className = "",
}: B2BHeroProps) {
  const centered = variant === "centered" && !compact;

  return (
    <div
      className={`relative overflow-hidden ${image ? "bg-charcoal" : "bg-image-placeholder"} ${
        compact ? "w-[390px] aspect-[390/580]" : "w-[1440px] aspect-[1440/646]"
      } ${className}`}
    >
      {image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
      )}
      <div className="absolute inset-0 bg-black/20" />
      {centered && (
        <div
          className="absolute inset-0 mix-blend-multiply"
          style={{ backgroundImage: "linear-gradient(106deg, rgba(83,53,53,0.69) 7.65%, rgba(255,255,255,0) 85.24%)" }}
        />
      )}
      <div
        className={`absolute flex flex-col ${
          compact
            ? "left-5 right-5 bottom-10 gap-5 text-center items-center"
            : centered
              ? "left-[75px] right-[75px] top-[10px] bottom-9 justify-center gap-[35px]"
              : "left-[75px] right-[75px] bottom-9 gap-9 max-w-[1104px]"
        }`}
      >
        <div className={`flex flex-col ${compact ? "gap-1" : "gap-2.5"}`}>
          <p
            className={`font-bold uppercase text-white tracking-wide-ui ${centered ? "leading-6" : ""} ${compact ? "text-xs" : "text-lg"}`}
          >
            {eyebrow}
          </p>
          <h2
            className={`font-display text-white ${
              compact ? "text-[38px] leading-tight" : centered ? "max-w-[739px] text-[68px] leading-[70px]" : "text-[68px] leading-tight"
            }`}
          >
            {headline}
          </h2>
          {!compact && body && (
            <p className={`text-lg font-semibold text-white max-w-[687px] ${centered ? "leading-6" : "mt-1.5"}`}>{body}</p>
          )}
        </div>
        {centered ? (
          <B2BButton variant="outline-inverse" className="w-fit bg-[rgba(219,206,198,0.04)] backdrop-blur-[3px]">
            {ctaLabel}
          </B2BButton>
        ) : (
          <Button variant="primary" className="w-fit">
            {ctaLabel}
          </Button>
        )}
      </div>
    </div>
  );
}
