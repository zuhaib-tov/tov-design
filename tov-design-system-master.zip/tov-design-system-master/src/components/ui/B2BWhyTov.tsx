import { B2BStatCard } from "./B2BStatCard";

/**
 * TOV B2B — Why TOV. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 12:81 ("Why TOV" symbol frame), Default/Desktop
 * (12:68, 1440x317) and Default/Mobile (12:80, 390x381) variants.
 *
 * Brand-value section pairing the Why TOV message with supporting statistics.
 * Keep evidence-bearing metric copy consistent with the source Stat Cards.
 */
export interface B2BWhyTovProps {
  compact?: boolean;
  /** Sets the unit of each figure ("+ years", "+ clients") in the brand color. */
  accentUnits?: boolean;
  className?: string;
}

export function B2BWhyTov({ compact = false, accentUnits = false, className = "" }: B2BWhyTovProps) {
  return (
    <div
      className={`bg-white flex ${
        compact
          ? "w-[390px] flex-col gap-6 px-5 py-5"
          : "w-[1440px] flex-row items-center gap-[17px] px-[75px] py-20"
      } ${className}`}
    >
      <div className={`flex flex-col gap-4 ${compact ? "items-center text-center" : "w-[436px] shrink-0"}`}>
        <p className="text-base font-semibold text-charcoal tracking-wide-ui uppercase">Why TOV</p>
        <h2 className={`font-display text-charcoal leading-tight ${compact ? "text-[26px] text-center" : "text-[46px]"}`}>
          Elevated Design. Never Overpriced.
        </h2>
      </div>
      <div className={`flex ${compact ? "flex-col gap-4 w-full" : "flex-row gap-[17px]"}`}>
        <B2BStatCard
          value={accentUnits ? "10" : "10+ years"}
          accent={accentUnits ? "+ years" : undefined}
          description="A decade of experience making the whole process seamless for our trade partners."
          compact={compact}
        />
        <B2BStatCard
          value={accentUnits ? "10k" : "10k+ clients"}
          accent={accentUnits ? "+ clients" : undefined}
          description="From boutique hotels to model homes, we've helped a wide variety of clients."
          compact={compact}
        />
      </div>
    </div>
  );
}
