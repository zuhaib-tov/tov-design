import { FileStack } from "lucide-react";
import { ReactNode } from "react";
import { B2BDashboardCountBadge } from "./B2BDashboardCountBadge";

/**
 * TOV B2B Dashboard / Download Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 43:49 → Version=Default (43:48),
 * 278px tall. Downloads bucket: icon, file Count Badge, title, description
 * and a full Brand "Download All" button. White fill, #efebe4 border, 24px
 * radius, 32px padding, 24px gaps, soft drop shadow — taller and narrower
 * than Asset Card, and ends in a real call-to-action rather than a text link.
 */
export interface B2BDashboardDownloadCardProps {
  icon?: ReactNode;
  count: string;
  title: string;
  description: string;
  buttonLabel?: string;
  className?: string;
}

export function B2BDashboardDownloadCard({
  icon,
  count,
  title,
  description,
  buttonLabel = "Download All",
  className = "",
}: B2BDashboardDownloadCardProps) {
  return (
    <div
      className={`flex h-[278px] w-[301px] max-w-full flex-col items-start gap-6 rounded-app-lg border border-[#efebe4] bg-white p-8 shadow-[0px_12px_12px_rgba(74,67,63,0.07)] ${className}`}
    >
      <div className="flex w-full items-center justify-between">
        <span className="inline-flex size-10 items-center justify-center rounded-xl bg-[#fdf1f2] text-primary">
          {icon ?? <FileStack size={20} strokeWidth={1.75} />}
        </span>
        <B2BDashboardCountBadge>{count}</B2BDashboardCountBadge>
      </div>
      <div className="flex w-full flex-col gap-2">
        <p className="font-sans text-xl font-bold text-charcoal">{title}</p>
        <p className="font-sans text-sm font-medium leading-5 text-[#8e8e8e]">{description}</p>
      </div>
      <div className="flex w-full items-start justify-end">
        <button
          type="button"
          className="rounded-pill bg-primary px-6 py-3 font-sans text-xs font-bold uppercase tracking-wide-ui text-white"
        >
          {buttonLabel}
        </button>
      </div>
    </div>
  );
}
