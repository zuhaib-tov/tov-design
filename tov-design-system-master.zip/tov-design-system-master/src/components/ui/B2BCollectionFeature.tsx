import { B2BFeatureCard } from "./B2BFeatureCard";
import { B2BProductCard } from "./B2BProductCard";

/**
 * TOV B2B — Collection Feature. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 18:324 ("Collection Feature" symbol frame),
 * Contract Grade/Desktop (18:257, 1440x672 — image feature card + 2x2 product
 * grid) and Contract Grade/Mobile (18:323, 390x655 — image feature card above
 * a scrolling row of product tiles) variants.
 *
 * Contract Grade merchandising feature that combines collection messaging
 * with product imagery. Use for a focused collection story; replace
 * placeholder product details where present.
 *
 * The product tiles' "Product name" / "$0000.00" copy is the real file's own
 * placeholder content (not a guess) — the desktop grid shows image-only tiles
 * with no text at all, matching the source exactly.
 */
function ProductTile({ label, showDetails = false }: { label?: string; showDetails?: boolean }) {
  return (
    <div className="flex flex-col gap-3 flex-1 min-w-[140px]">
      <div className="bg-image-placeholder rounded-lg aspect-[295/311] relative overflow-hidden">
        {label && (
          <span className="absolute top-2 left-2 bg-white text-charcoal text-[10px] font-bold uppercase tracking-wide-ui px-2 py-1 rounded">
            {label}
          </span>
        )}
      </div>
      {showDetails && (
        <div className="flex flex-col gap-0.5">
          <p className="text-sm text-charcoal">Product name</p>
          <p className="text-sm text-[#8e8e8e]">$0000.00</p>
        </div>
      )}
    </div>
  );
}

export interface B2BCollectionFeatureProduct {
  tag: string;
  image?: string;
}

export interface B2BCollectionFeatureProps {
  compact?: boolean;
  /** `even` splits the desktop row into two equal 640px halves with photographic product tiles. */
  layout?: "wide" | "even";
  /** Photograph behind the feature card. */
  image?: string;
  /** The four product tiles of the `even` layout. */
  products?: B2BCollectionFeatureProduct[];
  className?: string;
}

export function B2BCollectionFeature({
  compact = false,
  layout = "wide",
  image,
  products = [],
  className = "",
}: B2BCollectionFeatureProps) {
  if (layout === "even" && !compact) {
    return (
      <div className={`bg-white w-[1440px] flex gap-2.5 px-[75px] pb-10 ${className}`}>
        <div className="flex-1">
          <B2BFeatureCard
            size="large"
            eyebrow="The best performance"
            title="Contract Grade"
            linkLabel="All Contract Grade"
            image={image}
          />
        </div>
        <div className="grid flex-1 grid-cols-2 content-start gap-2.5">
          {products.map((p, i) => (
            <B2BProductCard key={i} variant="image-only" tag={p.tag} name="" image={p.image} showWishlist={false} />
          ))}
        </div>
      </div>
    );
  }

  const feature = (
    <div
      className={`bg-image-placeholder relative overflow-hidden rounded-2xl shrink-0 ${
        compact ? "w-[350px] aspect-[350/296]" : "w-[680px] aspect-[680/632]"
      }`}
    >
      <div className="absolute inset-0 bg-black/20" />
      <div className="absolute left-5 right-5 bottom-5 flex flex-col gap-2.5">
        <p className="text-sm font-semibold text-white">The best performance</p>
        <h3 className="font-display text-[46px] text-white leading-none">Contract Grade</h3>
        <a href="#" className="text-sm font-bold text-white underline w-fit">
          All Contract Grade
        </a>
      </div>
    </div>
  );

  if (compact) {
    return (
      <div className={`bg-white w-[390px] flex flex-col gap-5 p-5 ${className}`}>
        {feature}
        <div className="flex gap-2.5 overflow-x-auto pb-2">
          <ProductTile label="Sustainable" showDetails />
          <ProductTile label="Best Seller" showDetails />
          <ProductTile showDetails />
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white w-[1440px] flex gap-2.5 px-[75px] py-0 pb-10 ${className}`}>
      {feature}
      <div className="w-[600px] grid grid-cols-2 gap-2.5">
        <ProductTile />
        <ProductTile />
        <ProductTile />
        <ProductTile />
      </div>
    </div>
  );
}
