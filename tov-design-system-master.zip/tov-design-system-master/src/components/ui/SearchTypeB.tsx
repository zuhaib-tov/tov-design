/**
 * Search — Type B ("Material / attribute") — fileKey
 * DTjIdCKhnDUVvJhEfpn10v, node 1696:1829. 4 real variants: Desktop -
 * Default (1696:1376), Desktop - Bottom Scroll (1696:1467), Desktop -
 * Category Selected (1696:1563), Mobile (1696:1654). The only Search type
 * with a real category filter panel actually visible (Types A/C/D/E have
 * the identical panel in their layer tree too, but at `opacity: 0`).
 *
 * Across the 3 Desktop variants:
 * - Default: category panel, no selection, row 1 of results (Callie/Yara/
 *   Mel), no "See all" button, "Showing results for 'Velvet'" (no colon).
 * - Bottom Scroll: same header/panel, but a different, later row of
 *   results (Lou/Kylie/Graham) plus a real "See all products (310)"
 *   button beneath it — and "Showing results for: 'Velvet'" WITH a
 *   trailing colon that Default lacks. A genuine minor Figma
 *   inconsistency, reproduced as found rather than normalized.
 * - Category Selected: "Sofas" chip turns `text-primary` (#B15A63, exact
 *   token match) with no background/border change; query becomes "Velvet
 *   Sofas"; results narrow to sofas only (Callie/Yara/Lou).
 *
 * Mobile card 2 is titled 'Callie 84" Velvet Sofa' (same as card 1) but
 * its swatch colors match Yara's, not Callie's own (which are used
 * correctly on cards 1 and 3) — a real content bug in the Figma source,
 * kept verbatim. Mobile card 3 goes further still: it's titled 'Callie
 * 84" Velvet Sofa' with Callie's own swatch colors, but its actual photo
 * is the Mel Faux Mohair Velvet Bed. Mobile's category chip row literally
 * reads "Wall art" (no "& Decor"), a genuinely different string from
 * Desktop's label, not a narrow-viewport truncation.
 */
import {
  SearchTopBar,
  MobileSearchTopBar,
  ResultsHeaderMobile,
  DesktopProductCard,
  MobileProductCard,
  PromoBanner,
  SeeAllProductsButton,
  CategoryPanelDesktop,
  CategoryChipsMobile,
  type SearchProduct,
} from "./SearchShared";

const ROW_1: SearchProduct[] = [
  { image: "/images/search/sofa-callie-velvet.jpg", title: 'Callie 84" Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-yara-pleated-velvet.jpg", title: 'Yara 90.6" Pleated Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/bed-mel-faux-mohair-velvet.jpg", title: "Mel Faux Mohair Velvet Bed", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#59483B", "#045047"] },
];

const ROW_2: SearchProduct[] = [
  { image: "/images/search/sofa-lou-performance-velvet.jpg", title: 'Lou 91" Performance Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#B29D7D", "#D4D1C2"] },
  { image: "/images/search/chair-kylie-velvet-dining.jpg", title: "Kylie Velvet Dining Chair", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/lamp-graham-velvet-floor.jpg", title: "Graham Velvet Floor Lamp", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#BB7B50", "#4C6935", "#835C35", "#582628"] },
];

const CATEGORY_SELECTED_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/sofa-callie-velvet.jpg", title: 'Callie 84" Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-yara-pleated-velvet.jpg", title: 'Yara 90.6" Pleated Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/sofa-lou-performance-velvet.jpg", title: 'Lou 91" Performance Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#B29D7D", "#D4D1C2"] },
];

const MOBILE_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/sofa-callie-velvet-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-typeB-card2-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/bed-mel-faux-mohair-velvet-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-lou-performance-velvet-sq.jpg", title: 'Lou 91" Performance Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#B49F7F", "#CCC1B0"] },
  { image: "/images/search/chair-kylie-velvet-dining-sq.jpg", title: "Kylie Velvet Dining Chair", price: "$479", materialTag: "Performance Fabric", swatches: ["#ABABAB", "#937F7F"] },
  { image: "/images/search/lamp-graham-velvet-floor-sq.jpg", title: "Graham Velvet Floor Lamp", price: "$479", materialTag: "Performance Fabric", swatches: ["#B87247", "#3A5D2D", "#6E4E38", "#572323"] },
];

export function SearchTypeBDesktopDefault() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Velvet" />
      <p className="text-xs text-ink px-10 pt-6 pb-4"><span className="text-ink-muted">Showing results for</span> &lsquo;Velvet&rsquo;</p>
      <div className="flex gap-8 px-10 pb-10 overflow-x-auto">
        <CategoryPanelDesktop />
        <div className="grid grid-cols-3 gap-grid-gutter-lg min-w-[970px]">
          {ROW_1.map((p) => <DesktopProductCard key={p.title} product={p} />)}
        </div>
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeBDesktopBottomScroll() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Velvet" />
      <p className="text-xs text-ink px-10 pt-6 pb-4"><span className="text-ink-muted">Showing results for:</span> &lsquo;Velvet&rsquo;</p>
      <div className="flex gap-8 px-10 pb-6 overflow-x-auto">
        <CategoryPanelDesktop />
        <div className="flex flex-col gap-6 min-w-[970px]">
          <div className="grid grid-cols-3 gap-grid-gutter-lg">
            {ROW_2.map((p) => <DesktopProductCard key={p.title} product={p} />)}
          </div>
          <SeeAllProductsButton />
        </div>
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeBDesktopCategorySelected() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Velvet Sofas" />
      <p className="text-xs text-ink px-10 pt-6 pb-4"><span className="text-ink-muted">Showing results for</span> &lsquo;Velvet Sofas&rsquo;</p>
      <div className="flex gap-8 px-10 pb-10 overflow-x-auto">
        <CategoryPanelDesktop selected="Sofas" />
        <div className="grid grid-cols-3 gap-grid-gutter-lg min-w-[970px]">
          {CATEGORY_SELECTED_PRODUCTS.map((p) => <DesktopProductCard key={p.title} product={p} />)}
        </div>
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeBMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <ResultsHeaderMobile query="Velvet" />
      <div className="mb-4"><CategoryChipsMobile /></div>
      <div className="grid grid-cols-2 gap-grid-gutter-md px-5 pb-6">
        {MOBILE_PRODUCTS.map((p, i) => <MobileProductCard key={`${p.title}-${i}`} product={p} />)}
      </div>
      <div className="px-5 pb-6">
        <SeeAllProductsButton />
      </div>
    </div>
  );
}
