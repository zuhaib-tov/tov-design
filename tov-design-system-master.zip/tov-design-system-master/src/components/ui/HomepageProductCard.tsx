/**
 * Shared card shape used by both "New Arrivals Product Row" (fileKey
 * DTjIdCKhnDUVvJhEfpn10v, node 1063:2050) and the Collections sub-cards
 * (Chair/Storage/Nightstand/Side Table, nodes 1063:2506/1067:1455/1067:1466/
 * 1067:1477) — same shape as HomepageCategoryCard (301.75x338, rounded-36)
 * but with a much lighter 6% overlay and the label centered at the bottom
 * instead of left-aligned. New Arrivals uses 14px charcoal text; Collections
 * sub-cards use 20px white text.
 *
 * The Collections sub-cards' on-canvas text is stale/copy-paste ("Chair"'s
 * live text literally reads "Living room") — each component set's own
 * real name is used as the label instead of that stale on-canvas text.
 *
 * Both sizes are `textCase: UPPER` with the shared all-caps tracking. New
 * Arrivals' 14px label is additionally `textDecoration: UNDERLINE`;
 * Collections' 20px label isn't.
 */
export interface HomepageProductCardProps {
  label: string;
  size?: "sm" | "lg";
}

export function HomepageProductCard({ label, size = "lg" }: HomepageProductCardProps) {
  const isLarge = size === "lg";
  return (
    <div className="bg-image-placeholder relative rounded-[36px] overflow-hidden w-full aspect-[301.75/338]">
      <div className="absolute inset-0 bg-black/[0.06]" />
      <p
        className={`absolute bottom-5 left-0 right-0 text-center font-bold uppercase tracking-wide-ui ${
          isLarge ? "text-xl leading-6 text-white" : "text-sm leading-[17px] text-charcoal underline"
        }`}
      >
        {label}
      </p>
    </div>
  );
}
