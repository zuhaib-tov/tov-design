/**
 * Draws an icon or logo inside a fixed container so that every glyph in a row
 * fills the same share of its container, whatever padding is built into the
 * source file. The artwork's own bounds (including stroke) are used for the
 * fit, not the file's canvas, so icons from different sources look the same
 * size side by side.
 */
export interface PDPArtBounds {
  /** Source canvas (viewBox or pixel size). */
  canvas: readonly [w: number, h: number];
  /** Visible artwork inside the canvas, including stroke: [x, y, w, h]. */
  art: readonly [x: number, y: number, w: number, h: number];
}

export interface PDPFittedImageProps extends PDPArtBounds {
  src: string;
  alt?: string;
  /** Container size in px. */
  box: readonly [w: number, h: number];
  /** Share of the container the artwork may fill, 0–1. The limiting side reaches this share. */
  fill: number;
  className?: string;
}

export function PDPFittedImage({ src, alt = "", canvas, art, box, fill, className = "" }: PDPFittedImageProps) {
  const [boxW, boxH] = box;
  const [cw, ch] = canvas;
  const [ax, ay, aw, ah] = art;
  const scale = Math.min((boxW * fill) / aw, (boxH * fill) / ah);
  const left = boxW / 2 - (ax + aw / 2) * scale;
  const top = boxH / 2 - (ay + ah / 2) * scale;
  return (
    <span className={`relative block shrink-0 ${className}`} style={{ width: boxW, height: boxH }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        draggable={false}
        className="absolute max-w-none"
        style={{ width: cw * scale, height: ch * scale, left, top }}
      />
    </span>
  );
}

/** Artwork bounds for the PDP icons, measured from the extracted SVG files. */
export const PDP_ICON_ART = {
  "delivery-box": { canvas: [21.5, 20.2837], art: [0, 0, 21.5, 20.2837] },
  verified: { canvas: [24, 24], art: [2.55, 2.48, 18.9, 18.76] },
  "box-remove": { canvas: [18, 19], art: [1.65, 1.65, 16.45, 17.45] },
  "truck-schedule": { canvas: [20.5, 19.5], art: [0, 0, 20.5, 19.5] },
  trophy: { canvas: [17.5001, 19.5], art: [0, 0, 17.5001, 19.5] },
} as const satisfies Record<string, PDPArtBounds>;

/** Artwork bounds for the payment logos, measured from the files in public/brand/payment. */
export const PDP_LOGO_ART = {
  klarna: { canvas: [2560, 571], art: [1, 0, 2558, 571] },
  afterpay: { canvas: [1039, 200], art: [6, 1, 1030, 199] },
  affirm: { canvas: [1005, 404], art: [2, 2, 1000, 399] },
  "shop-pay": { canvas: [47.84, 11.35], art: [1.44, 0.23, 44.93, 10.9] },
} as const satisfies Record<string, PDPArtBounds>;
