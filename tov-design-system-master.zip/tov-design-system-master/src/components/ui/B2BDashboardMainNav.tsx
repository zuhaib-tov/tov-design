import { Logo } from "./Logo";

/**
 * TOV B2B Dashboard / Main Nav — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 45:121, Dashboard page,
 * Organisms section. The signed-in utility header shown across every
 * Dashboard page — distinct from the marketing Header documented under
 * Components (src/components/ui/B2BHeader.tsx).
 *
 * Desktop (45:57, 1440x153) stacks a Utility Bar (logo + "Professional"
 * wordmark, four utility links, a "View Dashboard" pill, then
 * search/wishlist/cart icons) over a Category Nav row carrying the same
 * 9 category links as the marketing Header plus a 10th "Closeout" link.
 * Mobile (45:103, 390x69) collapses to a hamburger, centered logo lockup,
 * a search icon, and a circular account-pill icon — no utility links or
 * category row at that viewport.
 */
const UTILITY_LINKS = ["Order status", "Downloads", "Quick Order", "Support"];

const CATEGORY_LINKS = [
  "New",
  "Furniture",
  "Rugs",
  "Lighting",
  "Decor & Tabletop",
  "Pillows & Throws",
  "Outdoor",
  "Wall Art & Mirrors",
  "Closeout",
];

export function B2BDashboardMainNavDesktop() {
  return (
    <div className="w-[1440px] bg-white font-sans">
      <div className="flex items-center justify-center gap-[41px] border-b-[0.5px] border-[#e8e8e8] px-[75px] py-5">
        <div className="flex flex-1 items-center gap-[5px]">
          <Logo className="h-[27px] w-[90px] text-black" />
          <span className="text-[15.27px] font-medium uppercase tracking-wide-ui text-charcoal">Professional</span>
        </div>
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-5 text-sm font-bold text-charcoal">
            {UTILITY_LINKS.map((label) => (
              <a key={label} href="#">{label}</a>
            ))}
          </div>
          <div className="flex items-center gap-[10px] rounded-pill bg-cream-200 px-4 py-[11px] shadow-[0px_0px_4px_0px_rgba(0,0,0,0.25)]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/profile.svg" alt="" className="size-[15px]" />
            <span className="text-sm font-bold text-charcoal">View Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/search.svg" alt="Search" className="h-[18px] w-[18px]" />
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/heart.svg" alt="Wishlist" className="h-[18px] w-[18px]" />
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/bag-alt-light.svg" alt="Cart" className="h-[18px] w-[18px]" />
          </div>
        </div>
      </div>
      <div className="flex items-center justify-center gap-[34px] border-b-[0.5px] border-[#e8e8e8] py-3 pr-[50px] drop-shadow-[0px_8px_7.35px_rgba(77,5,5,0.06)]">
        {CATEGORY_LINKS.map((label) => (
          <a key={label} href="#" className="whitespace-nowrap text-base font-medium text-charcoal">
            {label}
          </a>
        ))}
      </div>
    </div>
  );
}

export function B2BDashboardMainNavMobile() {
  return (
    <div className="flex w-[390px] items-center justify-between border-b border-[#e8e8e8] bg-white p-4 font-sans">
      <button aria-label="Open menu" className="flex flex-col gap-[7px]">
        <span className="block h-px w-6 bg-charcoal" />
        <span className="block h-px w-6 bg-charcoal" />
        <span className="block h-px w-6 bg-charcoal" />
      </button>
      <div className="flex flex-col items-center gap-[3.7px]">
        <Logo className="h-[19px] w-[65px] text-charcoal" />
        <span className="text-[8.6px] font-semibold uppercase tracking-wide-ui text-charcoal">Professional</span>
      </div>
      <div className="flex items-center gap-[6px]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/search.svg" alt="Search" className="size-5" />
        <div className="flex items-center rounded-pill bg-cream-200 px-4 py-[10px]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/profile.svg" alt="Account" className="size-[15px]" />
        </div>
      </div>
    </div>
  );
}
