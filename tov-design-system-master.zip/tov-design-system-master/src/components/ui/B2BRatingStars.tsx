/**
 * TOV B2B rating display — Figma Core/Rating Stars component set (node
 * 8:23), "5 Stars"/All. A fixed 5-star appearance (outline only, no fill),
 * not a variable 1–5 rating control — the file supplies exactly one variant.
 * Stroke color #CCB583 is this component's own gold tone; it doesn't match
 * any existing app token, so it's kept as its real sourced value.
 */
export function B2BRatingStars({ className = "" }: { className?: string }) {
  return (
    <div
      className={`inline-flex items-center gap-1 ${className}`}
      role="img"
      aria-label="5 out of 5 stars"
    >
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
          <path
            d="M7 1.4l1.7 3.5 3.8.4-2.8 2.6.7 3.8L7 9.8 3.6 11.7l.7-3.8-2.8-2.6 3.8-.4L7 1.4Z"
            stroke="#ccb583"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
        </svg>
      ))}
    </div>
  );
}
