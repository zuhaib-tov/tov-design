import { B2BButton } from "./B2BButton";

/**
 * TOV B2B promo banner — Figma Promo Banner component set (node 22:490),
 * "Closeout"/Desktop (22:482) and "Closeout"/Mobile (22:489). Desktop sits a
 * rounded-16 mauve card inside a 75px page margin with the real Outline
 * Inverse button as its CTA; Mobile runs the mauve fill full-bleed with a
 * plain text link ("Shop sale") instead of a button — that's the real
 * supplied structure, not a simplification made here.
 */
export function B2BPromoBanner({
  viewport = "desktop",
}: {
  viewport?: "desktop" | "mobile";
}) {
  if (viewport === "mobile") {
    return (
      <div className="flex w-[390px] flex-col gap-[26px] bg-primary px-5 py-5">
        <div className="flex flex-col gap-2.5">
          <p className="font-display text-[22px] leading-[25px] text-white">
            Closeout Items, Up to 60% Off
          </p>
          <p className="text-base text-white">Savings on select inventory</p>
        </div>
        <a href="#" className="text-sm font-semibold text-white">
          Shop sale
        </a>
      </div>
    );
  }

  return (
    <div className="w-[1440px] bg-white px-[75px]">
      <div className="flex items-center justify-between gap-[26px] rounded-app-lg bg-primary px-[75px] py-5">
        <div className="flex flex-col gap-1">
          <p className="font-display text-[26px] leading-[30px] text-white">
            Closeout Items, Up to 60% Off
          </p>
          <p className="text-lg font-light leading-6 text-white">
            Take advantage of savings on select inventory
          </p>
        </div>
        <B2BButton variant="outline-inverse">View sale items</B2BButton>
      </div>
    </div>
  );
}
