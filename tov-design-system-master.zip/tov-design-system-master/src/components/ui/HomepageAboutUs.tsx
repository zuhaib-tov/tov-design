import { TextLink } from "./TextLink";

/**
 * The Homepage "About Us" component (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1063:2626) — a 2-variant Live set (Desktop, Mobile). Full-bleed media hero
 * ("features video content or fullwidth image"): the Figma source's fill is a
 * video, rendered here as its poster frame, under a 20% black overlay. The
 * Desktop poster is cropped from the top of the frame; the Mobile poster is
 * centered.
 *
 * Heading copy: "Always in vouge, Never overpriced." (46px GT Ultra Fine,
 * white — "vouge" is a typo in the Figma source itself, reproduced as-is) +
 * "The Amara dining chairs are sculptural yet supremely comfortable." (22px
 * Gotham Book, cream-50) + "about us" (14px Gotham Bold underlined CTA link,
 * cream-50, all caps). Mobile drops the subheading entirely — just a smaller
 * heading (26px, not a scaled-down 46px) + the same CTA.
 */
export function HomepageAboutUs({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`relative overflow-hidden w-full ${compact ? "aspect-[375/352]" : "aspect-[1440/567.82]"}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/images/homepage/about-us/about-us-video-poster.webp"
        alt=""
        className={`absolute inset-0 w-full h-full object-cover ${compact ? "object-center" : "object-top"}`}
      />
      <div className="absolute inset-0 bg-black/20" />
      <div className={`absolute bottom-8 flex flex-col gap-px ${compact ? "left-5 right-5" : "left-[100px] right-[100px]"}`}>
        <h3 className={`font-display text-white ${compact ? "text-[26px] leading-[30px]" : "text-[46px] leading-[50px]"}`}>
          Always in vouge, Never overpriced.
        </h3>
        {!compact && (
          <p className="text-[22px] leading-[33px] text-cream-50">
            The Amara dining chairs are sculptural yet supremely comfortable.
          </p>
        )}
        <TextLink href="#" inverse className="self-start my-[8.5px]">About us</TextLink>
      </div>
    </div>
  );
}
