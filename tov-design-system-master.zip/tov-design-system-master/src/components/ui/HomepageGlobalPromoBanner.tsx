/**
 * The Homepage "Global Promo Banner" component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1060:1915) — a Live set of two variants, Desktop and Mobile. A cream
 * (#F1ECE5) pill, 56px tall with a 10px radius and 20px/10px padding, holding
 * one centered line of 14/16 charcoal copy. The offer in bold, the connecting
 * words in regular weight. Outer inset is 20px above and the page margin at
 * the sides (100px Desktop, 20px Mobile). No letter-spacing: this is not a
 * button or an all-caps label.
 */
export interface HomepagePromoBannerSegment {
  text: string;
  bold?: boolean;
}

export interface HomepagePromoBannerProps {
  /** The line of copy, in order. Bold segments carry the offer. */
  segments?: HomepagePromoBannerSegment[];
  compact?: boolean;
}

const DEFAULT_SEGMENTS: HomepagePromoBannerSegment[] = [
  { text: "FREE SHIPPING", bold: true },
  { text: " on orders over " },
  { text: "$299*", bold: true },
];

export function HomepageGlobalPromoBanner({ segments = DEFAULT_SEGMENTS, compact = false }: HomepagePromoBannerProps) {
  return (
    <div className={compact ? "px-page-margin-mobile pt-5" : "px-page-margin-desktop pt-5"}>
      <div className="flex h-14 items-center justify-center rounded-[10px] bg-cream-200 px-2.5 py-5 font-sans">
        <p className="whitespace-nowrap text-sm leading-4 text-charcoal">
          {segments.map((s, i) => (
            <span key={i} className={s.bold ? "font-bold" : "font-normal"}>
              {s.text}
            </span>
          ))}
        </p>
      </div>
    </div>
  );
}
