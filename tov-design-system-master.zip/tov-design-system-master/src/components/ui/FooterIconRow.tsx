import { TextLink } from "./TextLink";

/**
 * The site "Footer Icon Row" component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1688:3759) — 3 real cards (Trade Program, Design Box, Registry),
 * each an icon + heading + description + "Join Now" link. A 4-variant
 * Live set (2 looks × Desktop/Mobile); both looks share identical content,
 * varying only in card height (168px vs 208px Desktop) — built as one
 * shared layout rather than reproducing a height difference with no
 * visible content difference behind it.
 *
 * Background is solid charcoal (`#3F3D3E`), matching Footer directly
 * above it, not white — every text node is white. Desktop is 3
 * left-aligned columns side by side (not centered stacked cards) with a
 * real 1px white vertical divider between each; Mobile stacks the same 3
 * blocks vertically with the same divider rotated 90° into a horizontal
 * rule.
 *
 * All 3 icons are real, distinct outline vectors saved as
 * `footer-trade-program.svg`, `footer-design-box.svg` (a paint palette,
 * not a pencil), and `footer-registry.svg` (a gift box with a ribbon, a
 * different shape from the library's own `gift.svg`).
 *
 * "Join Now" is real title-case text ("Join Now") with `textCase: UPPER`
 * applied as a style — uppercased via CSS here, not literal characters.
 */
const CARDS = [
  {
    icon: "footer-trade-program",
    title: "Trade Program",
    description: "Are you an interior designer or architect? Join today.",
  },
  {
    icon: "footer-design-box",
    title: "Design Box",
    description: "Bring your vision to life. Try our design tool to see how our pieces fit beautifully into your space.",
  },
  {
    icon: "footer-registry",
    title: "Registry",
    description: "Celebrating your next chapter? Create a registry and start saving the perfect pieces for your home.",
  },
];

function IconCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="flex flex-col items-start text-left gap-2.5">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`/icons/${icon}.svg`} alt="" className="w-6 h-6" />
      <p className="text-base font-bold text-white">{title}</p>
      <p className="text-sm leading-[21px] text-white">{description}</p>
      <TextLink href="#" inverse className="self-start">Join now</TextLink>
    </div>
  );
}

export function FooterIconRowDesktop() {
  return (
    <div className="w-full bg-charcoal font-sans px-page-margin-desktop py-5">
      <div className="min-w-[1240px] flex items-stretch gap-10">
        {CARDS.map((card, i) => (
          <div key={card.title} className="flex items-stretch gap-10 flex-1">
            <div className="flex-1">
              <IconCard {...card} />
            </div>
            {i < CARDS.length - 1 && <div className="w-px bg-white shrink-0" />}
          </div>
        ))}
      </div>
    </div>
  );
}

export function FooterIconRowMobile() {
  return (
    <div className="w-full max-w-sm bg-charcoal font-sans px-page-margin-mobile py-5 flex flex-col gap-10">
      {CARDS.map((card, i) => (
        <div key={card.title} className="contents">
          <IconCard {...card} />
          {i < CARDS.length - 1 && <div className="h-px bg-white" />}
        </div>
      ))}
    </div>
  );
}
