/**
 * Amazon Store — Storefront "Category Tile" (fileKey I95mnwwaoq0CvJOGop9tfn,
 * "TOV25 - B2C - Amazon store", "Amazon store images" section 16:363,
 * "Category images" sub-section 16:366). 4 tiles: Home Office, Outdoor,
 * Lighting, Decor.
 *
 * Unlike the Hero/3-Tile-Grid banners (see AmazonStorefrontBanner.tsx),
 * these are not flat pre-composited images — each tile is a photo frame
 * ("Frame 10", e.g. 34:1242, 750x598) sitting above a separate white
 * caption block ("Frame 1235") with two real text layers: a title ("Home
 * office", 48px) and an underlined "Shop now" link (36px), both node
 * siblings under a shared tile parent (e.g. 34:1242 / 34:1244 / 34:1245 all
 * live under tile frame 34:1241).
 *
 *  - Image region: 750x598 (~1.254:1), a 40px gap, then an 88px-tall caption
 *    block (title 39px + 10px gap + "Shop now" 39px = 88, matches exactly).
 *  - Title: font-family "GT Ultra Fine:Regular" (this codebase's existing
 *    --font-display stand-in), 48px, leading 39px (a tight/compressed
 *    leading ratio, read directly from the live text style).
 *  - "Shop now": font-family "Gotham:Book" — no existing --font-gotham
 *    token in this app; reusing --font-sans (Montserrat, this codebase's
 *    existing general body-copy stand-in) rather than inventing a new font
 *    stack for one line of text. 36px, same 39px leading, underlined
 *    (decoration-from-font, i.e. the underline sits at the font's own
 *    baseline offset, not a fixed CSS offset).
 *  - Color: both text layers resolve to fill "colors/tertiary/not-black"
 *    (#3f3d3e) — an exact match for this app's existing --color-charcoal
 *    token, reused directly rather than a new raw hex.
 *
 * All 4 tiles map to their slot names in figma-slots.ts
 * (STOREFRONT_CATEGORY_TILE_SLOTS): 34:1242→"Home office",
 * 34:1248→"Outdoor", 34:1254→"Lighting", 34:1260→"Decor".
 */
export interface AmazonCategoryTileProps {
  /** Real Figma caption text, e.g. "Home office" — no invented default beyond a docs fallback. */
  title: string;
  ctaLabel?: string;
  imageSrc?: string;
  imageAlt?: string;
  className?: string;
}

export function AmazonCategoryTile({
  title,
  ctaLabel = "Shop now",
  imageSrc,
  imageAlt,
  className = "",
}: AmazonCategoryTileProps) {
  return (
    <div className={`w-[750px] max-w-full flex flex-col ${className}`}>
      <div
        className="bg-image-placeholder w-full overflow-hidden"
        style={{ aspectRatio: 750 / 598 }}
        role={!imageSrc ? "img" : undefined}
        aria-label={!imageSrc ? `${title} — image placeholder` : undefined}
      >
        {imageSrc && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={imageSrc} alt={imageAlt ?? title} className="w-full h-full object-cover" />
        )}
      </div>
      <div className="flex flex-col items-center gap-[10px] mt-10 text-center text-charcoal">
        <p className="font-display text-[48px] leading-[39px]">{title}</p>
        <p className="font-sans text-[36px] leading-[39px] underline decoration-from-font underline-offset-[6px]">
          {ctaLabel}
        </p>
      </div>
    </div>
  );
}
