/**
 * The site "Footer" component (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 65:1143) — real Live variants for both Desktop (65:1144) and Mobile
 * (65:1196); Draft alternates of each exist but aren't built.
 *
 * Background is solid charcoal (`#3F3D3E`); every text node is white, at a
 * 1.3 line height. A large "TOV" wordmark sits behind the link area as a
 * watermark: the Figma file's own artwork (`/brand/footer-wordmark.svg`,
 * white at 22% opacity), not the logo with its pink "O".
 *
 * Desktop (1440, 100px side padding, 50px bottom padding): the wordmark,
 * 439 x 131, sits 2px in from the left margin and 26px from the top. The
 * link block is 750px wide against the right margin: two equal columns
 * (Support, Company), each a 16px Bold title over 14px Regular links, 10px
 * apart. The last row holds the four social icons (24px, 16px apart, in a
 * 471px group) and the 12px legal line, right-aligned.
 *
 * Mobile (375): 25px top padding and 100px bottom padding (50px on the
 * footer plus 50px on its outer frame, as in Figma), 25px gaps. The wordmark is
 * 335 x 100, centered; below a 0.5px white rule, a 20px-padded column holds
 * both link groups stacked, the social icons, and the legal line.
 *
 * Social icons are the Figma file's exported 24px icons (`/icons/footer-*.svg`,
 * glyphs inset within the 24px box). A 14px, 0.5-opacity frame ("TOV footer
 * last line") at the very top of the Desktop instance has no children —
 * leftover Figma cruft, excluded rather than reproduced.
 */
const SUPPORT_LINKS = [
  "Contact Us", "Returns, Refunds Claims", "Shipping and Delivery", "FAQs",
  "Product Care", "Find a Store", "Financing",
];

const COMPANY_LINKS = ["About TOV", "Trade Program", "Affiliates", "Careers", "Get Inspired"];

const LEGAL_TEXT = "© 2026 TOV Furniture. All right reserved  Privacy Policy | Terms and Conditions | Prop 65 | Do Not Sell or Share My Information";

const SOCIAL = [
  { name: "Instagram", icon: "/icons/footer-instagram.svg" },
  { name: "TikTok", icon: "/icons/footer-tiktok.svg" },
  { name: "YouTube", icon: "/icons/footer-youtube.svg" },
  { name: "Pinterest", icon: "/icons/footer-pinterest.svg" },
];

function FooterColumn({ title, links, className = "" }: { title: string; links: string[]; className?: string }) {
  return (
    <div className={`flex flex-col gap-2.5 text-white ${className}`}>
      <p className="text-base leading-[1.3] font-bold">{title}</p>
      {links.map((label) => (
        <a key={label} href="#" className="text-sm leading-[1.3]">{label}</a>
      ))}
    </div>
  );
}

function SocialIcons({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-end gap-4 ${className}`}>
      {SOCIAL.map((s) => (
        <a key={s.name} href="#" aria-label={s.name} className="block size-6 shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={s.icon} alt="" className="size-6" />
        </a>
      ))}
    </div>
  );
}

export function FooterDesktop() {
  return (
    <footer className="w-full bg-charcoal font-sans px-[100px] pt-6 pb-[50px]">
      <div className="relative min-w-[1240px] flex flex-col items-end gap-2.5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/footer-wordmark.svg" alt="" aria-hidden className="absolute left-0.5 top-0.5 w-[439px] h-[131px]" />
        <div className="relative flex w-[750px] items-start">
          <FooterColumn title="Support" links={SUPPORT_LINKS} className="flex-1 min-w-0" />
          <FooterColumn title="Company" links={COMPANY_LINKS} className="flex-1 min-w-0" />
        </div>
        <div className="relative flex w-full items-center gap-2.5">
          <SocialIcons className="w-[471px] shrink-0" />
          <p className="flex-1 min-w-0 text-xs text-white text-right whitespace-pre-wrap">{LEGAL_TEXT}</p>
        </div>
      </div>
    </footer>
  );
}

export function FooterMobile() {
  return (
    <footer className="w-full max-w-sm bg-charcoal font-sans pt-[25px] pb-[100px] flex flex-col items-center gap-[25px] overflow-hidden">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/footer-wordmark-mobile.svg" alt="" aria-hidden className="w-[335px] max-w-[calc(100%-40px)] h-auto aspect-[335/100.315]" />
      <div className="w-full border-t-[0.5px] border-white px-5 flex flex-col gap-5">
        <div className="flex flex-col gap-2.5 pt-2.5">
          <FooterColumn title="Support" links={SUPPORT_LINKS} />
          <FooterColumn title="Company" links={COMPANY_LINKS} />
        </div>
        <SocialIcons className="h-[49px]" />
        <p className="text-xs text-white whitespace-pre-wrap">{LEGAL_TEXT}</p>
      </div>
    </footer>
  );
}
