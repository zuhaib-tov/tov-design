/**
 * TOV B2B Dashboard / Avatar — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 39:127. Circular
 * account-manager / agent photo. Small is 40px (20px radius), Large is 110px
 * (55px radius); the image is cropped with object-cover.
 */
export type AvatarSize = "small" | "large";

export interface B2BDashboardAvatarProps {
  size?: AvatarSize;
  src?: string;
  alt?: string;
  /** Used for the fallback initials when no image is provided. */
  name?: string;
  className?: string;
}

const sizes: Record<AvatarSize, string> = {
  small: "size-10 rounded-[20px] text-sm",
  large: "size-[110px] rounded-[55px] text-3xl",
};

function initials(name?: string) {
  if (!name) return "";
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

export function B2BDashboardAvatar({
  size = "small",
  src,
  alt = "",
  name,
  className = "",
}: B2BDashboardAvatarProps) {
  const base = `relative inline-block shrink-0 overflow-hidden ${sizes[size]} ${className}`;
  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={src} alt={alt || name || ""} className={`${base} object-cover`} />
    );
  }
  return (
    <span
      role="img"
      aria-label={alt || name || "Avatar"}
      className={`${base} inline-flex items-center justify-center bg-cream-200 font-sans font-bold text-primary`}
    >
      {initials(name)}
    </span>
  );
}
