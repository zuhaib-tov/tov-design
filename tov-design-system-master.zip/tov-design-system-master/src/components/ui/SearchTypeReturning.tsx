/**
 * Search — Returning Users — fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1696:2824. 2 real variants: Desktop (1696:2555) and Mobile (1696:2651).
 * Empty search bar (just a typing-cursor glyph) + a left "Recent
 * Searches" panel + a "Recently Viewed" product grid, reusing the exact
 * same Callie/Yara/Mel photos and the same buggy mobile card data already
 * extracted for Type B (verified: identical titles, prices, and the same
 * card-3-shows-the-wrong-product bug).
 *
 * Flagged, not corrected: Desktop's "Recent Searches" list ("Velvet
 * Sofas", "Ottomans", "Benches", "Coffee Table", "Accent Chair") is a
 * genuinely different set from Mobile's ("Velvet Sofas", "Ottomans",
 * "Benches", "Stools", "Wall art" — Type B's category chip labels reused
 * verbatim), not a reflow of the same list. Kept exactly as Figma has it.
 */
import {
  SearchTopBar,
  MobileSearchTopBar,
  DesktopProductCard,
  MobileProductCard,
  PromoBanner,
  type SearchProduct,
} from "./SearchShared";

const RECENT_SEARCHES_DESKTOP = ["Velvet Sofas", "Ottomans", "Benches", "Coffee Table", "Accent Chair"];
const RECENT_SEARCHES_MOBILE = ["Velvet Sofas", "Ottomans", "Benches", "Stools", "Wall art"];

const DESKTOP_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/sofa-callie-velvet.jpg", title: 'Callie 84" Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-yara-pleated-velvet.jpg", title: 'Yara 90.6" Pleated Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/bed-mel-faux-mohair-velvet.jpg", title: "Mel Faux Mohair Velvet Bed", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#59483B", "#045047"] },
];

const MOBILE_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/sofa-callie-velvet-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-typeB-card2-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#C8C5C5", "#9C8C8C"] },
  { image: "/images/search/bed-mel-faux-mohair-velvet-sq.jpg", title: 'Callie 84" Velvet Sofa', price: "$479", materialTag: "Performance Fabric", swatches: ["#DEE0D8", "#2B2B2B"] },
  { image: "/images/search/sofa-lou-performance-velvet-sq.jpg", title: 'Lou 91" Performance Velvet Sofa', price: "$1,499", materialTag: "Performance Fabric", swatches: ["#B49F7F", "#CCC1B0"] },
  { image: "/images/search/chair-kylie-velvet-dining-sq.jpg", title: "Kylie Velvet Dining Chair", price: "$479", materialTag: "Performance Fabric", swatches: ["#ABABAB", "#937F7F"] },
  { image: "/images/search/lamp-graham-velvet-floor-sq.jpg", title: "Graham Velvet Floor Lamp", price: "$479", materialTag: "Performance Fabric", swatches: ["#B87247", "#3A5D2D", "#6E4E38", "#572323"] },
];

function RecentSearchesPanel({ items }: { items: string[] }) {
  return (
    <div className="flex w-[178px] shrink-0 flex-col gap-4">
      <p className="text-xs font-bold text-ink-muted">Recent Searches</p>
      {items.map((label) => (
        <p key={label} className="text-base font-bold text-charcoal">{label}</p>
      ))}
      <button type="button" className="text-left text-xs font-semibold uppercase tracking-wide-ui text-ink-muted underline">clear recent searches</button>
    </div>
  );
}

export function SearchTypeReturningDesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="" />
      <div className="flex gap-8 px-10 pt-6 pb-10">
        <RecentSearchesPanel items={RECENT_SEARCHES_DESKTOP} />
        <div className="flex-1 flex flex-col gap-4">
          <p className="text-xs font-bold text-ink">Recently Viewed</p>
          <div className="grid grid-cols-3 gap-grid-gutter-lg">
            {DESKTOP_PRODUCTS.map((p) => <DesktopProductCard key={p.title} product={p} />)}
          </div>
        </div>
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeReturningMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <div className="px-grid-margin pt-6 pb-4 flex flex-col gap-2">
        <p className="text-xs font-bold text-ink-muted">Recent Searches</p>
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {RECENT_SEARCHES_MOBILE.map((label) => (
            <span key={label} className="shrink-0 whitespace-nowrap rounded-pill bg-neutral-300 px-4 py-2 text-xs font-bold text-ink-muted">{label}</span>
          ))}
        </div>
        <button type="button" className="text-left text-xs font-semibold uppercase tracking-wide-ui text-ink-muted underline">clear recent searches</button>
      </div>
      <p className="text-xs font-bold text-ink px-5 pb-4">Recently Viewed</p>
      <div className="grid grid-cols-2 gap-grid-gutter-md px-5 pb-6">
        {MOBILE_PRODUCTS.map((p, i) => <MobileProductCard key={`${p.title}-${i}`} product={p} />)}
      </div>
    </div>
  );
}
