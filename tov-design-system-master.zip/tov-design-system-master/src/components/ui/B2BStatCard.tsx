/**
 * TOV B2B — Stat Card. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 4:53 ("Stat Card" symbol frame), Default/Desktop
 * (4:48, 410x157) and Default/Mobile (4:52, 350x120) variants.
 *
 * Metric and supporting explanation used as proof in program storytelling.
 * Keep the number, unit and explanatory copy together.
 */
export interface B2BStatCardProps {
  /** The headline figure, e.g. "10+ years" — keep the number and its unit together. */
  value: string;
  /** Trailing part of the figure set in the brand color, e.g. "+ years" after "10". */
  accent?: string;
  /** Supporting explanatory copy beneath the figure. */
  description: string;
  /** Renders the Mobile variant (centered, smaller type) instead of Desktop. */
  compact?: boolean;
  className?: string;
}

export function B2BStatCard({ value, accent, description, compact = false, className = "" }: B2BStatCardProps) {
  return (
    <div
      className={`bg-cream-100 rounded-2xl flex flex-col ${
        compact ? "w-[350px] items-center text-center gap-2 p-[15px]" : "w-[410px] gap-[17px] p-5"
      } ${className}`}
    >
      <p className={`font-display text-charcoal leading-none ${compact ? "text-[38px]" : "text-[56px]"}`}>
        {value}
        {accent && <span className="text-primary">{accent}</span>}
      </p>
      <p className={`font-light text-charcoal ${compact ? "text-sm" : "text-base"}`}>{description}</p>
    </div>
  );
}
