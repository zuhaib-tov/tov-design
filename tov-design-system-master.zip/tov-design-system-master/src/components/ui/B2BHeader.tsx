import { Logo } from "./Logo";
import { B2BButton } from "./B2BButton";

/**
 * TOV B2B global header — Figma Header component set (node 10:104),
 * Default/Desktop (10:84) and Default/Mobile (10:103). Desktop stacks a
 * Utility Bar (logo + "Professional" wordmark, Support link, Join Today /
 * Sign in, search / wishlist / cart) over a Category Nav row with the real
 * 9 category links. Mobile collapses to a hamburger, centered logo lockup,
 * and a search icon + Sign In pill — no category row or Join Today button
 * at that viewport, matching the real supplied variant.
 */
const CATEGORY_LINKS = [
  "New",
  "Furniture",
  "Rugs",
  "Lighting",
  "Decor & Tabletop",
  "Pillows & Throws",
  "Outdoor",
  "Wall Art & Mirrors",
  "Sale",
];

function SearchIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <circle cx="8.5" cy="8.5" r="6" stroke="currentColor" strokeWidth="1.5" />
      <path d="M13 13l5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function CartIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M4 7h12l-1 10.5a1.5 1.5 0 0 1-1.5 1.5H6.5A1.5 1.5 0 0 1 5 17.5L4 7Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <path d="M7 7V5.5a3 3 0 0 1 6 0V7" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

function HeartIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M10 17S2.5 12.4 2.5 7.3C2.5 4.6 4.6 2.5 7.2 2.5c1.4 0 2.7.7 3.5 1.9.8-1.2 2.1-1.9 3.5-1.9 2.6 0 4.7 2.1 4.7 4.8 0 5.1-7.4 9.7-7.4 9.7Z"
        stroke="currentColor"
        strokeWidth="1.3"
      />
    </svg>
  );
}

export function B2BHeader({
  viewport = "desktop",
  navStyle = "default",
}: {
  viewport?: "desktop" | "mobile";
  /** Desktop only. `centered` sets the wordmark in capitals and centers a taller category row. */
  navStyle?: "default" | "centered";
}) {
  const centered = navStyle === "centered";
  if (viewport === "mobile") {
    return (
      <header className="flex w-[390px] items-center justify-between border-b border-[#e8e8e8] bg-white px-4 py-4">
        <button aria-label="Open menu" className="flex flex-col gap-[7px]">
          <span className="block h-px w-6 bg-charcoal" />
          <span className="block h-px w-6 bg-charcoal" />
          <span className="block h-px w-6 bg-charcoal" />
        </button>
        <div className="flex flex-col items-center gap-0.5">
          <Logo className="h-[18px] text-charcoal" accentColor="currentColor" />
          <span className="text-[9px] font-semibold uppercase tracking-wide-ui text-charcoal">
            Professional
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <SearchIcon className="h-5 w-5 text-charcoal" />
          <B2BButton variant="header-sign-in" icon={false} className="!px-3 !py-2 text-xs">
            Sign In
          </B2BButton>
        </div>
      </header>
    );
  }

  return (
    <header className="w-[1440px] bg-white">
      <div className="flex items-center justify-between gap-10 border-b border-[#d4d4d4] px-[75px] py-5">
        <div className="flex items-center gap-[5px]">
          <Logo className="h-[27px] text-black" />
          <span className={centered ? "text-[15px] font-medium uppercase tracking-wide-ui text-charcoal" : "text-base font-medium text-charcoal"}>
            Professional
          </span>
        </div>
        <div className="flex items-center gap-5">
          <a href="#" className="text-sm font-bold text-charcoal">
            Support
          </a>
          <div className="flex items-center gap-[7px]">
            <B2BButton variant="header-join">Join Today</B2BButton>
            <B2BButton variant="header-sign-in">Sign in</B2BButton>
          </div>
          <SearchIcon className="h-[18px] w-[18px] text-charcoal" />
          <HeartIcon className="h-[18px] w-[18px] text-charcoal" />
          <CartIcon className="h-[18px] w-[18px] text-charcoal" />
        </div>
      </div>
      <nav
        className={`flex items-center gap-[34px] border-b border-[#e8e8e8] ${
          centered ? "justify-center pr-[50px]" : "px-[50px]"
        } py-3`}
      >
        {CATEGORY_LINKS.map((label) => (
          <a
            key={label}
            href="#"
            className={`text-base text-charcoal hover:text-primary ${centered ? "py-3 font-medium leading-[14px]" : ""}`}
          >
            {label}
          </a>
        ))}
      </nav>
    </header>
  );
}
