import { Button } from "./Button";

/**
 * New Arrivals — page-level sections mapped from the Figma file
 * "TOV26 - B2C - New Arrivals Refresh" (fileKey `tefhO0Dx4CNYT09diRqfB2`),
 * canvas "💠Components" (node `1:7`) → "Desktop - Default" (`8005:9839`,
 * 1440×7412) / "Mobile - Default" (`8005:9838`, 375×7984).
 *
 * Page structure: navbar → "New arrivals" heading → 4 repeats of [2 rows of
 * 4/2 Product Cards (8 products) + a "Social CTA header" bar + a "Get the
 * look" lifestyle banner] → a "showing X of Y" / load-more block → footer.
 * Navbar and Footer are the existing `MainNav`/`Footer` components, reused
 * as-is.
 *
 * The product grid reuses the existing Collection (PLP)
 * `PLPProductRowDesktop`/`PLPProductRowMobile` (4/2 `PLPProductCard`s, 10px
 * gap — see the New Arrivals doc page). Figma's own card width here
 * (302.5px Desktop / 162.5px Mobile, to fit 4-up/2-up in the narrower
 * 1240px/375px container) is narrower than `PLPProductCard`'s fixed
 * 342px/167px — the same fixed-pixel-grid-in-a-fluid-box situation already
 * precedented on Homepage (see FIGMA_SYSTEMS.md); same fix applied there:
 * horizontally-scrollable rows at their real intrinsic width, rather than
 * resizing the shared, already-shipped component. Badge text on individual
 * product cards varies between "Best Seller · Sale" and "New Arrival ·
 * Sale" from card to card in the Figma source — placeholder-catalog
 * variety rather than a meaningful per-card distinction (same convention as
 * `PLPProductCard`'s own doc comment), so the row's own default badge is
 * used rather than inventing a rule for which badge goes where.
 *
 * The 4 pieces below (Heading, Social CTA Header, Get the Look Banner, Load
 * More) are page-specific patterns with no existing equivalent elsewhere in
 * the design system — Homepage's own "Social CTA Header" and "Get the
 * Look" card (`HomepageSocial.tsx`) are visually unrelated (different
 * Figma file, different content, different layout), so they are not reused
 * here. These 4 are flagged **NEW / UNREVIEWED** and are not logged in
 * FIGMA_SYSTEMS.md's Sync Log or COMPONENT_CHANGELOG.md as synced pieces
 * (see the doc page callout).
 */

// ---------------------------------------------------------------------------
// Heading — NEW / UNREVIEWED
// Desktop node 8001:469 (border rgba(0,0,0,0.32), 68px/70px GT Ultra Fine
// Trial). Mobile node 8001:865 (border #b7b7b7, 26px/30px).
// ---------------------------------------------------------------------------
export function NewArrivalsHeading({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={
        compact
          ? "w-full border-b-[0.3px] border-[#b7b7b7] pl-4 pb-[5px]"
          : "w-full border-b-[0.5px] border-[rgba(0,0,0,0.32)] pl-page-margin-desktop pb-[15px]"
      }
    >
      <h1
        className={`font-display text-charcoal ${
          compact ? "text-[26px] leading-[30px]" : "text-[68px] leading-[70px]"
        }`}
      >
        New arrivals
      </h1>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Social CTA Header — NEW / UNREVIEWED
// A dark (#333) strip carrying an image-spec annotation, not real UI copy.
// Desktop (node 8001:5033) and Mobile (node 8005:5286) have different real
// text, font, size, alignment and padding — reproduced exactly per-viewport
// rather than sharing one string.
// ---------------------------------------------------------------------------
export function NewArrivalsSocialCtaHeader({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="w-full bg-[#333333] px-page-margin-mobile py-2.5">
        <p className="text-base text-white">
          Category image: Lifestyle Image | Mobile size - can use 474 x 375
        </p>
      </div>
    );
  }
  return (
    <div className="w-full bg-[#333333] px-page-margin-desktop py-2.5 flex items-center justify-center">
      <p className="text-[22px] text-white text-center">
        Collection [will be the same image as LP]: Lifestyle Image | Desktop 1920 x 720
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Get the Look Banner — NEW / UNREVIEWED
// Desktop node 8012:5406 (inside Frame 1229): full-bleed lifestyle image,
// eyebrow/header/sub-copy + a "Get the look" pill CTA (real `bag-add` icon
// approximated with the existing `bag-outline` icon, same precedent as
// HomepageSocial's Post Container / Get the Look). Mobile node 8012:5427
// (inside Frame 1228): same idea, centered text, with no CTA button — not
// omitted by mistake. Every image fill is Figma's own empty/checkered
// placeholder (no real photo in the source) — reproduced with
// `.bg-image-placeholder`, same convention as Homepage/PDP.
// ---------------------------------------------------------------------------
export function NewArrivalsGetTheLookBanner({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="w-full px-page-margin-mobile pt-5 pb-10">
        <div className="relative rounded-2xl overflow-hidden bg-image-placeholder h-[474px] flex flex-col justify-end p-card-padding-sm">
          <div className="absolute inset-0 bg-black/20" />
          <div className="relative flex flex-col gap-2.5 items-center text-center">
            <p className="text-white">
              <span className="block text-[22px] font-light">Eyebrow</span>
              <span className="block text-[46px] font-display leading-[50px]">Header</span>
            </p>
            <p className="text-sm text-white">Sub copy</p>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="w-full px-page-margin-desktop pb-10">
      <div className="relative rounded-[36px] overflow-hidden bg-image-placeholder h-[567.82px] flex flex-col justify-end items-end p-card-padding-lg">
        <div className="absolute inset-0 bg-black/[0.12]" />
        <div className="relative flex flex-col gap-3.5 items-start w-full">
          <div className="flex flex-col gap-px">
            <p className="text-[22px] text-cream-50">Eyebrow</p>
            <p className="text-[64px] leading-[60px] font-display text-white w-full max-w-[953px]">Header</p>
            <p className="text-[32px] text-cream-50 max-w-[1090px]">Sub copy</p>
          </div>
          <button
            type="button"
            className="flex items-center gap-2.5 rounded-pill px-[27px] py-2.5 drop-shadow-[0_0_2px_rgba(0,0,0,0.25)]"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/bag-outline.svg" alt="" className="w-6 h-6 invert" />
            <span className="text-xs font-bold uppercase tracking-wide-ui text-white">Get the look</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Load More — NEW / UNREVIEWED
// Desktop node 8001:849 / Mobile node 8001:1332: "showing X of Y" caption +
// progress bar, a large "load more products" CTA (reuses the existing
// `Button` `primary`/`lg` — a close match to the source's charcoal pill,
// 54px tall, 14px bold uppercase), and two floating circular icon buttons
// (a pink chat-launcher, a bordered "back to top" arrow) that read as
// generic site-wide chrome, not New-Arrivals-specific content — reused
// existing `chat.svg`/`arrow-up.svg` icons rather than exporting new ones.
// Figma places those two buttons at fixed viewport-edge pixel offsets
// (e.g. literal `left: 1291.5px` in a 1440px frame) that only make sense
// pinned to a full browser viewport, not inside a component of arbitrary
// width — laid out here as a flanking row instead of reproducing those
// literal offsets.
// ---------------------------------------------------------------------------
export function NewArrivalsLoadMore({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="w-full px-4 py-[50px] flex items-center justify-center gap-2">
        <button
          type="button"
          aria-label="Chat"
          className="shrink-0 w-9 h-9 rounded-full bg-brand-pink flex items-center justify-center"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/chat.svg" alt="" className="w-4 h-4" />
        </button>
        <div className="flex flex-col items-center gap-5 flex-1 max-w-[280px]">
          <div className="w-full flex flex-col items-center gap-1.5">
            <p className="text-xs text-[#333333]">showing 00 out of 000</p>
            <div className="w-full h-[7px] rounded-pill bg-neutral-200 overflow-hidden">
              <div className="h-full w-[25%] rounded-pill bg-charcoal" />
            </div>
          </div>
          <Button variant="primary" size="lg" className="w-full">
            Load more products
          </Button>
        </div>
        <button
          type="button"
          aria-label="Back to top"
          className="shrink-0 w-9 h-9 rounded-full border border-charcoal shadow-sm flex items-center justify-center"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/arrow-up.svg" alt="" className="w-4 h-4" />
        </button>
      </div>
    );
  }
  return (
    <div className="w-full px-page-margin-desktop py-[50px] flex items-center justify-center gap-6">
      <button
        type="button"
        aria-label="Chat"
        className="shrink-0 w-[60px] h-[60px] rounded-full bg-brand-pink flex items-center justify-center"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/chat.svg" alt="" className="w-7 h-7" />
      </button>
      <div className="flex flex-col items-center gap-5">
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-base text-[#333333]">showing 00 out of 000</p>
          <div className="w-[324px] h-[9px] rounded-pill bg-neutral-200 overflow-hidden">
            <div className="h-full w-[28%] rounded-pill bg-charcoal" />
          </div>
        </div>
        <Button variant="primary" size="lg" className="w-[407px]">
          Load more products
        </Button>
      </div>
      <button
        type="button"
        aria-label="Back to top"
        className="shrink-0 w-[60px] h-[60px] rounded-full border border-charcoal shadow-sm flex items-center justify-center"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/arrow-up.svg" alt="" className="w-6 h-6" />
      </button>
    </div>
  );
}
