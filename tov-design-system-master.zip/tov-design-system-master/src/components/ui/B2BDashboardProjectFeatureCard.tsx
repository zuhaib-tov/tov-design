/**
 * TOV B2B Dashboard / Project Feature Card — Figma "TOV26 - B2B - Design
 * system" (fileKey CGe5J4j6AI5uus5G2f8iqh), node 43:69 → Version=Default
 * (43:68), 316.67x209.94. Image-led saved-project card used on the
 * Overview: a full-bleed photo with a dark gradient scrim, a created-date
 * stamp and, over the image, the project name/qty and a "View Project"
 * link — unlike Project Card, there's no separate white content area, and
 * no chevron/thumbnail split.
 */
export interface B2BDashboardProjectFeatureCardProps {
  title: string;
  quantityLabel: string;
  dateLabel: string;
  className?: string;
}

export function B2BDashboardProjectFeatureCard({
  title,
  quantityLabel,
  dateLabel,
  className = "",
}: B2BDashboardProjectFeatureCardProps) {
  return (
    <div
      className={`bg-image-placeholder relative flex h-[210px] w-[317px] max-w-full flex-col items-start justify-end gap-[10px] overflow-hidden rounded-[10px] border-[0.5px] border-[#e0e0e0] p-3 ${className}`}
    >
      <div
        className="pointer-events-none absolute inset-0 rounded-[10px]"
        style={{ backgroundImage: "linear-gradient(8deg, rgba(0,0,0,0.62) 9%, rgba(255,255,255,0) 123%)" }}
      />
      <p className="relative font-sans text-[10px] font-normal uppercase tracking-wide-ui text-white/60">{dateLabel}</p>
      <div className="relative flex flex-col gap-6 text-white">
        <div className="flex flex-col gap-1">
          <p className="font-sans text-xl font-bold">{title}</p>
          <p className="font-sans text-[15px] font-normal">{quantityLabel}</p>
        </div>
        <p className="font-sans text-sm font-bold underline underline-offset-2">View Project</p>
      </div>
    </div>
  );
}
