export function Rating({
  value,
  count,
  max = 5,
}: {
  value: number;
  count?: number;
  max?: number;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex" aria-label={`${value} out of ${max} stars`}>
        {Array.from({ length: max }).map((_, i) => {
          const filled = i + 1 <= Math.round(value);
          return (
            <svg
              key={i}
              viewBox="0 0 20 20"
              className={`w-4 h-4 ${filled ? "fill-primary" : "fill-neutral-300"}`}
            >
              <path d="M10 1.5l2.6 5.6 6.1.6-4.6 4.1 1.3 6-5.4-3.2-5.4 3.2 1.3-6-4.6-4.1 6.1-.6z" />
            </svg>
          );
        })}
      </div>
      {typeof count === "number" && (
        <span className="text-xs text-ink-muted">({count})</span>
      )}
    </div>
  );
}
