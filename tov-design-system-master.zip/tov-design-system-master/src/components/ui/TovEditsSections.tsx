import { PDPBreadCrumbs } from "./PDPBreadCrumbs";
import { TextLink } from "./TextLink";

/**
 * TOV Edits — page-level sections mapped from the Figma file
 * "TOV26 - B2C - TOV Edits" (fileKey `PXf8n9b6WW5X5ZkYqiykJH`), one page
 * ("👩‍🎨 Design review", node `1:6`), node `1:4` ("Design review" canvas).
 *
 * Nothing in this file is labeled with real page names. Two candidate
 * frames share a section literally named "Edits - Landing Page design"
 * (nodes `8015:1446` and `8023:4970`), despite representing two different
 * real pages:
 *
 * - `8015:1447` (Desktop, 1440×1172) / `8015:1765` (Mobile, 375×2145) is the
 *   **Directory/Landing page**: a "TOV Edits" H1 + subcopy directly under
 *   the navbar, then a 3-up grid of large lifestyle-image tiles (title/
 *   subcopy/"Shop edit" per tile), then the footer.
 * - `8023:4971` (Desktop, 1440×4877) / `8023:5028` (Mobile, 375×6934) is an
 *   **individual Edit's own page**: its breadcrumb reads "Home / TOV Edits
 *   / The [Name] Edit" (a 3-level crumb, confirming this is a child page of
 *   the directory above), then a full-bleed hero (Edit title + subcopy),
 *   then 24 (Desktop) / 32 (Mobile — the two viewports don't reconcile to
 *   the same count in this draft file, reproduced as authored rather than
 *   forced to match) curated `PLPProductCard`s in 4-up/2-up rows, with one
 *   mid-page editorial banner breaking up the grid.
 *
 * A `Section > Desktop Layouts / Mobile Layouts` component-exploration area
 * (node `8001:1886`) contains isolated "TOV - Edits - 2 Edits" / "TOV -
 * Edits - 3 Edits" tile-count variants of the same grid tile used on the
 * real Directory page (the real Directory page's grid frame is itself
 * named "TOV - Edits - 3 Edits" and is pixel-identical to the isolated
 * 3-tile variant) — the grid supports 2 or 3 tiles depending how many Edits
 * are published, so `TovEditsGrid` below takes a `count` prop rather than
 * being duplicated. The Mobile "TOV - Edits - 2 Edits" instance actually
 * used on the real Directory page contains three stacked tiles, not two —
 * its name doesn't match its content.
 *
 * Two more sections under `1:4` are out of scope for this "TOV Edits" doc
 * page (they belong to other page systems, not to the Edits pages
 * themselves):
 * - "Edits - Homepage Placements" (`8023:7286`) — a full Homepage mockup
 *   annotated with image-spec callouts, one section of which shows how an
 *   Edits teaser (3 tiles, "VIEW ALL" link) is embedded on the Homepage.
 *   That's Homepage content, not an Edits page.
 * - "Marketing Module" (`8032:12183`) — a small single promo card ("Edit
 *   name" / "Short description about this TOV edit" / "SHOP THE EDIT")
 *   with different copy from either page above — a reusable cross-sell
 *   card used elsewhere in the site (e.g. PDP/cart), not part of the Edits
 *   pages themselves.
 * - "Navigation" (`8023:10505`) / the mega-menu's own "The [Name] Edit /
 *   Shop the Edit" promo tile inside the Furniture dropdown — both are the
 *   existing `MainNav`, reused as-is, not redefined here.
 *
 * Every tile/hero/banner title, subcopy, and price below is Figma's own
 * template placeholder content ("Edit Title- 17 ch max", "Up to 79
 * characters...", "Product name", "$0000.00") — reproduced verbatim per the
 * project's placeholder-content convention. The one exception: the
 * individual Edit page's mid-page banner ("Just landed" / "The finishing
 * touches." / "Accents that do the heavy lifting...") reads as genuine
 * authored marketing copy, not a length-placeholder pattern, and is kept
 * as real copy rather than treated as a placeholder.
 *
 * Product cards reuse the existing `PLPProductCard` (`size="desktop"`/
 * `"mobile"`) via the existing `PLPProductRowDesktop`/`PLPProductRowMobile`
 * — pixel-identical in swatch shape/badge/price treatment to this file's
 * own "Product card" instances (unlike New Arrivals, where the source
 * cards were narrower). Figma's real card width in the 4-up rows (302.5px
 * Desktop) is narrower than `PLPProductCard`'s fixed 342px, same
 * fixed-pixel-grid-in-a-fluid-box situation as New Arrivals/Homepage — same
 * fix applied: horizontally-scrollable rows at their real intrinsic width.
 *
 * The breadcrumb reuses the existing, already-synced `PDPBreadCrumbs` (home
 * icon + dot separators) for the individual Edit page's 3-level crumb — a
 * pixel-for-pixel match (15px home icon, 10px Montserrat, #777, 0.5px/10px
 * dot separators). The Directory page's crumb is shorter (just "Home / TOV
 * Edits", no third segment) so it's a small inline variant below rather
 * than a `PDPBreadCrumbs` call, since that component's shape is fixed at
 * exactly 2 link segments after the icon.
 *
 * The mid-page "Get the look" banner (Desktop node `8023:4992`, Mobile node
 * `8023:5173`) is visually similar in structure to New Arrivals'
 * `NewArrivalsGetTheLookBanner` (full-bleed image, bottom-anchored copy, a
 * pill "Get the look" CTA with the same `bag-add`→`bag-outline.svg` icon
 * approximation already precedented there) but is not reused from it —
 * different Figma file, different real copy, and New Arrivals' own version
 * is itself still NEW/UNREVIEWED, so per that file's own precedent
 * (Homepage's visually-similar banner wasn't reused for New Arrivals
 * either), this gets its own component, also flagged NEW/UNREVIEWED.
 * Figma's own source has no dark scrim/overlay on this banner (unlike the
 * Hero and Directory tiles, which both do) — reproduced faithfully with no
 * invented scrim; a real photo would likely supply enough natural contrast
 * even though the gray checkerboard image placeholder reads as low-contrast
 * here. The Mobile variant stacks 3 identical copies of the same
 * placeholder image as separate layers in the Figma source (an apparent
 * duplicate-layer artifact) — collapsed to one `<img>` here rather than
 * reproducing the redundant stack.
 */

// ---------------------------------------------------------------------------
// Directory page breadcrumb — Node 8023:10393. Home icon + "TOV Edits" only
// (current page, not a link) — genuinely one segment shorter than
// PDPBreadCrumbs' fixed 2-segment shape, so it's not reused from there.
// Same tokens or icon markup as PDPBreadCrumbs for visual consistency.
// ---------------------------------------------------------------------------
const HOME_PATH =
  "M5.98994 9.1766V7.3016M0.798912 9.38421L0.477408 5.52616C0.407248 4.68425 0.767048 3.86385 1.43392 3.34517L4.45509 0.995369C5.35787 0.29321 6.62202 0.293211 7.5248 0.99537L10.546 3.34517C11.2128 3.86385 11.5726 4.68425 11.5025 5.52616L11.181 9.38421C11.073 10.6799 9.98983 11.6766 8.68961 11.6766H3.29028C1.99005 11.6766 0.906889 10.6799 0.798912 9.38421Z";

export function TovEditsDirectoryBreadcrumb() {
  return (
    <nav className="flex items-center gap-1.5 font-sans text-neutral-700">
      <svg viewBox="0 0 11.98 12.15" className="w-[15px] h-[15px] shrink-0" fill="none" stroke="currentColor" strokeWidth="0.9375" strokeLinecap="round" strokeLinejoin="round">
        <path d={HOME_PATH} />
      </svg>
      <span className="w-px h-2.5 bg-neutral-700 rounded-full" />
      <span className="text-xs">TOV Edits</span>
    </nav>
  );
}

// Individual Edit page breadcrumb — reuses the already-synced PDPBreadCrumbs
// as-is: "Home / TOV Edits / The [Name] Edit".
export function TovEditsPageBreadcrumb() {
  return <PDPBreadCrumbs menuItem="TOV Edits" productLabel="The [Name] Edit" />;
}

// ---------------------------------------------------------------------------
// Directory Heading — NEW / UNREVIEWED
// Desktop node 8023:7053/7057 (56px/62px GT Ultra, centered). Mobile node
// 8023:9826/9827 (26px/30px).
// ---------------------------------------------------------------------------
export function TovEditsHeading({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`w-full bg-white flex flex-col items-center text-center gap-2.5 ${compact ? "px-page-margin-mobile pt-5" : "px-page-margin-desktop pt-5"}`}>
      <h1 className={`font-display text-black ${compact ? "text-[26px] leading-[30px]" : "text-[56px] leading-[62px]"}`}>
        TOV Edits
      </h1>
      <p className={`font-sans text-charcoal ${compact ? "text-base leading-6" : "text-lg leading-[27px]"}`}>
        The edit everyone&apos;s talking about. Chosen by us, styled your way.
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Directory Grid (tile mosaic) — NEW / UNREVIEWED
// Desktop node 8023:7040 "TOV - Edits - 3 Edits" (real page instance) /
// isolated variants under 8001:1886 "Edits - Components". Mobile node
// 8080:3002 "TOV - Edits - 2 Edits" (real page instance, 3 children despite
// the name). `count` picks 2 or 3 tiles per the "Edits - Components"
// isolated variants (2-tile and 3-tile states of the same component).
// Desktop tiles are centered text on a black-only bottom gradient; Mobile
// tiles are left-aligned text on a different duotone (mix-blend-multiply)
// gradient over a dimmed (opacity-20) image.
// ---------------------------------------------------------------------------
export function TovEditsGrid({ compact = false, count = 3 }: { compact?: boolean; count?: 2 | 3 }) {
  const tiles = Array.from({ length: count });

  if (compact) {
    return (
      <div className="w-full bg-white flex flex-col gap-3 px-4 pt-4 pb-[18px]">
        {tiles.map((_, i) => (
          <div
            key={i}
            className="relative h-[343px] w-full rounded-2xl overflow-hidden bg-image-placeholder flex flex-col items-start justify-end p-5"
          >
            <div
              className="absolute inset-0 mix-blend-multiply"
              style={{ backgroundImage: "linear-gradient(0.04deg, rgba(0,0,0,0.65) 0%, rgba(255,255,255,0.65) 77.5%)" }}
            />
            <div className="relative flex flex-col gap-2.5 items-start w-full">
              <div className="flex flex-col gap-px">
                <h3 className="text-[38px] leading-[42px] font-display text-white whitespace-nowrap">
                  Edit Title- 17 ch max
                </h3>
                <p className="text-base leading-6 text-white w-[189px]">
                  Up to 79 characters of supporting text can fit here across two lines.
                </p>
              </div>
              <TextLink href="#" inverse>
                Shop edit
              </TextLink>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="w-full bg-white px-page-margin-desktop pt-5 pb-10">
      <div className="flex gap-grid-gutter-sm">
        {tiles.map((_, i) => (
          <div
            key={i}
            className="relative flex-1 h-[494px] rounded-[36px] overflow-hidden bg-image-placeholder flex flex-col items-center justify-end p-card-padding-lg text-center"
          >
            <div
              className="absolute inset-0"
              style={{ background: "linear-gradient(to bottom, rgba(36,16,18,0) 22%, rgba(36,16,18,0.72) 100%)" }}
            />
            <div className="relative flex flex-col gap-4 items-center w-full">
              <div className="flex flex-col gap-1.5 items-center">
                <h3 className="text-[38px] leading-[42px] font-display text-white whitespace-nowrap">
                  Edit Title- 17 ch max
                </h3>
                <p className="text-lg leading-[27px] text-white text-center">
                  Up to 79 characters of supporting text can fit here across two lines.
                </p>
              </div>
              <TextLink href="#" inverse>
                Shop edit
              </TextLink>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Individual Edit Hero — NEW / UNREVIEWED
// Desktop node 8023:4980 (578px tall, 64px/42px title,
// centered). Mobile node 8023:5030 (same 578px height, 46px/50px title,
// left-set text block). A hidden alternate hero draft ("Frame 1278",
// hidden=true, real copy "Amara" / "Warm, textural, and effortlessly
// inviting...") sits in the same position in the source on both this page
// and the Directory page — excluded here since Figma itself marks it
// hidden, i.e. not part of the shipped design.
// ---------------------------------------------------------------------------
export function TovEditsHero({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`relative w-full h-[578px] bg-image-placeholder flex flex-col items-center justify-center gap-[17px] ${
        compact ? "px-5" : "px-[200px]"
      }`}
    >
      <div className="absolute inset-0 bg-black/[0.33]" />
      <div className={`relative flex flex-col items-center gap-[17px] text-white ${compact ? "" : "text-center"}`}>
        <h1
          className={`font-display ${
            compact ? "text-[46px] leading-[50px]" : "text-[64px] leading-[42px] whitespace-nowrap"
          }`}
        >
          Edit Title- 17 ch max
        </h1>
        <p className={`font-sans text-lg leading-[27px] ${compact ? "" : "text-center"}`}>
          Up to 79 characters of supporting text can fit here across two lines.
        </p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Mid-page editorial banner ("The finishing touches.") — NEW / UNREVIEWED
// Desktop node 8023:4992 (rounded-36 card, 525px tall, bottom-right text
// block, real copy). Mobile node 8023:5173 (rounded-16 card, 474px tall,
// centered text block). Real authored copy, not a length placeholder — see
// file header. CTA icon is Figma's own "bag-add" (pixelpf icons library, no
// local asset) approximated with the existing bag-outline.svg, same
// precedent as NewArrivalsGetTheLookBanner.
// ---------------------------------------------------------------------------
export function TovEditsFinishingTouchesBanner({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="w-full px-page-margin-mobile pt-5">
        <div className="relative rounded-2xl overflow-hidden bg-image-placeholder h-[474px] p-card-padding-sm flex flex-col items-center justify-end gap-[42px]">
          <div className="flex flex-col gap-2.5 items-center text-center text-white">
            <p>
              <span className="block text-[22px] font-sans font-light leading-[44px]">Just landed</span>
              <span className="block text-[46px] font-display leading-[50px]">The finishing touches.</span>
            </p>
            <p className="text-sm font-sans leading-[21px]">
              Accents that do the heavy lifting, from statement vases to side tables that earn their square footage.
            </p>
          </div>
          <button
            type="button"
            className="flex items-center gap-2.5 rounded-pill bg-white/40 px-[27px] py-2.5 shadow-[0_0_4px_rgba(0,0,0,0.25)]"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/bag-outline.svg" alt="" className="w-6 h-6 invert" />
            <span className="text-xs font-bold uppercase tracking-wide-ui text-white">Get the look</span>
          </button>
        </div>
      </div>
    );
  }
  return (
    <div className="w-full px-page-margin-desktop pt-5">
      <div className="relative rounded-[36px] overflow-hidden bg-image-placeholder h-[525px] flex flex-col justify-end items-end p-card-padding-lg">
        <div className="relative flex flex-col gap-3.5 items-end w-full">
          <div className="flex flex-col gap-px items-start w-full">
            <p className="text-[22px] font-sans text-cream-50 leading-[33px]">Just landed</p>
            <p className="text-[64px] leading-[60px] font-display text-white w-full max-w-[953px]">The finishing touches.</p>
            <p className="text-[32px] font-sans leading-[33px] text-cream-50 max-w-[1090px]">
              Accents that do the heavy lifting, from statement vases to side tables that earn their square footage.
            </p>
          </div>
          <button
            type="button"
            className="flex items-center gap-2.5 rounded-pill px-[27px] py-2.5 drop-shadow-[0_0_2px_rgba(0,0,0,0.25)]"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/bag-outline.svg" alt="" className="w-6 h-6 invert" />
            <span className="text-xs font-bold uppercase tracking-wide-ui text-white">Get the look</span>
          </button>
        </div>
      </div>
    </div>
  );
}
