/**
 * Editorial merchandising card combining imagery, a heading and a
 * collection CTA (Figma "Feature Card", node 6:68 — Standard/Large,
 * Desktop/Mobile, all Status=Live). Standard is available for desktop and
 * mobile; Large is desktop only.
 *
 * Standard's eyebrow row carries an optional live-stock status dot (used
 * for "In stock" copy); Large's eyebrow is a plain marketing line with no
 * dot, confirmed from the file's own Large/Desktop and Best Sellers
 * instances.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:617.
 */
export interface B2BFeatureCardProps {
  eyebrow: string;
  title: string;
  linkLabel: string;
  /** Status indicator dot next to the eyebrow — on for stock-status copy like "In stock". */
  showStatusDot?: boolean;
  size?: "standard" | "large";
  viewport?: "desktop" | "mobile";
  /** Photograph behind the copy; a bottom scrim keeps the text legible. */
  image?: string;
  className?: string;
}

export function B2BFeatureCard({
  eyebrow,
  title,
  linkLabel,
  showStatusDot = false,
  size = "standard",
  viewport = "desktop",
  image,
  className = "",
}: B2BFeatureCardProps) {
  const isLarge = size === "large";
  const isMobile = viewport === "mobile";

  const eyebrowRow = (
    <div className="flex items-center gap-2.5">
      {showStatusDot && <span className="w-3 h-3 rounded-full bg-primary shrink-0" />}
      <p className={`font-semibold uppercase text-white ${isMobile ? "text-[11px]" : "text-base"} tracking-wide-ui`}>
        {eyebrow}
      </p>
    </div>
  );
  const titleEl = (
    <h3 className={`font-display leading-none text-white ${isMobile ? "text-[38px]" : "text-[46px]"}`}>{title}</h3>
  );
  const linkEl = (
    <a href="#" className={`w-fit text-sm font-bold uppercase tracking-wide-ui text-white ${image ? "underline" : ""}`}>
      {linkLabel}
    </a>
  );

  return (
    <div
      className={`${image ? "bg-charcoal" : "bg-image-placeholder"} relative flex w-full flex-col justify-end overflow-hidden rounded-app-md ${
        isLarge ? "aspect-[640/632] p-10" : isMobile ? "aspect-[350/296] p-5" : "aspect-[469/402] p-5"
      } ${className}`}
    >
      {image && (
        <>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                "linear-gradient(14deg, rgba(0,0,0,0.46) 16.8%, rgba(255,255,255,0) 61.6%), linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2))",
            }}
          />
        </>
      )}
      {isMobile ? (
        <div className="relative flex flex-col gap-[37px]">
          <div className="flex flex-col">
            {eyebrowRow}
            {titleEl}
          </div>
          {linkEl}
        </div>
      ) : (
        <div className="relative flex flex-col gap-2.5">
          {eyebrowRow}
          {titleEl}
          {linkEl}
        </div>
      )}
    </div>
  );
}
