/**
 * Image-led category entry with a short category name (Figma "Category
 * Tile", node 6:43 — Version=Default, Viewport=Desktop/Mobile, both
 * Status=Live). Used inside Browse by Category; keep labels consistent with
 * the catalog taxonomy.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:613.
 */
export interface B2BCategoryTileProps {
  label: string;
  size?: "sm" | "lg";
  /** Photograph filling the tile. Falls back to the image placeholder. */
  image?: string;
  /** Horizontal alignment of the label along the bottom edge. */
  labelAlign?: "start" | "center";
  className?: string;
}

export function B2BCategoryTile({
  label,
  size = "lg",
  image,
  labelAlign = "start",
  className = "",
}: B2BCategoryTileProps) {
  const isLarge = size === "lg";
  return (
    <div
      className={`${image ? "bg-charcoal" : "bg-image-placeholder"} relative overflow-hidden rounded-app-md w-full aspect-[250/285] p-5 ${className}`}
    >
      {image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
      )}
      <p
        className={`absolute bottom-5 left-5 right-5 font-bold uppercase tracking-wide-ui text-white ${
          isLarge ? "text-lg" : "text-sm"
        } ${labelAlign === "center" ? "text-center" : ""}`}
      >
        {label}
      </p>
    </div>
  );
}
