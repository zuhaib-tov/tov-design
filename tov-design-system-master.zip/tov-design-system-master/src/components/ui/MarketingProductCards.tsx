/**
 * Marketing email "Product Cards" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1755:498) — Draft. Real per-breakpoint divergence, not a shared
 * constant: image radius is 24px (2-col desktop) vs 16px (3-col desktop
 * and both mobile); name/price sizes step down 14/14 -> 12/14 -> 12/12
 * across 2-col desktop -> 3-col desktop -> mobile. Sale price uses
 * --color-mauve, compare-at uses an unbound #8a8788 (no matching token).
 */
export interface ProductCardItem {
  name: string;
  price: string;
  compareAt?: string;
}

const DEFAULT_ITEM: ProductCardItem = { name: "Rattan Striped Accent Chair", price: "$599" };
const DEFAULT_SALE_ITEM: ProductCardItem = {
  name: "Rattan Striped Accent Chair",
  price: "$479",
  compareAt: "$599",
};

function ProductCard({
  item,
  imageClassName,
  nameClassName,
  priceClassName,
  spacerClassName,
}: {
  item: ProductCardItem;
  imageClassName: string;
  nameClassName: string;
  priceClassName: string;
  spacerClassName: string;
}) {
  return (
    <div className="flex flex-col">
      <div className={`bg-image-placeholder relative ${imageClassName}`}>
        <div className="absolute inset-0 bg-black/[6%]" />
        {item.compareAt && (
          <span className="absolute left-2.5 top-2.5 rounded-pill bg-mauve text-white font-bold uppercase text-[14px] tracking-wide-ui px-3.5 py-2">
            SALE
          </span>
        )}
      </div>
      <div className={spacerClassName} />
      <p className={`font-bold text-charcoal ${nameClassName}`}>{item.name}</p>
      <div className={`flex items-baseline gap-1.5 ${priceClassName}`}>
        <span className={item.compareAt ? "text-mauve" : "text-charcoal"}>{item.price}</span>
        {item.compareAt && <span className="text-[#8a8788] line-through">{item.compareAt}</span>}
      </div>
    </div>
  );
}

export function MarketingProductCardsDesktop2Col({
  items = [DEFAULT_ITEM, DEFAULT_SALE_ITEM],
}: {
  items?: [ProductCardItem, ProductCardItem];
}) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex gap-5">
      {items.map((item, i) => (
        <ProductCard
          key={i}
          item={item}
          imageClassName="w-[265px] h-[299px] rounded-[24px]"
          nameClassName="text-[14px] leading-[1.3]"
          priceClassName="text-[14px] leading-[1.3]"
          spacerClassName="h-1.5"
        />
      ))}
    </div>
  );
}

export function MarketingProductCardsDesktop3Col({
  items = [DEFAULT_ITEM, DEFAULT_SALE_ITEM, DEFAULT_ITEM],
}: {
  items?: [ProductCardItem, ProductCardItem, ProductCardItem];
}) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex gap-5">
      {items.map((item, i) => (
        <ProductCard
          key={i}
          item={item}
          imageClassName="w-[170px] h-[192px] rounded-[16px]"
          nameClassName="text-[12px] leading-[18px]"
          priceClassName="text-[14px] leading-[1.3]"
          spacerClassName="h-1.5"
        />
      ))}
    </div>
  );
}

export function MarketingProductCardsMobile({
  items = [DEFAULT_ITEM, DEFAULT_SALE_ITEM],
}: {
  items?: [ProductCardItem, ProductCardItem];
}) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex gap-grid-gutter-sm">
      {items.map((item, i) => (
        <ProductCard
          key={i}
          item={item}
          imageClassName="w-[172.5px] h-[194px] rounded-[16px]"
          nameClassName="text-[12px] leading-[18px]"
          priceClassName="text-[12px] leading-[1.3]"
          spacerClassName="h-1"
        />
      ))}
    </div>
  );
}
