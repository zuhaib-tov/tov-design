/**
 * TOV B2B Dashboard / Table Header — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 44:45 → Version=Orders (44:44),
 * full-width (1066px). Data-table header row: uppercase bold 11px labels on
 * a cream (#faf7f2) background with a bottom border. Pairs with Table Row
 * to form the Orders Table organism.
 */
const DEFAULT_COLUMNS = [
  "SO Order",
  "PO Number",
  "Order Date",
  "Status",
  "Est Ship",
  "Act Ship",
  "Tracking",
  "Carrier",
  "Method",
  "Total",
];

export interface B2BDashboardTableHeaderProps {
  columns?: string[];
  className?: string;
}

export function B2BDashboardTableHeader({ columns = DEFAULT_COLUMNS, className = "" }: B2BDashboardTableHeaderProps) {
  return (
    <div
      className={`flex w-full gap-[13px] border-b border-[#e0e0e0] bg-cream-100 px-4 py-3.5 font-sans text-[11px] font-bold uppercase tracking-wide-ui text-charcoal ${className}`}
    >
      {columns.map((col) => (
        <p key={col} className="w-[98px] shrink-0">
          {col}
        </p>
      ))}
      <p className="w-[98px] shrink-0 text-right">Items</p>
      <p className="w-[77px] shrink-0 text-right">Shipping</p>
    </div>
  );
}
