export interface B2BCarouselArrowProps {
  direction?: "next" | "previous";
  className?: string;
}

export function B2BCarouselArrow({ direction = "next", className = "" }: B2BCarouselArrowProps) {
  return (
    <button
      type="button"
      aria-label={direction === "next" ? "Next" : "Previous"}
      className={`inline-flex h-10 w-10 items-center justify-center rounded-[4px] border border-[#dddddd] bg-white/44 ${className}`}
    >
      <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        className={direction === "previous" ? "rotate-180" : ""}
        aria-hidden
      >
        <path d="M6 3l5 5-5 5" stroke="#b15a63" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </button>
  );
}
