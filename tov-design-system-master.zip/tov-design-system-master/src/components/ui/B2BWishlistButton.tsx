/**
 * TOV B2B wishlist action — Figma Core/Wishlist Button component set (node
 * 4:37), Default/All. Fixed 45×45 hit target around a 28×25 heart outline;
 * the file supplies only this default appearance, no saved/active state.
 */
export function B2BWishlistButton({ className = "" }: { className?: string }) {
  return (
    <button
      type="button"
      aria-label="Add to wishlist"
      className={`inline-flex h-[45px] w-[45px] items-center justify-center ${className}`}
    >
      <svg width="28" height="25" viewBox="0 0 28 25" fill="none" aria-hidden>
        <path
          d="M14 24S3 17.3 3 9.2C3 4.9 6.1 2 9.8 2c2 0 3.8 1 4.9 2.6C15.8 3 17.6 2 19.6 2 23.3 2 26 4.9 26 9.2 26 17.3 14 24 14 24Z"
          fill="#fefbf6"
          fillOpacity="0.35"
          stroke="#3f3d3e"
          strokeWidth="1.2"
        />
      </svg>
    </button>
  );
}
