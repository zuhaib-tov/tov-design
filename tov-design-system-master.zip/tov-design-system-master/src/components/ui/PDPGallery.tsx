"use client";

import { useEffect, useRef, useState } from "react";
import { Badge } from "./Badge";

/**
 * The PDP "Gallery" components (fileKey ySZYmjbO2Wck8u1JGAtI5J, Desktop
 * node 15:348, Mobile node 15:349) — standalone components, not a
 * Version=/Viewport=/Status= variant set, so both are included as-is.
 *
 * Desktop's thumbnail rail ends in a non-photo tile (cream background,
 * ruler icon). Mobile's dot pagination and heart+count pill reuse the same
 * heart glyph as ATC Stack (PDPAddToCartRow).
 *
 * Every image slot (main image and every thumbnail, both viewports) uses
 * the shared checkerboard placeholder pattern (`.bg-image-placeholder`,
 * globals.css) rather than invented product photography, matching Figma's
 * own empty-image-fill state.
 *
 * Desktop has no icon+text strip below the main image — that pattern is a
 * legacy design not part of the current PDP.
 *
 * The main image has a fixed 657x677 aspect ratio. The thumbnail column
 * matches that height but holds more content than fits (10 tiles,
 * itemSpacing 6, running to 1054px); the overflow is clipped with a
 * scrollable-but-visually-hidden scrollbar (`.no-scrollbar`, globals.css)
 * rather than a visible scrollbar track.
 *
 * The rail's max-height is synced to the main image's actual rendered
 * height via a ResizeObserver on the image (`imageRef`) rather than a
 * fixed value — flexbox sizes an auto row by the tallest item's own
 * hypothetical content size, so without this the rail's full 1054px of
 * tile content would stretch the row and distort the image's aspect ratio
 * at any width.
 *
 * Overlay measurements: Desktop badge sits 27px inset with a 157.6x45 size
 * (Badge "lg"); Mobile's badge is 94.56x27 (Badge "md"). Desktop arrow
 * buttons sit 34px inset from each edge, with 0.79 background opacity,
 * #bbbbbb border, and 6px corner radius. Desktop thumbnails have a 10.91px
 * corner radius. Mobile's dot pagination sits ~17px from the bottom.
 */
const HEART_PATH =
  "M 11.81247615814209 20.99995549519857 C 11.663167426397852 21.001454513830446 11.51607991898184 20.963741825272642 11.385914302755273 20.89058272043864 C 10.9156027301226 20.62808324893316 0 14.426532904307049 0 6.56248664855957 C 3.1086182129324058e-15 5.185135642687479 0.4333692128260389 3.842698236306509 1.238720563167219 2.7253330151240034 C 2.044071913508399 1.607967793941498 3.180576138023164 0.7723218947649002 4.487246079364427 0.33676525950431824 C 5.79391602070569 -0.09879137575626373 7.204507182379787 -0.11217716832955676 8.519207459261706 0.2985042730967204 C 9.833907736143624 0.7091857145229976 10.986065482323434 1.5231136182943983 11.81247615814209 2.6249944368998213 C 12.638886833960745 1.5231136182943983 13.79104346752046 0.7091857145229976 15.105743744402378 0.2985042730967204 C 16.420444021284297 -0.11217716832955676 17.831036573733513 -0.09879137575626373 19.137706515074775 0.33676525950431824 C 20.444376456416038 0.7723218947649002 21.580880959085828 1.607967793941498 22.386232309427008 2.7253330151240034 C 23.191583659768188 3.842698236306509 23.62495231628418 5.185135642687479 23.62495231628418 6.56248664855957 C 23.62495231628418 9.90935480594635 21.689018661887552 13.343721906344097 17.871838577882723 16.77808984120687 C 16.138510261361343 18.33633214235306 14.251199078689034 19.714253505071007 12.23903690090881 20.89058272043864 C 12.108871284682243 20.963741825272642 11.961784889886328 21.001454513830446 11.81247615814209 20.99995549519857 Z";

export interface PDPGalleryDesktopProps {
  thumbnailCount?: number;
  badgeLabel?: string;
}

export function PDPGalleryDesktop({ thumbnailCount = 9, badgeLabel = "New Arrival" }: PDPGalleryDesktopProps) {
  const imageRef = useRef<HTMLDivElement>(null);
  const [railHeight, setRailHeight] = useState<number>();

  useEffect(() => {
    const el = imageRef.current;
    if (!el) return;
    setRailHeight(el.getBoundingClientRect().height);
    const observer = new ResizeObserver(([entry]) => {
      if (entry) setRailHeight(entry.contentRect.height);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="flex flex-col gap-5 w-[765px] max-w-full font-sans">
      <div className="flex gap-2">
        <div
          className="no-scrollbar flex flex-col gap-1.5 shrink-0 overflow-y-auto"
          style={railHeight ? { maxHeight: railHeight } : undefined}
        >
          {Array.from({ length: thumbnailCount }).map((_, i) => (
            <div
              key={i}
              className="bg-image-placeholder w-[100px] h-[100px] rounded-[10.91px] border border-[#e8e8e8] shrink-0"
            />
          ))}
          <div className="w-[100px] h-[100px] rounded-[10.91px] border border-[#e8e8e8] bg-cream-50 flex flex-col items-center justify-center gap-1 shrink-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/dimensions.svg" alt="" className="w-6 h-8" />
          </div>
        </div>
        <div
          ref={imageRef}
          className="bg-image-placeholder relative flex-1 min-w-0 self-start aspect-[657/677] rounded-2xl overflow-hidden"
        >
          <div className="absolute top-[27px] left-[27px]">
            <Badge variant="new-arrival" size="md">{badgeLabel}</Badge>
          </div>
          <button
            type="button"
            aria-label="Previous image"
            className="absolute left-[34px] top-1/2 -translate-y-1/2 w-[38px] h-[38px] rounded-md bg-white/[0.79] border border-[#bbbbbb] flex items-center justify-center"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/chevron-left.svg" alt="" className="w-4 h-4" />
          </button>
          <button
            type="button"
            aria-label="Next image"
            className="absolute right-[34px] top-1/2 -translate-y-1/2 w-[38px] h-[38px] rounded-md bg-white/[0.79] border border-[#bbbbbb] flex items-center justify-center"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/chevron-right.svg" alt="" className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export interface PDPGalleryMobileProps {
  thumbnailCount?: number;
  badgeLabel?: string;
  wishlistCount?: number;
  activeDot?: number;
  dotCount?: number;
}

export function PDPGalleryMobile({
  thumbnailCount = 6,
  badgeLabel = "New Arrival",
  wishlistCount = 249,
  activeDot = 1,
  dotCount = 8,
}: PDPGalleryMobileProps) {
  return (
    <div className="flex flex-col gap-5 w-full max-w-sm font-sans">
      <div className="bg-image-placeholder relative rounded-2xl overflow-hidden aspect-[335/372]">
        <div className="absolute top-2.5 left-2.5">
          <Badge variant="new-arrival">{badgeLabel}</Badge>
        </div>
        <div className="absolute top-2.5 right-2.5 flex items-center gap-2.5 rounded-pill bg-[#e8e8e8] px-1.5 py-1.5">
          <svg viewBox="0 0 23.62495231628418 21" className="w-[17px] h-[15px]" fill="none" stroke="#3F3D3E">
            <path d={HEART_PATH} />
          </svg>
          <span className="text-xs text-charcoal">{wishlistCount}</span>
        </div>
        <div className="absolute bottom-[17px] left-1/2 -translate-x-1/2 flex items-center gap-1">
          {Array.from({ length: dotCount }).map((_, i) => (
            <span
              key={i}
              className={`w-2.5 h-2.5 rounded-full border border-[#e8e8e8] ${i === activeDot ? "bg-[#e8e8e8]" : ""}`}
            />
          ))}
        </div>
      </div>

      <div className="no-scrollbar flex gap-1 overflow-x-auto">
        {Array.from({ length: thumbnailCount }).map((_, i) => (
          <div
            key={i}
            className="bg-image-placeholder w-[62px] h-[61px] rounded-lg border border-[#e8e8e8] shrink-0"
          />
        ))}
      </div>
    </div>
  );
}
