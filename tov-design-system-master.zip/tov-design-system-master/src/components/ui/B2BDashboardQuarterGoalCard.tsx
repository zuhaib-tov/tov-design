/**
 * TOV B2B Dashboard / Quarter Goal Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 46:486, Dashboard page, Organisms
 * section. A 400x375 card holding a semi-circle progress gauge — a brand
 * rose arc drawn over a blush track — with the percentage centered beneath
 * it and an "All goals" link with a trailing arrow.
 */
function Gauge({ value }: { value: number }) {
  const radius = 90;
  const circumference = Math.PI * radius;
  const progress = Math.max(0, Math.min(100, value));
  const dash = (progress / 100) * circumference;

  return (
    <svg viewBox="0 0 210 110" className="h-[110px] w-[210px]" aria-hidden>
      <path
        d="M 15 100 A 90 90 0 0 1 195 100"
        fill="none"
        stroke="#f9d2d2"
        strokeWidth="14"
        strokeLinecap="round"
      />
      <path
        d="M 15 100 A 90 90 0 0 1 195 100"
        fill="none"
        stroke="#b15a63"
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray={`${dash} ${circumference}`}
      />
    </svg>
  );
}

export function B2BDashboardQuarterGoalCard({
  value = 84,
  className = "",
}: {
  value?: number;
  className?: string;
}) {
  return (
    <div className={`flex h-[375px] w-[400px] flex-col items-center justify-center gap-2 rounded-[16px] border border-[#e8e8e8] bg-white p-6 font-sans ${className}`}>
      <span className="text-base font-medium text-charcoal">Quarter goal</span>
      <div className="relative flex h-[110px] w-[210px] items-center justify-center">
        <Gauge value={value} />
        <span className="absolute top-[63px] text-center text-[32px] text-charcoal">
          {value}%
        </span>
      </div>
      <div className="flex items-center gap-1 pt-3">
        <span className="text-sm font-bold text-charcoal">All goals</span>
        <svg viewBox="0 0 14 14" className="size-[14px]" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M3 11 11 3M5 3h6v6" />
        </svg>
      </div>
    </div>
  );
}
