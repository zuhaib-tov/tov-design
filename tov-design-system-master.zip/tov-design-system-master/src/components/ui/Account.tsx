import { Button } from "./Button";
import { MainNavDesktop, MainNavMobile } from "./MainNav";
import { FooterDesktop, FooterMobile } from "./Footer";

/**
 * The customer "Account" components (fileKey DTjIdCKhnDUVvJhEfpn10v, canvas
 * "👤 Account Components", node 1777:1912). The Figma page is modeled on
 * the live Shopify-hosted customer account on tovfurniture.com (Orders +
 * Profile), restyled with this file's own tokens. Every set is still
 * `Status=Draft` in Figma, since the live site hasn't been redesigned to
 * match yet.
 *
 * - Cards: white, 16px radius (`Radius/3`), 24px padding Desktop / 16px
 *   Mobile, 640px / 343px wide.
 * - Section titles: 22px/25px GT Ultra Fine (`H-7 V2`). Welcome heading:
 *   26px/30px (`H-6 V2`).
 * - Body: Montserrat 18/24 (`B-1`), 16/19 (`B-2`), 14/16 (`B-3`), 12/14
 *   (`B-4`); primary text `#3F3D3E` (charcoal), secondary `#777777`
 *   (`Neutral/700`), dividers `#E8E8E8` (`Neutral/200`).
 * - Page background `#F1ECE5` (`Soft taupe` = `cream-200`).
 *
 * `AccountOrderCard` and the `saved` state of `AccountAddresses` weren't
 * verifiable against the live site, because the reference account has no
 * orders or saved addresses — both follow the standard Shopify customer
 * account layout instead.
 */

type Viewport = { compact?: boolean };

const cardPad = (compact?: boolean) => (compact ? "p-card-padding-sm" : "p-card-padding-md");
const cardWidth = (compact?: boolean) => (compact ? "w-[343px]" : "w-[640px]");

/** "Account Button - small" (1778:6) — the Small button (33px tall, 12/14): Primary when filled, Tertiary when outlined. */
export function AccountButtonSmall({ label, filled = false }: { label: string; filled?: boolean }) {
  return (
    <Button size="sm" variant={filled ? "primary" : "tertiary"}>
      {label}
    </Button>
  );
}

/** "Account Toggle" (1778:11) — 40×24 track, 18px white knob inset 3px. On = charcoal, Off = `#E8E8E8`. */
export function AccountToggle({ on = true }: { on?: boolean }) {
  return (
    <span
      role="switch"
      aria-checked={on}
      className={`relative inline-block w-10 h-6 rounded-pill shrink-0 ${on ? "bg-charcoal" : "bg-[#e8e8e8]"}`}
    >
      <span className={`absolute top-[3px] w-[18px] h-[18px] rounded-full bg-white ${on ? "left-[19px]" : "left-[3px]"}`} />
    </span>
  );
}

const NAV_ITEMS = ["Home", "Orders", "Profile", "Logout"] as const;

/**
 * "Account Nav" (1778:32) — same 4 links as the live account. Desktop is a
 * left rail (18px, 12px gap), Mobile a row (14px, 24px gap). Current page:
 * SemiBold charcoal (+ underline on Mobile); the rest `#777`.
 */
export function AccountNav({ active, compact }: { active: "Orders" | "Profile" } & Viewport) {
  return (
    <nav className={compact ? "flex gap-6" : "flex flex-col gap-3"}>
      {NAV_ITEMS.map((label) => {
        const on = label === active;
        return (
          <a
            key={label}
            href="#"
            className={`${compact ? "text-sm leading-4" : "text-lg leading-6"} ${
              on ? `font-semibold text-charcoal ${compact ? "underline" : ""}` : "text-neutral-700"
            }`}
          >
            {label}
          </a>
        );
      })}
    </nav>
  );
}

/** "Account Points Banner" (1778:41) — TOV Points message + "View ways to earn". Stacks on Mobile. */
export function AccountPointsBanner({ compact }: Viewport) {
  return (
    <div
      className={`bg-white rounded-app-md gap-4 ${cardPad(compact)} ${cardWidth(compact)} ${
        compact ? "flex flex-col items-start" : "flex items-center justify-between"
      }`}
    >
      <p className="text-sm leading-[21px] text-charcoal">You&apos;ve got 0 TOV Points. Earn more to redeem rewards.</p>
      <AccountButtonSmall label="View ways to earn" />
    </div>
  );
}

/** "Account Welcome Card" (1778:56) — the Orders empty state. Uses the real primary `Button` (Figma "Button - large" 244×54); full-width on Mobile. */
export function AccountWelcomeCard({ name = "Customer", compact }: { name?: string } & Viewport) {
  return (
    <div
      className={`bg-white rounded-app-md gap-4 ${cardPad(compact)} ${cardWidth(compact)} ${
        compact ? "flex flex-col" : "flex items-center justify-between"
      }`}
    >
      <div className="flex flex-col gap-1">
        <h3 className="font-display text-[26px] leading-[30px] text-charcoal">Welcome, {name}</h3>
        <p className="text-base leading-6 text-neutral-700">Ready to shop?</p>
      </div>
      <Button size="lg" className={`h-[54px] ${compact ? "w-full" : "w-[244px]"}`}>
        Shop now
      </Button>
    </div>
  );
}

/**
 * "Account Order Card" (1778:196) — status dot (`#1FC16B`) + status + date,
 * 3 product thumbnails (96px Desktop / 72px Mobile, 8px radius), order
 * number, item count + total, "View order". Standard Shopify structure, not
 * verified live (see file header).
 */
export function AccountOrderCard({ compact }: Viewport) {
  const thumb = compact ? "w-[72px] h-[72px]" : "w-24 h-24";
  return (
    <div className={`bg-white rounded-app-md flex flex-col gap-4 ${cardPad(compact)} ${cardWidth(compact)}`}>
      <div className="flex items-center gap-2 text-sm leading-4">
        <span className="w-2 h-2 rounded-full bg-success" />
        <span className="font-semibold text-charcoal">Delivered</span>
        <span className="text-neutral-700">Sep 12, 2026</span>
      </div>
      <div className="flex gap-2">
        {[0, 1, 2].map((i) => (
          <div key={i} className={`bg-image-placeholder rounded-md ${thumb}`} />
        ))}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-sm leading-4 text-neutral-700">Order #TOV0000</span>
          <span className="text-base leading-[19px] text-charcoal">3 items · $0000</span>
        </div>
        <AccountButtonSmall label="View order" />
      </div>
    </div>
  );
}

function SectionHeader({ title, action }: { title: string; action?: string }) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="font-display text-[22px] leading-[25px] text-charcoal">{title}</h3>
      {action && <AccountButtonSmall label={action} />}
    </div>
  );
}

/** "Account Contact Info" (1778:221) — name + Edit, then Email / Phone rows (label left, value right on Desktop; stacked on Mobile). */
export function AccountContactInfo({ compact }: Viewport) {
  const rows = [
    ["Email", "name@email.com"],
    ["Phone number", "+1 000-000-0000"],
  ];
  return (
    <div className={`flex flex-col gap-4 ${cardWidth(compact)}`}>
      <SectionHeader title="Customer name" action="Edit" />
      <div className="bg-white rounded-app-md overflow-hidden">
        {rows.map(([label, value], i) => (
          <div
            key={label}
            className={`py-card-padding-sm text-sm leading-4 ${compact ? "px-card-padding-sm flex flex-col gap-1" : "px-card-padding-md flex items-center justify-between"} ${
              i === 0 ? "border-b border-[#e8e8e8]" : ""
            }`}
          >
            <span className="text-neutral-700">{label}</span>
            <span className="text-charcoal">{value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * "Account Addresses" (1778:300) — `Empty` matches the live account (the
 * pin icon on a cream-200 tile + "No addresses added"). `saved` is the
 * standard Shopify filled state, not verified live. Icon is the approved
 * General-set `pin` (a pushpin, not the live site's map marker).
 */
export function AccountAddresses({ saved = false, compact }: { saved?: boolean } & Viewport) {
  return (
    <div className={`flex flex-col gap-4 ${cardWidth(compact)}`}>
      <SectionHeader title="Addresses" action="Add" />
      <div className={`bg-white rounded-app-md flex gap-4 ${saved ? "items-start" : "items-center"} ${cardPad(compact)}`}>
        <span className="bg-cream-200 rounded-md p-2 shrink-0">
          <img src="/icons/pin.svg" alt="" className="w-6 h-6" />
        </span>
        {saved ? (
          <>
            <div className="flex flex-col gap-1 flex-1 text-sm leading-4">
              <span className="font-semibold text-charcoal">Customer name</span>
              <span className="text-neutral-700">123 Street Address, Apt 4</span>
              <span className="text-neutral-700">City, ST 00000</span>
              <span className="text-neutral-700">United States</span>
              <span className="text-xs leading-[14px] text-charcoal underline">Default address</span>
            </div>
            <AccountButtonSmall label="Edit" />
          </>
        ) : (
          <span className="text-sm leading-4 text-neutral-700">No addresses added</span>
        )}
      </div>
    </div>
  );
}

/** "Account Marketing Preferences" (1778:236) — Email opt-in row with `AccountToggle`. */
export function AccountMarketingPreferences({ compact }: Viewport) {
  return (
    <div className={`flex flex-col gap-4 ${cardWidth(compact)}`}>
      <SectionHeader title="Marketing preferences" />
      <div className={`bg-white rounded-app-md flex items-center justify-between py-card-padding-sm ${compact ? "px-card-padding-sm" : "px-card-padding-md"}`}>
        <span className="text-sm leading-4 text-charcoal">Email</span>
        <AccountToggle on />
      </div>
    </div>
  );
}

/** "Account Sign Out" (1778:245) — "Sign out" pill + underlined "Sign out of all devices", 24px gap. */
export function AccountSignOut({ compact }: Viewport) {
  return (
    <div className={`flex items-center gap-6 ${cardWidth(compact)}`}>
      <AccountButtonSmall label="Sign out" />
      <a href="#" className="text-sm leading-4 text-charcoal underline">
        Sign out of all devices
      </a>
    </div>
  );
}

/**
 * Full account page, as composed in Figma ("Account - Orders / Desktop"
 * 1778:961, "Account - Orders Empty / …" 1778:1168, "Account - Profile / …"
 * 1778:1304, plus the Mobile trio 1778:1462 / 1778:1655 / 1778:1751): the
 * real Navbar + Footer around a cream-200 body. Desktop body: nav rail +
 * 640px content column, 120px apart, centered, 56px top / 120px bottom
 * padding. Mobile body: 16px sides, 24px top / 56px bottom, nav row above
 * content. Content gap is 16px on Orders, 40px (Desktop) / 32px (Mobile) on
 * Profile.
 */
export function AccountPageLayout({
  page,
  empty = false,
  compact,
}: { page: "Orders" | "Profile"; empty?: boolean } & Viewport) {
  const content =
    page === "Orders" ? (
      <div className="flex flex-col gap-4">
        <AccountPointsBanner compact={compact} />
        {empty ? (
          <AccountWelcomeCard compact={compact} />
        ) : (
          <>
            <AccountOrderCard compact={compact} />
            <AccountOrderCard compact={compact} />
          </>
        )}
      </div>
    ) : (
      <div className={`flex flex-col ${compact ? "gap-8" : "gap-10"}`}>
        <AccountContactInfo compact={compact} />
        <AccountAddresses compact={compact} />
        <AccountMarketingPreferences compact={compact} />
        <AccountSignOut compact={compact} />
      </div>
    );

  if (compact) {
    return (
      <div className="w-[375px] bg-cream-200">
        <MainNavMobile />
        <div className="px-4 pt-6 pb-14 flex flex-col gap-6">
          <AccountNav active={page} compact />
          {content}
        </div>
        <FooterMobile />
      </div>
    );
  }
  return (
    <div className="w-[1440px] bg-cream-200">
      <MainNavDesktop />
      <div className="flex justify-center items-start gap-[120px] pt-14 pb-[120px]">
        <AccountNav active={page} />
        {content}
      </div>
      <FooterDesktop />
    </div>
  );
}
