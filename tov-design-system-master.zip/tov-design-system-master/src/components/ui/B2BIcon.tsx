import { ReactNode } from "react";

/**
 * TOV B2B benefit icon set — Figma Core/Icon component set (node 14:59),
 * 4 supplied variants (Book Library, Shield, Delivery Truck, Pencil Edit).
 * Each is a 24×24 outline glyph, 1.5–2px stroke, meant to pair with a short
 * text label for benefit messaging. The component set's own fill is the
 * brand mauve — used here as the default circular background.
 */
export type B2BIconName = "book-library" | "shield" | "delivery-truck" | "pencil-edit";

const PATHS: Record<B2BIconName, ReactNode> = {
  "book-library": (
    <>
      <path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z" />
      <path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H13v16h5.5a1.5 1.5 0 0 0 1.5-1.5v-13Z" />
      <path d="M11 4v16" />
    </>
  ),
  shield: (
    <path d="M12 3 5 5.8v5.4c0 5 3 8.6 7 9.8 4-1.2 7-4.8 7-9.8V5.8L12 3Z" />
  ),
  "delivery-truck": (
    <>
      <path d="M2.5 7.5h12v9h-12z" />
      <path d="M14.5 10.5h3.6l3.4 3.4v2.6h-7z" />
      <circle cx="7" cy="18" r="1.8" />
      <circle cx="18" cy="18" r="1.8" />
    </>
  ),
  "pencil-edit": (
    <>
      <path d="M4 20l.9-4.3L15.6 5 19 8.4 8.3 19.1 4 20Z" />
      <path d="M13.8 6.2 17.8 10.2" />
    </>
  ),
};

export function B2BIcon({
  name,
  size = 24,
  withBackground = false,
  className = "",
}: {
  name: B2BIconName;
  size?: number;
  withBackground?: boolean;
  className?: string;
}) {
  const glyph = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {PATHS[name]}
    </svg>
  );

  if (!withBackground) return glyph;

  return (
    <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-white">
      {glyph}
    </span>
  );
}
