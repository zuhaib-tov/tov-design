/**
 * Marketing email "Image Grid" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1754:473) — Draft. Pure 2x2 photo grid, no text/CTA. Cell radius is 24px
 * desktop / 16px mobile.
 */
function GridCell({ className = "" }: { className?: string }) {
  return <div className={`bg-image-placeholder ${className}`} />;
}

export function MarketingImageGridDesktop() {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex flex-col gap-grid-gutter-sm">
      <div className="flex gap-grid-gutter-sm">
        <GridCell className="w-[270px] h-[279px] rounded-[24px]" />
        <GridCell className="w-[270px] h-[279px] rounded-[24px]" />
      </div>
      <div className="flex gap-grid-gutter-sm">
        <GridCell className="w-[270px] h-[279px] rounded-[24px]" />
        <GridCell className="w-[270px] h-[279px] rounded-[24px]" />
      </div>
    </div>
  );
}

export function MarketingImageGridMobile() {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex flex-col gap-grid-gutter-sm">
      <div className="flex gap-grid-gutter-sm">
        <GridCell className="w-[172.5px] h-[178px] rounded-[16px]" />
        <GridCell className="w-[172.5px] h-[178px] rounded-[16px]" />
      </div>
      <div className="flex gap-grid-gutter-sm">
        <GridCell className="w-[172.5px] h-[178px] rounded-[16px]" />
        <GridCell className="w-[172.5px] h-[178px] rounded-[16px]" />
      </div>
    </div>
  );
}
