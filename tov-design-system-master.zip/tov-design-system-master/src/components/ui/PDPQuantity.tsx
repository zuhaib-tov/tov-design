/**
 * The PDP "Quantity" stepper (fileKey ySZYmjbO2Wck8u1JGAtI5J, node 15:5671,
 * "Version=Quantity, Viewport=All, Status=Live" — universal).
 *
 * The pill is 111px wide, 10px side padding, 9px between the minus glyph,
 * the count and the plus glyph. Each glyph sits in a 31px target and is a
 * 10.3px line drawn at a 1.72px stroke; the count is Montserrat Bold 10.33px.
 * The stepper is shared with the mobile fixed Add to Cart bar, which uses the
 * same pill at a 49px height.
 */
export interface PDPQuantityStepperProps {
  value: number;
  /** Pill height: 40px in the Quantity component, 49px in the mobile fixed Add to Cart bar. */
  height?: 40 | 49;
  className?: string;
}

const GLYPH = 10.33;
const STROKE = 1.72;

export function PDPQuantityStepper({ value, height = 40, className = "" }: PDPQuantityStepperProps) {
  return (
    <div
      className={`inline-flex shrink-0 items-center justify-center gap-[9px] rounded-pill bg-charcoal/[0.07] px-2.5 font-sans ${className}`}
      style={{ width: 111, height }}
    >
      <button type="button" aria-label="Decrease quantity" className="flex h-[31px] w-[31px] items-center justify-center">
        <svg width={GLYPH} height={GLYPH} viewBox={`0 0 ${GLYPH} ${GLYPH}`} fill="none" stroke="#3F3D3E" strokeWidth={STROKE} strokeLinecap="round" aria-hidden="true">
          <path d={`M${STROKE / 2} ${GLYPH / 2}H${GLYPH - STROKE / 2}`} />
        </svg>
      </button>
      <span className="w-[11px] text-center text-[10.33px] font-bold leading-[18px] text-ink">{value}</span>
      <button type="button" aria-label="Increase quantity" className="flex h-[31px] w-[31px] items-center justify-center">
        <svg width={GLYPH} height={GLYPH} viewBox={`0 0 ${GLYPH} ${GLYPH}`} fill="none" stroke="#3F3D3E" strokeWidth={STROKE} strokeLinecap="round" aria-hidden="true">
          <path d={`M${STROKE / 2} ${GLYPH / 2}H${GLYPH - STROKE / 2}M${GLYPH / 2} ${STROKE / 2}V${GLYPH - STROKE / 2}`} />
        </svg>
      </button>
    </div>
  );
}

export interface PDPQuantityProps {
  value: number;
}

export function PDPQuantity({ value }: PDPQuantityProps) {
  return (
    <div className="flex flex-col gap-2 font-sans">
      <span className="text-sm leading-4 font-light text-ink">Quantity:</span>
      <PDPQuantityStepper value={value} />
    </div>
  );
}
