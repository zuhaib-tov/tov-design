/**
 * TOV B2B — Testimonial Card. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 8:72 ("Testimonial Card" symbol frame),
 * Default/Desktop (8:54, 409x290) and Default/Mobile (8:71, 350x218) variants.
 *
 * Customer quote with attribution and rating imagery. Use as social proof and
 * preserve the quotation, author and role as a single content unit.
 */
export interface B2BTestimonialCardProps {
  quote: string;
  name: string;
  role: string;
  /** Out of 5 — the real file always shows a full 5-star rating. */
  rating?: number;
  compact?: boolean;
  className?: string;
}

function RatingStars({ rating = 5 }: { rating?: number }) {
  return (
    <div className="flex gap-1" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 14 14" className="w-3.5 h-3.5">
          <path
            d="M7 1.2l1.8 3.7 4 .5-2.9 2.8.7 4-3.6-2-3.6 2 .7-4-2.9-2.8 4-.5z"
            fill="none"
            stroke={i < rating ? "#ccb583" : "#e3e3e3"}
            strokeWidth="1.2"
          />
        </svg>
      ))}
    </div>
  );
}

export function B2BTestimonialCard({
  quote,
  name,
  role,
  rating = 5,
  compact = false,
  className = "",
}: B2BTestimonialCardProps) {
  return (
    <div
      className={`bg-white border border-primary rounded-2xl flex flex-col ${
        compact ? "w-[350px] gap-4 p-6" : "w-[409px] gap-10 p-9"
      } ${className}`}
    >
      <RatingStars rating={rating} />
      <div className={`flex flex-col ${compact ? "gap-4" : "gap-6"}`}>
        <p className={`text-charcoal ${compact ? "text-[15px] font-light" : "text-lg leading-6"}`}>&ldquo;{quote}&rdquo;</p>
        <div className={`flex flex-col ${compact ? "gap-0.5" : "gap-1"}`}>
          <p className={`text-charcoal ${compact ? "text-sm font-semibold" : "text-base leading-[19px]"}`}>{name}</p>
          <p className={`text-primary ${compact ? "text-xs font-medium" : "text-base leading-[19px]"}`}>{role}</p>
        </div>
      </div>
    </div>
  );
}
