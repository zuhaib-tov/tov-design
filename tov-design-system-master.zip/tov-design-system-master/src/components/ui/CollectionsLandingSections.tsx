import { TextLink } from "./TextLink";
import { Button } from "./Button";

/**
 * Collections Landing — page-level sections mapped from the Figma file
 * "TOV26 - B2C - Explore collections LP" (fileKey `oO2Li1XutYUUAgUUs4f3lJ`),
 * canvas node `1:5` → section "Collections LP" (`6052:1798`) → "Explore
 * collections" Desktop (`6084:479`, 1440×5283) / Mobile (`6052:1385`,
 * 375×5391.6).
 *
 * Page structure: navbar → "Shop our featured collections" / "Featured
 * collections" heading → 4 repeats of [a full-bleed Collection Banner + a
 * row of 4/2 Product Cards] → a "Signature collections" heading + a row
 * (Desktop) / 2x2 grid (Mobile) of 4 smaller Collection Tiles → footer.
 * Navbar and Footer are the existing `MainNav`/`Footer`, reused as-is.
 *
 * A second, unrelated section on the same Figma canvas (`6135:1599`, also
 * named "Collections LP") holds a flat list of loose reference/duplicate
 * frames (Frame 1240, 1313, 1314, ...) — not additional page content, not
 * mapped here.
 *
 * The product grid reuses the existing Collection (PLP)
 * `PLPProductRowDesktop`/`PLPProductRowMobile` (4/2 `PLPProductCard`s)
 * as-is. This file's own product cards show round color-swatch dots (nodes
 * named "Frame 1277" with ellipse children) and real product photography
 * instead of `PLPProductCard`'s square swatches / checkered placeholder,
 * and no badge/tag pill at all — the existing card is reused unchanged
 * rather than forking a new variant over that difference.
 *
 * `CollectionBanner` (the big full-bleed module, 4x per page) and
 * `CollectionTile` (the smaller "Signature collections" grid variant) are
 * new components with no existing equivalent elsewhere in the system —
 * flagged **NEW / UNREVIEWED** below and on the doc page. Each Figma
 * collection banner uses its own bespoke display font for the collection
 * name (GT Ultra Fine Trial for "Cynthia", "Felix Titling" for "Amara",
 * "Spectral SC" for "Hump"/"Marlow") — none of the latter two are part of
 * this project's loaded font set, so both components use the existing
 * `font-display` (GT Ultra Fine stand-in) uniformly rather than pulling in
 * 2 more licensed fonts for an unreviewed component. Real title point sizes
 * also vary per collection instance (68–96px Desktop) — a fixed default is
 * used here rather than fully parameterizing it.
 *
 * Content anomalies in the source, reproduced or noted rather than
 * silently fixed:
 * - Desktop banner 2 ("Hump", node `6084:529`) has its collection-name text
 *   layer set to `opacity:0` in the source, invisible in Figma's own
 *   render (only the "collection" subtitle shows). Rendered here with the
 *   title visible instead, since an unreadable collection name serves no
 *   one — likely a Figma authoring bug, not reproduced literally.
 * - The Desktop banner's background photo for both the "The Cynthia
 *   Collection" slot (`6084:488`) and the "Amara" slot (`6097:473`) is the
 *   same source image — the beach-view dining-chairs photo that the
 *   separate individual-collection-page Figma file uses as Amara's own
 *   canonical hero photo. The Cynthia slot is very likely using the
 *   wrong/mislabeled photo, since its own product row directly below it
 *   correctly shows real Cynthia travertine-table products.
 * - Mobile repeats a broken banner (opacity-0 "Amara" title compositing the
 *   Cynthia + Hump background images, nodes `6052:1429` and `6128:1563`,
 *   identical to each other) in 2 of its 4 banner slots, and its 4th slot
 *   shows a visible "Marlow" title paired with real Amara product cards
 *   below it — Marlow never actually appears paired with its own products
 *   on Mobile. See the doc page callout.
 */

export interface CollectionBannerProps {
  image: string;
  name: string;
  subtitle?: string;
  ctaLabel?: string;
  compact?: boolean;
}

/**
 * Collection Banner — NEW / UNREVIEWED. Desktop: full-bleed image inset
 * 100px each side (1240×500 inside the 1440 outer frame), rounded 36px.
 * Mobile: full-bleed image inset 20px each side (335×400 inside the 375
 * outer frame), rounded 16px. Both: 33%-black overlay, centered white
 * name/subtitle, and a bordered (not filled) pill CTA.
 */
export function CollectionBanner({
  image,
  name,
  subtitle = "collection",
  ctaLabel = "Shop the collection",
  compact = false,
}: CollectionBannerProps) {
  return (
    <div
      className={
        compact
          ? "relative w-full h-[400px] mx-auto rounded-[16px] overflow-hidden flex flex-col items-center justify-end gap-[30px] px-5 pt-[100px] pb-5"
          : "relative w-full h-[500px] rounded-[36px] overflow-hidden flex flex-col items-center justify-center gap-2.5 px-[200px] pt-[270px]"
      }
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={image} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/[0.33]" />
      <div className="relative flex flex-col items-center gap-0.5 text-center text-white">
        <p className={`font-display ${compact ? "text-[26px] leading-[30px]" : "text-[68px] leading-[70px]"}`}>
          {name}
        </p>
        <p
          className={`font-sans font-light ${
            compact ? "text-[20px] leading-[20px]" : "text-[32px] leading-[70px]"
          }`}
        >
          {subtitle}
        </p>
      </div>
      <Button variant="inverse" size="lg" className="relative shrink-0">
        {ctaLabel}
      </Button>
    </div>
  );
}

export interface CollectionTileProps {
  image: string;
  name: string;
  ctaLabel?: string;
  compact?: boolean;
}

/**
 * Collection Tile — NEW / UNREVIEWED. The smaller "Signature collections"
 * grid variant of the same banner pattern. Desktop: 306.25×362, rounded
 * 36px, 4-up row. Mobile: full-width×190, rounded 16px, 2×2 grid. CTA copy
 * genuinely differs by viewport in the source — "Shop collection"
 * (Desktop) vs. lowercase "shop Now" (Mobile) — reproduced verbatim, not
 * unified.
 */
export function CollectionTile({ image, name, ctaLabel, compact = false }: CollectionTileProps) {
  const label = ctaLabel ?? (compact ? "shop Now" : "Shop collection");
  return (
    <div
      className={
        compact
          ? "relative w-full h-[190px] rounded-[16px] overflow-hidden flex items-end justify-center py-[21px]"
          : "relative w-full h-[362px] rounded-[36px] overflow-hidden flex items-end justify-center py-[21px]"
      }
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={image} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/20" />
      <div className="relative flex flex-col items-center gap-2 text-center text-white">
        <p className={`font-display ${compact ? "text-[22px] leading-[25px]" : "text-[26px] leading-[30px]"}`}>
          {name}
        </p>
        <TextLink href="#" inverse size={compact ? "sm" : "md"}>
          {label}
        </TextLink>
      </div>
    </div>
  );
}

/** Node `6084:486` (Desktop, 46px/50px) / `6052:1392` (Mobile, 22px/25px). */
export function CollectionsLandingHeading({ compact = false }: { compact?: boolean }) {
  return (
    <p className={`font-display text-charcoal ${compact ? "text-[22px] leading-[25px]" : "text-[46px] leading-[50px]"}`}>
      {compact ? "Featured collections" : "Shop our featured collections"}
    </p>
  );
}

/** Node `6084:696` (Desktop, 38px/42px) / `6052:1540` (Mobile, 26px/30px). */
export function SignatureCollectionsHeading({ compact = false }: { compact?: boolean }) {
  return (
    <p
      className={`font-display text-charcoal text-center ${
        compact ? "text-[26px] leading-[30px]" : "text-[38px] leading-[42px]"
      }`}
    >
      Signature collections
    </p>
  );
}
