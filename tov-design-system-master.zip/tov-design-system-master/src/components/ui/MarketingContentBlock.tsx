/**
 * Marketing email "Content Block" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1757:476) — Draft. Uses an OUTLINE button (transparent fill, charcoal
 * border) — confirmed against the real node's stroke, not the shared
 * Button.tsx system (whose "tertiary" variant has a cream fill, not a
 * transparent one). "Product Image" wraps content in a cream card;
 * "Room Shot" has no wrapper fill at all — a real structural difference.
 */
export interface MarketingContentBlockProps {
  headline?: string;
  body?: string;
  buttonLabel?: string;
}

function OutlineButton({ children }: { children: string }) {
  return (
    <button className="self-start rounded-pill border border-charcoal text-charcoal font-bold text-[12px] uppercase tracking-wide-ui px-8 py-4">
      {children}
    </button>
  );
}

export function MarketingContentBlockProductImageDesktop({
  headline = "The Riviera chair",
  body = "Hand-woven rattan frame, striped performance fabric, and a seat deep enough to sink into.",
  buttonLabel = "Shop the chair",
}: MarketingContentBlockProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="flex items-center gap-6 rounded-[36px] bg-cream-200 p-card-padding-md">
        <div className="bg-image-placeholder w-[230px] h-[198px] rounded-[24px] shrink-0" />
        <div className="flex flex-col gap-3">
          <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
          <p className="text-charcoal text-[16px] leading-[1.5]">{body}</p>
          <OutlineButton>{buttonLabel}</OutlineButton>
        </div>
      </div>
    </div>
  );
}

export function MarketingContentBlockProductImageMobile({
  headline = "The Riviera chair",
  body = "Hand-woven rattan frame, striped performance fabric, and a seat deep enough to sink into.",
  buttonLabel = "Shop the chair",
}: MarketingContentBlockProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="flex flex-col items-center gap-5 rounded-[24px] bg-cream-200 px-3 pt-3 pb-7">
        <div className="bg-image-placeholder w-full h-[363px] rounded-[20px]" />
        <div className="flex flex-col items-center text-center gap-3 px-3">
          <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
          <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
          <OutlineButton>{buttonLabel}</OutlineButton>
        </div>
      </div>
    </div>
  );
}

export function MarketingContentBlockRoomShotDesktop({
  headline = "Styled for long lunches",
  body = "Our Positano dining collection, set for eight under the pergola.",
  buttonLabel = "Shop the look",
}: MarketingContentBlockProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="flex items-center gap-6">
        <div className="bg-image-placeholder w-[265px] h-[229px] rounded-[24px] shrink-0" />
        <div className="flex flex-col gap-3">
          <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
          <p className="text-charcoal text-[16px] leading-[1.5]">{body}</p>
          <OutlineButton>{buttonLabel}</OutlineButton>
        </div>
      </div>
    </div>
  );
}

export function MarketingContentBlockRoomShotMobile({
  headline = "Styled for long lunches",
  body = "Our Positano dining collection, set for eight under the pergola.",
  buttonLabel = "Shop the look",
}: MarketingContentBlockProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="flex flex-col items-center gap-5">
        <div className="bg-image-placeholder w-full h-[390px] rounded-[20px]" />
        <div className="flex flex-col items-center text-center gap-3">
          <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
          <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
          <OutlineButton>{buttonLabel}</OutlineButton>
        </div>
      </div>
    </div>
  );
}
