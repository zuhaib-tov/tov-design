import { PDPQuantityStepper } from "./PDPQuantity";

/**
 * The PDP "Sticky ATC" component — specifically "Version=Fixed ATC,
 * Viewport=Mobile, Status=Live" (fileKey ySZYmjbO2Wck8u1JGAtI5J, node
 * 13:193). The mobile fixed/floating bar: a white pill with 9px padding and a
 * soft shadow holding the shared quantity stepper (49px tall) and an Add to
 * Cart button whose label and price share one line (Bold label, Light price,
 * 12.5px, +4.5% tracking).
 */
export interface PDPStickyAddToCartProps {
  quantity?: number;
  label?: string;
  price: string;
}

export function PDPStickyAddToCart({ quantity = 1, label = "Add to cart", price }: PDPStickyAddToCartProps) {
  return (
    <div className="flex w-[343px] max-w-full items-center gap-[3.5px] rounded-pill bg-white p-[9px] font-sans shadow-[0_0_19.5px_rgba(0,0,0,0.18)]">
      <PDPQuantityStepper value={quantity} height={49} />
      <button
        type="button"
        className="flex h-[49px] min-w-0 flex-1 items-center justify-center whitespace-nowrap rounded-pill border border-charcoal bg-charcoal px-[18px] text-[12.5px] leading-none tracking-wide-ui text-white"
      >
        <span className="font-bold uppercase">{label}</span>
        <span className="whitespace-pre font-light"> - {price}</span>
      </button>
    </div>
  );
}
