"use client";

import { useState } from "react";

/**
 * TOV B2B Dashboard / View Toggle — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 39:134. Grid / list layout
 * switch for project views. Each option is a 30px square with a 6px radius and a
 * 30px glyph (2px strokes). Selected: white fill, 1px #dfd7ce border, charcoal
 * glyph. Unselected: no fill or border, sand (#9e8567) glyph.
 */
export type ViewMode = "grid" | "list";

export interface B2BDashboardViewToggleOptionProps {
  mode: ViewMode;
  selected?: boolean;
  onClick?: () => void;
  className?: string;
}

export function B2BDashboardViewToggleOption({
  mode,
  selected = false,
  onClick,
  className = "",
}: B2BDashboardViewToggleOptionProps) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      aria-label={mode === "grid" ? "Grid view" : "List view"}
      onClick={onClick}
      className={`relative box-border size-[30px] shrink-0 rounded-[6px] transition-colors ${
        selected
          ? "border border-[#dfd7ce] bg-white text-charcoal"
          : "border border-transparent text-[#9e8567] hover:text-charcoal"
      } ${className}`}
    >
      <svg
        width="30"
        height="30"
        viewBox="0 0 30 30"
        fill="none"
        aria-hidden
        className="absolute -left-px -top-px"
      >
        {mode === "grid" ? (
          <path
            d="M9.75 13.25H20.25M9.75 16.75H20.25M13.25 9.75V20.25M16.75 9.75V20.25M10.9167 9.75H19.0833C19.7277 9.75 20.25 10.2723 20.25 10.9167V19.0833C20.25 19.7277 19.7277 20.25 19.0833 20.25H10.9167C10.2723 20.25 9.75 19.7277 9.75 19.0833V10.9167C9.75 10.2723 10.2723 9.75 10.9167 9.75Z"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        ) : (
          <path
            d="M9.75 10.9163H9.75583M9.75 15.0001H9.75583M9.75 19.0839H9.75583M12.6667 10.9163H20.25M12.6667 15.0001H20.25M12.6667 19.0839H20.25"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        )}
      </svg>
    </button>
  );
}

export interface B2BDashboardViewToggleProps {
  value?: ViewMode;
  defaultValue?: ViewMode;
  onChange?: (mode: ViewMode) => void;
  className?: string;
}

export function B2BDashboardViewToggle({
  value,
  defaultValue = "grid",
  onChange,
  className = "",
}: B2BDashboardViewToggleProps) {
  const [inner, setInner] = useState<ViewMode>(defaultValue);
  const current = value ?? inner;
  const pick = (mode: ViewMode) => {
    if (value === undefined) setInner(mode);
    onChange?.(mode);
  };
  return (
    <div role="group" aria-label="Layout" className={`inline-flex items-center gap-2 ${className}`}>
      <B2BDashboardViewToggleOption mode="grid" selected={current === "grid"} onClick={() => pick("grid")} />
      <B2BDashboardViewToggleOption mode="list" selected={current === "list"} onClick={() => pick("list")} />
    </div>
  );
}
