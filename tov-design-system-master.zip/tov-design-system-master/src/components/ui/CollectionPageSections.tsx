import { Button } from "./Button";

/**
 * Collection — Individual Page — mapped from the Figma file "TOV26 - B2C -
 * Collections on TOV" (fileKey `9xYNBPcAsKBOCCGP5X6wJ9`), canvas node
 * `2159:2814` ("Collections design example") → Desktop frame "Colections - D"
 * (`2159:2815`, 1440×7098) / Mobile frame, also named "Colections - D" in
 * the source despite being 375px wide (`2159:3150`, 375×6021.7).
 *
 * Structure: navbar → a full-bleed Hero (real lifestyle photo + a
 * collection-specific display-font name + "collection" subtitle + a
 * description paragraph, all in one banner, no separate "Description"
 * block) → a product grid interleaved with lifestyle imagery (a 3-up row of
 * Product Cards on Desktop / repeating 2-up rows on Mobile, broken up by
 * full-width "Get the Look"-style lifestyle image blocks that are empty
 * image slots in this Figma file) → a 2-column "[Collection] + you / Shape
 * the Look" masonry image gallery + a "View more" button → footer.
 *
 * A hidden duplicate hero frame (`2159:2817`) sits alongside the real
 * visible hero (`2159:2824`) — an abandoned earlier draft (an oversized
 * 339px title, mismatched centering math, a different cream tint),
 * excluded here.
 *
 * The product grid reuses the existing Collection (PLP)
 * `PLPProductRowDesktop`/`PLPProductRowMobile` as-is. This file's cards show
 * round color-swatch dots and real product photography instead of
 * `PLPProductCard`'s square swatches/checkered placeholder, and no badge/tag
 * pill (they also reuse a real `Likes button`/`Tag` component instance in a
 * couple of spots, unlike the Landing file's raw ellipses) — see
 * `CollectionsLandingSections.tsx` for the same reuse-over-fork note. The
 * hero's photo is the same source image as Collections Landing's "Amara"
 * banner photo — see that file's note on the probable mislabel there.
 *
 * `CollectionHero`, `CollectionLookbookBlock`, and `CollectionShapeTheLook`
 * are new components with no existing equivalent — flagged **NEW /
 * UNREVIEWED** below and on the doc page. The masonry "Shape the Look"
 * gallery (7 image cells of varying height across 2 columns in the source,
 * `2159:3481`) is simplified here to a uniform 2-column grid of placeholder
 * cells rather than reproducing each cell's exact pixel height.
 */

export interface CollectionHeroProps {
  image: string;
  name?: string;
  subtitle?: string;
  description?: string;
  compact?: boolean;
}

/**
 * Collection Hero — NEW / UNREVIEWED. Node `2159:2824` (Desktop, 1440×578)
 * / `2159:3152` (Mobile, 375×578) — full-bleed real lifestyle photo, 33%
 * black overlay, centered white name/subtitle/description, no CTA button
 * (unlike the Landing page's banners). The source's "Felix Titling" name
 * treatment is approximated with this project's own `font-display` token
 * (same substitution as `CollectionBanner`).
 */
export function CollectionHero({
  image,
  name = "Amara",
  subtitle = "collection",
  description = "Warm, textural, and effortlessly inviting. From the dining room to the bedroom, living room, entryway, and office, every piece is designed to feel curated.",
  compact = false,
}: CollectionHeroProps) {
  return (
    <div
      className={
        compact
          ? "relative w-full h-[578px] overflow-hidden flex flex-col items-center justify-center gap-2.5 px-5 pt-[270px]"
          : "relative w-full h-[578px] overflow-hidden flex flex-col items-center justify-center gap-2.5 px-[200px] pt-[270px]"
      }
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={image} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/[0.33]" />
      <div className="relative flex flex-col items-center gap-2.5 text-center text-white">
        <div className="flex flex-col items-center gap-0.5">
          <p className={`font-display ${compact ? "text-[63px] leading-[46px]" : "text-[96px] leading-[70px]"}`}>
            {name}
          </p>
          <p className={`font-sans font-light ${compact ? "text-[22px]" : "text-[32px] leading-[70px]"}`}>
            {subtitle}
          </p>
        </div>
        <p className={`font-sans max-w-[860px] ${compact ? "text-[18px] leading-[27px]" : "text-[22px] leading-[26px]"}`}>
          {description}
        </p>
      </div>
    </div>
  );
}

/**
 * Collection Lookbook Block — NEW / UNREVIEWED. The full-width lifestyle
 * image slot interleaved with the product grid (Desktop node `2159:2872`
 * area, Mobile `2159:3211`/`2159:3295` etc.) — genuinely empty/unfilled in
 * the Figma source (no photo dropped in), reproduced here with the
 * project's standard `.bg-image-placeholder` rather than inventing a photo.
 */
export function CollectionLookbookBlock({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={
        compact
          ? "w-full h-[474px] rounded-[36px] bg-image-placeholder"
          : "w-full h-[525px] rounded-[36px] bg-image-placeholder"
      }
    />
  );
}

/**
 * Collection "Shape the Look" — NEW / UNREVIEWED. Node `2159:3481`
 * (Mobile) / `2159:2830`+ area (Desktop) — a 2-column masonry gallery
 * headed "[Collection] + you" / "Shape the Look", ending in a bordered
 * "View more" button (reuses the existing `Button` `tertiary` variant, a
 * close match to the source's outlined pill). Simplified to a uniform grid
 * of 6 placeholder cells rather than the source's 7 cells of varying
 * height — see this file's header comment.
 */
export function CollectionShapeTheLook({ collectionName = "Amara", compact = false }: { collectionName?: string; compact?: boolean }) {
  return (
    <div className={compact ? "w-full flex flex-col gap-5 px-page-margin-mobile py-10" : "w-full flex flex-col gap-6 px-page-margin-desktop py-16"}>
      <div className="flex flex-col items-center gap-1 text-center">
        <p className={`font-display text-charcoal ${compact ? "text-[26px] leading-[30px]" : "text-[38px] leading-[42px]"}`}>{collectionName} + you</p>
        <p className="text-sm text-ink-muted">Shape the Look</p>
      </div>
      <div className="grid grid-cols-2 gap-grid-gutter-md">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className={`bg-image-placeholder rounded-app-md ${i % 3 === 1 ? "aspect-[160/265]" : "aspect-[160/207]"}`}
          />
        ))}
      </div>
      <Button variant="tertiary" size="lg" className="mx-auto">
        View more
      </Button>
    </div>
  );
}
