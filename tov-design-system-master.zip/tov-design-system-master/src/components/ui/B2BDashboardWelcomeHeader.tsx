/**
 * TOV B2B Dashboard / Welcome Header — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:450, Dashboard page, Organisms
 * section. The Overview page's greeting: a "Welcome back, [company name]"
 * headline (the source file leaves the company name as a literal merge
 * field) followed by a row of four Dashboard/KPI Card instances — Active
 * Orders, Orders, Spend, Saved Items, each with a value and a trailing
 * arrow link — and a "+ Place new order" link at the row's end.
 */
const KPIS = [
  { label: "Active Orders", value: "12" },
  { label: "Orders", value: "54" },
  { label: "Spend", value: "$12k" },
  { label: "Saved Items", value: "34" },
];

function ArrowGlyph() {
  return (
    <span className="flex size-[22px] shrink-0 items-center justify-center rounded-full bg-charcoal">
      <svg viewBox="0 0 14 14" className="size-[9px]" fill="none" stroke="white" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M3 11 11 3M5 3h6v6" />
      </svg>
    </span>
  );
}

export function B2BDashboardWelcomeHeader({
  companyName = "Holloway Design Studio",
  className = "",
}: {
  companyName?: string;
  className?: string;
}) {
  return (
    <div className={`flex w-[1000px] flex-col items-start gap-4 font-sans ${className}`}>
      <p className="whitespace-nowrap text-4xl font-bold text-charcoal">
        Welcome back, <span className="font-light">{companyName}</span>
      </p>
      <div className="flex w-full items-center gap-[10px]">
        {KPIS.map((kpi) => (
          <div
            key={kpi.label}
            className="flex w-[192px] flex-col items-start justify-center gap-[10px] rounded-[16px] border-[0.5px] border-[#e0e0e0] bg-white p-3"
          >
            <span className="text-[15px] font-bold text-charcoal">{kpi.label}</span>
            <div className="flex items-end justify-end gap-3">
              <span className="text-2xl font-bold text-[#777]">{kpi.value}</span>
              <ArrowGlyph />
            </div>
          </div>
        ))}
        <div className="flex-1" />
        <span className="whitespace-nowrap text-sm font-bold uppercase tracking-wide-ui text-charcoal">
          + Place new order
        </span>
      </div>
    </div>
  );
}
