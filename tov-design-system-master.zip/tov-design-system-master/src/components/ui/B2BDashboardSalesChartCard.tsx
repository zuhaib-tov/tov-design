/**
 * TOV B2B Dashboard / Sales Chart Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 46:473, Dashboard page, Organisms
 * section. A year-to-date sales area chart (580px card): a "Yearly to Date
 * Sales" heading with a one-line description, a "Monthly Sales" area plot
 * with gridlines at 0/10k/20k/50k/100k against Jan–Aug month ticks, and two
 * Dashboard/Stat Pill highlights below the plot ("Top Month" and "Top Sale").
 * The area fills from a solid rose at the curve's peaks to white near zero.
 */
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"];
// Approximate monthly values (in thousands) read off the real plot —
// a dip into May before the back half of the year climbs to its August peak.
const VALUES = [8, 16, 40, 56, 9, 16, 55, 88];

function buildAreaPath(values: number[], width: number, height: number) {
  const max = 100;
  const points = values.map((v, i) => {
    const x = (i / (values.length - 1)) * width;
    const y = height - (v / max) * height;
    return [x, y];
  });
  const line = points.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;
  return { line, area };
}

export function B2BDashboardSalesChartCard({
  topMonth = "Aug",
  topMonthYear = "2026",
  topSaleValue = "50K",
  topSaleCaption = "96K sold so far",
  className = "",
}: {
  topMonth?: string;
  topMonthYear?: string;
  topSaleValue?: string;
  topSaleCaption?: string;
  className?: string;
}) {
  const plotWidth = 405;
  const plotHeight = 128;
  const { line, area } = buildAreaPath(VALUES, plotWidth, plotHeight);

  return (
    <div className={`flex w-[580px] flex-col items-start rounded-[16px] border border-[#e8e8e8] bg-white p-5 font-sans ${className}`}>
      <div className="flex w-full flex-col gap-[7px] text-[15px] text-charcoal">
        <span className="font-bold">Yearly to Date Sales</span>
        <span className="font-normal">Monthly sales trend for the current year (excluding cancelled orders)</span>
      </div>

      <div className="flex w-full flex-col items-center gap-2 p-6">
        <span className="text-center text-xs font-bold uppercase tracking-wide-ui text-charcoal">Monthly sales</span>
        <div className="relative h-40 w-full">
          <div className="absolute left-0 top-0 flex h-[129px] w-[38px] flex-col justify-between text-[10px] text-[#7d7d7d]">
            <span>100k</span>
            <span>50k</span>
            <span>20k</span>
            <span>10k</span>
            <span>0</span>
          </div>
          <svg
            viewBox={`0 0 ${plotWidth} ${plotHeight}`}
            className="absolute left-[43px] top-0 h-[129px] w-[405px] overflow-visible"
            preserveAspectRatio="none"
          >
            {[0, 1, 2, 3, 4].map((i) => (
              <line
                key={i}
                x1="0"
                x2={plotWidth}
                y1={(i / 4) * plotHeight}
                y2={(i / 4) * plotHeight}
                stroke="#efebe4"
              />
            ))}
            <defs>
              <linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#b15a63" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#b15a63" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={area} fill="url(#salesFill)" />
            <path d={line} fill="none" stroke="#b15a63" strokeWidth="2" strokeDasharray="1 5" strokeLinecap="round" />
          </svg>
          <div className="absolute left-[43px] top-[145px] flex w-[405px] justify-between text-[10px] text-[#7d7d7d]">
            {MONTHS.map((m) => (
              <span key={m}>{m}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="flex w-full gap-4">
        <div className="flex flex-1 items-center justify-center gap-[10px] whitespace-nowrap rounded-[16px] border border-[#e8e8e8] bg-white p-[10px]">
          <span className="text-xs uppercase tracking-wide-ui text-[#7d7d7d]">Top month</span>
          <div className="flex flex-1 items-end justify-end gap-[6px]">
            <span className="text-2xl font-bold text-[#777]">{topMonth}</span>
            <span className="text-base text-charcoal">{topMonthYear}</span>
          </div>
        </div>
        <div className="flex flex-1 items-center justify-center gap-[10px] whitespace-nowrap rounded-[16px] border border-[#e8e8e8] bg-white p-[10px]">
          <span className="text-xs uppercase tracking-wide-ui text-[#7d7d7d]">Top Sale</span>
          <div className="flex flex-1 items-end justify-end gap-[6px]">
            <span className="text-2xl font-bold text-[#777]">{topSaleValue}</span>
            <span className="text-base text-charcoal">{topSaleCaption}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
