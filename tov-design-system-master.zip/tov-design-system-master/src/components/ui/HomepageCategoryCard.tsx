/**
 * The Homepage "Category Cards" (fileKey DTjIdCKhnDUVvJhEfpn10v) — 4
 * separate Desktop component sets (Living Room `1063:1669`, Accent Chairs
 * `1063:1679`, Outdoor `1063:1692`, Storage `1063:1706`) that share one
 * shape: a full-bleed photo card with a black overlay and a bottom
 * white bold label. `Default` = Live; each set's Draft "2" variant adds a
 * "Shop Now" link under the label, not built here since it's not the live
 * content.
 *
 * Desktop cards are 302x338 with a 36px radius, a 20% black overlay, a
 * 20px label on a 32px line height and 20px of padding. Mobile Categories'
 * tiles use a 16px radius, a 26% overlay, a 12px underlined label on a 16px
 * line height and 10px of padding. All labels are upper-case, center-aligned
 * and use the shared all-caps tracking.
 *
 * The photo fills the card (`object-cover`, centered) and is looked up from
 * the label; pass `image` to use a different photo. Cards keep their Figma
 * width as a minimum, so a group of them keeps its real size inside a
 * shrink-to-fit container such as the docs Preview.
 *
 * Font family is a deliberate substitution: Figma specifies Gotham, this
 * project has no Gotham font file, so it renders in Montserrat — the same
 * substitute used project-wide, including on PDP.
 */
const CATEGORY_IMAGES: Record<string, string> = {
  "living room": "/images/homepage/categories/living-room.webp",
  "accent chairs": "/images/homepage/categories/accent-chairs.webp",
  outdoor: "/images/homepage/categories/outdoor.webp",
  storage: "/images/homepage/categories/storage.webp",
  "home office": "/images/homepage/categories/home-office.webp",
  bedroom: "/images/homepage/categories/storage.webp",
};

export interface HomepageCategoryCardProps {
  label: string;
  /** Desktop cards use a 20px label, no underline; Mobile Categories' tiles use 12px, underlined. */
  size?: "sm" | "lg";
  /** Photo URL. Defaults to the photo that belongs to the label. */
  image?: string;
  className?: string;
}

export function HomepageCategoryCard({ label, size = "lg", image, className = "" }: HomepageCategoryCardProps) {
  const src = image ?? CATEGORY_IMAGES[label.trim().toLowerCase()];
  const isSmall = size === "sm";
  return (
    <div
      className={`bg-image-placeholder relative overflow-hidden w-full ${
        isSmall ? "rounded-2xl aspect-[335/190] min-w-[335px]" : "rounded-[36px] aspect-[301.75/338] min-w-[301.75px]"
      } ${className}`}
    >
      {src && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" className="absolute inset-0 h-full w-full object-cover" />
      )}
      <div className={`absolute inset-0 ${isSmall ? "bg-black/[0.26]" : "bg-black/20"}`} />
      <p
        className={`absolute left-0 right-0 text-center font-bold uppercase tracking-wide-ui text-white ${
          isSmall ? "bottom-2.5 px-2.5 text-xs leading-4 underline" : "bottom-5 px-5 text-xl leading-8"
        }`}
      >
        {label}
      </p>
    </div>
  );
}
