import { ButtonHTMLAttributes } from "react";

/**
 * TOV B2B Dashboard / Pagination Item — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:666. Page-number button
 * for table pagination. Default: 13px Medium charcoal on transparent.
 * Active: brand-filled (#b15a63) with 13px Bold white. 12px x 6px padding,
 * 6px radius.
 */
export interface B2BDashboardPaginationItemProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  active?: boolean;
  /** Page number (or label) shown in the item. */
  children: React.ReactNode;
}

export function B2BDashboardPaginationItem({
  active = false,
  children,
  className = "",
  ...props
}: B2BDashboardPaginationItemProps) {
  return (
    <button
      type="button"
      aria-current={active ? "page" : undefined}
      className={`inline-flex items-center justify-center whitespace-nowrap rounded-[6px] px-3 py-[6px] font-sans text-[13px] transition-colors ${
        active
          ? "bg-primary font-bold text-white"
          : "font-medium text-charcoal hover:bg-cream-100"
      } ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
