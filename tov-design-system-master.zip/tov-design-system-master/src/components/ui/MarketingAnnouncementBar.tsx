/**
 * Marketing email "Announcement Bar" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1760:619) — Draft. Background is a raw #3f3d3e literal in Figma, not
 * bound to a variable, though it matches --color-charcoal — using the
 * token here rather than copying the hex.
 */
export interface MarketingAnnouncementBarProps {
  text?: string;
}

export function MarketingAnnouncementBarDesktop({
  text = "Notice of updated collections",
}: MarketingAnnouncementBarProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="rounded-[16px] bg-charcoal p-5 flex justify-center">
        <p className="text-white font-bold uppercase text-[16px] tracking-wide-ui text-center">
          {text}
        </p>
      </div>
    </div>
  );
}

export function MarketingAnnouncementBarMobile({
  text = "Notice of updated collections",
}: MarketingAnnouncementBarProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="rounded-[12px] bg-charcoal px-5 py-4 flex justify-center">
        <p className="text-white font-bold uppercase text-[12px] tracking-wide-ui text-center">
          {text}
        </p>
      </div>
    </div>
  );
}
