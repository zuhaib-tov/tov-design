/**
 * The site "Main Nav" (Navbar) component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1340:3009) — an 11-variant set:
 * - **Default** (Desktop `1340:3008` / Mobile `1341:3963`) — the base header at rest.
 * - **Navbar 3** (`1360:3882`) — the condensed/sticky desktop header shown on
 *   scroll: logo, primary nav, and search/wishlist/cart, with a drop shadow.
 * - **Condensed** (Mobile, `1360:3564`) — the same sticky-on-scroll idea for Mobile.
 * - **Navbar 6-11** — the primary nav's category mega-menu dropdowns
 *   (Furniture/Lighting/Decor & Tabletop/Outdoor/Wall Art & Mirrors/Sale)
 *   — see MegaMenu.tsx.
 *
 * Default Desktop (1440 x 202): a charcoal announcement bar (11/16 white,
 * with "10%" and "Free shipping" Bold in brand pink, split by a white 1 x 11
 * divider; 48 x 5 padding) above a white block with 20px top padding: the
 * main row (100px side padding, 21px gap, 20px bottom padding) holds the
 * 90 x 27 logo, a fixed 498px search pill (#F6F6F6, 1px #E8E8E8 border, 9px
 * padding, 18px grey search icon), and the profile/wishlist/cart icons
 * flush right as 42px tap targets. Two centered link rows follow, each with
 * a 0.5px #E8E8E8 top rule, 41px gaps, and 120px side padding: utility links
 * (10/14 Regular caps, 12px vertical padding) and the primary category nav
 * (12/14 Medium, 8px row padding plus 12px per link; "Sale" in `primary`).
 * All link text is charcoal.
 *
 * Default Mobile (375): the announcement bar (12/10, 20 x 10 padding), then
 * a row of menu, the 50.6 x 15.2 logo, and wishlist/cart (4px apart), and a
 * 36px search pill with "Search for accent chairs..." (10px, #8E8E8E).
 *
 * Icons and the logo are the Figma file's own exported assets
 * (`/brand/tov-logo-nav.svg`, `/icons/nav-*.svg`); `profile.svg` and
 * `menu.svg` already matched. All-caps link text carries the system's caps
 * tracking (+4.5%); Figma sets 0 there.
 *
 * The Desktop variants are 1440px wide in Figma and keep that as a minimum
 * width (as the Footer does), so the centered link rows never overlap the
 * logo or each other; the docs `Preview` box's `ScaleToFit` wrapper
 * measures that natural width and shrinks the whole nav to fit.
 */
const SECONDARY_LINKS = [
  "Best Sellers", "Get Inspired!", "Collections", "TOV Edits",
  "Collaborations", "Showrooms", "Design Box", "Trade Program",
];

export const PRIMARY_LINKS = [
  "New", "Furniture", "Rugs", "Lighting", "Decor & Tabletop",
  "Throw Pillows", "Outdoor", "Wall Art & Mirrors", "Sale",
];

/** Figma's neutral/200 rule color; the `neutral-200` token is a lighter #F0F0F0. */
const RULE = "border-[#e8e8e8]";

function AnnouncementBar() {
  return (
    <div className="bg-charcoal flex items-center justify-center px-12 py-[5px]">
      <div className="flex items-center gap-6 text-[11px] leading-4 text-white whitespace-nowrap">
        <p>
          Shop Sale: <span className="font-bold text-brand-pink">10%</span> off items $99+*
        </p>
        <span className="w-px h-[11px] bg-white" aria-hidden />
        <p>
          <span className="font-bold text-brand-pink">Free shipping</span> on orders of $299
        </p>
      </div>
    </div>
  );
}

function NavLogo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#" aria-label="TOV Furniture home" className="block shrink-0">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/brand/tov-logo-nav.svg"
        alt="TOV"
        className={compact ? "w-[50.643px] h-[15.21px]" : "w-[90.166px] h-[27.081px]"}
      />
    </a>
  );
}

function PrimaryLink({ label, active }: { label: string; active?: boolean }) {
  return (
    <a
      href="#"
      className={`py-3 text-xs leading-[14px] whitespace-nowrap ${active ? "font-bold" : "font-medium"} ${label === "Sale" ? "text-primary" : "text-charcoal"}`}
    >
      {label}
    </a>
  );
}

function PrimaryLinksRow({ activeLabel }: { activeLabel?: string }) {
  return (
    <nav aria-label="Shop" className={`flex h-[54px] items-center justify-center gap-[41px] px-[120px] border-t-[0.5px] ${RULE}`}>
      {PRIMARY_LINKS.map((label) => (
        <PrimaryLink key={label} label={label} active={label === activeLabel} />
      ))}
    </nav>
  );
}

function WishlistAndCart() {
  return (
    <>
      <a href="#" aria-label="Wishlist" className="block shrink-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/nav-favourite.svg" alt="" className="w-[44.25px] h-[42px]" />
      </a>
      {/* The cart artwork is 21px tall in a 20px box and overhangs it by 1px at the top, as in Figma. */}
      <a href="#" aria-label="Cart" className="flex shrink-0 items-center justify-center p-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/nav-cart.svg" alt="" className="w-[21.111px] h-[21px] -mt-px" />
      </a>
    </>
  );
}

/** Default Desktop — logo + always-visible search bar + profile/wishlist/cart icons. */
export function MainNavDesktop() {
  return (
    <header className="w-full min-w-[1440px] font-sans bg-cream-50">
      <AnnouncementBar />
      <div className="bg-white pt-5">
        <div className="flex items-center justify-center gap-[21px] px-[100px] pb-5">
          <div className="flex flex-1 min-w-0 items-center">
            <NavLogo />
          </div>
          <div className={`flex w-[498px] h-9 shrink-0 items-center rounded-pill bg-neutral-100 border ${RULE} px-[9px]`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/nav-search.svg" alt="" className="size-[18px]" />
            <span className="sr-only">Search</span>
          </div>
          <div className="flex flex-1 min-w-0 items-center justify-end">
            <a href="#" aria-label="Account" className="block shrink-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/profile.svg" alt="" className="w-[41.901px] h-[42px]" />
            </a>
            <WishlistAndCart />
          </div>
        </div>
        <div className={`flex h-[38px] items-center justify-center gap-[41px] px-[120px] border-t-[0.5px] ${RULE}`}>
          {SECONDARY_LINKS.map((label) => (
            <a key={label} href="#" className="text-[10px] leading-[14px] uppercase tracking-wide-ui text-charcoal whitespace-nowrap">
              {label}
            </a>
          ))}
        </div>
        <PrimaryLinksRow />
      </div>
    </header>
  );
}

/** Navbar 3 — condensed/sticky desktop header shown on scroll: logo + primary nav + search/wishlist/cart (no account icon). */
export function MainNavCondensed() {
  return (
    <header className="w-full min-w-[1440px] font-sans bg-white pt-5 shadow-[0_5px_2px_rgba(0,0,0,0.25)]">
      <div className="flex items-center justify-center gap-[21px] px-[100px] pb-5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/tov-logo-nav.svg" alt="TOV" className="w-[89.898px] h-[27px] shrink-0" />
        <nav aria-label="Shop" className="flex flex-1 min-w-0 items-center justify-center gap-[31px] px-[120px]">
          {PRIMARY_LINKS.map((label) => (
            <PrimaryLink key={label} label={label} />
          ))}
        </nav>
        <div className="flex shrink-0 items-center justify-end">
          <a href="#" aria-label="Search" className="flex w-11 h-[42px] shrink-0 items-center justify-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/nav-search-lg.svg" alt="" className="size-7" />
          </a>
          <WishlistAndCart />
        </div>
      </div>
    </header>
  );
}

function MobileMenuButton() {
  return (
    <div className="flex flex-1 min-w-0 items-center">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/icons/menu.svg" alt="Menu" className="w-6 h-[18px]" />
    </div>
  );
}

function MobileCart() {
  return (
    <a href="#" aria-label="Cart" className="flex w-[29.348px] shrink-0 items-center justify-center px-[5.318px] py-[10.636px]">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/icons/nav-cart-mobile.svg" alt="" className="w-[18.261px] h-[17.965px]" />
    </a>
  );
}

/** Default Mobile — announcement bar, menu/logo/wishlist/cart row, and the search pill. */
export function MainNavMobile() {
  return (
    <header className="w-[375px] font-sans bg-white flex flex-col gap-2.5 pb-2.5">
      <div className="bg-charcoal px-5 py-2.5">
        <p className="text-xs leading-[10px] text-white text-center">
          <span className="font-bold text-brand-pink">Free shipping</span> on orders $299+
        </p>
      </div>
      <div className="flex flex-col gap-[7px]">
        <div className="flex items-center justify-center gap-[21px] px-5">
          <MobileMenuButton />
          <div className="flex w-[65.111px] h-[18px] shrink-0 items-center justify-center">
            <NavLogo compact />
          </div>
          <div className="flex flex-1 min-w-0 items-center justify-end gap-1">
            <a href="#" aria-label="Wishlist" className="block shrink-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/nav-favourite-mobile.svg" alt="" className="w-[28.585px] h-[37.227px]" />
            </a>
            <MobileCart />
          </div>
        </div>
        <div className="px-5">
          <div className={`flex h-9 items-center rounded-pill bg-neutral-100 border ${RULE}`}>
            <span className="flex shrink-0 p-[9px]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/nav-search.svg" alt="" className="size-[18px]" />
            </span>
            <p className="flex-1 min-w-0 text-[10px] leading-[10px] text-[#8e8e8e]">Search for accent chairs...</p>
          </div>
        </div>
      </div>
    </header>
  );
}

/** Condensed (Mobile) — sticky-on-scroll: menu + logo + search/wishlist/cart, no promo bar or search pill. */
export function MainNavMobileCondensed() {
  return (
    <header className="w-[375px] font-sans bg-white py-2.5">
      <div className="flex items-center justify-center gap-[21px] px-5">
        <MobileMenuButton />
        <div className="flex w-[72.346px] h-5 shrink-0 items-center justify-center">
          <NavLogo compact />
        </div>
        <div className="flex flex-1 min-w-0 items-center justify-end gap-1">
          <a href="#" aria-label="Search" className="block shrink-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/nav-search-mobile.svg" alt="" className="size-[25px]" />
          </a>
          <a href="#" aria-label="Wishlist" className="block shrink-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/nav-favourite-mobile-condensed.svg" alt="" className="w-[28.585px] h-[26px]" />
          </a>
          <a href="#" aria-label="Cart" className="flex w-[29.348px] shrink-0 items-center justify-center p-[5px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/nav-cart-mobile.svg" alt="" className="w-[18.261px] h-[17.965px]" />
          </a>
        </div>
      </div>
    </header>
  );
}
