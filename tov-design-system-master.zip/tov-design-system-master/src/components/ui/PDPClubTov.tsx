import { PDPFittedImage, PDP_ICON_ART } from "./PDPFittedImage";

/**
 * The PDP "Club TOV" component (fileKey ySZYmjbO2Wck8u1JGAtI5J) — Desktop
 * uses "Version=Default, Viewport=All, Status=Draft" (node 105:793), Mobile
 * uses "Version=Club TOV, Viewport=Mobile, Status=Draft" (node 813:8190).
 * Both are Draft — no Live version exists yet. The message always stays on
 * one line: the points figure is bold, the rest regular. Desktop runs at 14px
 * with 10px/16px padding; Mobile at 12px with 4px/8px padding. The trophy
 * sits in a fixed container and fills the same share of it in both.
 */
export interface PDPClubTovProps {
  points: number;
  /** Mobile sizing (12px text, tighter padding) instead of Desktop (14px). */
  compact?: boolean;
}

export function PDPClubTov({ points, compact = false }: PDPClubTovProps) {
  const box: [number, number] = compact ? [16, 16] : [20, 20];
  return (
    <div
      className={`flex w-fit max-w-full items-center gap-2.5 whitespace-nowrap rounded-lg bg-brand-pink/[0.55] font-sans ${
        compact ? "px-2 py-1" : "px-4 py-2.5"
      }`}
    >
      <PDPFittedImage src="/icons/trophy.svg" box={box} fill={0.8} {...PDP_ICON_ART.trophy} />
      <p className={compact ? "text-xs leading-[19px] text-ink" : "text-sm leading-[19px] text-ink"}>
        <span className="font-bold">+{points.toLocaleString()}</span> TOV Points when you buy this
      </p>
    </div>
  );
}
