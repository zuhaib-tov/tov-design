/**
 * TOV B2B Dashboard / Stat Pill — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:39 → Version=Default (41:38),
 * 262px wide. Inline stat chip (label + value + suffix) used under charts.
 * White fill, 1px #e8e8e8 border, 16px radius, 10px padding, centered.
 */
export interface B2BDashboardStatPillProps {
  /** Uppercase label, e.g. "Top month". */
  label: string;
  /** Headline value, e.g. "Aug". */
  value: string;
  /** Secondary suffix shown beside the value, e.g. "2026". */
  suffix?: string;
  className?: string;
}

export function B2BDashboardStatPill({
  label,
  value,
  suffix,
  className = "",
}: B2BDashboardStatPillProps) {
  return (
    <div
      className={`inline-flex w-[262px] items-center justify-center gap-[10px] whitespace-nowrap rounded-app-md border border-neutral-200 bg-white p-[10px] ${className}`}
    >
      <p className="font-sans text-xs font-medium uppercase tracking-wide-ui text-[#7d7d7d]">{label}</p>
      <div className="flex flex-1 items-end justify-end gap-1.5">
        <p className="font-sans text-2xl font-bold text-neutral-700">{value}</p>
        {suffix && <p className="font-sans text-base font-normal text-charcoal">{suffix}</p>}
      </div>
    </div>
  );
}
