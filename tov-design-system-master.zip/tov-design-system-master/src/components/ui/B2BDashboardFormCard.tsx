/**
 * TOV B2B Dashboard / Form Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:724, Dashboard page, Organisms
 * section. A 515px editable account-settings section: a bold title over
 * rows of Dashboard/Text Field instances (an uppercase label above a
 * bordered input). Two real variants — Personal Information (first/last
 * name, email, phone) and Company Information (company name, job title,
 * website).
 */
function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex min-w-0 flex-1 flex-col gap-[6px]">
      <span className="whitespace-nowrap text-[11px] font-semibold uppercase tracking-wide-ui text-[#8e8e8e]">
        {label}
      </span>
      <div className="w-full rounded-[8px] border border-[#e0e0e0] bg-white px-4 py-3">
        <span className="whitespace-nowrap text-sm font-medium text-charcoal">{value}</span>
      </div>
    </div>
  );
}

export function B2BDashboardFormCard({
  variant = "personal",
  className = "",
}: {
  variant?: "personal" | "company";
  className?: string;
}) {
  return (
    <div className={`flex w-[515px] flex-col items-start gap-5 rounded-[12px] border border-[#e0e0e0] bg-white p-6 font-sans ${className}`}>
      {variant === "personal" ? (
        <>
          <span className="text-base font-bold text-charcoal">Personal Information</span>
          <div className="flex w-full gap-3">
            <Field label="First Name" value="Sarah" />
            <Field label="Last Name" value="Holloway" />
          </div>
          <Field label="Email Address" value="sarah.holloway@designstudio.com" />
          <Field label="Phone Number" value="(212) 555-0847" />
        </>
      ) : (
        <>
          <span className="text-base font-bold text-charcoal">Company Information</span>
          <Field label="Company Name" value="Holloway Design Studio" />
          <Field label="Job Title" value="Principal Designer" />
          <Field label="Company Website" value="www.hollowaydesign.com" />
        </>
      )}
    </div>
  );
}
