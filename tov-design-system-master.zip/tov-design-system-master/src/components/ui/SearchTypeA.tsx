/**
 * Search — Type A ("By product", ~55% of search volume per Figma's own
 * note) — fileKey DTjIdCKhnDUVvJhEfpn10v, node 1696:1360. 2 real variants:
 * Desktop (1696:1103) and Mobile (1696:1195). Single-column results grid,
 * no category left panel — Figma's own file has a "Search results by
 * category" sidebar frame present, but it's `opacity: 0` (invisible), so
 * it's omitted here.
 *
 * Real product photography (not empty placeholder fills like Homepage/PDP)
 * — every product image and the promo banner's lifestyle photo were
 * exported from Figma and saved under `public/images/search/`. Each
 * downloaded product image already has its "BEST SELLER" badge baked in
 * (Figma renders the badge instance as a child of the same image frame),
 * so no separate badge overlay is rendered in code.
 *
 * Desktop prices show $1,499 for every ottoman; Mobile shows $479 for the
 * same products — reproduced as Figma has it, not a code bug.
 */
import { SearchTopBar, MobileSearchTopBar, ResultsHeader, ResultsHeaderMobile, DesktopProductCard, MobileProductCard, PromoBanner, SeeAllProductsButton, type SearchProduct } from "./SearchShared";

const DESKTOP_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/ottoman-dex-mohair.jpg", title: "Dex Vegan Mohair Ottoman", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#9F7A3E", "#5E3F3F", "#601515", "#31463D"] },
  { image: "/images/search/ottoman-gertrude-yellow-gingham.jpg", title: "Gertrude Yellow Gingham Linen Skirted Ottoman", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#AF9881"] },
  { image: "/images/search/ottoman-gertrude-striped.jpg", title: "Gertrude Striped Linen Skirted Ottoman", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#E3D9C8", "#D8CCB6"] },
];

const MOBILE_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/ottoman-dex-mohair-sq.jpg", title: "Dex Vegan Mohair Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/ottoman-gertrude-yellow-gingham-sq.jpg", title: "Gertrude Yellow Gingham Linen Skirted Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/ottoman-gertrude-striped-sq.jpg", title: "Gertrude Striped Linen Skirted Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/ottoman-arezza-stone-white.jpg", title: "Arezza Stone White Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/ottoman-tomlin.jpg", title: "Tomlin Ottoman", price: "$479", materialTag: "Performance Fabric" },
  { image: "/images/search/ottoman-desi-woven-fabric.jpg", title: "Desi Woven Fabric Ottoman", price: "$479", materialTag: "Performance Fabric" },
];

export function SearchTypeADesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Ottomans" />
      <ResultsHeader query="Ottomans" />
      <div className="grid grid-cols-3 gap-grid-gutter-lg px-10 pb-10">
        {DESKTOP_PRODUCTS.map((p) => (
          <DesktopProductCard key={p.title} product={p} />
        ))}
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeAMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <ResultsHeaderMobile query="Ottomans" />
      <div className="grid grid-cols-2 gap-grid-gutter-md px-5 pb-6">
        {MOBILE_PRODUCTS.map((p) => (
          <MobileProductCard key={p.title} product={p} />
        ))}
      </div>
      <div className="px-5 pb-6">
        <SeeAllProductsButton />
      </div>
    </div>
  );
}
