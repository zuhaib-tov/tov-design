import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Nav Item — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 39:65. Sidebar navigation
 * row, 270px wide: 24px icon + 14px label, 12px gap, 12px / 10px padding,
 * 8px radius. Default: #8e8e8e icon and Regular label. Active: white pill with
 * brand (#b15a63) icon and Bold label.
 */
export interface B2BDashboardNavItemProps {
  label?: string;
  active?: boolean;
  /** 24px line icon. Defaults to the four-square overview glyph. */
  icon?: ReactNode;
  href?: string;
  className?: string;
}

export function DashboardOverviewIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden className="shrink-0">
      <g stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round">
        <path d="M3.5 5.5C3.5 4.39543 4.39543 3.5 5.5 3.5H8.5C9.60457 3.5 10.5 4.39543 10.5 5.5V8.5C10.5 9.60457 9.60457 10.5 8.5 10.5H5.5C4.39543 10.5 3.5 9.60457 3.5 8.5V5.5Z" />
        <path d="M13.5 5.5C13.5 4.39543 14.3954 3.5 15.5 3.5H18.5C19.6046 3.5 20.5 4.39543 20.5 5.5V8.5C20.5 9.60457 19.6046 10.5 18.5 10.5H15.5C14.3954 10.5 13.5 9.60457 13.5 8.5V5.5Z" />
        <path d="M13.5 15.5C13.5 14.3954 14.3954 13.5 15.5 13.5H18.5C19.6046 13.5 20.5 14.3954 20.5 15.5V18.5C20.5 19.6046 19.6046 20.5 18.5 20.5H15.5C14.3954 20.5 13.5 19.6046 13.5 18.5V15.5Z" />
        <path d="M3.5 15.5C3.5 14.3954 4.39543 13.5 5.5 13.5H8.5C9.60457 13.5 10.5 14.3954 10.5 15.5V18.5C10.5 19.6046 9.60457 20.5 8.5 20.5H5.5C4.39543 20.5 3.5 19.6046 3.5 18.5V15.5Z" />
      </g>
    </svg>
  );
}

export function B2BDashboardNavItem({
  label = "Overview",
  active = false,
  icon,
  href = "#",
  className = "",
}: B2BDashboardNavItemProps) {
  return (
    <a
      href={href}
      aria-current={active ? "page" : undefined}
      className={`flex w-[270px] items-center gap-3 rounded-md px-3 py-[10px] font-sans text-sm transition-colors ${
        active
          ? "bg-white font-bold text-primary"
          : "font-normal text-[#8e8e8e] hover:bg-white/60"
      } ${className}`}
    >
      {icon ?? <DashboardOverviewIcon />}
      <span className="whitespace-nowrap">{label}</span>
    </a>
  );
}
