/**
 * The Main Nav's category mega-menu dropdown (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * nodes 1365:7362/7512/7614/7720/7840/7947 — "Navbar 6-11").
 *
 * Menu contents follow tovfurniture.com. Live has no mega-menu for Wall Art
 * & Mirrors (plain link), no "Collections" quick link, and Decor & Tabletop
 * only offers In-Stock / All / Sale; Sale has All Sale + Final Sale.
 *
 * Real layout per category: a 168px quick-links column (New/All X/Best
 * Seller/Hot List/Contract Grade X/Sale, 16px bold) + 2-5
 * subcategory columns (16px bold uppercase group heading + "View All" +
 * 12px links, some groups also split into 14px bold uppercase sub-groups
 * like Furniture's "Living Room" → Seating/Tables) + a 412px promo panel
 * (image + "Collection name" placeholder card — no real image/collection
 * name in the source, left as a checker placeholder).
 *
 * Type styles, scoped to the dropdown panel (`Frame 1254`):
 * - Quick links: 16px Bold `#3F3D3E` (charcoal) — except the literal
 *   "Sale" quick-link, which is `#B15A63` (the `primary` token), matching
 *   the primary nav's own "Sale" link treatment.
 * - Group heading (no sub-groups, e.g. "Bedroom"): 16px Bold uppercase
 *   `#3F3D3E`.
 * - Sub-group heading (e.g. "Seating"/"Tables"): 14px Bold uppercase
 *   `#A4A4A4` — a light gray, not charcoal.
 * - Item links: 12px Medium `#777777` (exact match for the existing
 *   `neutral-700` token).
 * - "View All": 10px Medium `#777777` (`neutral-700`).
 *
 * The quick-links column is a real fixed 168px box in Figma, and long
 * labels like "Contract Grade Furniture" and "In-Stock Ready to Ship
 * Furniture" genuinely wrap to 2 (or 3, for "Wall Art & Mirrors"/"Decor &
 * Table Top") lines there — they aren't meant to render on one line, so
 * the quick-link `<a>` has no `whitespace-nowrap`. Every category's
 * quick-links list starts with an "In-Stock Ready to Ship X" item.
 */
export interface MegaMenuGroup {
  title: string;
  subgroups?: { title: string; links: string[] }[];
  links?: string[];
}

export interface MegaMenuData {
  category: string;
  quickLinks: string[];
  /** Subcategory columns; groups in the same column are stacked top to bottom. */
  columns: MegaMenuGroup[][];
  /** Label on the promo panel at the right of the menu. */
  promo: string;
}

const quickLinksFor = (name: string) => [
  `In-Stock Ready to Ship ${name}`, "New", `All ${name}`, "Best Seller", "Hot List", `Contract Grade ${name}`, "Sale",
];

export const MEGA_MENUS: Record<string, MegaMenuData> = {
  Furniture: {
    category: "Furniture",
    quickLinks: quickLinksFor("Furniture"),
    columns: [
      [
        {
          title: "Living Room",
          subgroups: [
            { title: "Seating", links: ["Sofas", "Sectionals", "Loveseats & Settees", "Accent Chairs", "Benches & Ottomans"] },
            { title: "Tables", links: ["Coffee & Cocktail Tables", "Game Tables", "Side Tables", "Console Tables", "Entertainment Centers", "Sideboards & Buffets", "Bar Carts"] },
          ],
        },
      ],
      [
        { title: "Bedroom", links: ["Beds", "Nightstands", "Chests & Dressers", "Benches & Ottomans", "Vanities", "TV Consoles", "Mattresses"] },
        { title: "Dining Room", links: ["Dining Tables", "Dining Chairs", "Bar & Counter Stools", "Sideboards & Buffets", "Bar Carts"] },
      ],
      [
        { title: "Home Office", links: ["Desks", "Office Chairs", "Book Shelves"] },
        { title: "Entryway", links: ["Console Tables", "Benches & Ottomans"] },
        { title: "Outdoor", links: ["Outdoor Dining", "Outdoor Lounge", "Outdoor Accents"] },
      ],
    ],
    promo: "The Cynthia Collection",
  },
  Lighting: {
    category: "Lighting",
    quickLinks: quickLinksFor("Lighting"),
    columns: [
      [{ title: "Lamps", links: ["Table Lamps", "Floor Lamps"] }],
      [{ title: "Ceiling Lights", links: ["Pendants", "Chandeliers"] }],
    ],
    promo: "Lighting",
  },
  "Decor & Tabletop": {
    category: "Decor & Tabletop",
    quickLinks: ["In-Stock Ready to Ship Decor & Tabletop", "All Decor & Tabletop", "Sale"],
    columns: [
      [{ title: "Decorative Objects", links: ["Vases & Planters", "Judaica", "Candles & Candle Holders", "Home Accents", "Bowls & Catchalls", "Pet Beds"] }],
      [{ title: "Entertaining", links: ["Placemats, Table Linens & Napkins", "Drinkware", "Cutlery & Serveware"] }],
    ],
    promo: "Decor",
  },
  Outdoor: {
    category: "Outdoor",
    quickLinks: quickLinksFor("Outdoor"),
    columns: [
      [{ title: "Outdoor Dining", links: ["Dining Tables", "Dining Seating"] }],
      [{ title: "Outdoor Lounge", links: ["Sofas", "Sectionals", "Accent Chairs", "Coffee Tables", "Chaise Lounges", "Benches & Ottomans"] }],
      [{ title: "Outdoor Accents", links: ["Accent Tables", "Console Tables"] }],
    ],
    promo: "Outdoor Furniture",
  },
  Sale: {
    category: "Sale",
    quickLinks: ["All Sale", "Final Sale"],
    columns: [
      [{ title: "Sale by Category", links: ["Furniture", "Rugs", "Lighting", "Decor & Tabletop", "Pillows & Throws", "Outdoor", "Wall Art & Mirrors"] }],
    ],
    promo: "All Sale",
  },
};

export function MegaMenu({ data }: { data: MegaMenuData }) {
  return (
    <div className="bg-white font-sans px-10 py-7 flex gap-[50px] w-full">
      <div className="flex flex-col gap-4 w-[168px] shrink-0">
        {data.quickLinks.map((label) => (
          <a
            key={label}
            href="#"
            className={`text-base font-bold leading-5 ${label === "Sale" ? "text-primary" : "text-charcoal"}`}
          >
            {label}
          </a>
        ))}
      </div>
      {data.columns.map((column) => (
        <div key={column[0].title} className="flex flex-col gap-8 w-[184px] shrink-0">
          {column.map((group) => (
            <div key={group.title} className="flex flex-col gap-4">
              {group.subgroups ? (
                <>
                  <div className="flex items-center justify-between">
                    <p className="text-base font-bold uppercase tracking-wide-ui leading-[14px] text-charcoal">{group.title}</p>
                    <a href="#" className="text-[10px] font-medium leading-[14px] text-neutral-700">View All</a>
                  </div>
                  {group.subgroups.map((sub) => (
                    <div key={sub.title} className="flex flex-col gap-2">
                      <p className="text-sm font-bold uppercase tracking-wide-ui leading-[14px] text-[#A4A4A4]">{sub.title}</p>
                      {sub.links.map((link) => (
                        <a key={link} href="#" className="text-xs font-medium leading-[14px] text-neutral-700 whitespace-nowrap">{link}</a>
                      ))}
                    </div>
                  ))}
                </>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <p className="text-base font-bold uppercase tracking-wide-ui leading-[14px] text-charcoal">{group.title}</p>
                    <a href="#" className="text-[10px] font-medium leading-[14px] text-neutral-700">View All</a>
                  </div>
                  {group.links?.map((link) => (
                    <a key={link} href="#" className="text-xs font-medium leading-[14px] text-neutral-700 whitespace-nowrap">{link}</a>
                  ))}
                </>
              )}
            </div>
          ))}
        </div>
      ))}
      <div className="bg-image-placeholder relative rounded-2xl overflow-hidden w-[412px] shrink-0 aspect-[412/300]">
        <p className="absolute bottom-4 left-4 text-base font-bold uppercase tracking-wide-ui text-ink">{data.promo}</p>
      </div>
    </div>
  );
}
