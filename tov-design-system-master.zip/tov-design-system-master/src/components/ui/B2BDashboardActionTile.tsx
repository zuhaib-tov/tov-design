import { ArrowRight, FolderDown } from "lucide-react";
import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Action Tile — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:32 → Version=Default (41:31),
 * 238x160. Quick-action card: a tinted Icon Tile (swappable), a label and an
 * arrow. White fill, #efebe4 border, 16px radius, 24px padding, soft drop
 * shadow (0px 12px 12px rgba(74,67,63,0.07)).
 */
export interface B2BDashboardActionTileProps {
  /** Icon shown in the rose Icon Tile — defaults to a folder/download glyph. */
  icon?: ReactNode;
  label?: string;
  className?: string;
}

export function B2BDashboardActionTile({
  icon,
  label = "Downloads",
  className = "",
}: B2BDashboardActionTileProps) {
  return (
    <div
      className={`flex h-[160px] w-[238px] flex-col items-start gap-5 rounded-app-md border border-[#efebe4] bg-white p-6 shadow-[0px_12px_12px_rgba(74,67,63,0.07)] ${className}`}
    >
      <span className="inline-flex size-12 items-center justify-center rounded-xl bg-[#fdf1f2] text-primary">
        {icon ?? <FolderDown size={24} strokeWidth={1.75} />}
      </span>
      <div className="flex w-full items-center justify-between">
        <p className="font-sans text-base font-medium text-charcoal">{label}</p>
        <ArrowRight size={16} className="text-primary" />
      </div>
    </div>
  );
}
