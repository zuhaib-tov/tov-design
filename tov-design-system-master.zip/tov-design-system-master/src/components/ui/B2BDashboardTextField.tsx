import { InputHTMLAttributes, useId } from "react";

/**
 * TOV B2B Dashboard / Text Field — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:694. Form field with an
 * uppercase label above a bordered input: 6px gap, 11px SemiBold #8e8e8e
 * label with 1px tracking, input with white fill, 1px #e0e0e0 border, 8px
 * radius, 16px / 12px padding and 14px Medium charcoal value. 225.5px wide.
 */
export interface B2BDashboardTextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  containerClassName?: string;
}

export function B2BDashboardTextField({
  label,
  containerClassName = "",
  className = "",
  id,
  ...props
}: B2BDashboardTextFieldProps) {
  const autoId = useId();
  const inputId = id ?? autoId;
  return (
    <div className={`flex w-[225.5px] flex-col items-start gap-[6px] ${containerClassName}`}>
      <label
        htmlFor={inputId}
        className="whitespace-nowrap font-sans text-[11px] font-semibold uppercase tracking-wide-ui text-[#8e8e8e]"
      >
        {label}
      </label>
      <input
        id={inputId}
        className={`w-full rounded-md border border-[#e0e0e0] bg-white px-4 py-3 font-sans text-sm font-medium text-charcoal outline-none placeholder:text-[#8e8e8e] focus:border-primary ${className}`}
        {...props}
      />
    </div>
  );
}
