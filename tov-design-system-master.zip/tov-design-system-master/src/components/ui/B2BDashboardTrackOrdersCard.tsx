/**
 * TOV B2B Dashboard / Track Orders Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:518, Dashboard page, Organisms
 * section. A 1000px card listing the buyer's most recent orders as
 * Dashboard/Order Row instances, each a cream row with a status dot, the
 * order id + date/item count, and an uppercase status label colored by
 * state (Shipped = rose, Processing = tan, Delivered = muted truffle).
 */
const ORDERS = [
  { id: "492-3024", meta: "Jun 30 · 12 items", status: "Shipped", dot: "bg-primary", text: "text-primary" },
  { id: "884-1102", meta: "Jun 28 · 5 items", status: "Processing", dot: "bg-[#9e8567]", text: "text-[#9e8567]" },
  { id: "755-9081", meta: "Jun 24 · 24 items", status: "Delivered", dot: "bg-[#82736c]", text: "text-[#82736c]" },
];

export function B2BDashboardTrackOrdersCard({
  activeCount = 12,
  className = "",
}: {
  activeCount?: number;
  className?: string;
}) {
  return (
    <div className={`flex w-[1000px] flex-col items-start gap-4 rounded-[24px] border border-[#efebe4] bg-white p-6 drop-shadow-[0px_12px_12px_rgba(74,66,64,0.07)] font-sans ${className}`}>
      <div className="flex w-full items-center justify-between">
        <span className="font-display text-lg text-charcoal">Track Your Orders</span>
        <span className="text-[11px] font-medium uppercase tracking-wide-ui text-[#9e8567]">{activeCount} Active</span>
      </div>
      <div className="flex w-full flex-col items-start gap-3">
        {ORDERS.map((order) => (
          <div key={order.id} className="flex w-full items-center gap-3 rounded-[12px] bg-cream-100 p-3">
            <span className={`size-2 shrink-0 rounded-full ${order.dot}`} />
            <div className="flex flex-1 flex-col gap-[2px]">
              <span className="whitespace-nowrap text-[13px] font-semibold text-charcoal">Order ID {order.id}</span>
              <span className="whitespace-nowrap text-[11px] text-[#82736c]">{order.meta}</span>
            </div>
            <span className={`whitespace-nowrap text-[11px] font-bold uppercase tracking-wide-ui ${order.text}`}>
              {order.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
