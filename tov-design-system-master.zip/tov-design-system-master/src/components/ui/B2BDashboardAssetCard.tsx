import { MousePointerClick, ArrowRight } from "lucide-react";
import { ReactNode } from "react";
import { B2BDashboardCountBadge } from "./B2BDashboardCountBadge";

/**
 * TOV B2B Dashboard / Asset Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 43:33 → Version=Default (43:32),
 * 339.33x200. Marketing-materials category card: icon, Count Badge, title,
 * description and a "Browse Assets" link. White fill, #efebe4 border, 24px
 * radius, 24px padding, soft drop shadow.
 */
export interface B2BDashboardAssetCardProps {
  icon?: ReactNode;
  count: string;
  title: string;
  description: string;
  linkLabel?: string;
  className?: string;
}

export function B2BDashboardAssetCard({
  icon,
  count,
  title,
  description,
  linkLabel = "Browse Assets",
  className = "",
}: B2BDashboardAssetCardProps) {
  return (
    <div
      className={`flex h-[200px] w-[339px] max-w-full flex-col items-start gap-4 rounded-app-lg border border-[#efebe4] bg-white p-6 shadow-[0px_12px_12px_rgba(74,67,63,0.07)] ${className}`}
    >
      <div className="flex w-full items-center justify-between">
        <span className="inline-flex size-10 items-center justify-center rounded-xl bg-[#fdf1f2] text-primary">
          {icon ?? <MousePointerClick size={20} strokeWidth={1.75} />}
        </span>
        <B2BDashboardCountBadge>{count}</B2BDashboardCountBadge>
      </div>
      <div className="flex w-full flex-col gap-2">
        <p className="font-sans text-base font-bold text-charcoal">{title}</p>
        <p className="font-sans text-[13px] font-medium leading-[18px] text-[#8e8e8e]">{description}</p>
      </div>
      <div className="flex items-center gap-1.5">
        <p className="font-sans text-[13px] font-medium text-primary">{linkLabel}</p>
        <ArrowRight size={12} className="text-primary" />
      </div>
    </div>
  );
}
