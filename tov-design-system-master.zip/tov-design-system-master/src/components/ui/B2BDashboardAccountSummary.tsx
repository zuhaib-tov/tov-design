/**
 * TOV B2B Dashboard / Account Summary — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:48 → Version=Default (41:47),
 * 270px wide. Customer name, ID and a gradient membership banner — sits at
 * the top of the dashboard sidebar. Banner gradient runs brand rose
 * (#b15a63) to brand pink (#f9d2d2), 8px radius.
 */
export interface B2BDashboardAccountSummaryProps {
  name: string;
  /** Customer ID shown beside the name, e.g. "CUS656273". */
  customerId: string;
  tierLabel?: string;
  tierNote?: string;
  className?: string;
}

export function B2BDashboardAccountSummary({
  name,
  customerId,
  tierLabel = "Pro Tier Member",
  tierNote = "Active 20% discount applied",
  className = "",
}: B2BDashboardAccountSummaryProps) {
  return (
    <div className={`flex w-[270px] flex-col items-start gap-3 ${className}`}>
      <div className="flex w-full flex-wrap items-baseline gap-1.5 whitespace-nowrap">
        <p className="font-sans text-xl font-bold text-charcoal">{name}</p>
        <p className="font-sans text-[11px] font-light text-[#8e8e8e]">| {customerId}</p>
      </div>
      <div className="flex w-full flex-col gap-0.5 rounded-md bg-gradient-to-r from-primary to-brand-pink px-3 py-2 text-[11px] text-white">
        <p className="font-sans font-extrabold uppercase tracking-wide-ui">{tierLabel}</p>
        <p className="font-sans font-medium opacity-90">{tierNote}</p>
      </div>
    </div>
  );
}
