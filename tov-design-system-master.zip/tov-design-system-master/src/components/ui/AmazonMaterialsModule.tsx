/**
 * Amazon A+ Content "Materials Module" (fileKey P6ISgCbxCzraEqRtTr0j3P,
 * "TOV26 - Amazon - Premium A+ content - 476", frame "Materials", node
 * 9:265, Components page): 4 stacked 300x225 symbols, still in legacy
 * `Property 1=...` naming:
 *
 *   - `9:266` "Property 1=Design" -> real name "Design"
 *   - `9:272` "Property 1=Material" -> real name "Material"
 *   - `9:307` "Property 1=Variant3" -> real name **Durable** ("Module 2
 *     Durable", node 23:704, 12 real photo instances)
 *   - `9:313` "Property 1=Variant4" -> real name **Craftsmanship**
 *     ("Module 2 Craftsmanship", node 23:776, 18 real photo instances)
 *
 * Structure per card, consistent on both the empty symbol (9:266) and a
 * real populated instance ("Module 2 Design - Materials 1", node 18:896,
 * an actual accent-chair photo): a full-bleed photo (`object-cover`,
 * square corners, no radius on the card itself), a pill label top-left,
 * and a circular icon badge bottom-right. There is no separate "dark
 * charcoal card" layer in the node tree — the dark backing seen in some
 * views comes from Figma's own canvas fill showing through the
 * symbols-only frame's dark background via the placeholder PNG's alpha
 * channel. Empty state here uses this project's standard
 * `.bg-image-placeholder` instead, same as every other Amazon module.
 *
 * Pill + badge fill: both are a fully transparent color
 * (`rgba(241,236,229,0)` / `rgba(249,210,210,0)`), yet render as a soft
 * white capsule against the empty/checkered state and as a soft dark
 * capsule against a real photo — a background-blur ("frosted glass")
 * effect sampling whatever sits behind it. Reproduced here with
 * `backdrop-blur` + a low-opacity white fill, which gives the same
 * behavior natively in CSS; this is an approximation, not a
 * pixel-measured blur radius.
 *
 * Typography: "Gotham:Bold", 11px, uppercase,
 * mapped to this project's `font-sans` + `font-bold` (Gotham's
 * stand-in here, same as every other Amazon component) + `tracking-wide-ui`.
 * Pill radius `881.471px` and badge `28px` on a 48px box are both just
 * Figma's auto-radius for "fully rounded" -> this project's `rounded-pill`
 * (`--radius-pill: 999px`) / `rounded-full`.
 *
 * Icons: real vectors, one per variant:
 *   - Design ("IMG_3", 9:270): an abstract paint-splash/palette glyph,
 *     originally exported on a 56x56 canvas because its Figma layer carries
 *     a drop-shadow filter baked into the SVG's bounding box — the actual
 *     glyph only occupies roughly the middle 28x28 of that canvas. Re-cropped
 *     the viewBox here (`14 13 28 28`) so it reads at the same visual scale
 *     as the other 3 icons, which are authored directly at ~30x30 with no
 *     extra filter padding.
 *   - Material ("_ÎÓÈ_2", 9:277): a woven/fabric-grid line icon.
 *   - Durable ("verified", 9:312): a scalloped certification-seal outline.
 *   - Craftsmanship ("setting", 9:318): a gear/cog outline with a center dot.
 * All 4 are single-color white linework (`stroke="white"`, `fill="none"`),
 * reproduced as inline SVG (`currentColor` swapped in for `white` so the
 * icon color follows the badge's text color) rather than shipping 4 static
 * image assets, matching how this project's other icon usage works.
 */

export type MaterialsCategory = "Design" | "Material" | "Durable" | "Craftsmanship";

export const MATERIALS_CATEGORIES: readonly MaterialsCategory[] = [
  "Design",
  "Material",
  "Durable",
  "Craftsmanship",
];

function DesignIcon() {
  return (
    <svg viewBox="14 13 28 28" fill="none" className="w-[26px] h-[26px]" aria-hidden>
      <path
        d="M22.5806 37.0832C22.5277 37.0526 22.4752 37.0217 22.4229 36.9903M22.4229 36.9903C19.0692 34.9784 16.8248 31.3071 16.8248 27.1116C16.8248 20.7539 21.9787 15.6 28.3364 15.6C33.6751 15.6 38.165 19.2342 39.4671 24.1637C39.6491 24.8526 39.8198 25.193 39.8198 26.2999C39.5893 28.1987 37.9718 29.6698 36.0108 29.6698C35.3501 29.6698 34.7284 29.5028 34.1856 29.2087C33.582 28.8128 32.8599 28.5826 32.0841 28.5826C29.9648 28.5826 28.2469 30.3006 28.2469 32.4198C28.2469 32.6397 28.2376 32.8553 28.2731 33.0651C28.3147 33.2913 28.3364 33.5245 28.3364 33.7628C28.3364 35.882 26.6184 37.6 24.4992 37.6C23.7341 37.6 23.0214 37.3761 22.4229 36.9903ZM24.0426 31.0929C23.9054 31.6047 23.3794 31.9084 22.8677 31.7713C22.3559 31.6342 22.0522 31.1081 22.1893 30.5964C22.3265 30.0846 22.8525 29.7809 23.3642 29.918C23.876 30.0552 24.1797 30.5812 24.0426 31.0929ZM24.0426 24.6976C23.9054 25.2094 23.3794 25.5131 22.8677 25.3759C22.3559 25.2388 22.0522 24.7128 22.1893 24.201C22.3265 23.6893 22.8525 23.3856 23.3642 23.5227C23.876 23.6598 24.1797 24.1858 24.0426 24.6976ZM30.4379 20.8604C30.3008 21.3722 29.7748 21.6759 29.263 21.5387C28.7512 21.4016 28.4475 20.8756 28.5847 20.3638C28.7218 19.8521 29.2478 19.5484 29.7596 19.6855C30.2713 19.8226 30.575 20.3486 30.4379 20.8604ZM35.5542 24.6976C35.4171 25.2094 34.891 25.5131 34.3793 25.3759C33.8675 25.2388 33.5638 24.7128 33.7009 24.201C33.8381 23.6893 34.3641 23.3856 34.8758 23.5227C35.3876 23.6598 35.6913 24.1858 35.5542 24.6976Z"
        stroke="currentColor"
        strokeWidth={0.74}
        strokeLinejoin="round"
      />
    </svg>
  );
}

function MaterialIcon() {
  return (
    <svg viewBox="0 0 25.7644 23" fill="none" className="w-[26px] h-[23px]" aria-hidden>
      <g strokeLinecap="round" strokeLinejoin="round" stroke="currentColor" strokeWidth={0.738024}>
        <path d="M20.1892 2.78022V1.62469C20.1892 0.930942 20.7511 0.368989 21.4449 0.368989C22.1386 0.368989 22.7006 0.930942 22.7006 1.62469" />
        <path d="M20.1892 9.29696V5.5615" />
        <path d="M20.1892 13.935V12.0783" />
        <path d="M22.7006 20.613V21.3753C22.7006 22.069 22.1386 22.631 21.4449 22.631C20.7511 22.631 20.1892 22.069 20.1892 21.3753V18.595" />
        <path d="M22.7006 12.3282V16.0636" />
        <path d="M8.77296 2.44073V1.62469C8.77296 0.930942 9.33491 0.368989 10.0287 0.368989C10.7224 0.368989 11.2843 0.930942 11.2843 1.62469V4.16665" />
        <path d="M8.77296 10.2248V6.4893" />
        <path d="M8.77296 16.7416V13.0061" />
        <path d="M11.2843 20.1354V21.3753C11.2843 22.069 10.7224 22.631 10.0287 22.631C9.33491 22.631 8.77296 22.069 8.77296 21.3753V19.5228" />
        <path d="M11.2844 13.6186V15.4858" />
        <path d="M11.2844 7.10189V10.8373" />
        <path d="M14.4811 7.10188C13.9508 7.17252 13.4162 7.20837 12.8827 7.20837C12.3492 7.20837 11.8147 7.17252 11.2833 7.10188C10.4325 6.98907 9.59008 6.78453 8.77193 6.48932C8.4978 6.39021 8.22579 6.28162 7.95799 6.16248C7.59003 5.99906 7.21259 5.86832 6.82881 5.76922" />
        <path d="M13.2096 4.42179C11.7103 4.46186 10.2048 4.22358 8.77301 3.70802C8.49888 3.60891 8.22687 3.50032 7.95907 3.38118C7.1968 3.04274 6.39024 2.84137 5.57631 2.77916" />
        <path d="M3.0649 5.81246C2.70011 5.91473 2.34269 6.04652 1.99477 6.20783C1.23671 6.55892 0.37006 6.0054 0.37006 5.16933V4.90996C0.37006 4.46399 0.628368 4.05913 1.03323 3.87146L1.71748 3.55411" />
        <path d="M18.3051 5.96319C18.9166 5.74389 19.5503 5.60999 20.1892 5.56044C21.0305 5.49507 21.8814 5.57942 22.7006 5.81137C23.0654 5.91258 23.4228 6.04542 23.7707 6.20674C24.5288 6.55782 25.3954 6.00431 25.3954 5.16823V4.90887C25.3954 4.46289 25.1371 4.05803 24.7323 3.87036L23.7707 3.42438C23.4228 3.26307 23.0654 3.13023 22.7006 3.02901C21.8814 2.79706 21.0305 2.71272 20.1892 2.77809C19.3753 2.84029 18.5698 3.04167 17.8075 3.3801H17.8033C17.5365 3.5003 17.2666 3.60889 16.9925 3.70589" />
        <path d="M14.4811 13.6187C13.9508 13.6893 13.4162 13.7252 12.8828 13.7252C12.3493 13.7252 11.8147 13.6893 11.2833 13.6187C10.4325 13.5059 9.59011 13.3013 8.77196 13.0061C8.49783 12.907 8.22582 12.7984 7.95802 12.6793C7.19575 12.3408 6.38919 12.1395 5.57526 12.0773" />
        <path d="M14.4811 10.8374C13.4205 10.9787 12.345 10.9787 11.2844 10.8374C10.4336 10.7246 9.59116 10.5211 8.77301 10.2248C8.49888 10.1268 8.22687 10.0171 7.95907 9.89798C7.1968 9.55954 6.39024 9.35817 5.57631 9.29596" />
        <path d="M3.0649 12.3292C2.70011 12.4315 2.34269 12.5633 1.99477 12.7246C1.23671 13.0757 0.37006 12.5222 0.37006 11.6861V11.4267C0.37006 10.9807 0.628368 10.5759 1.03323 10.3882L1.99477 9.94224C2.34269 9.78093 2.70011 9.64914 3.0649 9.54687" />
        <path d="M16.9925 13.005C17.2666 12.908 17.5365 12.7994 17.8033 12.6803H17.8075C18.5698 12.3408 19.3742 12.1394 20.1892 12.0772C21.0305 12.0118 21.8814 12.0962 22.7006 12.3281C23.0654 12.4293 23.4228 12.5622 23.7707 12.7235C24.5288 13.0746 25.3954 12.5211 25.3954 11.685V11.4256C25.3954 10.9796 25.1371 10.5748 24.7323 10.3871L23.7707 9.94113C23.4228 9.77982 23.0654 9.64803 22.7006 9.54576C21.8814 9.31487 21.0316 9.23052 20.1892 9.29483C19.3763 9.35704 18.5698 9.55841 17.8075 9.89685H17.8033C17.5365 10.017 17.2666 10.1256 16.9925 10.2226" />
        <path d="M5.57526 18.594C6.38919 18.6562 7.19575 18.8576 7.95802 19.196C8.22582 19.3151 8.49889 19.4237 8.77196 19.5228C9.59011 19.818 10.4325 20.0215 11.2833 20.1354C11.8147 20.206 12.3482 20.2419 12.8828 20.2419C13.4173 20.2419 13.9508 20.206 14.4811 20.1354" />
        <path d="M13.2096 17.4553C12.5664 17.4732 11.9233 17.4384 11.2844 17.353C10.4335 17.2402 9.59114 17.0367 8.77299 16.7404C8.49886 16.6424 8.22685 16.5327 7.95905 16.4136C7.59531 16.2523 7.22103 16.1215 6.84042 16.0224" />
        <path d="M18.3041 18.9967C18.9156 18.7774 19.5492 18.6435 20.1881 18.594C21.0295 18.5286 21.8803 18.6129 22.6995 18.8449C23.0643 18.9461 23.4217 19.079 23.7697 19.2403C24.5277 19.5914 25.3944 19.0378 25.3944 18.2018V17.9424C25.3944 17.4964 25.1361 17.0916 24.7312 16.9039L23.7697 16.4579C23.4217 16.2966 23.0643 16.1648 22.6995 16.0625C21.0885 15.6081 19.3573 15.7241 17.8064 16.4126H17.8022C17.5355 16.5328 17.2656 16.6414 16.9914 16.7384" />
        <path d="M14.4811 8.96908V1.62469C14.4811 0.930942 15.043 0.368989 15.7367 0.368989C16.4305 0.368989 16.9924 0.930942 16.9924 1.62469V14.8733" />
        <path d="M16.9924 16.7405V21.3753C16.9924 22.069 16.4305 22.631 15.7367 22.631C15.043 22.631 14.4811 22.069 14.4811 21.3753V10.8373" />
        <path d="M5.57629 14.1954V21.3742C5.57629 22.068 5.01434 22.6299 4.3206 22.6299C3.62686 22.6299 3.0649 22.068 3.0649 21.3742V18.8439C2.70116 18.9472 2.34269 19.079 1.99477 19.2403C1.23671 19.5914 0.37006 19.0378 0.37006 18.2018V17.9424C0.37006 17.4964 0.628368 17.0916 1.03323 16.9039L1.71116 16.5897" />
        <path d="M3.0649 7.68386V1.62469C3.0649 0.930942 3.62685 0.368989 4.32059 0.368989C5.01434 0.368989 5.57629 0.930942 5.57629 1.62469V12.0772" />
        <path d="M3.0649 18.8449V9.54687" />
        <path d="M22.6542 7.92112V5.85887" />
      </g>
    </svg>
  );
}

function DurableIcon() {
  return (
    <svg viewBox="0 0 30 30" fill="none" className="w-[26px] h-[26px]" aria-hidden>
      <path
        d="M18.75 12.5L14.885 16.5156C14.3933 17.0265 13.5755 17.0265 13.0838 16.5156L11.875 15.2597M10.9274 5.61328C11.8019 5.98091 12.8143 5.68363 13.3512 4.90158C14.1458 3.74426 15.8542 3.74426 16.6488 4.90158C17.1857 5.68363 18.1981 5.98091 19.0726 5.61328C20.3667 5.06924 21.8039 5.9929 21.8466 7.39606C21.8755 8.34423 22.5665 9.14169 23.5009 9.3052C24.8837 9.54717 25.5934 11.1012 24.8708 12.3047C24.3824 13.118 24.5326 14.1624 25.2303 14.8052C26.2627 15.7563 26.0196 17.4474 24.761 18.0691C23.9105 18.4893 23.4721 19.4491 23.7116 20.367C24.0659 21.7254 22.9471 23.0165 21.5522 22.8591C20.6095 22.7527 19.7219 23.3232 19.427 24.2249C18.9907 25.5591 17.3515 26.0405 16.2631 25.1539C15.5276 24.5548 14.4724 24.5548 13.7369 25.1539C12.6485 26.0405 11.0093 25.5591 10.573 24.2249C10.2781 23.3232 9.39047 22.7527 8.44784 22.8591C7.05288 23.0165 5.93408 21.7254 6.28841 20.367C6.52785 19.4491 6.08951 18.4893 5.23901 18.0691C3.98039 17.4474 3.73726 15.7563 4.76972 14.8052C5.46741 14.1624 5.61758 13.118 5.12923 12.3047C4.40656 11.1012 5.11627 9.54717 6.49908 9.3052C7.43349 9.14169 8.12449 8.34423 8.15335 7.39606C8.19607 5.9929 9.63331 5.06924 10.9274 5.61328Z"
        stroke="currentColor"
        strokeWidth={0.925}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CraftsmanshipIcon() {
  return (
    <svg viewBox="0 0 30 30" fill="none" className="w-[26px] h-[26px]" aria-hidden>
      <path
        d="M16.25 3.75H13.75C12.3693 3.75 11.25 4.86929 11.25 6.25C11.25 7.25214 10.1652 7.87847 9.29728 7.3774C8.10155 6.68705 6.57257 7.09674 5.88221 8.29247L4.63221 10.4575C3.94186 11.6533 4.35154 13.1822 5.54728 13.8726C6.41514 14.3737 6.41511 15.6263 5.54725 16.1274C4.35151 16.8177 3.94183 18.3467 4.63218 19.5425L5.88218 21.7075C6.57254 22.9033 8.10151 23.3129 9.29725 22.6226C10.1651 22.1215 11.25 22.7478 11.25 23.75C11.25 25.1307 12.3693 26.25 13.75 26.25H16.25C17.6307 26.25 18.75 25.1307 18.75 23.75C18.75 22.7479 19.8348 22.1215 20.7027 22.6226C21.8985 23.313 23.4274 22.9033 24.1178 21.7075L25.3678 19.5425C26.0581 18.3467 25.6485 16.8178 24.4527 16.1274C23.5848 15.6263 23.5848 14.3737 24.4527 13.8726C25.6484 13.1822 26.0581 11.6533 25.3678 10.4575L24.1178 8.29246C23.4274 7.09673 21.8984 6.68704 20.7027 7.37739C19.8348 7.87845 18.75 7.25212 18.75 6.25C18.75 4.86929 17.6307 3.75 16.25 3.75Z"
        stroke="currentColor"
        strokeWidth={0.925}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M17.5 15C17.5 16.3807 16.3807 17.5 15 17.5C13.6193 17.5 12.5 16.3807 12.5 15C12.5 13.6193 13.6193 12.5 15 12.5C16.3807 12.5 17.5 13.6193 17.5 15Z"
        stroke="currentColor"
        strokeWidth={0.925}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

const CATEGORY_ICON: Record<MaterialsCategory, () => React.JSX.Element> = {
  Design: DesignIcon,
  Material: MaterialIcon,
  Durable: DurableIcon,
  Craftsmanship: CraftsmanshipIcon,
};

export function AmazonMaterialsCard({
  category,
  className,
}: {
  category: MaterialsCategory;
  className?: string;
}) {
  const Icon = CATEGORY_ICON[category];
  return (
    <div
      className={`bg-image-placeholder relative w-[300px] h-[225px] overflow-hidden font-sans ${className ?? ""}`}
    >
      <div className="absolute left-[15px] top-[15px]">
        <span className="flex h-[30px] items-center justify-center rounded-pill px-[8.824px] py-[4.412px] bg-white/10 backdrop-blur-md text-white text-[11px] font-bold uppercase tracking-wide-ui whitespace-nowrap">
          {category}
        </span>
      </div>
      <div className="absolute bottom-[15px] right-[15px] size-[48px] rounded-full bg-white/10 backdrop-blur-md drop-shadow-[0px_1px_2px_rgba(0,0,0,0.15)] flex items-center justify-center text-white">
        <Icon />
      </div>
    </div>
  );
}
