/**
 * Marketing email "Sign-off" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1760:665) — Draft. No bound variables anywhere in this component (Figma
 * returned an empty variable set) — every color here is a literal hex.
 */
export interface MarketingSignOffProps {
  email?: string;
}

export function MarketingSignOffDesktop({
  email = "orders@tovfurniture.com",
}: MarketingSignOffProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="rounded-[36px] bg-cream-200 px-6 py-8 flex flex-col items-center gap-2.5 text-center">
        <div>
          <p className="text-charcoal text-[16px] leading-[1.4]">xo,</p>
          <p className="text-charcoal font-bold text-[18px] leading-[1.4]">The TOV Team</p>
        </div>
        <p className="text-charcoal underline text-[16px] leading-[1.5]">{email}</p>
      </div>
    </div>
  );
}

export function MarketingSignOffMobile({
  email = "orders@tovfurniture.com",
}: MarketingSignOffProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="rounded-[24px] bg-cream-200 px-6 py-6 flex flex-col items-center gap-2 text-center">
        <div>
          <p className="text-charcoal text-[14px] leading-[1.4]">xo,</p>
          <p className="text-charcoal font-bold text-[16px] leading-[1.4]">The TOV Team</p>
        </div>
        <p className="text-charcoal underline text-[14px] leading-[1.5]">{email}</p>
      </div>
    </div>
  );
}
