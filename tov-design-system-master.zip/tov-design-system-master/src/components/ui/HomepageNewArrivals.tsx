import { TextLink } from "./TextLink";
import { Button } from "./Button";

/**
 * The Homepage "New Arrivals" hero (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1063:2001) and its separate "New Arrivals Product Row" (node 1063:2050) —
 * two distinct components that sit stacked on the page, not one.
 *
 * Hero: a full-bleed lifestyle photo (1440x534 Desktop, 375x233 Mobile) under
 * a 20% black wash. Mobile adds a bottom-weighted multiply gradient that
 * darkens the lower 58% of the photo up to a further 20%. Copy sits bottom-left
 * ("Just dropped" in GT Ultra Fine Trial, 46/50 Desktop and 38/42 Mobile, white;
 * "All New arrivals" in 14/33 Gotham Bold, all caps, underlined, cream-50).
 * Desktop carries a 44px translucent "add to cart" icon button at the bottom
 * right; Mobile has no icon button. The second Desktop variant replaces that
 * button with a frosted product card (173x164 photo, 22px title, 18px price,
 * outlined "Buy now" button and the same icon button) inset 86px from the right.
 *
 * Product Row: four product tiles on a white ground under a 6% black wash,
 * label centred at the bottom in 14px (Desktop, 36px radius) or 12px (Mobile,
 * 16px radius) Gotham Bold, all caps, underlined, charcoal. Desktop is one row
 * of four at 302.5x338 with a 10px gap; Mobile is a 2x2 grid of 165x190 tiles.
 */
const HERO_IMAGE_DESKTOP = "/images/homepage/new-arrivals/new-arrivals-hero-desktop.webp";
const HERO_IMAGE_MOBILE = "/images/homepage/new-arrivals/new-arrivals-hero-mobile.webp";

export interface HomepageNewArrivalsProduct {
  image: string;
  title: string;
  price: string;
  ctaLabel?: string;
}

const DEFAULT_FEATURED_PRODUCT: HomepageNewArrivalsProduct = {
  image: "/images/homepage/new-arrivals/new-arrivals-featured-bench.webp",
  title: 'Greenspace 39" Rounded Upholstered Bench',
  price: "$469",
  ctaLabel: "Buy now",
};

export interface HomepageNewArrivalsHeroProps {
  compact?: boolean;
  /** Desktop only: shows the frosted product card with the "Buy now" button (the "New Arrivals 2" variant). */
  showProductCard?: boolean;
  /** Content for the product card. Defaults to the Greenspace bench. */
  product?: HomepageNewArrivalsProduct;
}

/** The `bag-add` glyph: a bag outline with a plus, 1.5px round white stroke on a 24px grid. */
function BagAddIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        transform="translate(2.74 2)"
        d="M18.26 12C18.56 9.54 18.66 8.2 18.23 7.13C17.8 6.07 17.03 5.19 16.03 4.63C14.9 4 13.33 4 10.2 4H8.32C5.19 4 3.63 4 2.49 4.63C1.49 5.19 0.72 6.07 0.29 7.13C-0.2 8.33 0 9.88 0.38 12.99C0.7 15.47 0.85 16.71 1.43 17.65C1.95 18.47 2.69 19.13 3.57 19.54C4.57 20 5.82 20 8.32 20H10.2C10.22 20 10.24 20 10.26 20M14.26 18H18.26M16.26 16V20M13.26 7V4C13.26 1.79 11.47 0 9.26 0C7.05 0 5.26 1.79 5.26 4V7"
        stroke="#fff"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CartIconButton({ className }: { className: string }) {
  return (
    <div className={`${className} flex h-11 w-11 items-center justify-center rounded-full bg-charcoal/20 backdrop-blur-[4px]`}>
      <BagAddIcon />
    </div>
  );
}

export function HomepageNewArrivalsHero({
  compact = false,
  showProductCard = false,
  product = DEFAULT_FEATURED_PRODUCT,
}: HomepageNewArrivalsHeroProps) {
  return (
    <div className={`relative overflow-hidden w-full bg-white ${compact ? "min-w-[375px] aspect-[375/233]" : "min-w-[1440px] aspect-[1440/534]"}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={compact ? HERO_IMAGE_MOBILE : HERO_IMAGE_DESKTOP} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-black/20" />
      {compact && <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent_42%,rgba(0,0,0,0.2)_100%)]" />}
      <div className={`absolute flex flex-col gap-[9px] ${compact ? "bottom-2.5 left-5" : "bottom-8 left-[100px]"}`}>
        <h3 className={`font-display text-white ${compact ? "text-[38px] leading-[42px]" : "text-[46px] leading-[50px]"}`}>Just dropped</h3>
        <TextLink href="#" inverse className="self-start my-[8.5px]">
          All new arrivals
        </TextLink>
      </div>
      {!compact && !showProductCard && <CartIconButton className="absolute bottom-8 right-[100px]" />}
      {!compact && showProductCard && (
        <div className="absolute bottom-8 right-[86px] flex h-[204px] w-[602px] gap-[14px] rounded-[36px] bg-black/20 p-5 ring-1 ring-inset ring-white/20 backdrop-blur-[6px]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={product.image} alt="" className="h-[164px] w-[173px] shrink-0 rounded-2xl object-cover" />
          <div className="flex w-[317px] shrink-0 flex-col gap-[14px]">
            <div className="flex flex-col gap-1.5 text-white">
              <p className="text-[22px] leading-[33px] font-bold">{product.title}</p>
              <p className="text-lg leading-6">{product.price}</p>
            </div>
            <Button variant="inverse" size="lg" className="w-full">
              {product.ctaLabel ?? "Buy now"}
            </Button>
          </div>
          <CartIconButton className="absolute bottom-5 right-5" />
        </div>
      )}
    </div>
  );
}

/** A product tile: the photo plus an optional crop window per viewport (no crop means the photo covers the tile). */
interface ProductTile {
  label: string;
  image: string;
  desktopCrop?: ImageCrop;
  mobileCrop?: ImageCrop;
}

/** Visible window of a photo as fractions of its width/height: size (sx, sy) and start (tx, ty). */
interface ImageCrop {
  sx: number;
  sy: number;
  tx: number;
  ty: number;
}

const IMAGE_BASE = "/images/homepage/new-arrivals/new-arrivals-product-";

const PRODUCT_ROW_TILES: ProductTile[] = [
  {
    label: "Living room",
    image: `${IMAGE_BASE}living-room.webp`,
    mobileCrop: { sx: 0.867, sy: 0.999, tx: 0.066, ty: 0.066 },
  },
  {
    label: "Lighting",
    image: `${IMAGE_BASE}lighting.webp`,
    desktopCrop: { sx: 1.052, sy: 1.179, tx: -0.028, ty: -0.048 },
    mobileCrop: { sx: 1, sy: 1.152, tx: 0, ty: 0.003 },
  },
  {
    label: "Entryway",
    image: `${IMAGE_BASE}entryway.webp`,
  },
  {
    label: "Accent chairs",
    image: `${IMAGE_BASE}accent-chairs.webp`,
    desktopCrop: { sx: 0.931, sy: 1.043, tx: 0.034, ty: 0.031 },
    mobileCrop: { sx: 0.926, sy: 1.066, tx: 0.037, ty: 0.003 },
  },
];

function ProductRowTile({ tile, compact }: { tile: ProductTile; compact: boolean }) {
  const crop = compact ? tile.mobileCrop : tile.desktopCrop;
  const imageStyle = crop
    ? {
        left: `${(-crop.tx / crop.sx) * 100}%`,
        top: `${(-crop.ty / crop.sy) * 100}%`,
        width: `${100 / crop.sx}%`,
        height: `${100 / crop.sy}%`,
      }
    : undefined;
  return (
    <div className={`relative w-full overflow-hidden bg-white ${compact ? "aspect-[165/190] rounded-2xl" : "aspect-[302.5/338] rounded-[36px]"}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={tile.image} alt="" className={crop ? "absolute max-w-none" : "absolute inset-0 h-full w-full object-cover"} style={imageStyle} />
      <div className="absolute inset-0 bg-black/[0.06]" />
      <div className={`absolute left-0 right-0 flex justify-center ${compact ? "bottom-2.5" : "bottom-5"}`}>
        <TextLink href="#" size={compact ? "sm" : "md"}>
          {tile.label}
        </TextLink>
      </div>
    </div>
  );
}

export function HomepageNewArrivalsProductRow({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "grid w-full min-w-[375px] max-w-[375px] grid-cols-2 gap-[5px] px-5 py-5" : "grid w-full min-w-[1440px] grid-cols-4 gap-[10px] px-[100px] py-5"}>
      {PRODUCT_ROW_TILES.map((tile) => (
        <ProductRowTile key={tile.label} tile={tile} compact={compact} />
      ))}
    </div>
  );
}
