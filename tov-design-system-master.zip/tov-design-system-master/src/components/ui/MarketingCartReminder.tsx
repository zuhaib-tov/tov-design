/**
 * Marketing email "Cart Reminder" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1761:677) — Draft. Multi Item is a real structural fork between
 * viewports, not a responsive reflow of one layout: Desktop pins price to
 * the right of name/qty (built here as a flex row with price pushed
 * right, standing in for Figma's absolute positioning); Mobile stacks
 * price inline below quantity, left-aligned, inside the same column.
 * Product name/qty text-align is CENTER in Single Item but LEFT in Multi
 * Item — a real per-layout difference, not an inconsistency.
 */
export interface CartItem {
  name: string;
  price: string;
  quantity?: number;
}

const DEFAULT_ITEM: CartItem = { name: "Riviera Striped Rattan Accent Chair", price: "$599" };
const DEFAULT_ITEMS: CartItem[] = [
  { name: "Riviera Striped Rattan Accent Chair", price: "$599", quantity: 1 },
  { name: "Positano Woven Accent Chair", price: "$349", quantity: 1 },
];

function ReturnToCartButton({ children = "Return to cart" }: { children?: string }) {
  return (
    <button className="rounded-pill bg-charcoal text-white font-bold text-[12px] uppercase tracking-wide-ui w-[245px] h-[54px]">
      {children}
    </button>
  );
}

export function MarketingCartReminderSingleDesktop({
  headline = "Still thinking it over?",
  subhead = "Your cart is saved - pick up right where you left off.",
  item = DEFAULT_ITEM,
}: {
  headline?: string;
  subhead?: string;
  item?: CartItem;
}) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex flex-col items-center gap-5">
      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="text-charcoal font-bold text-[22px] leading-[25px]">{headline}</h2>
        <p className="text-charcoal text-[16px] leading-[1.5]">{subhead}</p>
      </div>
      <div className="flex flex-col items-center gap-1.5">
        <div className="bg-image-placeholder relative w-[360px] h-[406px] rounded-[36px]">
          <div className="absolute inset-0 rounded-[36px] bg-black/[6%]" />
        </div>
        <p className="text-charcoal font-bold text-[18px] leading-[1.4] text-center">{item.name}</p>
        <p className="text-charcoal text-[16px] leading-[1.4] text-center">{item.price}</p>
      </div>
      <ReturnToCartButton />
    </div>
  );
}

export function MarketingCartReminderSingleMobile({
  headline = "Still thinking it over?",
  subhead = "Your cart is saved - pick up right where you left off.",
  item = DEFAULT_ITEM,
}: {
  headline?: string;
  subhead?: string;
  item?: CartItem;
}) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex flex-col items-center gap-4">
      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
        <p className="text-charcoal text-[14px] leading-[1.5]">{subhead}</p>
      </div>
      <div className="flex flex-col items-center gap-1.5">
        <div className="bg-image-placeholder relative w-[355px] h-[400px] rounded-[24px]">
          <div className="absolute inset-0 rounded-[24px] bg-black/[6%]" />
        </div>
        <p className="text-charcoal font-bold text-[16px] leading-[1.4] text-center">{item.name}</p>
        <p className="text-charcoal text-[14px] leading-[1.4] text-center">{item.price}</p>
      </div>
      <ReturnToCartButton />
    </div>
  );
}

export function MarketingCartReminderMultiDesktop({
  headline = "Still thinking it over?",
  subhead = "Your cart is saved - pick up right where you left off.",
  items = DEFAULT_ITEMS,
}: {
  headline?: string;
  subhead?: string;
  items?: CartItem[];
}) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex flex-col items-center gap-5">
      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="text-charcoal font-bold text-[22px] leading-[25px]">{headline}</h2>
        <p className="text-charcoal text-[16px] leading-[1.5]">{subhead}</p>
      </div>
      <div className="w-full flex flex-col gap-5">
        {items.map((item) => (
          <div
            key={item.name}
            className="flex items-center gap-5 rounded-[16px] border border-[#e8e8e8] p-5"
          >
            <div className="bg-image-placeholder w-[134px] h-[122px] rounded-[16px] shrink-0" />
            <div className="flex flex-col gap-1">
              <p className="text-charcoal font-bold text-[16px]">{item.name}</p>
              <p className="text-charcoal text-[16px]">Quantity: {item.quantity ?? 1}</p>
            </div>
            <p className="text-charcoal text-[16px] ml-auto">{item.price}</p>
          </div>
        ))}
      </div>
      <ReturnToCartButton />
    </div>
  );
}

export function MarketingCartReminderMultiMobile({
  headline = "Still thinking it over?",
  subhead = "Your cart is saved - pick up right where you left off.",
  items = DEFAULT_ITEMS,
}: {
  headline?: string;
  subhead?: string;
  items?: CartItem[];
}) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex flex-col items-center gap-4">
      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="text-charcoal font-bold text-[20px] leading-[1.2]">{headline}</h2>
        <p className="text-charcoal text-[14px] leading-[1.5]">{subhead}</p>
      </div>
      <div className="w-full flex flex-col gap-2.5">
        {items.map((item) => (
          <div
            key={item.name}
            className="flex items-center gap-3 rounded-[16px] border border-[#e8e8e8] p-3"
          >
            <div className="bg-image-placeholder w-[96px] h-[96px] rounded-[16px] shrink-0" />
            <div className="flex flex-col gap-1">
              <p className="text-charcoal font-bold text-[14px]">{item.name}</p>
              <p className="text-charcoal text-[13px]">Quantity: {item.quantity ?? 1}</p>
              <p className="text-charcoal text-[14px]">{item.price}</p>
            </div>
          </div>
        ))}
      </div>
      <ReturnToCartButton />
    </div>
  );
}
