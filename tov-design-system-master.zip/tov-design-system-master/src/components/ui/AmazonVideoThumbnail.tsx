/**
 * Amazon A+ Content — Video Thumbnail Module (fileKey P6ISgCbxCzraEqRtTr0j3P,
 * "TOV26 - Amazon - Premium A+ content - 476"). Canonical symbol "Video
 * Tumbnail Module" (Figma's own typo, not reproduced in this file's naming)
 * — node 15:235, section 15:176. 800x600, structurally simple: no variants,
 * a single flat full-bleed photo fill and nothing else.
 *
 * The canonical symbol and 3 of its 16 real category instances (Accent
 * Chairs 18:900, Living Room 18:513, Dining Room 29:1014) share this same
 * structure: zero children, zero extra fills, no play-button vector, no
 * pill label, no overlay of any kind — a plain photo, full stop.
 *
 * That reading does not generalize to the file as a whole, though. The
 * other 13 of the 16 real instances carry a translucent black SOLID fill
 * (20% opacity) stacked on top of the photo/video (see
 * VIDEO_THUMBNAIL_MODULE_SLOTS in figma-slots.ts for the per-category
 * breakdown). This component intentionally matches the clean baseline
 * (15:235 / 18:900), not the scrim some instances happen to carry.
 */
export function AmazonVideoThumbnail({
  category,
  imageSrc,
  imageAlt,
  className = "",
}: {
  /** Dev-facing label only — nothing in the source renders a visible category name on this module. */
  category?: string;
  imageSrc?: string;
  imageAlt?: string;
  className?: string;
}) {
  return (
    <div
      className={`w-[800px] max-w-full aspect-[4/3] overflow-hidden rounded-app-md ${className}`}
    >
      {imageSrc ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={imageSrc}
          alt={imageAlt ?? category ?? "Video thumbnail"}
          className="w-full h-full object-cover"
        />
      ) : (
        <div
          className="w-full h-full bg-image-placeholder"
          role="img"
          aria-label={category ? `${category} — video thumbnail placeholder` : "Video thumbnail placeholder"}
        />
      )}
    </div>
  );
}
