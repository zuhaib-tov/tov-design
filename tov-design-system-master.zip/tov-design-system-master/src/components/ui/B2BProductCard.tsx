import { Heart } from "lucide-react";

/**
 * Product preview for merchandising grids and carousels (Figma "Product
 * Card", node 6:34 — Version=Default/Image Only, Viewport=Desktop/Mobile,
 * all Status=Live).
 *
 * Default carries full product details: an eyebrow + product name on
 * desktop, product name + price + color swatches on mobile. Image Only
 * drops the Details block entirely and is supplied for desktop.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:609.
 */
export interface B2BProductCardProps {
  /** Overlay tag text, e.g. "New Arrival" / "Best Seller". */
  tag?: string;
  name: string;
  /** Desktop only — e.g. "New Color", "Contract Grade". */
  eyebrow?: string;
  /** Price or price range, e.g. "$170 - $180". */
  price?: string;
  /** Mobile only — number of color swatches to render. */
  swatchCount?: number;
  selectedSwatch?: number;
  variant?: "default" | "image-only";
  viewport?: "desktop" | "mobile";
  /** Product photograph filling the tile. Falls back to the image placeholder. */
  image?: string;
  /** Desktop only — `strong` sets the eyebrow as a bold grade label ("Contract Grade") instead of a muted uppercase note. */
  eyebrowStyle?: "muted" | "strong";
  /** Desktop only — product name size. */
  nameSize?: "lg" | "base";
  /** Wishlist button on the tile. */
  showWishlist?: boolean;
  className?: string;
}

export function B2BProductCard({
  tag = "New Arrival",
  name,
  eyebrow,
  price,
  swatchCount = 0,
  selectedSwatch = 0,
  variant = "default",
  viewport = "desktop",
  image,
  eyebrowStyle = "muted",
  nameSize = "lg",
  showWishlist = true,
  className = "",
}: B2BProductCardProps) {
  const isMobile = viewport === "mobile";

  return (
    <div className={`flex flex-col ${isMobile ? "gap-[21px] w-[183px]" : "gap-5 w-[315px]"} ${className}`}>
      <div
        className={`${image ? "bg-[#f2f2f2]" : "bg-image-placeholder"} relative w-full overflow-hidden ${
          isMobile ? "aspect-[183/167] rounded-app-md bg-black/[0.06]" : "aspect-[315/311] rounded-md bg-white"
        }`}
      >
        {image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
        )}
        <span
          className={`absolute inline-flex items-center rounded-md bg-charcoal/[0.88] font-medium text-white ${
            image && !isMobile ? "left-[15px] top-3" : "left-2 top-2"
          } ${isMobile ? "px-2 py-1 text-[8px]" : "px-3 py-1.5 text-[13px]"}`}
        >
          {tag}
        </span>
        {showWishlist && (
          <button
            type="button"
            aria-label="Add to wishlist"
            className={`absolute bottom-2.5 right-2.5 flex items-center justify-center rounded-full bg-white ${
              isMobile ? "w-7 h-7" : "w-[45px] h-[45px]"
            }`}
          >
            <Heart className={isMobile ? "w-3.5 h-3.5 text-charcoal" : "w-5 h-5 text-charcoal"} strokeWidth={1.5} />
          </button>
        )}
      </div>

      {variant === "default" &&
        (isMobile ? (
          <div className="flex flex-col gap-[21px]">
            <div className="flex flex-col">
              <p className="text-xs text-[#333333]">{name}</p>
              {price && <p className="text-xs font-bold text-[#333333]">{price}</p>}
            </div>
            {swatchCount > 0 && (
              <div className="flex gap-[7px]">
                {Array.from({ length: swatchCount }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-7 h-7 rounded-md flex items-center justify-center ${
                      i === selectedSwatch ? "border border-charcoal p-0.5" : ""
                    }`}
                  >
                    <div className="w-full h-full rounded-[4px] bg-[#cdcdcd]" />
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col gap-[5px]">
            {eyebrow &&
              (eyebrowStyle === "strong" ? (
                <p className="text-sm font-bold text-charcoal">{eyebrow}</p>
              ) : (
                <p className="text-sm uppercase tracking-wide-ui text-[#8e8e8e]">{eyebrow}</p>
              ))}
            <p className={`font-light text-charcoal ${nameSize === "base" ? "text-base" : "text-lg"}`}>{name}</p>
            {price && <p className="text-base font-bold text-charcoal">{price}</p>}
          </div>
        ))}
    </div>
  );
}
