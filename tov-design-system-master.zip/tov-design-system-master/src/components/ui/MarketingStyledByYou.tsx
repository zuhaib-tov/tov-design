/**
 * Marketing email "Styled By You" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1761:713) — Draft. Headline is genuinely set in "GT Ultra Fine Trial"
 * in Figma (not a Gotham label) — this is the one place in the Marketing
 * email set that legitimately uses `font-display`, the app's real GT
 * Ultra Fine file, rather than the Gotham -> Montserrat substitution used
 * everywhere else in this section.
 */
export interface MarketingStyledByYouProps {
  headline?: string;
  caption?: string;
}

export function MarketingStyledByYouDesktop({
  headline = "Our pieces, styled by you",
  caption = "Tag @tovfurniture to be featured",
}: MarketingStyledByYouProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px]">
      <div className="rounded-[36px] bg-cream-200 px-6 py-8 flex flex-col items-center gap-6 text-center">
        <h2 className="font-display text-charcoal text-[34px] leading-[1.15]">{headline}</h2>
        <div className="flex gap-3">
          <div className="bg-image-placeholder w-[159.33px] h-[164px] rounded-[16px]" />
          <div className="bg-image-placeholder w-[159.33px] h-[164px] rounded-[16px]" />
          <div className="bg-image-placeholder w-[159.33px] h-[164px] rounded-[16px]" />
        </div>
        <p className="text-charcoal text-[14px] leading-[1.5]">{caption}</p>
      </div>
    </div>
  );
}

export function MarketingStyledByYouMobile({
  headline = "Our pieces, styled by you",
  caption = "Tag @tovfurniture to be featured",
}: MarketingStyledByYouProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5">
      <div className="rounded-[24px] bg-cream-200 px-3 pt-6 pb-6 flex flex-col items-center gap-4 text-center">
        <h2 className="font-display text-charcoal text-[26px] leading-[30px]">{headline}</h2>
        <div className="flex gap-2">
          <div className="bg-image-placeholder w-[105px] h-[108px] rounded-[12px]" />
          <div className="bg-image-placeholder w-[105px] h-[108px] rounded-[12px]" />
          <div className="bg-image-placeholder w-[105px] h-[108px] rounded-[12px]" />
        </div>
        <p className="text-charcoal text-[12px] leading-[1.5]">{caption}</p>
      </div>
    </div>
  );
}
