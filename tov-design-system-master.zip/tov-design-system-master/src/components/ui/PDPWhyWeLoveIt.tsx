/**
 * The PDP "Why We Love It" component (fileKey ySZYmjbO2Wck8u1JGAtI5J,
 * node 582:9579, "Version=Why We Love It, Viewport=All, Status=Live" —
 * universal). The component is named "Why We Love It" in Figma but
 * displays "Why You'll Love It" — another stale-label case. The outer card
 * has a white background with a #E8E8E8 border; the description box is
 * #E8E8E8 at 31% opacity, not solid.
 */
export interface PDPWhyWeLoveItProps {
  bullets: string[];
  /** May include a "[Product Name]" placeholder token, matching the source. */
  description: string;
}

export function PDPWhyWeLoveIt({ bullets, description }: PDPWhyWeLoveItProps) {
  return (
    <div className="flex flex-col gap-2.5 rounded-lg border border-[#e8e8e8] bg-white p-2.5 font-sans max-w-md">
      <div className="flex items-center gap-1">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/hearts-floating.svg" alt="" className="w-5 h-5" />
        <h3 className="text-sm font-bold text-neutral-900">Why You&apos;ll Love It</h3>
      </div>
      <ul className="flex flex-col gap-1.5 pl-4">
        {bullets.map((b, i) => (
          <li key={i} className="text-sm leading-[21px] font-light text-neutral-900 list-disc">
            {b}
          </li>
        ))}
      </ul>
      <div className="rounded-lg bg-[#e8e8e8]/[0.31] p-4">
        <p className="text-xs leading-[18px] font-light text-neutral-900">{description}</p>
      </div>
    </div>
  );
}
