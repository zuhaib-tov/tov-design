import { ChevronDown } from "lucide-react";
import { B2BDashboardPaginationItem } from "./B2BDashboardPaginationItem";

/**
 * TOV B2B Dashboard / Pagination Bar — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 44:164 → Version=Default (44:163),
 * full-width (1066px). Result-count summary, a per-page select, a run of
 * Pagination Items (with an ellipsis and next/last arrows) and a
 * go-to-page jump control. Sits below a data table.
 */
export interface B2BDashboardPaginationBarProps {
  rangeStart?: number;
  rangeEnd?: number;
  total?: number;
  perPage?: number;
  currentPage?: number;
  lastPage?: number;
  className?: string;
}

export function B2BDashboardPaginationBar({
  rangeStart = 1,
  rangeEnd = 8,
  total = 54,
  perPage = 10,
  currentPage = 1,
  lastPage = 7,
  className = "",
}: B2BDashboardPaginationBarProps) {
  return (
    <div className={`flex w-full flex-wrap items-center justify-between gap-4 py-3 ${className}`}>
      <div className="flex flex-wrap items-center gap-4">
        <p className="whitespace-nowrap font-sans text-[13px] font-medium text-[#8e8e8e]">
          Showing {rangeStart}-{rangeEnd} of {total} orders
        </p>
        <div className="flex items-center gap-1.5">
          <p className="whitespace-nowrap font-sans text-[13px] font-medium text-[#8e8e8e]">Showing per page</p>
          <div className="flex items-center gap-1 rounded-[6px] border border-neutral-200 bg-white px-2.5 py-1.5">
            <p className="font-sans text-[13px] font-semibold text-charcoal">{perPage}</p>
            <ChevronDown size={16} className="text-[#8e8e8e]" />
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <B2BDashboardPaginationItem active={currentPage === 1}>1</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem active={currentPage === 2}>2</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem active={currentPage === 3}>3</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem>…</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem active={currentPage === lastPage}>{lastPage}</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem>{">"}</B2BDashboardPaginationItem>
        <B2BDashboardPaginationItem>{">>"}</B2BDashboardPaginationItem>
      </div>
      <div className="flex items-center gap-2">
        <p className="whitespace-nowrap font-sans text-[13px] font-medium text-[#8e8e8e]">Go to page</p>
        <div className="flex h-8 w-12 items-center justify-center rounded-[6px] border border-neutral-200 bg-white">
          <p className="font-sans text-[13px] font-medium text-charcoal">{currentPage}</p>
        </div>
        <p className="font-sans text-[13px] font-bold text-primary">Go</p>
      </div>
    </div>
  );
}
