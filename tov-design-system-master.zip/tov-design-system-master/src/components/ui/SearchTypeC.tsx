/**
 * Search — Type C ("SKU name / product name") — fileKey
 * DTjIdCKhnDUVvJhEfpn10v, node 1696:2014. 2 real variants: Desktop
 * (1696:1845) and Mobile (1696:1932). Figma's own note calls for "an
 * instant exact-match card at the top" for this type — confirmed by the
 * node tree: 3 "Product card" frames exist on Desktop (2 on Mobile), but
 * only the first is `opacity: 1`; the rest are leftover `opacity: 0`
 * copies of the same Type A cards. Built with exactly the one visible
 * card, reusing the same Dex Vegan Mohair Ottoman photo and promo banner
 * already extracted for Type A (same underlying assets, same product).
 */
import { SearchTopBar, MobileSearchTopBar, ResultsHeader, ResultsHeaderMobile, DesktopProductCard, MobileProductCard, PromoBanner } from "./SearchShared";

const PRODUCT_DESKTOP = { image: "/images/search/ottoman-dex-mohair.jpg", title: "Dex Vegan Mohair Ottoman", price: "$1,499", materialTag: "Performance Fabric", swatches: ["#9F7A3E", "#5E3F3F", "#601515", "#31463D"] };
const PRODUCT_MOBILE = { image: "/images/search/ottoman-dex-mohair-sq.jpg", title: "Dex Vegan Mohair Ottoman", price: "$479", materialTag: "Performance Fabric" };

export function SearchTypeCDesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="SKU TOV-OC69425" />
      <ResultsHeader query="SKU TOV-OC69425" />
      <div className="px-10 pb-10 w-[303px]">
        <DesktopProductCard product={PRODUCT_DESKTOP} />
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeCMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <ResultsHeaderMobile query="SKU TOV-OC69425" />
      <div className="px-5 pb-6 w-[169px]">
        <MobileProductCard product={PRODUCT_MOBILE} />
      </div>
    </div>
  );
}
