import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Quick Actions — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:494, Dashboard page, Organisms
 * section. A "Tactile Core Tools & Actions" section title over four
 * Dashboard/Action Tile instances (Downloads, Invoices, Quick Order, Item
 * Lookup), each a white card with its own tinted Icon Tile, a label and a
 * trailing arrow link.
 */
const TILES: { label: string; tint: string; icon: ReactNode }[] = [
  { label: "Downloads", tint: "bg-[#fdf1f2]", icon: <DownloadIcon /> },
  { label: "Invoices", tint: "bg-[#eaf4f0]", icon: <DocumentIcon /> },
  { label: "Quick Order", tint: "bg-[#faf3e7]", icon: <HouseIcon /> },
  { label: "Item Lookup", tint: "bg-[#eef2fc]", icon: <ArrowIcon /> },
];

export function B2BDashboardQuickActions({ className = "" }: { className?: string }) {
  return (
    <div className={`flex w-[1000px] flex-col items-start gap-4 font-sans ${className}`}>
      <p className="font-display text-lg text-charcoal">Tactile Core Tools &amp; Actions</p>
      <div className="flex w-full items-start gap-4">
        {TILES.map((tile) => (
          <div
            key={tile.label}
            className="flex h-40 flex-1 flex-col items-start gap-5 rounded-[16px] border border-[#efebe4] bg-white p-6 drop-shadow-[0px_12px_12px_rgba(74,67,63,0.07)]"
          >
            <span className={`flex size-12 items-center justify-center rounded-[12px] ${tile.tint}`}>
              <span className="size-6 text-charcoal">{tile.icon}</span>
            </span>
            <div className="flex w-full items-center justify-between">
              <span className="text-base font-medium text-charcoal">{tile.label}</span>
              <svg viewBox="0 0 16 16" className="size-4 text-primary" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M4 12 12 4M6 4h6v6" />
              </svg>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DownloadIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M12 3.5v11" />
      <path d="M7.5 10 12 14.5 16.5 10" />
      <path d="M4 17.5v1.8a1.7 1.7 0 0 0 1.7 1.7h12.6a1.7 1.7 0 0 0 1.7-1.7v-1.8" />
    </svg>
  );
}

function DocumentIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M7 3.5h7l4 4v12.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15.5a1 1 0 0 1 1-1Z" />
      <path d="M14 3.5V8h4" />
      <path d="M8.5 13h7M8.5 16.5h7" />
    </svg>
  );
}

function HouseIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M3.5 11 12 4l8.5 7" />
      <path d="M5.5 9.5V20h13V9.5" />
      <path d="M10 20v-5.5h4V20" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}
