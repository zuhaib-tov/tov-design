/**
 * PLP Product Card (fileKey jDOs1dFChECKIYdAyPUkav, "💠Components" page,
 * "Product Display" section, node `1:80`) — the core PLP/collection grid
 * card. 3-variant component set `Product card`: `Default` (342×507,
 * Desktop), `Mobile` (167×277), `Variant3` (167×301, a denser mobile/grid
 * look with a square 167×167 image and a "+N more" swatch-overflow label
 * instead of showing every swatch). A 4th state ("Quick View", node
 * `8:1523`) is the same Default card with a "QUICK SHOP" pill revealed
 * over the image — built here as a `showQuickShop` prop/hover state, not
 * a separate component.
 *
 * Every field in Figma is template placeholder content (checkered empty
 * image fill, literal "Product name" / "$0000.00" text, flat `#CDCDCD`
 * swatch squares) — matches the established placeholder-content
 * convention used for Homepage/PDP, not the real-photography approach
 * used for Search (where Figma itself had real product photos).
 *
 * Badge text ("BEST SELLER · SALE" / "NEW ARRIVAL · SALE") is rendered as
 * converted vector paths in the source, not live text — reproduced here as
 * real text with the same visual result. The `Tag` component has a 3rd
 * variant (`Variant2`) whose real label wasn't found used anywhere in this
 * file; only these 2 combinations are wired.
 *
 * Selected swatch = a 34×34 rounded (6px) box with a 1px `#3F3D3E` border
 * around the plain 28×28 swatch.
 *
 * Wishlist heart: the real "Likes button" instance is a 42×42 tap target
 * (28×28 on the Mobile variant, node `I1:318;314:3970`) containing a
 * 26.25×23.33px vector glyph (17.5×15.56px on Mobile). `heart.svg`'s
 * viewBox is `0 0 28 25`, matching the source's path bounds — sizing the
 * CSS box alone isn't enough to make the glyph read at the right size if
 * the viewBox itself is padded wider than the path.
 */
export interface PLPProductCardProps {
  badge?: string;
  swatchCount?: number;
  showQuickShop?: boolean;
  size?: "desktop" | "mobile" | "dense";
}

function Swatches({ count, moreLabel }: { count: number; moreLabel?: string }) {
  return (
    <div className="flex items-center gap-1.5">
      {Array.from({ length: count }).map((_, i) =>
        i === 0 ? (
          <span key={i} className="w-[34px] h-[34px] rounded-[6px] border border-charcoal flex items-center justify-center shrink-0">
            <span className="w-7 h-7 rounded-[4px] bg-[#CDCDCD]" />
          </span>
        ) : (
          <span key={i} className="w-7 h-7 rounded-[4px] bg-[#CDCDCD] shrink-0" />
        )
      )}
      {moreLabel && <span className="text-[10px] text-[#333333] whitespace-nowrap">{moreLabel}</span>}
    </div>
  );
}

export function PLPProductCard({ badge = "Best Seller · Sale", swatchCount = 7, showQuickShop = false, size = "desktop" }: PLPProductCardProps) {
  const isDense = size === "dense";
  const width = size === "desktop" ? "w-[342px]" : "w-[167px]";
  const imageAspect = size === "desktop" ? "aspect-[342/379]" : isDense ? "aspect-square" : "aspect-[167/189]";

  return (
    <div className={`${width} shrink-0`}>
      <div className={`relative rounded-2xl overflow-hidden bg-image-placeholder ${imageAspect} group`}>
        {badge && (
          <span className="absolute top-3 left-3 bg-charcoal text-white text-[10px] font-bold uppercase tracking-wide-ui rounded-pill px-3 py-1.5 whitespace-nowrap">
            {badge}
          </span>
        )}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/icons/heart.svg"
          alt="Wishlist"
          className={`absolute top-3 right-3 invert ${
            size === "desktop" ? "w-[26px] h-[23px]" : "w-[18px] h-[16px]"
          }`}
        />
        {showQuickShop && (
          <button
            type="button"
            className="absolute left-1/2 -translate-x-1/2 bottom-4 rounded-pill bg-white/80 backdrop-blur-sm px-8 py-3 text-xs font-bold uppercase tracking-wide-ui text-ink whitespace-nowrap"
          >
            Quick Shop
          </button>
        )}
      </div>
      <div className="pt-3 flex flex-col gap-1">
        <p className="text-lg text-[#333333]">Product name</p>
        <p className="text-lg font-bold text-[#333333]">$0000.00</p>
        <div className="pt-1">
          <Swatches count={isDense ? 3 : swatchCount} moreLabel={isDense ? "+ 3 more" : undefined} />
        </div>
      </div>
    </div>
  );
}
