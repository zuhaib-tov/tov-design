/**
 * Marketing email "Text Block" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1760:650) — Draft. "With List"'s item list mixes two real run styles per
 * line (underlined SKU code, plain product name) — not one uniform style.
 * The CTA button is a fixed 245x54 pill on both Desktop and Mobile; unlike
 * the surrounding copy it does not scale down for mobile.
 */
export interface MarketingTextBlockCenteredProps {
  greeting?: string;
  body?: string;
  body2?: string;
  buttonLabel?: string;
}

function PinkButton({ children }: { children: string }) {
  return (
    <button className="rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] uppercase tracking-wide-ui w-[245px] h-[54px]">
      {children}
    </button>
  );
}

export function MarketingTextBlockCenteredDesktop({
  greeting = "Hi TOV Partner,",
  body = "We have refreshed our fall collections with new fabrics, finishes, and a few long-awaited restocks. Everything is live on the site now.",
  body2 = "Take a look and let us know what catches your eye.",
  buttonLabel = "Shop new arrivals",
}: MarketingTextBlockCenteredProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex justify-center">
      <div className="max-w-[490px] flex flex-col items-center gap-5 px-[30px] py-2.5 text-center">
        <p className="text-charcoal font-bold text-[18px] leading-[1.3]">{greeting}</p>
        <p className="text-charcoal text-[16px] leading-[1.5]">{body}</p>
        <p className="text-charcoal text-[16px] leading-[1.5]">{body2}</p>
        <PinkButton>{buttonLabel}</PinkButton>
      </div>
    </div>
  );
}

export function MarketingTextBlockCenteredMobile({
  greeting = "Hi TOV Partner,",
  body = "We have refreshed our fall collections with new fabrics, finishes, and a few long-awaited restocks. Everything is live on the site now.",
  body2 = "Take a look and let us know what catches your eye.",
  buttonLabel = "Shop new arrivals",
}: MarketingTextBlockCenteredProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex justify-center">
      <div className="max-w-[335px] flex flex-col items-center gap-4 px-2.5 py-2 text-center">
        <p className="text-charcoal font-bold text-[16px] leading-[1.3]">{greeting}</p>
        <p className="text-charcoal text-[14px] leading-[1.5]">{body}</p>
        <p className="text-charcoal text-[14px] leading-[1.5]">{body2}</p>
        <PinkButton>{buttonLabel}</PinkButton>
      </div>
    </div>
  );
}

export interface ListItem {
  sku: string;
  name: string;
}

export interface MarketingTextBlockWithListProps {
  greeting?: string;
  intro?: string;
  items?: ListItem[];
  closing?: string;
  buttonLabel?: string;
}

const DEFAULT_LIST_ITEMS: ListItem[] = [
  { sku: "TOV-L69501", name: "Halsey Brown Textured Fabric Sofa" },
  { sku: "TOV-OC18724", name: "Olivier Cotton Oval Storage Ottoman" },
  { sku: "TOV-D54287", name: "Brandyss Natural Burl Rectangular Dining Table" },
  { sku: "TOV-B54394", name: "Brandyss Natural Burl 7-Drawer Dresser" },
];

export function MarketingTextBlockWithListDesktop({
  greeting = "Hi TOV Partner,",
  intro = "We have updated our images for the following items to better reflect their appearance:",
  items = DEFAULT_LIST_ITEMS,
  closing = "Please have your listings updated accordingly.",
  buttonLabel = "Update now",
}: MarketingTextBlockWithListProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex justify-center">
      <div className="max-w-[490px] flex flex-col items-center gap-5 px-[30px] py-2.5 text-center">
        <p className="text-charcoal font-bold text-[18px] leading-[1.3]">{greeting}</p>
        <p className="text-charcoal text-[16px] leading-[1.5]">{intro}</p>
        <p className="text-charcoal text-[16px] leading-[1.5]">
          {items.map((item, i) => (
            <span key={item.sku}>
              <span className="underline">{item.sku}</span> - {item.name}
              {i < items.length - 1 && <br />}
            </span>
          ))}
        </p>
        <p className="text-charcoal text-[16px] leading-[1.5]">{closing}</p>
        <PinkButton>{buttonLabel}</PinkButton>
      </div>
    </div>
  );
}

export function MarketingTextBlockWithListMobile({
  greeting = "Hi TOV Partner,",
  intro = "We have updated our images for the following items to better reflect their appearance:",
  items = DEFAULT_LIST_ITEMS,
  closing = "Please have your listings updated accordingly.",
  buttonLabel = "Update now",
}: MarketingTextBlockWithListProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 flex justify-center">
      <div className="max-w-[335px] flex flex-col items-center gap-4 px-2.5 py-2 text-center">
        <p className="text-charcoal font-bold text-[16px] leading-[1.3]">{greeting}</p>
        <p className="text-charcoal text-[14px] leading-[1.5]">{intro}</p>
        <p className="text-charcoal text-[14px] leading-[1.5]">
          {items.map((item, i) => (
            <span key={item.sku}>
              <span className="underline">{item.sku}</span> - {item.name}
              {i < items.length - 1 && <br />}
            </span>
          ))}
        </p>
        <p className="text-charcoal text-[14px] leading-[1.5]">{closing}</p>
        <PinkButton>{buttonLabel}</PinkButton>
      </div>
    </div>
  );
}
