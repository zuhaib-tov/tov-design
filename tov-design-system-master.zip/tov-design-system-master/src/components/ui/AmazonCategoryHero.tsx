import { Logo } from "./Logo";

/**
 * Amazon A+ Content "Category Hero" module (fileKey P6ISgCbxCzraEqRtTr0j3P,
 * "TOV26 - Amazon - Premium A+ content - 476", component set "Hero Module"
 * node 9:324, inside section 8:124) — built from that set's `desktop`
 * (9:323, 1464x600) and `mobile` (9:325, 600x450) variants.
 *
 * Root: single IMAGE fill (the empty/checkered placeholder photo), full
 * bleed, no rounding. There is no scrim/overlay rectangle anywhere in
 * either variant — the only other fills in the tree are the pill's own
 * background and one internal (invisible, unrelated) logo sub-layer fill.
 *
 * Uniform content inset: 24px (desktop) / 30px (mobile) on every edge that
 * matters — logo's top-left offset and the pill+headline block's
 * bottom-left offset both match this margin exactly in both variants.
 *
 * Pill (desktop 169x35 / mobile 121x25, both `Frame 1241`): fill is
 * exactly `--color-charcoal` (#3f3d3e) in both variants. Label is Gotham
 * Bold, textCase UPPER, white, real fontSize 14.29px desktop / 10.2px
 * mobile, letter-spacing via `tracking-wide-ui`. Padding (from the inner
 * `Frame 408` box): ~18px horizontal / ~3-4px vertical desktop, ~13px
 * horizontal / ~2-3px vertical mobile. Gotham -> font-sans (this
 * codebase's existing Gotham->Montserrat stand-in, same as every other
 * Marketing/PDP component).
 *
 * Headline — a real divergence between the two variants, not normalized
 * here:
 * - Desktop (`18:228`, "Statement seating to elevate."): two runs at the
 *   SAME 63.2px size — "Statement seating to " is Gotham Bold, but
 *   "elevate." is a completely different family, "Red Hat Display" Bold
 *   Italic (variationSettings wght 700). Red Hat Display isn't configured
 *   anywhere in this codebase (a third font, distinct from both the
 *   Gotham->Montserrat and GT Ultra Fine->font-display stand-ins already in
 *   use) — rather than add a new font dependency for one word in one
 *   component, the emphasis run below stays in font-sans and picks up
 *   `italic` only.
 * - Mobile (`18:275`, "Statement seating[break]to elevate."): the ENTIRE
 *   headline is one uniform Gotham Bold 45px run — no italic, no second
 *   font anywhere. The line break is a real forced break in the source
 *   (a literal U+2028 between "seating" and "to"), not natural wrapping.
 *   Built here as natural wrap instead of a hardcoded `<br>` at that exact
 *   word, but the absence of any italic/emphasis treatment on mobile is
 *   real and kept as-is rather than made consistent with desktop.
 *
 * Subhead: Gotham Book (-> font-sans font-normal), fully opaque white
 * (not translucent), real fontSize 42.13px desktop / 24.04px mobile.
 *
 * Logo: real instance size 147x44 desktop / 84x25 mobile (~3.34:1 aspect,
 * consistent across both and close to this component's own aspect), at the
 * same top-left inset as the content margin above.
 *
 * This component is built from the "Hero Module" set's `desktop`/`mobile`
 * variants (9:323 / 9:325).
 */
export interface AmazonCategoryHeroProps {
  categoryLabel?: string;
  headline?: string;
  headlineEmphasis?: string;
  subhead?: string;
}

export function AmazonCategoryHeroDesktop({
  categoryLabel = "Accent Chairs",
  headline = "Statement seating to",
  headlineEmphasis = "elevate.",
  subhead = "Redefining modern furniture.",
}: AmazonCategoryHeroProps) {
  return (
    <div className="bg-image-placeholder relative w-[1464px] max-w-full h-[600px] overflow-hidden font-sans">
      <div className="absolute top-6 left-6">
        <Logo className="h-11 text-white" accentColor="currentColor" />
      </div>
      <div className="absolute bottom-6 left-6 flex flex-col items-start gap-3 max-w-[1214px]">
        <span className="rounded-pill bg-charcoal text-white text-sm font-bold uppercase tracking-wide-ui px-[18px] py-1 whitespace-nowrap">
          {categoryLabel}
        </span>
        <div className="flex flex-col gap-1">
          <h2 className="font-sans font-bold text-white text-[63px] leading-[1.05]">
            {headline} <em className="italic">{headlineEmphasis}</em>
          </h2>
          <p className="font-sans font-normal text-white text-[42px] leading-[1.1]">{subhead}</p>
        </div>
      </div>
    </div>
  );
}

export function AmazonCategoryHeroMobile({
  categoryLabel = "Accent Chairs",
  headline = "Statement seating to",
  headlineEmphasis = "elevate.",
  subhead = "Redefining modern furniture.",
}: AmazonCategoryHeroProps) {
  return (
    <div className="bg-image-placeholder relative w-[600px] max-w-full h-[450px] overflow-hidden font-sans">
      <div className="absolute top-[30px] left-[30px]">
        <Logo className="h-[25px] text-white" accentColor="currentColor" />
      </div>
      <div className="absolute bottom-[30px] left-[30px] flex flex-col items-start gap-2 max-w-[540px]">
        <span className="rounded-pill bg-charcoal text-white text-[10px] font-bold uppercase tracking-wide-ui px-[13px] py-1 whitespace-nowrap">
          {categoryLabel}
        </span>
        <div className="flex flex-col gap-1">
          {/* No italic run here — the real mobile source is one uniform
              Gotham Bold run with no emphasis styling at all, unlike desktop. */}
          <h2 className="font-sans font-bold text-white text-[45px] leading-[1.05]">
            {headline} {headlineEmphasis}
          </h2>
          <p className="font-sans font-normal text-white text-[24px] leading-[1.1]">{subhead}</p>
        </div>
      </div>
    </div>
  );
}
