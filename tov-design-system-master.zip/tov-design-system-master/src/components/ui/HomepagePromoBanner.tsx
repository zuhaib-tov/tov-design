import { TextLink } from "./TextLink";

/**
 * The Homepage "Promo Banner" component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * node 1063:2215) — a cream (`#F1ECE5`/`cream-200`) rounded card with a
 * heading, a supporting line and an underlined CTA link. The Figma copy is
 * the module's own placeholder text ("Header here - promo banner",
 * "Supporting content here - promo banner", "SHop the sale").
 *
 * Two variants:
 * - `default` (Version=Default, Status=Live): a full-width card (1240 x 167
 *   in the 1440 layout) with a 36px radius, 20px padding and left-aligned
 *   copy — 46px GT Ultra Fine heading, 22px Gotham Book supporting line.
 * - `promo-banner-2` (Version=Promo Banner 2, Status=Draft): a compact
 *   335px-wide card with a 16px radius and centered copy — 22px heading,
 *   12px supporting line.
 *
 * The CTA link's Figma `textCase` is `UPPER` — the mixed-case "SHop" in the
 * raw string doesn't affect the rendered output, since `uppercase` handles
 * it in CSS. The banner carries no imagery.
 */
export type HomepagePromoBannerVersion = "default" | "promo-banner-2";

export function HomepagePromoBanner({ version = "default" }: { version?: HomepagePromoBannerVersion }) {
  if (version === "promo-banner-2") {
    return (
      <div className="bg-cream-200 rounded-2xl w-full max-w-[335px] p-5 flex flex-col items-center gap-2.5 text-center">
        <div className="flex flex-col gap-px w-full">
          <h3 className="font-display text-[22px] text-charcoal leading-[25px]">Header here - promo banner</h3>
          <p className="text-xs leading-[14px] text-charcoal">Supporting content here - promo banner</p>
        </div>
        <TextLink href="#" className="self-start my-[8.5px]">Shop the sale</TextLink>
      </div>
    );
  }
  return (
    <div className="bg-cream-200 rounded-[36px] w-full p-5 flex flex-col gap-2.5">
      <div className="flex flex-col gap-px">
        <h3 className="font-display text-[46px] text-charcoal leading-[50px]">Header here - promo banner</h3>
        <p className="text-[22px] leading-[33px] text-charcoal">Supporting content here - promo banner</p>
      </div>
      <TextLink href="#" className="self-start my-[8.5px]">Shop the sale</TextLink>
    </div>
  );
}
