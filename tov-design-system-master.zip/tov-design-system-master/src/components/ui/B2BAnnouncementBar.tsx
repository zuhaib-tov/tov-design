/**
 * TOV B2B announcement bar — Figma Announcement Bar component set (node
 * 10:35), Default/Desktop (10:31) and Default/Mobile (10:34). Desktop wraps
 * a rounded-16 charcoal bar inside a 75px page margin; Mobile runs the
 * charcoal fill full-bleed with no rounding. The two variants ship
 * different real copy — Desktop's is "Free shipping on orders over $299
 * [Promo Placeholder Text]", Mobile's is "Free shipping on trade orders
 * over $299" — both reproduced verbatim from the source file.
 */
export function B2BAnnouncementBar({
  viewport = "desktop",
}: {
  viewport?: "desktop" | "mobile";
}) {
  if (viewport === "mobile") {
    return (
      <div className="flex w-[390px] items-center justify-center bg-charcoal px-4 py-3">
        <p className="text-center text-xs text-white">Free shipping on trade orders over $299</p>
      </div>
    );
  }

  return (
    <div className="w-[1440px] bg-white px-[75px]">
      <div className="flex items-center justify-center rounded-app-lg bg-charcoal px-12 py-[19px]">
        <p className="text-center text-base leading-[19px] text-white">
          <span className="font-bold">Free shipping</span> on orders over{" "}
          <span className="font-bold">$299 [Promo Placeholder Text]</span>
        </p>
      </div>
    </div>
  );
}
