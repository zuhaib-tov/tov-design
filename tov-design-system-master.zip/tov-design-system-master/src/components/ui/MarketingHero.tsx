/**
 * Marketing email "Hero" component (fileKey DTjIdCKhnDUVvJhEfpn10v,
 * "✉️ TOV Email Components" canvas, node 1753:460, "Marketing Hero"
 * component set) — first of the Marketing email components built. The
 * other 11 component sets in "Marketing email components" (Category Cards,
 * Image Grid, Product Cards, Banner, Content Block, Announcement Bar, Text
 * Block, Sign-off, Cart Reminder, Incentive, Styled By You) are not built
 * yet.
 *
 * 4 variants: Full Width x Inset, each x Desktop x Mobile. Full Width IS
 * the image card itself (cornerRadius 36 desktop / 24 mobile). Inset wraps
 * the same card in extra outer margin (30px desktop / 10px mobile) that
 * doesn't itself have a radius — same card, same content, just smaller and
 * floating inside a margin. Content is always bottom-aligned via padding
 * (40/40/40/56 desktop, 24/24/24/32 mobile). A 6% black card-level tint
 * plus a separate 20% black overlay rectangle sit behind the text for
 * contrast against a real photo; combined here into one ~25% scrim rather
 * than stacking two divs for a placeholder image.
 *
 * The headline uses `font-display` (GT Ultra Fine, Regular) and the button
 * uses the Montserrat Label/S style. Most email clients strip arbitrary
 * custom web fonts anyway, so email components may warrant a separate,
 * email-safe font choice from the rest of the design system.
 */
export interface MarketingHeroProps {
  headline?: string;
  subhead?: string;
  buttonLabel?: string;
  inset?: boolean;
}

export function MarketingHeroDesktop({
  headline = "The Fall Edit",
  subhead = "New arrivals made for slow evenings at home.",
  buttonLabel = "Shop now",
  inset = false,
}: MarketingHeroProps) {
  const card = (
    <div className="bg-image-placeholder relative w-full h-[718px] rounded-[36px] overflow-hidden flex flex-col justify-end items-center gap-4 px-10 pt-10 pb-14">
      <div className="absolute inset-0 bg-black/25" />
      <h2 className="relative text-[38px] leading-[42px] font-display text-white text-center">
        {headline}
      </h2>
      <p className="relative text-base text-white text-center">{subhead}</p>
      <button
        type="button"
        className="relative rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] px-8 py-4 uppercase tracking-wide-ui"
      >
        {buttonLabel}
      </button>
    </div>
  );

  return (
    <div className="w-[600px] max-w-full font-sans">
      {inset ? <div className="p-[30px]">{card}</div> : card}
    </div>
  );
}

export function MarketingHeroMobile({
  headline = "The Fall Edit",
  subhead = "New arrivals made for slow evenings at home.",
  buttonLabel = "Shop now",
  inset = false,
}: MarketingHeroProps) {
  const card = (
    <div className="bg-image-placeholder relative w-full h-[449px] rounded-[24px] overflow-hidden flex flex-col justify-end items-center gap-4 px-6 pt-6 pb-8">
      <div className="absolute inset-0 bg-black/25" />
      <h2 className="relative text-[38px] leading-[42px] font-display text-white text-center">
        {headline}
      </h2>
      <p className="relative text-base text-white text-center">{subhead}</p>
      <button
        type="button"
        className="relative rounded-pill bg-brand-pink text-charcoal font-bold text-[12px] px-8 py-4 uppercase tracking-wide-ui"
      >
        {buttonLabel}
      </button>
    </div>
  );

  return (
    <div className="w-[375px] max-w-full font-sans">
      {inset ? <div className="p-[10px]">{card}</div> : card}
    </div>
  );
}
