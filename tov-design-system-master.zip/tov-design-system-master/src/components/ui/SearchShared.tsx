import { Logo } from "./Logo";
import { Button } from "./Button";

/**
 * Shared pieces reused across the Search — Type A/B/C/D/E, Returning
 * Users, and No Results components (fileKey DTjIdCKhnDUVvJhEfpn10v).
 * Every Search type's Desktop variant shares the identical top bar
 * (announcement + logo + filled search input + account/wishlist/cart) and
 * "Showing results for 'X'" header, and the same product-card anatomy —
 * factored here once instead of repeated per type.
 */

export interface SearchProduct {
  image: string;
  title: string;
  price: string;
  materialTag?: string;
  /** `null` entries are non-solid (image-texture) fabric fills that can't be read as a hex color — rendered as a neutral placeholder swatch. */
  swatches?: (string | null)[];
}

export function SearchTopBar({ query }: { query: string }) {
  return (
    <div className="w-full bg-cream-50">
      <div className="bg-charcoal flex items-center justify-center gap-6 h-[26px]">
        <p className="text-[11px] text-white"><span className="font-bold">Shop Sale:</span> 10% off items $99+*</p>
        <p className="text-[11px] text-white"><span className="font-bold">Free shipping</span> on orders of $299</p>
      </div>
      <div className="bg-white flex items-center gap-6 px-10 py-4">
        <Logo className="h-6 text-charcoal shrink-0" />
        <div className="flex-1 flex items-center gap-inline-gap-sm rounded-pill bg-neutral-100 border border-neutral-200 px-5 py-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/search.svg" alt="" className="w-4 h-4" />
          <p className="text-xs text-ink">{query}</p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/profile.svg" alt="Account" className="w-6 h-6" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/heart.svg" alt="Wishlist" className="w-6 h-6" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/bag-alt-light.svg" alt="Cart" className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}

export function ResultsHeader({ query }: { query: string }) {
  return (
    <p className="text-xs text-ink px-10 pt-6 pb-4">
      <span className="text-ink-muted">Showing results for</span> &lsquo;{query}&rsquo;
    </p>
  );
}

export function ResultsHeaderMobile({ query }: { query: string }) {
  return (
    <p className="text-xs text-ink px-5 pt-6 pb-4">
      <span className="text-ink-muted">Showing results for</span> &lsquo;{query}&rsquo;
    </p>
  );
}

/**
 * Mobile top bar — identical to `MainNavMobile` (MainNav.tsx): announcement
 * + hamburger/logo/wishlist/cart + a search pill. Unlike Desktop, the
 * Mobile search pill always shows the static "Search for accent chairs..."
 * placeholder, never the live query.
 */
export function MobileSearchTopBar() {
  return (
    <div className="w-full bg-white">
      <div className="bg-charcoal flex items-center justify-center px-5 py-2.5">
        <p className="text-xs text-white">Free shipping on orders $299+</p>
      </div>
      <div className="flex items-center justify-between px-5 py-2.5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/menu.svg" alt="Menu" className="w-6 h-[18px]" />
        <Logo className="h-4 text-charcoal" />
        <div className="flex items-center gap-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/heart.svg" alt="Wishlist" className="w-6 h-6" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/bag-alt-light.svg" alt="Cart" className="w-6 h-6" />
        </div>
      </div>
      <div className="px-5 pb-2.5">
        <div className="flex items-center gap-inline-gap-sm rounded-pill bg-neutral-100 border border-neutral-200 px-5 py-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/search.svg" alt="" className="w-[14px] h-[14px]" />
          <p className="text-[10px] text-ink-muted">Search for accent chairs...</p>
        </div>
      </div>
    </div>
  );
}

/** "SEE ALL PRODUCTS (310)" — real verbatim text "See all products (310)", uppercased via CSS. Appears on every Mobile grid except Type C (single exact-match result). */
export function SeeAllProductsButton() {
  return (
    <div className="flex justify-center">
      <Button size="md">See all products (310)</Button>
    </div>
  );
}

/** "Showing All results (3)" — Type E's real (mixed-case source, uppercase-via-CSS) results-count label, Desktop and Mobile. */
export function ShowingAllResultsText({ count }: { count: number }) {
  return (
    <p className="text-center text-xs font-bold uppercase tracking-wide-ui text-ink">
      showing All results ({count})
    </p>
  );
}

const CATEGORY_LABELS_DESKTOP = ["Sofas", "Ottomans", "Benches", "Stools", "Wall art & Decor"];
/** Mobile's chip row genuinely reads "Wall art" (no "& Decor") in the real `characters` value — a different string, not a truncation. */
const CATEGORY_LABELS_MOBILE = ["Sofas", "Ottomans", "Benches", "Stools", "Wall art"];

/** Desktop's left category sidebar (Type B only — present but `opacity: 0` on Types A/C/D/E). Selected label turns `text-primary` (#B15A63), no background/border change. */
export function CategoryPanelDesktop({ selected }: { selected?: string }) {
  return (
    <div className="flex w-[178px] shrink-0 flex-col gap-4">
      <p className="text-xs font-bold text-ink-muted">Search results by category</p>
      {CATEGORY_LABELS_DESKTOP.map((label) => (
        <p key={label} className={`text-base font-bold ${label === selected ? "text-primary" : "text-charcoal"}`}>{label}</p>
      ))}
    </div>
  );
}

/** Mobile's category filter is a horizontal chip row, not a reflow of the desktop list. */
export function CategoryChipsMobile({ selected }: { selected?: string }) {
  return (
    <div className="flex flex-col gap-2 px-grid-margin">
      <p className="text-xs font-bold text-ink-muted">Search results by category:</p>
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {CATEGORY_LABELS_MOBILE.map((label) => (
          <span key={label} className={`shrink-0 whitespace-nowrap rounded-pill bg-neutral-300 px-4 py-2 text-xs font-bold ${label === selected ? "text-primary" : "text-ink-muted"}`}>{label}</span>
        ))}
      </div>
    </div>
  );
}

export function DesktopProductCard({ product }: { product: SearchProduct }) {
  return (
    <div className="w-full">
      <div className="relative rounded-app-sm overflow-hidden aspect-[303/379]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
      </div>
      <div className="pt-3 flex flex-col gap-1">
        {product.materialTag && <p className="text-xs font-semibold text-ink">{product.materialTag}</p>}
        <p className="text-lg text-ink">{product.title}</p>
        <p className="text-lg font-semibold text-ink">{product.price}</p>
        {product.swatches && (
          <div className="flex items-center gap-1.5 mt-1">
            {product.swatches.map((c, i) => (
              <span key={i} className="w-7 h-7 rounded-full border border-neutral-200" style={{ backgroundColor: c ?? "#E3E3E3" }} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function MobileProductCard({ product }: { product: SearchProduct }) {
  return (
    <div className="w-full">
      <div className="relative rounded-app-sm overflow-hidden aspect-[169/198]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
      </div>
      <div className="pt-2 flex flex-col gap-0.5">
        {product.materialTag && <p className="text-[10px] font-semibold text-ink">{product.materialTag}</p>}
        <p className="text-xs text-ink line-clamp-2">{product.title}</p>
        <p className="text-xs font-semibold text-ink">{product.price}</p>
      </div>
    </div>
  );
}

/** The "Summer Vacay" SALE promo — a single composited image (text baked in by Figma), reused across every Search type that shows it. */
export function PromoBanner() {
  return (
    <div className="w-full aspect-[1440/681] overflow-hidden">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/images/search/promo-summer-vacay-hero.jpg" alt="Sale — 15% off most items, free shipping on all orders $299+" className="w-full h-full object-cover" />
    </div>
  );
}
