/**
 * Marketing email "Category Cards" (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1754:458) — Draft. Desktop is a 4-up row (130x146 cards); Mobile is a 2x2
 * grid (172.5x194). Card bottom-padding is 12px desktop / 14px mobile — a
 * real divergence, not a scaled value.
 */
export interface MarketingCategoryCardsProps {
  categories?: [string, string, string, string];
}

const DEFAULT_CATEGORIES: [string, string, string, string] = [
  "Living room",
  "Accent chairs",
  "Outdoor",
  "Storage",
];

function CategoryCard({
  label,
  className = "",
  textClassName = "",
}: {
  label: string;
  className?: string;
  textClassName?: string;
}) {
  return (
    <div
      className={`bg-image-placeholder relative rounded-[16px] overflow-hidden flex items-end justify-center ${className}`}
    >
      <div className="absolute inset-0 bg-black/20" />
      <span
        className={`relative text-white font-bold uppercase tracking-wide-ui text-center ${textClassName}`}
      >
        {label}
      </span>
    </div>
  );
}

export function MarketingCategoryCardsDesktop({
  categories = DEFAULT_CATEGORIES,
}: MarketingCategoryCardsProps) {
  return (
    <div className="w-[600px] max-w-full font-sans px-[25px] flex gap-grid-gutter-sm">
      {categories.map((label) => (
        <CategoryCard
          key={label}
          label={label}
          className="w-[130px] h-[146px] pb-3"
          textClassName="text-[10px]"
        />
      ))}
    </div>
  );
}

export function MarketingCategoryCardsMobile({
  categories = DEFAULT_CATEGORIES,
}: MarketingCategoryCardsProps) {
  return (
    <div className="w-[375px] max-w-full font-sans px-2.5 grid grid-cols-2 gap-grid-gutter-sm">
      {categories.map((label) => (
        <CategoryCard
          key={label}
          label={label}
          className="w-[172.5px] h-[194px] pb-[14px]"
          textClassName="text-[11px]"
        />
      ))}
    </div>
  );
}
