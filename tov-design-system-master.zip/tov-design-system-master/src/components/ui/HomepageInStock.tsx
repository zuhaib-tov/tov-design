import { TextLink } from "./TextLink";

/**
 * The Homepage "In Stock" component (fileKey DTjIdCKhnDUVvJhEfpn10v, node
 * 1063:2295) — a lifestyle hero card beside a horizontally-scrolling row of
 * product tiles. Three variants share `Version=In Stock`:
 * - Desktop / Live: a 494 x 434 hero (36px radius, desk photo under a 20%
 *   black overlay) with a 46px GT Ultra Fine heading (white, wrapped to a
 *   354px measure) and a 14px Gotham Bold cream-50 link at its bottom-left,
 *   beside 312 x 434 product tiles. Each tile is a transparent product
 *   photo fitted inside a white card with a 6% black overlay on top. A 45px
 *   glass next-arrow button (white 0.6px outline, 7px radius) floats over the
 *   row, 100px from its right edge.
 * - Desktop / Draft (`status="draft"`): the first tile shortens to 344px and
 *   shows the product name (18px Gotham Book) and price (18px Gotham Bold)
 *   underneath.
 * - Mobile / Live: a 375 x 233 full-bleed hero (20% black overlay plus a
 *   bottom-weighted darkening gradient, 26px heading, "shop ready to ship"
 *   link) above a row of 135 x 190 tiles with a 16px radius and a 5% black
 *   tint.
 *
 * The caption under the heading is plain text, not a pill/badge. Both link
 * texts are `textCase: UPPER`.
 */
const HERO_IMAGE = "/images/homepage/in-stock/hero-desk.webp";

const DESKTOP_PRODUCTS = [
  { src: "/images/homepage/in-stock/product-bed.webp", alt: "Upholstered platform bed" },
  { src: "/images/homepage/in-stock/product-side-table.webp", alt: "Textured round side table" },
  { src: "/images/homepage/in-stock/product-dining-chair.webp", alt: "Upholstered dining chair" },
  { src: "/images/homepage/in-stock/product-ottoman.webp", alt: "Tie-waist linen ottoman" },
];

const MOBILE_PRODUCTS = [
  { src: "/images/homepage/in-stock/product-console.webp", alt: "Console table", fit: "object-contain" },
  { src: "/images/homepage/in-stock/product-lamp.webp", alt: "Table lamp with pleated shade", fit: "object-cover" },
  { src: "/images/homepage/in-stock/product-side-table.webp", alt: "Textured round side table", fit: "object-cover" },
  { src: "/images/homepage/in-stock/product-dining-chair.webp", alt: "Upholstered dining chair", fit: "object-contain" },
];

export type HomepageInStockStatus = "live" | "draft";

export function HomepageInStockDesktop({ status = "live" }: { status?: HomepageInStockStatus }) {
  const draft = status === "draft";
  return (
    <div className="flex gap-2.5 w-full">
      <div className="relative rounded-[36px] overflow-hidden w-[494px] h-[434px] shrink-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={HERO_IMAGE} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute bottom-5 left-5 right-5 pr-[100px] flex flex-col gap-2.5">
          <h3 className="font-display text-[46px] text-white leading-[50px]">In stock &amp; ready to ship</h3>
          <TextLink href="#" inverse className="self-start my-[8.5px]">All ready to ship</TextLink>
        </div>
      </div>
      <div className="relative flex-1 min-w-0 overflow-hidden">
        <div className="flex gap-2.5 overflow-x-auto no-scrollbar">
          {DESKTOP_PRODUCTS.map((product, i) => {
            const withInfo = draft && i === 0;
            const tile = (
              <div className={`relative rounded-[36px] overflow-hidden w-[312px] shrink-0 bg-white ${withInfo ? "h-[344px]" : "h-[434px]"}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={product.src} alt={product.alt} className="absolute inset-0 w-full h-full object-contain" />
                <div className="absolute inset-0 bg-black/[0.06]" />
              </div>
            );
            if (!withInfo) return <div key={product.src} className="shrink-0">{tile}</div>;
            return (
              <div key={product.src} className="flex flex-col gap-2.5 w-[312px] shrink-0">
                {tile}
                <div className="flex flex-col gap-[5px] w-[272px] text-[#333333]">
                  <p className="text-lg leading-[27px]">Luau Natural Rattan Round End Table</p>
                  <p className="text-lg leading-[21px] font-bold">$199</p>
                </div>
              </div>
            );
          })}
        </div>
        <button
          type="button"
          aria-label="Next product"
          className="absolute right-[100px] top-[175px] w-[45px] h-[45px] rounded-[7px] border-[0.6px] border-white backdrop-blur-[9px] flex items-center justify-center"
        >
          <svg width="45" height="45" viewBox="0 0 45 45" fill="none" aria-hidden="true">
            <path d="M18.75 31.875 28.125 22.5 18.75 13.125" stroke="white" strokeWidth="1.18" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>
    </div>
  );
}

export function HomepageInStockMobile() {
  return (
    <div className="flex flex-col w-full max-w-sm">
      <div className="relative overflow-hidden w-full aspect-[375/233]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={HERO_IMAGE} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(0,0,0,0)_42.7%,rgba(0,0,0,0.2)_100%)]" />
        <div className="absolute bottom-2.5 left-5 right-5 flex flex-col">
          <h3 className="font-display text-[26px] text-white leading-[30px]">In stock &amp; ready to ship</h3>
          <TextLink href="#" inverse className="self-start my-[8.5px]">Shop ready to ship</TextLink>
        </div>
      </div>
      <div className="flex gap-2.5 overflow-x-auto no-scrollbar py-2.5 pl-5">
        {MOBILE_PRODUCTS.map((product) => (
          <div key={product.src} className="relative rounded-2xl overflow-hidden w-[135px] h-[190px] shrink-0 bg-[#f2f2f2]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={product.src} alt={product.alt} className={`absolute inset-0 w-full h-full ${product.fit}`} />
          </div>
        ))}
      </div>
    </div>
  );
}
