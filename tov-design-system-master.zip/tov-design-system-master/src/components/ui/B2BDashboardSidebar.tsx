import { ReactNode } from "react";

/**
 * TOV B2B Dashboard / Sidebar — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 45:866, Dashboard page,
 * Organisms section. Desktop-only, 318x960. Eight real page variants
 * (one per active Dashboard page) share the same structure — an Account
 * Summary, two nav groups ("Main" and "Account") of Nav Item rows, and a
 * Help Card — and differ only in which single Nav Item is active.
 *
 * Active state (confirmed across the Overview and Orders variants):
 * a white pill background behind the row, with the icon and label both
 * recolored to the brand rose and the label weight bumped to bold.
 * Every other row stays on the sidebar's cream page background with a
 * muted gray icon and label.
 */
export type DashboardSidebarPage =
  | "overview"
  | "orders"
  | "saved-projects"
  | "marketing-materials"
  | "downloads"
  | "invoices"
  | "account-info"
  | "support";

const MAIN_ITEMS: { key: DashboardSidebarPage; label: string; icon: ReactNode }[] = [
  { key: "overview", label: "Overview", icon: <GridIcon /> },
  { key: "orders", label: "Orders", icon: <BoxIcon /> },
  { key: "saved-projects", label: "Saved Projects", icon: <HeartIcon /> },
  { key: "marketing-materials", label: "Marketing Materials", icon: <ArchiveIcon /> },
  { key: "downloads", label: "Downloads", icon: <DownloadIcon /> },
];

const ACCOUNT_ITEMS: { key: DashboardSidebarPage; label: string; icon: ReactNode }[] = [
  { key: "invoices", label: "Invoices", icon: <DocumentIcon /> },
  { key: "account-info", label: "Account Info", icon: <GearIcon /> },
  { key: "support", label: "Support", icon: <HeadsetIcon /> },
];

function NavRow({ label, icon, active }: { label: string; icon: ReactNode; active: boolean }) {
  return (
    <div
      className={`flex w-full items-center gap-3 rounded-[8px] px-3 py-[10px] ${
        active ? "bg-white" : ""
      }`}
    >
      <span className={`size-6 shrink-0 ${active ? "text-primary" : "text-[#8e8e8e]"}`}>{icon}</span>
      <span
        className={`whitespace-nowrap text-sm ${
          active ? "font-bold text-primary" : "font-normal text-[#8e8e8e]"
        }`}
      >
        {label}
      </span>
    </div>
  );
}

export function B2BDashboardSidebar({
  activePage = "overview",
  customerName = "Sarah Holloway",
  customerId = "CUS656273",
  repName = "Quinn Parker",
  repTitle = "Account Executive",
  className = "",
}: {
  activePage?: DashboardSidebarPage;
  customerName?: string;
  customerId?: string;
  repName?: string;
  repTitle?: string;
  className?: string;
}) {
  return (
    <div className={`flex h-[960px] w-[318px] flex-col gap-7 bg-cream-100 px-6 py-7 font-sans ${className}`}>
      <div className="flex w-full flex-col gap-3">
        <div className="flex flex-wrap items-baseline gap-[6px] whitespace-nowrap">
          <span className="text-xl font-bold text-charcoal">{customerName}</span>
          <span className="text-[11px] font-light text-[#8e8e8e]">| {customerId}</span>
        </div>
        <div className="flex w-full flex-col gap-[2px] rounded-[8px] bg-gradient-to-r from-primary to-[#f9d2d2] px-3 py-2 text-[11px] text-white">
          <span className="font-extrabold uppercase tracking-wide-ui">Pro Tier Member</span>
          <span className="font-medium opacity-90">Active 20% discount applied</span>
        </div>
      </div>

      <div className="flex w-full flex-col gap-5">
        <div className="flex w-full flex-col gap-1">
          <span className="text-[11px] font-bold uppercase tracking-wide-ui text-[#8e8e8e]">Main</span>
          {MAIN_ITEMS.map((item) => (
            <NavRow key={item.key} label={item.label} icon={item.icon} active={activePage === item.key} />
          ))}
        </div>
        <div className="flex w-full flex-col gap-1">
          <span className="text-[11px] font-bold uppercase tracking-wide-ui text-[#8e8e8e]">Account</span>
          {ACCOUNT_ITEMS.map((item) => (
            <NavRow key={item.key} label={item.label} icon={item.icon} active={activePage === item.key} />
          ))}
        </div>
      </div>

      <div className="flex-1" />

      <div className="flex w-full flex-col gap-4 rounded-[12px] border border-white bg-cream-200 p-4">
        <div className="flex w-full flex-col gap-1">
          <span className="text-[15px] font-bold text-charcoal">Need help?</span>
          <span className="text-[11px] text-[#8e8e8e]">Contact your account manager</span>
        </div>
        <div className="flex w-full items-center gap-[10px]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/b2b/dashboard/avatar-small.png"
            alt={repName}
            className="size-10 shrink-0 rounded-[20px] object-cover"
          />
          <div className="flex min-w-0 flex-1 flex-col gap-[2px]">
            <span className="text-[13px] font-semibold text-charcoal">{repName}</span>
            <span className="text-[11px] text-[#8e8e8e]">{repTitle}</span>
          </div>
        </div>
        <button className="w-full rounded-pill bg-primary px-6 py-3 text-xs font-bold tracking-wide-ui text-white">
          Contact {repName.split(" ")[0]}
        </button>
      </div>
    </div>
  );
}

function GridIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="size-full" aria-hidden>
      <rect x="4" y="4" width="7" height="7" rx="1.5" />
      <rect x="13" y="4" width="7" height="7" rx="1.5" />
      <rect x="4" y="13" width="7" height="7" rx="1.5" />
      <rect x="13" y="13" width="7" height="7" rx="1.5" />
    </svg>
  );
}

function BoxIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M3.5 7.5 12 3l8.5 4.5L12 12 3.5 7.5Z" />
      <path d="M3.5 7.5V16L12 20.5V12" />
      <path d="M20.5 7.5V16L12 20.5" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="size-full" aria-hidden>
      <path d="M12 20S3 14.5 3 8.6C3 5.5 5.5 3 8.6 3c1.7 0 3.2.8 4.1 2.1.9-1.3 2.4-2.1 4.1-2.1C19.9 3 22.4 5.5 22.4 8.6c0 5.9-8.9 11.4-8.9 11.4H12Z" transform="translate(-1 0)" />
    </svg>
  );
}

function ArchiveIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <rect x="3" y="4" width="18" height="4.5" rx="1" />
      <path d="M4.5 8.5V19a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V8.5" />
      <path d="M10 13h4" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M12 3.5v11" />
      <path d="M7.5 10 12 14.5 16.5 10" />
      <path d="M4 17.5v1.8a1.7 1.7 0 0 0 1.7 1.7h12.6a1.7 1.7 0 0 0 1.7-1.7v-1.8" />
    </svg>
  );
}

function DocumentIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M7 3.5h7l4 4v12.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15.5a1 1 0 0 1 1-1Z" />
      <path d="M14 3.5V8h4" />
      <path d="M8.5 13h7M8.5 16.5h7" />
    </svg>
  );
}

function GearIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 3.5v2.3M12 18.2v2.3M20.5 12h-2.3M5.8 12H3.5M17.8 6.2l-1.6 1.6M7.8 16.2l-1.6 1.6M17.8 17.8l-1.6-1.6M7.8 7.8 6.2 6.2" />
    </svg>
  );
}

function HeadsetIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M4 13v-1a8 8 0 0 1 16 0v1" />
      <rect x="3" y="13" width="4" height="6" rx="1.3" />
      <rect x="17" y="13" width="4" height="6" rx="1.3" />
      <path d="M19 19v1a2 2 0 0 1-2 2h-3" />
    </svg>
  );
}
