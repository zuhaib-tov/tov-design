/**
 * Email Sign Up (fileKey DTjIdCKhnDUVvJhEfpn10v, node 1688:3636) — the
 * banner shown when no sign-up pop-up is active. 2 real variants:
 * `Property 1=Default` (Desktop, `1688:3637`) and `Property 1=mobile`
 * (`1688:3646`). Solid `#3F3D3E` (charcoal) background on both; Desktop
 * lays the heading block, pill input, and pill button out in a single
 * horizontal row, Mobile stacks heading → input → button vertically.
 * "submit" is genuinely lowercase in the Figma source, not a typo.
 */
export function EmailSignUpDesktop() {
  return (
    <div className="w-full bg-charcoal flex items-center gap-5 px-page-margin-desktop py-5">
      <div className="flex flex-col gap-[5px] shrink-0 min-w-[679px]">
        <h2 className="font-display text-[38px] leading-[42px] text-white">Sign up for our email list</h2>
        <p className="text-lg leading-[27px] text-white">Drop your email to get first dips on new arrivals, sale and more.</p>
      </div>
      <form className="flex items-center gap-2.5 shrink-0">
        <input
          type="email"
          placeholder="Email Address"
          className="rounded-pill border border-white bg-transparent px-6 py-2.5 text-sm font-medium text-[#A4A4A4] placeholder-[#A4A4A4] w-[351px] outline-none"
        />
        <button type="submit" className="rounded-pill bg-white text-charcoal text-sm font-bold tracking-wide-ui px-[54px] py-5 whitespace-nowrap">
          submit
        </button>
      </form>
    </div>
  );
}

export function EmailSignUpMobile() {
  return (
    <div className="w-full max-w-sm bg-charcoal flex flex-col items-center gap-2.5 px-page-margin-mobile py-5">
      <div className="flex flex-col items-center gap-3 text-center">
        <h2 className="font-display text-[38px] leading-[42px] text-white">Sign up for our email list</h2>
        <p className="text-base leading-6 text-white">Drop your email to get first dips on new arrivals, sale and more.</p>
      </div>
      <form className="w-full flex flex-col items-center gap-5">
        <input
          type="email"
          placeholder="Email Address"
          className="w-full rounded-pill border border-white bg-transparent px-6 py-2.5 text-sm font-medium text-[#A4A4A4] placeholder-[#A4A4A4] outline-none"
        />
        <button type="submit" className="rounded-pill bg-white text-charcoal text-sm font-bold tracking-wide-ui px-[54px] py-5 whitespace-nowrap">
          submit
        </button>
      </form>
    </div>
  );
}
