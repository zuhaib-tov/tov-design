/**
 * The PDP "Bread Crumbs" component (fileKey ySZYmjbO2Wck8u1JGAtI5J, node
 * 582:11812) — standalone, not a variant set. Figma's own content is
 * template placeholder text ("Menu Item", "[Prod Name] TOV-000000"),
 * reproduced as-is rather than invented. The home icon is a distinct
 * smaller/lighter-weight glyph from the General UI "home" icon (11.98x12.15,
 * neutral-700, 0.94px stroke vs. the library icon's 24x24/#363538/1.5px) —
 * inlined here instead of reusing the wrong-colored library asset.
 */
const HOME_PATH =
  "M5.98994 9.1766V7.3016M0.798912 9.38421L0.477408 5.52616C0.407248 4.68425 0.767048 3.86385 1.43392 3.34517L4.45509 0.995369C5.35787 0.29321 6.62202 0.293211 7.5248 0.99537L10.546 3.34517C11.2128 3.86385 11.5726 4.68425 11.5025 5.52616L11.181 9.38421C11.073 10.6799 9.98983 11.6766 8.68961 11.6766H3.29028C1.99005 11.6766 0.906889 10.6799 0.798912 9.38421Z";

export interface PDPBreadCrumbsProps {
  menuItem?: string;
  productLabel?: string;
}

export function PDPBreadCrumbs({
  menuItem = "Menu Item",
  productLabel = "[Prod Name] TOV-000000",
}: PDPBreadCrumbsProps) {
  return (
    <nav className="flex items-center gap-1.5 font-sans text-neutral-700">
      <svg viewBox="0 0 11.98 12.15" className="w-[15px] h-[15px] shrink-0" fill="none" stroke="currentColor" strokeWidth="0.9375" strokeLinecap="round" strokeLinejoin="round">
        <path d={HOME_PATH} />
      </svg>
      <span className="w-px h-2.5 bg-neutral-700 rounded-full" />
      <a href="#" className="text-xs hover:underline">{menuItem}</a>
      <span className="w-px h-2.5 bg-neutral-700 rounded-full" />
      <span className="text-xs">{productLabel}</span>
    </nav>
  );
}
