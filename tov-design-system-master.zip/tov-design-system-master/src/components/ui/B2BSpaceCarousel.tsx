"use client";

import { useRef } from "react";
import { ChevronRight } from "lucide-react";
import { B2BSpaceCard } from "./B2BSpaceCard";

export interface B2BSpaceCarouselItem {
  title: string;
  linkLabel?: string;
}

export interface B2BSpaceCarouselProps {
  spaces: B2BSpaceCarouselItem[];
  viewport?: "desktop" | "mobile";
  className?: string;
}

/**
 * Horizontally scrolling row of Space Cards for introducing spaces or project
 * applications. Desktop sits the row on the 75px page margin with a carousel
 * arrow anchored to the right edge; Mobile runs the row from a 20px inset with
 * touch scrolling and no arrow.
 */
export function B2BSpaceCarousel({ spaces, viewport = "desktop", className = "" }: B2BSpaceCarouselProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const isMobile = viewport === "mobile";

  const scrollNext = () => {
    trackRef.current?.scrollBy({ left: 325, behavior: "smooth" });
  };

  if (isMobile) {
    return (
      <div className={`w-[390px] max-w-full font-sans ${className}`}>
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto py-5 pl-5 pr-5">
          {spaces.map((s) => (
            <div key={s.title} className="shrink-0">
              <B2BSpaceCard title={s.title} linkLabel={s.linkLabel} viewport="mobile" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-[1440px] font-sans ${className}`}>
      <div ref={trackRef} className="no-scrollbar flex scroll-smooth gap-2.5 overflow-x-auto py-5 pl-[75px] pr-[75px]">
        {spaces.map((s) => (
          <div key={s.title} className="shrink-0">
            <B2BSpaceCard title={s.title} linkLabel={s.linkLabel} viewport="desktop" />
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={scrollNext}
        aria-label="Next spaces"
        className="absolute right-6 top-[190px] flex h-10 w-10 items-center justify-center rounded-md bg-white/[0.44] shadow-[0_2px_8px_rgba(63,61,62,0.18)]"
      >
        <ChevronRight className="h-4 w-4 text-primary" />
      </button>
    </div>
  );
}
