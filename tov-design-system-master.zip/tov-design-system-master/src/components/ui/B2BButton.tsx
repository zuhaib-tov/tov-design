import { ButtonHTMLAttributes, forwardRef } from "react";

/**
 * TOV B2B core button set — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), Core/Button component set (node 4:28).
 * Primary and Outline Inverse each ship Desktop/Mobile sizing (padding taken
 * directly from the real variants: 20/79px desktop, 16/24px mobile). Outline
 * Inverse Compact, Header Join and Header Sign In are desktop-only header
 * treatments and keep a single size. Header Join/Header Sign In use sentence
 * case in the source file — not uppercased like the other three.
 */
type Variant =
  | "primary"
  | "outline-inverse"
  | "outline-inverse-compact"
  | "header-join"
  | "header-sign-in";
type Size = "desktop" | "mobile";

export interface B2BButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  /** Leading profile icon — defaults on for Header Sign In, matching the real variant. */
  icon?: boolean;
}

const base =
  "inline-flex items-center justify-center gap-2 rounded-pill font-bold transition-colors disabled:opacity-40 disabled:pointer-events-none";

const uppercase = "uppercase tracking-wide-ui";

function variantClasses(variant: Variant, size: Size): string {
  switch (variant) {
    case "primary":
      return `bg-charcoal text-white hover:bg-primary-dark ${uppercase} text-sm ${
        size === "mobile" ? "px-6 py-4" : "px-[79px] py-5"
      }`;
    case "outline-inverse":
      return `bg-transparent text-white border border-white hover:bg-white hover:text-charcoal ${uppercase} text-sm ${
        size === "mobile" ? "px-6 py-[14px]" : "px-[79px] py-5"
      }`;
    case "outline-inverse-compact":
      return `bg-transparent text-white border border-white hover:bg-white hover:text-charcoal ${uppercase} text-sm px-[75px] py-4`;
    case "header-join":
      return "bg-transparent text-primary border border-primary hover:bg-primary hover:text-white text-sm px-4 py-[11px]";
    case "header-sign-in":
      return "bg-primary text-white hover:bg-primary-dark text-sm px-4 py-[11px]";
  }
}

export const B2BButton = forwardRef<HTMLButtonElement, B2BButtonProps>(
  ({ variant = "primary", size = "desktop", icon, className = "", children, ...props }, ref) => {
    const showIcon = icon ?? variant === "header-sign-in";
    return (
      <button
        ref={ref}
        className={`${base} ${variantClasses(variant, size)} ${className}`}
        {...props}
      >
        {showIcon && (
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className="shrink-0" aria-hidden>
            <circle cx="7" cy="4.5" r="2.5" fill="currentColor" />
            <path d="M2 13c0-2.76 2.24-5 5-5s5 2.24 5 5" fill="currentColor" />
          </svg>
        )}
        {children}
      </button>
    );
  }
);
B2BButton.displayName = "B2BButton";
