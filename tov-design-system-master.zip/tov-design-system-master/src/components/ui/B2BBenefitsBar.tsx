import { Library, ShieldCheck, Truck, Palette } from "lucide-react";
import { B2BBenefitItem } from "./B2BBenefitItem";

/**
 * TOV B2B — Benefits Bar. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 14:254 ("Benefits Bar" symbol frame),
 * Default/Desktop (14:221, a single mauve band, 4 Benefit Items in a row
 * separated by vertical dividers) and Default/Mobile (14:253, mauve bar,
 * Benefit Items stacked with horizontal dividers) variants.
 *
 * Grouped program benefits using repeated Benefit Items. Desktop and mobile
 * layouts share the benefit story; maintain clear icon-to-label relationships.
 */
const BENEFITS = [
  { icon: Library, title: "Digital Asset Library", description: "Access an expansive library of digital assets for projects of every scale." },
  { icon: ShieldCheck, title: "Contract Grade Quality", description: "Certified to withstand severe corporate and hospitality applications." },
  { icon: Truck, title: "Dropship", description: "Ship directly to your clients without ever handling the logistics yourself." },
  { icon: Palette, title: "Services for Designers", description: "Designer-first personalized solutions for scale layouts and bulk orders." },
];

export interface B2BBenefitsBarProps {
  compact?: boolean;
  className?: string;
}

export function B2BBenefitsBar({ compact = false, className = "" }: B2BBenefitsBarProps) {
  return (
    <div
      className={`bg-primary flex ${
        compact ? "w-[390px] flex-col gap-5 px-5 py-8" : "w-[1440px] flex-row items-center gap-7 px-[75px] py-10"
      } ${className}`}
    >
      {BENEFITS.map((benefit, i) => (
        <div key={benefit.title} className={compact ? "contents" : "flex items-center gap-7 flex-1"}>
          <B2BBenefitItem icon={benefit.icon} title={benefit.title} description={benefit.description} />
          {i < BENEFITS.length - 1 &&
            (compact ? (
              <div className="h-px w-full bg-cream-200" />
            ) : (
              <div className="w-px h-13 bg-cream-200 shrink-0" />
            ))}
        </div>
      ))}
    </div>
  );
}
