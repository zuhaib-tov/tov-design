import { Button } from "./Button";
import { B2BButton } from "./B2BButton";
import { B2BProgramCard, TRADE_PROGRAM_PERKS, WHOLESALE_PERKS } from "./B2BProgramCard";

/**
 * TOV B2B — Trade Programs. Source: Figma "TOV26 - B2B - Design system"
 * (CGe5J4j6AI5uus5G2f8iqh), node 19:530 ("Trade Programs" symbol frame),
 * Default/Desktop (19:451, 1440x841) and Default/Mobile (19:529, 390x1362)
 * variants.
 *
 * Complete partnership section combining program cards and introductory
 * messaging. Use to compare Trade Program and Wholesale offers at the
 * appropriate viewport. A composition of two Program Cards plus the shared
 * Button and Apply note — not its own separate markup.
 */
export interface B2BTradeProgramsProps {
  compact?: boolean;
  className?: string;
}

export function B2BTradePrograms({ compact = false, className = "" }: B2BTradeProgramsProps) {
  return (
    <div
      className={`bg-cream-100 flex flex-col ${
        compact ? "w-[390px] gap-8 px-5 py-10" : "w-[1440px] gap-14 px-[100px] py-10"
      } ${className}`}
    >
      <div className="flex flex-col gap-3 items-center text-center">
        <p className="text-base font-semibold text-charcoal tracking-wide-ui uppercase">
          Professional Partnership
        </p>
        <h2 className={`font-display text-charcoal leading-tight ${compact ? "text-[26px]" : "text-[46px] max-w-[913px]"}`}>
          Perks That Make Furnishing Projects Easier
        </h2>
      </div>

      <div className={`flex gap-10 ${compact ? "flex-col" : "flex-row"}`}>
        <B2BProgramCard
          title="Trade Program"
          description="Perfect For interior designers, staging companies, hospitality projects and event planners."
          perks={TRADE_PROGRAM_PERKS}
          compact={compact}
        />
        <B2BProgramCard
          title="Wholesale"
          description="Perfect for brick & mortar stores and stocking dealers."
          tierBadge="Tier II"
          tierLabel="PREMIUM"
          perks={WHOLESALE_PERKS}
          compact={compact}
        />
      </div>

      <div className={`flex flex-col gap-4 ${compact ? "" : "items-center"}`}>
        {compact ? (
          <Button variant="primary" className="w-full">
            Apply Now
          </Button>
        ) : (
          <B2BButton variant="primary" className="w-fit px-[119px]!">
            Apply Now
          </B2BButton>
        )}
        <p className={`text-sm text-[#8e8e8e] ${compact ? "" : "text-center max-w-[709px]"}`}>
          One application for both programs — we&apos;ll match you with the right fit based on your business needs.
        </p>
      </div>
    </div>
  );
}
