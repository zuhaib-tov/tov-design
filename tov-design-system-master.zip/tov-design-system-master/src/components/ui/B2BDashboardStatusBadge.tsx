/**
 * TOV B2B Dashboard / Status Badge — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), component set 36:655. Order-status pill
 * driven by the status/* tokens: 10px padding x 5px, 10px Montserrat Medium
 * uppercase label, fully rounded.
 */
export type DashboardStatus = "shipped" | "processing" | "delivered" | "cancelled";

export interface B2BDashboardStatusBadgeProps {
  status?: DashboardStatus;
  /** Overrides the default label for the status. */
  children?: React.ReactNode;
  className?: string;
}

const styles: Record<DashboardStatus, { cls: string; label: string }> = {
  shipped: { cls: "bg-[#ebf3fc] text-[#1f78c1]", label: "Shipped" },
  processing: { cls: "bg-[#fffbeb] text-[#d1af52]", label: "Processing" },
  delivered: { cls: "bg-[#ecfdf5] text-[#32c11f]", label: "Delivered" },
  cancelled: { cls: "bg-[#fee2e2] text-[#ef4444]", label: "Cancelled" },
};

export function B2BDashboardStatusBadge({
  status = "shipped",
  children,
  className = "",
}: B2BDashboardStatusBadgeProps) {
  const s = styles[status];
  return (
    <span
      className={`inline-flex items-center justify-center whitespace-nowrap rounded-pill px-[10px] py-[5px] font-sans text-[10px] font-medium uppercase tracking-wide-ui ${s.cls} ${className}`}
    >
      {children ?? s.label}
    </span>
  );
}
