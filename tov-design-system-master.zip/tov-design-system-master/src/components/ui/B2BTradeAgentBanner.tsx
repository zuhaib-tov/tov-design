import { B2BButton } from "./B2BButton";

/**
 * TOV B2B — Trade Agent Banner. A full-width brand-colored band that invites
 * first-time visitors to speak with a trade agent: eyebrow, headline, a
 * short paragraph with phone and email contacts, and an outlined Contact Us
 * button.
 */
export interface B2BTradeAgentBannerProps {
  eyebrow?: string;
  title?: string;
  phone?: string;
  email?: string;
  ctaLabel?: string;
  className?: string;
}

export function B2BTradeAgentBanner({
  eyebrow = "New to TOV Professional?",
  title = "Talk to a trade agent.",
  phone = "516 - 888 - 3355",
  email = "sales@tovfurniture.com.",
  ctaLabel = "Contact us",
  className = "",
}: B2BTradeAgentBannerProps) {
  return (
    <section className={`w-[1440px] bg-primary px-[75px] py-5 ${className}`}>
      <div className="flex items-center gap-8 p-10">
        <div className="flex flex-1 flex-col gap-[13px] text-white">
          <div className="flex flex-col gap-3">
            <p className="text-base font-semibold uppercase leading-5 tracking-wide-ui">{eyebrow}</p>
            <h2 className="font-display text-[38px] leading-[42px]">{title}</h2>
          </div>
          <p className="max-w-[847px] text-base leading-[19px]">
            First time here? A real person can help you set up your account, unlock member pricing, and answer any
            questions about specifying for your projects. Call us at <u>{phone} </u>
            or email <u>{email}</u>
          </p>
        </div>
        <B2BButton variant="outline-inverse-compact">
          {ctaLabel}
        </B2BButton>
      </div>
    </section>
  );
}
