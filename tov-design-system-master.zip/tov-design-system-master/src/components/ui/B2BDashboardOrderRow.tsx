/**
 * TOV B2B Dashboard / Order Row — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:83, 3 variants: Shipped (41:68),
 * Processing (41:75), Delivered (41:82). Compact order line-item for the
 * Track Your Orders card. Cream (#faf7f2) fill, 12px radius, 12px padding/gap.
 *
 * The status dot and label share one color per variant: Shipped is brand
 * rose, Processing is a muted tan (#9e8567), Delivered is truffle (#82736c).
 * The secondary meta line ("Jun 24 • 24 items") is always truffle.
 */
export type B2BDashboardOrderRowStatus = "shipped" | "processing" | "delivered";

export interface B2BDashboardOrderRowProps {
  orderId: string;
  date: string;
  itemCount: number;
  status?: B2BDashboardOrderRowStatus;
  className?: string;
}

const STATUS_STYLES: Record<B2BDashboardOrderRowStatus, { dot: string; label: string }> = {
  shipped: { dot: "bg-primary", label: "text-primary" },
  processing: { dot: "bg-[#9e8567]", label: "text-[#9e8567]" },
  delivered: { dot: "bg-truffle", label: "text-truffle" },
};

export function B2BDashboardOrderRow({
  orderId,
  date,
  itemCount,
  status = "shipped",
  className = "",
}: B2BDashboardOrderRowProps) {
  const s = STATUS_STYLES[status];
  return (
    <div className={`flex w-full items-center gap-3 rounded-[12px] bg-cream-100 p-3 ${className}`}>
      <span className={`size-2 shrink-0 rounded-full ${s.dot}`} />
      <div className="flex min-w-0 flex-1 flex-col gap-0.5 whitespace-nowrap">
        <p className="font-sans text-[13px] font-semibold text-charcoal">Order ID {orderId}</p>
        <p className="font-sans text-[11px] font-normal text-truffle">
          {date} • {itemCount} items
        </p>
      </div>
      <p className={`font-sans text-[11px] font-bold uppercase tracking-wide-ui ${s.label}`}>{status}</p>
    </div>
  );
}
