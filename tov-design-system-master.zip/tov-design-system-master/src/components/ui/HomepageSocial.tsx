import { Button } from "./Button";

/**
 * The Homepage "Social" module (fileKey DTjIdCKhnDUVvJhEfpn10v) — 4
 * separate pieces that sit stacked on the page:
 * - Social CTA Header (node 1063:5022): cream (`cream-200`) banner.
 *   Desktop (1440 wide, 100px side padding) holds the heading +
 *   subheading on the left and a "Find us on social" outline pill on the
 *   right. Mobile (375 wide) is the heading + subheading only, centered,
 *   with no button.
 * - Social Post Container (node 1063:5053): Short/Medium/Tall (402 wide,
 *   467/480/584 tall) lifestyle photo cards with a 36px radius and a
 *   circular glass "add to cart" button (44px, charcoal at 20%, bag-add
 *   icon) pinned to the bottom-left corner.
 * - Social (node 1063:5069): the small 16px-radius photo card, Desktop
 *   160x207 and Mobile 160x265, with the same glass button inset 10px.
 * - Get the Look (node 1063:5870): a white card with a soft shadow — header
 *   row with a bordered close button, a lifestyle photo, and a product row
 *   (thumbnail, name, price and a small "Add to cart" pill). Desktop is
 *   700 wide (36px radius); Mobile is 342 wide (16px radius) and stacks the
 *   pill under the product name.
 *
 * The heading "TOV + you" mixes two faces: "TOV" is GT Ultra Fine
 * (`font-display`, 60px Desktop / 28px Mobile) and "+ you" is Gotham Light
 * (Montserrat Light, 64px Desktop / 28px Mobile).
 *
 * The "Find us on social" CTA is built inline rather than with the
 * shared `Button` component: the real Figma instance is fully
 * transparent (`fills.visible: false`) with just a charcoal border,
 * which doesn't match any existing Button variant. It is 54px tall with
 * 68px of horizontal padding including the 1px border.
 *
 * Photography lives in `public/images/homepage/social/`: one lifestyle
 * photo shared by every post card, and the Get the Look nightstand scene
 * with its product thumbnail (the mobile card uses a tighter crop).
 */

const IMG = "/images/homepage/social";

// Figma's `bag-add` glyph (24x24 frame, 1.5px white round stroke).
function BagAddIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <g transform="translate(2.74 2)" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18.26 12C18.56 9.54 18.66 8.2 18.23 7.13C17.8 6.07 17.03 5.19 16.03 4.63C14.9 4 13.33 4 10.2 4H8.32C5.19 4 3.63 4 2.49 4.63C1.49 5.19 0.72 6.07 0.29 7.13C-0.2 8.33 0 9.88 0.38 12.99C0.7 15.47 0.85 16.71 1.43 17.65C1.95 18.47 2.69 19.13 3.57 19.54C4.57 20 5.82 20 8.32 20H10.2C10.22 20 10.24 20 10.26 20" />
        <path d="M14.26 18H18.26M16.26 16V20" />
        <path d="M13.26 7V4C13.26 1.79 11.47 0 9.26 0C7.05 0 5.26 1.79 5.26 4V7" />
      </g>
    </svg>
  );
}

// Circular glass "add to cart" button that sits on a photo.
function AddToCartGlass({ className }: { className: string }) {
  return (
    <button
      type="button"
      aria-label="Add to cart"
      className={`absolute w-11 h-11 rounded-full bg-charcoal/20 backdrop-blur-xs flex items-center justify-center ${className}`}
    >
      <BagAddIcon />
    </button>
  );
}

// Bordered square close button (36px Desktop, 19px Mobile).
function CloseButton({ compact }: { compact: boolean }) {
  return (
    <button
      type="button"
      aria-label="Close"
      className={`shrink-0 flex items-center justify-center border-charcoal ${
        compact ? "w-[19px] h-[19px] rounded-[4.2px] border-[0.53px]" : "w-9 h-9 rounded-lg border"
      }`}
    >
      <svg
        width={compact ? 6 : 12}
        height={compact ? 6 : 12}
        viewBox="0 0 12 12"
        fill="none"
        stroke="#3f3d3e"
        strokeWidth={2}
        strokeLinecap="round"
        aria-hidden="true"
        className="overflow-visible"
      >
        <path d="M0 0L12 12M12 0L0 12" />
      </svg>
    </button>
  );
}

export function HomepageSocialCtaHeader({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="bg-cream-200 w-full min-w-[375px] max-w-[375px] px-5 py-5 flex flex-col items-center gap-2.5 text-center text-charcoal">
        <h3 className="font-display text-[28px] leading-[22px] h-[22px]">
          TOV<span className="font-sans font-light"> + you</span>
        </h3>
        <p className="text-base leading-[19px]">Shape the Look</p>
      </div>
    );
  }
  return (
    <div className="bg-cream-200 px-page-margin-desktop py-[60px] flex flex-wrap items-center gap-5 w-full min-w-[1440px]">
      <div className="grow flex flex-col gap-[15px] text-charcoal whitespace-nowrap">
        <h3 className="font-display text-[60px] leading-[68px] h-[68px]">
          TOV<span className="font-sans font-light text-[64px]"> + you</span>
        </h3>
        <p className="text-[22px] leading-[33px]">Shape the Look</p>
      </div>
      <Button variant="tertiary" size="lg" className="shrink-0">
        Find us on social
      </Button>
    </div>
  );
}

export function HomepageSocialPostContainer({ size = "short" }: { size?: "short" | "medium" | "tall" }) {
  const aspect = size === "short" ? "aspect-[402/467]" : size === "medium" ? "aspect-[402/480]" : "aspect-[402/584]";
  return (
    <div className={`relative rounded-[36px] overflow-hidden w-full min-w-[402px] ${aspect}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`${IMG}/social-post-dresser.webp`} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <AddToCartGlass className="bottom-5 left-5" />
    </div>
  );
}

export function HomepageSocial({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`relative rounded-2xl overflow-hidden w-full min-w-[160px] ${compact ? "aspect-[160/265]" : "aspect-[160/207]"}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`${IMG}/social-post-dresser.webp`} alt="" className="absolute inset-0 w-full h-full object-cover" />
      <AddToCartGlass className="bottom-2.5 left-2.5" />
    </div>
  );
}

export function HomepageGetTheLook({ compact = false }: { compact?: boolean }) {
  const addToCart = (
    <Button size="sm" className="shrink-0 w-[126px]">
      Add to cart
    </Button>
  );
  return (
    <div
      className={`bg-white shadow-[0_0_4px_rgba(0,0,0,0.25)] flex flex-col gap-2.5 w-full text-[#333333] ${
        compact ? "min-w-[342px] max-w-[342px] rounded-2xl p-5" : "min-w-[700px] max-w-[700px] rounded-[36px] p-[30px]"
      }`}
    >
      <div className="flex items-start gap-2.5">
        <h3 className={`flex-1 font-display ${compact ? "text-[22px] leading-[25px]" : "text-[38px] leading-[42px]"}`}>
          Get the look
        </h3>
        <CloseButton compact={compact} />
      </div>
      <div className={`flex flex-col ${compact ? "gap-2.5" : "gap-5"}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={`${IMG}/get-the-look-nightstand-${compact ? "mobile" : "desktop"}.webp`}
          alt=""
          className={`w-full rounded-2xl object-cover ${compact ? "aspect-[302/218]" : "aspect-[640/321]"}`}
        />
        <div className="flex items-center gap-2.5 h-[138px] rounded-2xl border border-[#e8e8e8] p-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={`${IMG}/get-the-look-nightstand-product.webp`}
            alt=""
            className="w-[108px] h-[118px] shrink-0 rounded-2xl object-cover"
          />
          {compact ? (
            <div className="flex-1 min-w-0 flex flex-col gap-2.5">
              <div className="flex flex-col gap-[5px] pt-1.5">
                <p className="text-sm leading-[18px]">Amara 25&quot; Natural Rattan Nightstand</p>
                <p className="text-xs leading-[21px] font-bold">$449</p>
              </div>
              {addToCart}
            </div>
          ) : (
            <div className="flex-1 min-w-0 flex items-center gap-2.5">
              <div className="flex-1 min-w-0 flex flex-col gap-[5px]">
                <p className="text-lg leading-[27px]">Amara 25&quot; Natural Rattan Nightstand</p>
                <p className="text-lg leading-[21px] font-bold">$449</p>
              </div>
              {addToCart}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
