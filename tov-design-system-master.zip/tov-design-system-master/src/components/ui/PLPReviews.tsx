/**
 * Reviews (fileKey DTjIdCKhnDUVvJhEfpn10v, "💬Reviews" canvas, node
 * `152:3788`) — the review summary + filter + card-list block. Real
 * 3-variant set: Default Desktop (`152:3785`), Default Mobile
 * (`349:9086`), and "Reviews 3" Mobile (`152:3789`, a "Customer reviews"
 * plain-heading look used in a different placement — same summary/filter
 * chrome otherwise). Built the Default look for both viewports here.
 *
 * Scope note: this canvas also has two much larger sub-systems not
 * mapped in this pass — a 10-variant set of individual review-card
 * layouts (`Frame 1077`, e.g. cards with photos/video, "Desktop 1-4",
 * "Mobile 1-4") and a full 8-variant "Write a Review" authoring flow
 * (Desktop: Default/step 2/All Images/Success; Mobile: 4 steps) with
 * its own image upload and success states. Both are substantial enough
 * to warrant their own mapping pass.
 *
 * Real content: star rating fill color is `#F9D2D2`, an exact match for
 * the existing `--color-brand-pink` token (not `--color-primary`, unlike
 * the PDP `Rating` component — built inline here rather than reusing
 * `Rating.tsx` because of that color difference). Rating-breakdown bar
 * track is `#F1ECE5`, an exact match for `--color-cream-200`. 3 icons
 * (shield-check for the trust header, a check-in-circle for "Verified
 * buyer", thumbs up/down for the helpfulness vote) didn't exist in the
 * icon library and were exported directly from Figma. "Write a review"
 * and "load more reviews" reuse the existing `Button` component
 * (`primary`/`tertiary`) rather than rebuilding button styling.
 */
import { Button } from "./Button";

function Star({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 20 20" className={`w-4 h-4 ${filled ? "fill-brand-pink" : "fill-cream-200"}`}>
      <path d="M10 1.5l2.6 5.6 6.1.6-4.6 4.1 1.3 6-5.4-3.2-5.4 3.2 1.3-6-4.6-4.1 6.1-.6z" />
    </svg>
  );
}

function StarRow({ value = 5, size = "md" }: { value?: number; size?: "md" | "lg" }) {
  return (
    <div className="flex items-center">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 20 20" className={`${size === "lg" ? "w-5 h-5" : "w-4 h-4"} ${i < value ? "fill-brand-pink" : "fill-cream-200"}`}>
          <path d="M10 1.5l2.6 5.6 6.1.6-4.6 4.1 1.3 6-5.4-3.2-5.4 3.2 1.3-6-4.6-4.1 6.1-.6z" />
        </svg>
      ))}
    </div>
  );
}

const BREAKDOWN = [
  { stars: 5, count: 2 },
  { stars: 4, count: 0 },
  { stars: 3, count: 0 },
  { stars: 2, count: 0 },
  { stars: 1, count: 0 },
];

function RatingBreakdown() {
  const max = Math.max(...BREAKDOWN.map((b) => b.count), 1);
  return (
    <div className="flex flex-col gap-2">
      {BREAKDOWN.map((row) => (
        <div key={row.stars} className="flex items-center gap-2 text-sm text-charcoal">
          <span className="w-2.5 text-right">{row.stars}</span>
          <Star filled />
          <div className="w-[110px] h-1.5 rounded-full bg-cream-200 overflow-hidden">
            <div className="h-full rounded-full bg-charcoal" style={{ width: `${(row.count / max) * 100}%` }} />
          </div>
          <span className="w-4">{row.count}</span>
        </div>
      ))}
    </div>
  );
}

function PopularTopics() {
  return (
    <div className="flex flex-col gap-2">
      <p className="text-sm text-charcoal">Popular topics</p>
      <div className="flex flex-wrap gap-2">
        {["Tag here", "Tag here", "Tag here"].map((label, i) => (
          <span key={i} className="rounded-pill border border-charcoal bg-cream-100 px-4 py-2.5 text-sm text-charcoal whitespace-nowrap">
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}

function FilterRow({ stacked = false }: { stacked?: boolean }) {
  return (
    <div className={`flex ${stacked ? "flex-col" : "items-center"} gap-3`}>
      <div className="flex-1 flex items-center gap-2 rounded-pill border border-neutral-300 px-5 py-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/search.svg" alt="" className="w-4 h-4 shrink-0" />
        <span className="text-sm text-charcoal">Search reviews</span>
      </div>
      <div className="flex items-center justify-between gap-2 rounded-pill border border-neutral-300 px-5 py-3 whitespace-nowrap">
        <span className="text-sm text-charcoal">Rating</span>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/chevron-down.svg" alt="" className="w-4 h-4" />
      </div>
      {!stacked && (
        <div className="flex items-center gap-2 rounded-pill border border-neutral-300 px-5 py-3 whitespace-nowrap">
          <span className="text-sm text-charcoal">With media</span>
          <span className="w-5 h-5 rounded-full border border-neutral-400" />
        </div>
      )}
    </div>
  );
}

interface ReviewCardData {
  title: string;
  body: string;
  storeResponse?: string;
}

const SAMPLE_REVIEW: ReviewCardData = {
  title: "Review title",
  body: "Customer review will go here. This is example text showing how a review will look in this space. ",
  storeResponse: "Store owner response will go here. This is example text showing how a reply will look in this space. ",
};

function ReviewCard({ data }: { data: ReviewCardData }) {
  return (
    <div className="flex flex-col gap-3 bg-cream-100 rounded-app-lg p-card-padding-md">
      <div className="flex items-center justify-between">
        <StarRow value={0} />
        <span className="text-sm text-ink-muted">00/00/00</span>
      </div>
      <p className="text-2xl font-bold text-charcoal">{data.title}</p>
      <p className="text-base text-charcoal">
        {data.body}
        <span className="font-bold">Read more…</span>
      </p>
      <p className="text-base text-charcoal flex items-center gap-2">
        Customer name
        <span className="text-neutral-400">|</span>
        <span className="flex items-center gap-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/check-circle-outline.svg" alt="" className="w-4 h-4" />
          Verified buyer
        </span>
      </p>
      {data.storeResponse && (
        <div className="border-t border-neutral-300 pt-3 flex flex-col gap-2">
          <p className="text-base font-bold text-charcoal">Store owner</p>
          <p className="text-base text-charcoal">
            {data.storeResponse}
            <span className="font-bold">Read more…</span>
          </p>
          <p className="text-base text-charcoal flex items-center gap-2">
            Was this review helpful?
            <span className="text-neutral-400">|</span>
            <span className="flex items-center gap-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/thumbs-up.svg" alt="Helpful" className="w-[18px] h-[18px]" /> 0
            </span>
            <span className="flex items-center gap-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/icons/thumbs-down.svg" alt="Not helpful" className="w-[18px] h-[18px]" /> 0
            </span>
          </p>
        </div>
      )}
    </div>
  );
}

export function PLPReviewsDesktop() {
  return (
    <div className="w-full font-sans flex flex-col gap-6 overflow-x-auto">
      <div className="min-w-[1440px] flex flex-col gap-6">
        <div className="bg-cream-100 rounded-app-lg p-card-padding-lg flex flex-col gap-1">
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/shield-check.svg" alt="" className="w-11 h-11" />
            <h2 className="font-display text-[38px] leading-[42px] text-charcoal">
              Trusted by <span>1M+</span> Customers
            </h2>
          </div>
          <p className="text-lg leading-[27px] text-charcoal pl-14">Read reviews from real customers.</p>
        </div>

        <div className="border border-neutral-300 rounded-app-lg p-card-padding-lg flex items-center justify-between gap-10">
          <RatingBreakdown />
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <span className="text-[46px] leading-none text-charcoal">5</span>
              <div className="flex flex-col gap-1">
                <StarRow value={5} size="lg" />
                <span className="text-sm text-charcoal whitespace-nowrap">Based on 2 reviews</span>
              </div>
            </div>
            <Button variant="primary" size="lg">Write a review</Button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <FilterRow />
        </div>

        <div className="flex items-end justify-between">
          <PopularTopics />
          <p className="text-sm text-charcoal whitespace-nowrap">Sort by: With media</p>
        </div>

        <div className="grid grid-cols-3 gap-5">
          <ReviewCard data={SAMPLE_REVIEW} />
          <ReviewCard data={SAMPLE_REVIEW} />
          <ReviewCard data={SAMPLE_REVIEW} />
        </div>

        <div className="flex justify-center">
          <Button variant="tertiary" size="lg">Load more reviews</Button>
        </div>
      </div>
    </div>
  );
}

export function PLPReviewsMobile() {
  return (
    <div className="w-full max-w-sm font-sans flex flex-col gap-5">
      <div className="bg-cream-100 rounded-app-lg p-5 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/shield-check.svg" alt="" className="w-8 h-8 shrink-0" />
          <h2 className="font-display text-[22px] leading-[25px] text-charcoal">
            Trusted by <span>1M+</span> Customers
          </h2>
        </div>
        <p className="text-sm text-charcoal">Read reviews from real customers.</p>
      </div>

      <div className="border border-neutral-300 rounded-app-lg p-5 flex flex-col items-center gap-5">
        <div className="flex flex-col items-center gap-1">
          <span className="text-[46px] leading-none text-charcoal">5</span>
          <StarRow value={5} size="lg" />
          <span className="text-sm text-charcoal">Based on 2 reviews</span>
        </div>
        <RatingBreakdown />
        <Button variant="primary" size="lg" className="w-full">Write a review</Button>
      </div>

      <FilterRow stacked />
      <PopularTopics />
      <p className="text-sm text-charcoal text-right">Sort by: With media</p>

      <div className="flex flex-col gap-5">
        <ReviewCard data={SAMPLE_REVIEW} />
        <ReviewCard data={SAMPLE_REVIEW} />
      </div>

      <Button variant="tertiary" size="lg" className="w-full">Load more reviews</Button>
    </div>
  );
}
