/**
 * Search — Type E ("Collection / style name") — fileKey
 * DTjIdCKhnDUVvJhEfpn10v, node 1696:2539. 2 real variants: Desktop
 * (1696:2306) and Mobile (1696:2402). Query "Mah" (partial for "mahjong")
 * returns all 3 real Tomlin Mahjong-collection products — matches Figma's
 * own designer note flagging that "mahjong" searches convert at 0% despite
 * the underlying product being TOV's top converter.
 *
 * Ends with a real "showing All results (3)" label (literal mixed-case
 * source text, uppercased via CSS) instead of a "See all products"
 * button — this type's result set is already complete.
 */
import { SearchTopBar, MobileSearchTopBar, ResultsHeader, ResultsHeaderMobile, DesktopProductCard, MobileProductCard, PromoBanner, ShowingAllResultsText, type SearchProduct } from "./SearchShared";

const SWATCHES = ["#5D788A", "#A28E82", "#E2E1DE", "#B1A693", "#DBC1A6"];
const SWATCHES_MOBILE = ["#5D788A", "#A28E82", "#E2E1DE", "#B1A693"];

const DESKTOP_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/table-tomlin-mahjong.jpg", title: 'Tomlin 35" Square Mahjong Table', price: "$1,499", materialTag: "Performance Fabric", swatches: SWATCHES },
  { image: "/images/search/ottoman-tomlin-ruched-fabric-game.jpg", title: "Tomlin Ruched Fabric Game Ottoman", price: "$1,499", materialTag: "Performance Fabric", swatches: SWATCHES },
  { image: "/images/search/table-tomlin-chenille-game-set.jpg", title: "Tomlin Chenille Game Table and Two Ottomans Set", price: "$1,499", materialTag: "Performance Fabric", swatches: SWATCHES },
];

const MOBILE_PRODUCTS: SearchProduct[] = [
  { image: "/images/search/table-tomlin-mahjong-sq.jpg", title: 'Tomlin 35" Square Mahjong Table', price: "$479", materialTag: "Performance Fabric", swatches: SWATCHES_MOBILE },
  { image: "/images/search/ottoman-tomlin-ruched-fabric-game-sq.jpg", title: "Tomlin Ruched Fabric Game Ottoman", price: "$479", materialTag: "Performance Fabric", swatches: SWATCHES_MOBILE },
  { image: "/images/search/table-tomlin-chenille-game-set-sq.jpg", title: "Tomlin Chenille Game Table and Two Ottomans Set", price: "$479", materialTag: "Performance Fabric", swatches: SWATCHES_MOBILE },
];

export function SearchTypeEDesktop() {
  return (
    <div className="w-full font-sans">
      <SearchTopBar query="Mah" />
      <ResultsHeader query="Mah" />
      <div className="grid grid-cols-3 gap-grid-gutter-lg px-10 pb-6">
        {DESKTOP_PRODUCTS.map((p) => (
          <DesktopProductCard key={p.title} product={p} />
        ))}
      </div>
      <div className="pb-10">
        <ShowingAllResultsText count={3} />
      </div>
      <PromoBanner />
    </div>
  );
}

export function SearchTypeEMobile() {
  return (
    <div className="w-full max-w-sm font-sans bg-white">
      <MobileSearchTopBar />
      <ResultsHeaderMobile query="Mah" />
      <div className="grid grid-cols-2 gap-grid-gutter-md px-5 pb-6">
        {MOBILE_PRODUCTS.map((p) => (
          <MobileProductCard key={p.title} product={p} />
        ))}
      </div>
      <div className="pb-6">
        <ShowingAllResultsText count={3} />
      </div>
    </div>
  );
}
