import { PLPProductCard } from "./PLPProductCard";

/**
 * PLP Product Row (fileKey jDOs1dFChECKIYdAyPUkav, "💠Components" page,
 * "Product Display" section, node `1:556`) — a simple horizontal row of
 * `Product card`s, 10px gap. Real 2-variant set: Desktop (`1:555`, 4
 * Default-size cards) and Mobile (`1:557`, 2 Mobile-size cards).
 */
export function PLPProductRowDesktop() {
  return (
    <div className="w-full font-sans overflow-x-auto">
      <div className="flex gap-grid-gutter-sm min-w-[1418px]">
        {Array.from({ length: 4 }).map((_, i) => (
          <PLPProductCard key={i} size="desktop" />
        ))}
      </div>
    </div>
  );
}

export function PLPProductRowMobile() {
  return (
    <div className="w-full max-w-sm font-sans">
      <div className="flex gap-grid-gutter-sm">
        {Array.from({ length: 2 }).map((_, i) => (
          <PLPProductCard key={i} size="mobile" />
        ))}
      </div>
    </div>
  );
}
