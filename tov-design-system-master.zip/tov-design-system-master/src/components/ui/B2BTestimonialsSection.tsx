/* eslint-disable @next/next/no-img-element */
import { B2BRatingStars } from "./B2BRatingStars";
import { B2BTestimonialCard } from "./B2BTestimonialCard";

/**
 * TOV B2B — Testimonials Section. Social proof for the trade: an eyebrow and
 * headline with an aggregate rating on the right, a row of three Testimonial
 * Cards, and a divider above a strip of partner logos.
 */
export interface B2BTestimonialsSectionTestimonial {
  quote: string;
  name: string;
  role: string;
}

export interface B2BPartnerLogo {
  name: string;
  src: string;
  width: number;
  height: number;
}

export interface B2BTestimonialsSectionProps {
  eyebrow?: string;
  title?: string;
  ratingLabel?: string;
  testimonials: B2BTestimonialsSectionTestimonial[];
  partners?: B2BPartnerLogo[];
  partnersLabel?: string;
  className?: string;
}

export function B2BTestimonialsSection({
  eyebrow = "Trusted by the trade",
  title = "Specified on real projects, from boutique hotels to model homes.",
  ratingLabel = "4.8/5 from 4,000+ design pros",
  testimonials,
  partners = [],
  partnersLabel = "Our partners",
  className = "",
}: B2BTestimonialsSectionProps) {
  return (
    <section className={`flex w-[1440px] flex-col gap-10 bg-cream-100 px-[75px] py-10 ${className}`}>
      <div className="flex items-end justify-between">
        <div className="flex w-[800px] flex-col gap-3">
          <p className="text-base font-semibold uppercase leading-5 tracking-wide-ui text-charcoal">{eyebrow}</p>
          <h2 className="font-display text-[26px] leading-[30px] text-charcoal">{title}</h2>
        </div>
        <div className="flex items-center gap-4 pb-px">
          <p className="text-base text-charcoal">{ratingLabel}</p>
          <B2BRatingStars />
        </div>
      </div>

      <div className="flex gap-8">
        {testimonials.map((t) => (
          <B2BTestimonialCard key={t.name} {...t} className="min-w-0 flex-1 border-primary/[0.29]!" />
        ))}
      </div>

      {partners.length > 0 && (
        <div className="flex flex-col gap-5">
          <div className="h-px w-full bg-neutral-300" />
          <div className="flex items-center gap-11">
            <p className="whitespace-nowrap text-sm uppercase tracking-wide-ui text-charcoal">{partnersLabel}</p>
            {partners.map((p) => (
              <img key={p.name} src={p.src} alt={p.name} width={p.width} height={p.height} className="shrink-0" />
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
