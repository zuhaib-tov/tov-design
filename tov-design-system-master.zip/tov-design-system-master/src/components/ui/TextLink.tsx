import { AnchorHTMLAttributes, forwardRef } from "react";

/**
 * Text call to action. Two forms:
 *
 * - `cta` — the underlined call to action used under category tiles and
 *   banners ("Shop now", "All new arrivals"). Bold, uppercase, underlined,
 *   +4.5% letter-spacing. Large is 16/18, Medium is 14/16, Small is 12/14.
 * - `inline` — a link inside a sentence or a footer line ("Learn more",
 *   "See examples"). Regular weight, sentence case, underlined, no tracking.
 *
 * `inverse` swaps the color to cream for dark backgrounds and photography.
 * Hover shifts the label to the brand mauve (cream links fade to 80%).
 * `data-state` forces a state for the docs.
 */
type Form = "cta" | "inline";
type Size = "lg" | "md" | "sm";

const base =
  "inline-flex items-center gap-2 whitespace-nowrap underline underline-offset-[3px] decoration-1 transition-colors outline-none focus-visible:outline-2 focus-visible:outline-offset-4 data-[state=focus]:outline-2 data-[state=focus]:outline-offset-4 aria-disabled:opacity-50 aria-disabled:pointer-events-none";

const forms: Record<Form, string> = {
  cta: "font-bold uppercase tracking-wide-ui",
  inline: "font-normal normal-case tracking-normal",
};

const sizes: Record<Size, string> = {
  md: "text-sm leading-4",
  lg: "text-base leading-[18px]",
  sm: "text-xs leading-[14px]",
};

const tones = {
  default:
    "text-charcoal hover:text-primary active:text-primary data-[state=hover]:text-primary data-[state=pressed]:text-primary focus-visible:outline-charcoal data-[state=focus]:outline-charcoal",
  inverse:
    "text-cream-50 hover:opacity-80 active:opacity-80 data-[state=hover]:opacity-80 data-[state=pressed]:opacity-80 focus-visible:outline-cream-50 data-[state=focus]:outline-cream-50",
};

export interface TextLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  form?: Form;
  size?: Size;
  inverse?: boolean;
  disabled?: boolean;
  state?: "hover" | "pressed" | "focus";
}

/**
 * Class names a developer adds to a link outside the component library:
 * `tov-link` on every link, one form, `tov-link--lg` for Large or
 * `tov-link--sm` for Small (Medium has no size class) and `tov-link--inverse`
 * on dark backgrounds. States are selectors (`:hover`, `:active`,
 * `:focus-visible`, `[aria-disabled="true"]`), not classes.
 */
export function textLinkClasses({
  form = "cta",
  size = "md",
  inverse = false,
}: Pick<TextLinkProps, "form" | "size" | "inverse"> = {}) {
  return ["tov-link", `tov-link--${form}`, size !== "md" && `tov-link--${size}`, inverse && "tov-link--inverse"]
    .filter(Boolean)
    .join(" ");
}

export const TextLink = forwardRef<HTMLAnchorElement, TextLinkProps>(
  ({ form = "cta", size = "md", inverse = false, disabled = false, state, className = "", ...props }, ref) => (
    <a
      ref={ref}
      data-state={state}
      aria-disabled={disabled || undefined}
      tabIndex={disabled ? -1 : props.tabIndex}
      className={`${textLinkClasses({ form, size, inverse })} ${base} ${forms[form]} ${sizes[size]} ${inverse ? tones.inverse : tones.default} ${className}`}
      {...props}
    />
  )
);
TextLink.displayName = "TextLink";
