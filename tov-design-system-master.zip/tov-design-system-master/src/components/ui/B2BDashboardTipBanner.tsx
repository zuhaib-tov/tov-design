import { Lightbulb } from "lucide-react";

/**
 * TOV B2B Dashboard / Tip Banner — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 41:98 → Version=Default (41:97),
 * full-width (1066px). Inline help/tip strip shown at the bottom of resource
 * pages. Cream (#faf7f2) fill, #e5ddd5 border, 12px radius, 20px padding.
 */
export interface B2BDashboardTipBannerProps {
  /** Bold lead-in, e.g. "Tip:". */
  lead?: string;
  text: string;
  className?: string;
}

export function B2BDashboardTipBanner({ lead = "Tip:", text, className = "" }: B2BDashboardTipBannerProps) {
  return (
    <div
      className={`flex w-full items-center gap-4 rounded-[12px] border border-[#e5ddd5] bg-cream-100 p-5 ${className}`}
    >
      <Lightbulb size={16} className="shrink-0 text-primary" strokeWidth={1.75} />
      <p className="flex-1 font-sans text-[13px]">
        <span className="font-medium text-charcoal">{lead}</span>{" "}
        <span className="font-medium text-[#8e8e8e]">{text}</span>
      </p>
    </div>
  );
}
