import { B2BCategoryTile } from "./B2BCategoryTile";

export interface B2BBrowseByCategoryItem {
  label: string;
  image?: string;
}

export interface B2BBrowseByCategoryProps {
  /** Category labels, or labels paired with a tile photograph. */
  categories: (string | B2BBrowseByCategoryItem)[];
  /** Alignment of each tile label. */
  labelAlign?: "start" | "center";
  viewport?: "desktop" | "mobile";
  className?: string;
}

/**
 * Category discovery section built from Category Tiles (Figma "Browse by
 * Category", node 22:473 — Version=Default, Viewport=Desktop/Mobile, both
 * Status=Live). Used for browsing the collection by product type; maintain
 * consistent category naming with the catalog taxonomy.
 *
 * Desktop centers an eyebrow + title above an even row of tiles. Mobile
 * left-aligns the heading above a horizontally scrolling tile row.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:629.
 */
export function B2BBrowseByCategory({
  categories,
  labelAlign = "start",
  viewport = "desktop",
  className = "",
}: B2BBrowseByCategoryProps) {
  const isMobile = viewport === "mobile";
  const items = categories.map((c) => (typeof c === "string" ? { label: c } : c));

  if (isMobile) {
    return (
      <div className={`flex w-full max-w-[390px] flex-col gap-5 pt-10 ${className}`}>
        <div className="flex flex-col gap-1.5 px-5">
          <p className="text-xs font-semibold uppercase tracking-wide-ui text-[#8e8e8e]">Our collection</p>
          <h2 className="font-display text-2xl text-charcoal">Browse by Category</h2>
        </div>
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-5 pl-5">
          {items.map((c) => (
            <div key={c.label} className="w-[167px] shrink-0">
              <B2BCategoryTile label={c.label} image={c.image} labelAlign={labelAlign} size="sm" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`flex w-full flex-col gap-5 px-[75px] py-10 ${className}`}>
      <div className="flex flex-col items-center gap-2.5 text-center">
        <p className="text-base font-semibold uppercase tracking-wide-ui leading-5 text-charcoal">Our collection</p>
        <h2 className="font-display text-[38px] leading-[42px] text-charcoal">Browse by category</h2>
      </div>
      <div className="flex gap-2.5">
        {items.map((c) => (
          <div key={c.label} className="flex-1">
            <B2BCategoryTile label={c.label} image={c.image} labelAlign={labelAlign} size="lg" />
          </div>
        ))}
      </div>
    </div>
  );
}
