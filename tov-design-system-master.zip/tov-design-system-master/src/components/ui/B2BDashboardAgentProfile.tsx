/**
 * TOV B2B Dashboard / Agent Profile — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:776, Dashboard page, Organisms
 * section. A wide (1054px) support-agent card on the Support page: a Large
 * Avatar, a serif-display name, an "Online & available" status line, three
 * Dashboard/Contact Row instances (phone, email, availability) and a pair
 * of Email Now / Call Now actions.
 */
function PhoneIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <path d="M5 4h3.5l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5l1.5-2 4 1.5V19a2 2 0 0 1-2 2C10.6 21 3 13.4 3 6a2 2 0 0 1 2-2Z" />
    </svg>
  );
}

function MailIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <rect x="3.5" y="5.5" width="17" height="13" rx="1.5" />
      <path d="M4.5 7 12 13l7.5-6" />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="size-full" aria-hidden>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  );
}

const CONTACT_ROWS = [
  { label: "Direct Phone", value: "(800) 555-8392", icon: <PhoneIcon /> },
  { label: "Direct Email", value: "s.mitchell@tovprofessional.com", icon: <MailIcon /> },
  { label: "Availability", value: "Mon–Fri, 9:00 AM – 6:00 PM EST", icon: <ClockIcon /> },
];

export function B2BDashboardAgentProfile({
  name = "Sarah Mitchell",
  className = "",
}: {
  name?: string;
  className?: string;
}) {
  return (
    <div className={`flex w-[1054px] items-start gap-6 font-sans ${className}`}>
      <div className="flex flex-1 items-center gap-6">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/b2b/dashboard/avatar-large.png"
          alt={name}
          className="size-[110px] shrink-0 rounded-[55px] object-cover"
        />
        <div className="flex flex-col items-start gap-[6px]">
          <span className="whitespace-nowrap font-display text-[22px] text-charcoal">{name}</span>
          <span className="whitespace-nowrap text-[13px] font-semibold text-[#8e8e8e]">Your Dedicated Agent</span>
          <div className="flex items-center gap-[6px]">
            <span className="size-[6px] rounded-full bg-[#2aa399]" />
            <span className="whitespace-nowrap text-[11px] font-medium text-[#2aa399]">Online &amp; available</span>
          </div>
        </div>
      </div>
      <div className="flex flex-1 flex-col items-start gap-4">
        {CONTACT_ROWS.map((row) => (
          <div key={row.label} className="flex w-full items-center gap-4">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-[8px] bg-cream-100">
              <span className="size-[18px] text-charcoal">{row.icon}</span>
            </span>
            <div className="flex min-w-0 flex-1 flex-col gap-[2px]">
              <span className="whitespace-nowrap text-[11px] font-bold uppercase tracking-wide-ui text-[#8e8e8e]">
                {row.label}
              </span>
              <span className="whitespace-nowrap text-[15px] font-semibold text-charcoal">{row.value}</span>
            </div>
          </div>
        ))}
        <div className="flex w-full gap-2">
          <button className="flex-1 rounded-pill bg-primary px-6 py-3 text-xs font-bold tracking-wide-ui text-white">
            Email Now
          </button>
          <button className="flex-1 rounded-pill border-[1.5px] border-primary px-6 py-3 text-sm font-bold uppercase tracking-wide-ui text-primary">
            Call Now
          </button>
        </div>
      </div>
    </div>
  );
}
