/**
 * The PDP "Price" component from the PDP Design System file (fileKey
 * ySZYmjbO2Wck8u1JGAtI5J, node 755:8551) — price on the left, a single
 * star + numeric rating + review count on the right. One universal layout
 * across all devices; the source frame's Affirm/financing, shipping-message,
 * and SKU content is stale/hidden and not part of the real component.
 * Distinct from the generic <Price /> atom (still used for PLP/cart).
 */
export interface PDPPriceProps {
  amount: number;
  rating: number;
  reviewCount: number;
  /** Pre-sale price. When set, `amount` is the sale price: the original is struck through and the sale price takes the brand accent. */
  originalAmount?: number;
}

export function PDPPrice({ amount, rating, reviewCount, originalAmount }: PDPPriceProps) {
  return (
    <div className="flex items-center justify-between gap-4 font-sans">
      {originalAmount != null ? (
        <span className="flex items-center gap-2.5 text-lg leading-[19px]">
          <span className="font-bold text-primary">${amount.toLocaleString()}</span>
          <span className="font-normal text-[#bbbbbb] line-through">${originalAmount.toLocaleString()}</span>
        </span>
      ) : (
        <span className="text-lg leading-[21px] font-bold text-ink">${amount.toLocaleString()}</span>
      )}
      <div className="flex items-center gap-[5px] rounded-[4px] bg-primary/10 px-3 py-1.5">
        <span className="flex items-center gap-px">
          <svg viewBox="0 0 20 20" className="w-2.5 h-2.5 fill-primary shrink-0">
            <path d="M10 1.5l2.6 5.6 6.1.6-4.6 4.1 1.3 6-5.4-3.2-5.4 3.2 1.3-6-4.6-4.1 6.1-.6z" />
          </svg>
          <span className="text-xs font-bold text-primary">{rating.toFixed(1)}</span>
        </span>
        <span className="text-xs text-primary underline">
          {reviewCount} review{reviewCount === 1 ? "" : "s"}
        </span>
      </div>
    </div>
  );
}
