/**
 * PLP Root Category Hero (fileKey jDOs1dFChECKIYdAyPUkav, "💠Components"
 * page, "Product Display" section, node `8:1265`) — the header shown at
 * the top of a root category page: breadcrumb, display-font title, a
 * placeholder sub-heading, and a horizontally-scrollable row of
 * sub-category cards (image + bold label). Real 2-variant set: Desktop
 * (`8:1264`, 1338×392) and Mobile (`8:1266`, 375×237).
 *
 * The sub-heading text is literally "B1 - Sub heading 80–120 characters"
 * in the source — a content-authoring placeholder describing the copy
 * length to write, not real copy — reproduced verbatim rather than
 * invented, same as "Product name"/"$0000.00" elsewhere in this file.
 */
const CATEGORIES = ["Category", "Category", "Category", "Category", "Category", "Category"];

export function PLPCategoryHeroDesktop() {
  return (
    <div className="w-full font-sans flex flex-col gap-5 overflow-x-auto">
      <div className="min-w-[1338px] flex flex-col gap-5">
        <div className="flex items-center gap-1 text-sm text-charcoal">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/home.svg" alt="" className="w-4 h-4" />
          <span>|</span>
          <span>Root Category</span>
        </div>
        <div className="flex flex-col gap-2.5">
          <h1 className="font-display text-[46px] leading-[50px] text-charcoal">Root Category</h1>
          <p className="text-lg leading-[27px] text-ink">B1 - Sub heading 80–120 characters</p>
        </div>
        <div className="flex gap-grid-gutter-sm">
          {CATEGORIES.map((label, i) => (
            <div key={i} className="w-[250px] shrink-0 flex flex-col gap-2.5">
              <div className="bg-image-placeholder rounded-2xl aspect-square" />
              <p className="text-lg font-bold text-[#333333] uppercase tracking-wide-ui">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function PLPCategoryHeroMobile() {
  return (
    <div className="w-full max-w-sm font-sans flex flex-col gap-4">
      <div className="flex items-center gap-1 text-xs text-charcoal px-page-margin-mobile">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icons/home.svg" alt="" className="w-3.5 h-3.5" />
        <span>|</span>
        <span>Root Category</span>
      </div>
      <div className="flex flex-col gap-2 px-page-margin-mobile">
        <h1 className="font-display text-3xl text-charcoal">Root Category</h1>
        <p className="text-sm leading-[21px] text-ink">B1 - Sub heading 80–120 characters</p>
      </div>
      <div className="flex gap-grid-gutter-sm overflow-x-auto px-grid-margin">
        {CATEGORIES.map((label, i) => (
          <div key={i} className="w-[140px] shrink-0 flex flex-col gap-2">
            <div className="bg-image-placeholder rounded-2xl aspect-square" />
            <p className="text-sm font-bold text-[#333333] uppercase tracking-wide-ui">{label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
