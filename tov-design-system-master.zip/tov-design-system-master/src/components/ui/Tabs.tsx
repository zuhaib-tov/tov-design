"use client";

import { ReactNode, useState } from "react";

export interface TabItem {
  key: string;
  label: string;
  content: ReactNode;
}

export function Tabs({ items, defaultKey }: { items: TabItem[]; defaultKey?: string }) {
  const [active, setActive] = useState(defaultKey ?? items[0]?.key);
  const activeItem = items.find((i) => i.key === active);

  return (
    <div>
      <div role="tablist" className="flex gap-6 border-b border-neutral-300">
        {items.map((item) => (
          <button
            key={item.key}
            role="tab"
            aria-selected={active === item.key}
            onClick={() => setActive(item.key)}
            className={`pb-3 text-xs font-semibold uppercase tracking-wide-ui border-b-2 -mb-px transition-colors ${
              active === item.key
                ? "border-primary text-primary-dark"
                : "border-transparent text-ink-muted hover:text-ink"
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
      <div role="tabpanel" className="pt-4 text-sm text-ink">
        {activeItem?.content}
      </div>
    </div>
  );
}
