/**
 * TOV B2B Dashboard / Account Rep Card — Figma "TOV26 - B2B - Design system"
 * (fileKey CGe5J4j6AI5uus5G2f8iqh), node 47:739, Dashboard page, Organisms
 * section. A 515px card introducing the buyer's assigned account rep: a
 * title over a cream Profile Box — Avatar, name, a rose role line, a
 * divider, two contact lines, and a full-width "Contact Rep" brand button.
 */
export function B2BDashboardAccountRepCard({
  repName = "Quinn Parker",
  repTitle = "Senior Account Manager",
  email = "quinn.parker@tovprofessional.com",
  phone = "(212) 555-0190 ext. 412",
  className = "",
}: {
  repName?: string;
  repTitle?: string;
  email?: string;
  phone?: string;
  className?: string;
}) {
  return (
    <div className={`flex w-[515px] flex-col items-start gap-5 rounded-[12px] border border-[#e0e0e0] bg-white p-6 font-sans ${className}`}>
      <span className="text-base font-bold text-charcoal">Account Representative</span>
      <div className="flex w-full flex-col items-start gap-5 rounded-[12px] bg-cream-100 p-5">
        <div className="flex items-center gap-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/b2b/dashboard/avatar-small.png"
            alt={repName}
            className="size-14 shrink-0 rounded-[20px] object-cover"
          />
          <div className="flex flex-col gap-1">
            <span className="whitespace-nowrap text-lg font-bold text-charcoal">{repName}</span>
            <span className="whitespace-nowrap text-[13px] font-medium text-primary">{repTitle}</span>
          </div>
        </div>
        <div className="h-px w-full bg-[#e5ddd5]" />
        <div className="flex w-full flex-col gap-2 text-sm text-charcoal">
          <span className="whitespace-nowrap">{email}</span>
          <span className="whitespace-nowrap">{phone}</span>
        </div>
        <button className="w-full rounded-pill bg-primary px-6 py-3 text-xs font-bold tracking-wide-ui text-white">
          Contact Rep
        </button>
      </div>
    </div>
  );
}
