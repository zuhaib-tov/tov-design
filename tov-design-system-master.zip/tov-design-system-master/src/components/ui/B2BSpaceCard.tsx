/**
 * Image-led use-case card such as Restaurants & Bars (Figma "Space Card",
 * node 8:36 — Version=Default, Viewport=Desktop/Mobile, both Status=Live).
 * Used to introduce spaces or project applications with a clear View All
 * destination.
 *
 * Structurally distinct from Category Tile: the image sits in its own
 * rounded frame above the text block, rather than the text overlaying a
 * full-bleed image.
 *
 * Source: TOV26 - B2B - Design system (CGe5J4j6AI5uus5G2f8iqh), node 29:621.
 */
export interface B2BSpaceCardProps {
  title: string;
  linkLabel?: string;
  /** Photograph in the image frame. Falls back to the image placeholder. */
  image?: string;
  viewport?: "desktop" | "mobile";
  className?: string;
}

export function B2BSpaceCard({
  title,
  linkLabel = "View All",
  image,
  viewport = "desktop",
  className = "",
}: B2BSpaceCardProps) {
  const isMobile = viewport === "mobile";
  return (
    <div className={`flex flex-col ${isMobile ? "w-[171px] gap-2" : "w-[315px] gap-2.5"} ${className}`}>
      <div
        className={`${image ? "bg-charcoal" : "bg-image-placeholder"} relative w-full overflow-hidden ${isMobile ? "aspect-[171/167] rounded-md" : "aspect-[315/376] rounded-[19px]"}`}
      >
        {image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
        )}
      </div>
      <div className="flex flex-col">
        <h3 className={`font-display text-charcoal ${isMobile ? "text-lg" : "text-[22px] leading-[25px]"}`}>{title}</h3>
        <a href="#" className={`w-fit text-sm font-semibold uppercase tracking-wide-ui text-primary ${image ? "underline" : ""} ${isMobile ? "" : "leading-[19px]"}`}>
          {linkLabel}
        </a>
      </div>
    </div>
  );
}
