import { PDPFittedImage, PDP_LOGO_ART } from "./PDPFittedImage";

/**
 * The PDP "BNPL" component (fileKey ySZYmjbO2Wck8u1JGAtI5J, node 838:8555)
 * — a Version=/Viewport=/Status= set with exactly 2 Live variants (Mobile,
 * Desktop), both included. Same content and layout; Desktop is simply
 * larger (14px copy vs. 12px). The financing line ("As low as … | Learn
 * more") stays on one line and both rows are centered.
 *
 * Klarna, Afterpay and Affirm are extracted logo images
 * (public/brand/payment/); Shop Pay is an extracted vector (bolt + wordmark,
 * #5433EB). Every logo sits in the same container and fills the same share of
 * it, so the four marks read as one size.
 */
export interface PDPBnplProps {
  monthlyPrice?: string;
  compact?: boolean;
}

const LOGOS = [
  { key: "klarna", src: "/brand/payment/klarna.png", alt: "Klarna" },
  { key: "afterpay", src: "/brand/payment/afterpay.png", alt: "Afterpay" },
  { key: "shop-pay", src: "/brand/payment/shop-pay.svg", alt: "Shop Pay" },
  { key: "affirm", src: "/brand/payment/affirm.png", alt: "Affirm" },
] as const;

/** Share of the logo container that every logo's artwork fills. */
const LOGO_FILL = 0.85;

export function PDPBnpl({ monthlyPrice = "$188.85", compact = false }: PDPBnplProps) {
  const textSize = compact ? "text-xs leading-[18px]" : "text-sm leading-[21px]";
  const learnMoreSize = compact ? "text-[10px] leading-[15px]" : "text-sm leading-[21px]";
  const logoBox: [number, number] = compact ? [40, 14] : [48, 17];

  return (
    <div className="flex w-full flex-col items-center gap-2 font-sans text-charcoal">
      <div className="flex items-center gap-2.5 whitespace-nowrap">
        <p className={textSize}>As low as {monthlyPrice}/month with</p>
        <span className="h-2.5 w-px shrink-0 bg-[#bbbbbb]" />
        <a href="#" className={`${learnMoreSize} underline`}>Learn more</a>
      </div>
      <div className={`flex items-center ${compact ? "gap-[11px]" : "gap-[13px]"}`}>
        {LOGOS.map((l) => (
          <PDPFittedImage key={l.key} src={l.src} alt={l.alt} box={logoBox} fill={LOGO_FILL} {...PDP_LOGO_ART[l.key]} />
        ))}
      </div>
    </div>
  );
}
