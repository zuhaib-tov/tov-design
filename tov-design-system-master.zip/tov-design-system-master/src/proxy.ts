import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { GATE_COOKIE, gateToken, safeEqual } from "@/lib/gate";

/**
 * Password gate for the whole design system. Every page, API route and file in
 * /public requires the shared SITE_PASSWORD cookie except the login page, its
 * handler, Next's own build assets, and the Figma webhook (which authenticates
 * with its own passcode).
 */
export async function proxy(request: NextRequest) {
  const password = process.env.SITE_PASSWORD;

  if (!password) {
    if (process.env.NODE_ENV === "production") {
      return new NextResponse("This site is locked: SITE_PASSWORD is not configured.", { status: 503 });
    }
    return NextResponse.next();
  }

  const cookie = request.cookies.get(GATE_COOKIE)?.value;
  if (cookie && safeEqual(cookie, await gateToken(password))) {
    return NextResponse.next();
  }

  const { pathname, search } = request.nextUrl;
  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const login = new URL("/gate", request.url);
  login.searchParams.set("next", pathname + search);
  return NextResponse.redirect(login);
}

export const config = {
  matcher: ["/((?!gate|api/gate|api/figma-webhook|api/figma-watch/cron|_next/static|_next/image|favicon.ico).*)"],
};
